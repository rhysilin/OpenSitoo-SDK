# 独立能力开发工具包

R07 Alpha总验收记录：仅核对开发/测试支持范围，不改变公共契约。

E3-R06独立多应用开发与CI。

E3-R04图片服务及原任务产物交付。

E3-R03产品宿主服务交付。

E3-R02原请求账本交付。

E3-R01持久引用交付。

第二十四批固定开发客户端确认与核对。

第二十三批签名宿主服务 · [服务适配](./public-services.md)。

第二十二批公共服务端口 · [可信服务适配](./public-services.md)。已安装服务声明与精确可信实现已接入，生产服务仍待后续。

第二十一批独立项目创建与E3收口 · 从零开发手册。优先补生态通用服务契约，现有应用用于兼容回归。

第二十批设计方案共享校验：独立业务示例复用原应用源码；旧应用收费推理/生图仍待迁移。

维护日期：2026-10-10。开发工具包 0.36.0（宿主 0.20.0、SDK0.0.11、references0.5.1），Node 24 参考宿主，未发布公共 npm。只绑定本机 loopback，不依赖 Desktop/Pi/Electron。模板和 HTTP 路由用于本地协议验收，不是生产网关。结构化请求助手与兼容发布模式见R05记录。

在平台仓库运行 `node scripts/capability-kit.mjs`，生成 `release/capability-kit/`。把整个目录复制到仓库外，保留 sitoo-capability.mjs、worker.mjs、quickjs.wasm、browser-client.mjs、conversation-browser.mjs、conversation-client.mjs、protocol、template 和许可文件。生成物无需平台源码、workspace 链接或 node_modules。

## 从零运行

```powershell
node sitoo-capability.mjs init C:/dev/my-capabilities
node sitoo-capability.mjs serve C:/dev/my-capabilities/host.json C:/dev/my-capabilities/data
```

init 只创建不存在的目录，不覆盖已有项目。生成独立能力源文件、可信 host.json、两个应用及各自随机 token.txt，并为应用复制零依赖的公开 `@sitoo/capability-protocol` JS 与类型分发。原模板中的 GENERATED 只是占位符，必须通过 init 初始化。Node 进程启动返回一行 `{url,protocolVersion:1}`，不输出 token。宿主持续运行直到 Ctrl+C，退出会持久化未知状态。

在另一终端，使用输出中的 URL，例如：

```powershell
node C:/dev/my-capabilities/app-a/client.mjs http://127.0.0.1:12345 submit " hello "
node C:/dev/my-capabilities/app-b/client.mjs http://127.0.0.1:12345 submit "world"
node C:/dev/my-capabilities/app-a/client.mjs http://127.0.0.1:12345 list
node C:/dev/my-capabilities/app-a/client.mjs http://127.0.0.1:12345 get <taskId>
node C:/dev/my-capabilities/app-a/client.mjs http://127.0.0.1:12345 cancel <taskId>
```

submit 可在文字后增加原 requestId；重复请求需保持全部输入不变，app-b 的 childRequestId 从父 ID 确定性派生。输出为 ProtocolValidation，ok 不代表任务已经完成，需读取 value.status/result。调用脚本退出不结束宿主；再次启动脚本可查询原任务。

## 项目与身份

`.guest` 文件是异步函数体，得到 input 和授权的 invoke，无 Node、文件、网络或模型凭据。normalize 规范文本；compose 通过受限桥调用同一 normalize，展示跨能力委托。应用只导入公开协议包并调用参考 HTTP 端口，不导入宿主源码/SDK 私有 Host。

host.json 格式版本 1：capabilities 数组（1–32 个 declaration/source/sourceSha256），consumers 数组（1–32 个 token/policy，可选 references），以及可选 fixtureConfirmationToken。declaration、policy 使用 Broker 真实契约；environment 强制 development。token 为唯一 64 位小写十六进制随机字符串。绑定的租户、安装、消费应用、入口和授权由宿主配置决定，HTTP body 不能覆盖。

能力源必须在 host.json 所在目录内，含 realpath 检查，不能通过 symlink 越界；每个文件和配置最多 64 KiB。sourceSha256 校验原文件；模板中的 binding.sha256 暂用该源摘要作为开发绑定身份，不能当成完整包签名或供应链证明。编辑源文件后由可信开发者更新 sourceSha256、绑定版本/摘要和消费者绑定，再重启。旧任务不会自动迁移或换版本重提。

host.json/token.txt 视为本地凭据，不能提交或发送给他人。Node 文件 mode 在 Windows 不等于完整 ACL；这个开发宿主没有生产登录、凭据轮换或账户系统。data/tasks.sqlite 为原任务 ledger，diagnostics.jsonl 只有关联元数据，不记录业务输入输出或 token；文件保护、清理与容量由开发者维护。

## 参考传输契约

消费 API 要求 `Authorization: Bearer <token>`，Host 必须等于启动 URL 的主机端口；不开放浏览器 CORS。0.7.0 固定容器 `/development` 与 `/development/client.mjs` 无令牌，允许同源 GET；v3 资源/任务允许精确宿主 Origin，application 任务校验应用摘要，0.9.0 conversation 新任务校验完整计划摘要，原对话任务查询不要求当前摘要，null/外部 Origin 仍拒绝。完整约束见[页面与任务桥](./pages.md)。仅监听 `127.0.0.1` 随机端口，无公网绑定选项。请求体最多 64 KiB，header/request timeout 5000ms，连接数最多 32。

| 方法与路由                    | 输入与返回                                                                            |
| ----------------------------- | ------------------------------------------------------------------------------------- |
| POST /v1/tasks                | CapabilityRequest JSON；成功 202，ProtocolValidation&lt;DurableTask&gt;；原 ID 去重。 |
| GET /v1/tasks                 | 可选 limit/offset，遵循任务服务 1–100/非负整数；返回当前消费身份的快照数组。          |
| GET /v1/application           | 0.6.0 新增，仅 v3 持久授权 application 入口；读取自己的已安装应用资源 JSON，200/403。 |
| GET /v1/tasks/:taskId         | 查询原任务快照；不属于调用者或不存在为 403 FORBIDDEN。                                |
| POST /v1/tasks/:taskId/cancel | 取消规则遵循持久任务；本地中断不表示上游回滚。                                        |

成功查询/取消 200；非法身份 401、Origin/Host 拒绝 403、业务/结构错误 400、未实现路由 404、宿主存储故障 503。错误消息固定，不回传路径/堆栈；流式超限可断开连接。本参考传输不提供 register、签发会话或管理配置端口。0.2.0 新增 POST /v1/tasks/:taskId/reconcile（200/400，query-only）与 GET/POST /v1/confirmations/:taskId（200/400）。确认路由同时要求独立 X-Fixture-Confirmation，缺失/错误为 403；GET 返回原计划，POST 仅接 {revision}。只在显式 fixture 配置中启用本地模拟模型，默认 init 仍拒绝副作用。

后台任务、unknown 保留与取消规则使用真实持久任务模块。没有登录用户的真实服务、收费授权、生产部署或浏览器入口；禁止把开发 token 配置当成生产认证方案。生产路由与 E2 包格式另外版本化。

## 受控引用和模拟确认

使用 `node sitoo-capability.mjs init-fixtures <新目录>` 创建独立操作者 confirmation-token.txt 与各消费应用 references.json。参考客户端增加 `reference`、`model <prompt>` 和 `reconcile <taskId>`；模型请求先进入 needs-approval。操作者使用 `plan <url> <project> <app> <taskId>` 查看原请求，再显式 `confirm <url> <project> <app> <taskId> <revision>`。应用 token 不能自行批准。模拟 prompt `__unknown__` 在记账后丢失响应；重启后 reconcile 查询原账本恢复，重复请求不会再次执行。

references 为 {textId,modelId,text}；fixtureConfirmationToken 为与消费者 token 不同的唯一 64 位小写十六进制字符串。引用、操作方法、权限、预算和局限见确认与引用参考。fixture 身份摘要只是开发绑定；模拟账本不是生产费用证明，操作者凭据与本地项目目录也不构成生产隔离。

## 验收

`node scripts/verify-capability-kit.mjs` 在系统临时目录复制工具包、创建两个应用、启动独立子进程宿主、发请求并检查隔离/去重/诊断/崩溃恢复。外部子进程 cwd 和依赖均在复制目录，清除 NODE_PATH/NODE_OPTIONS，不借用平台源码或 node_modules。23 项验收包含无费用能力与本地模拟模型账本，没有真实模型或外部网络请求。

返回文档总目录 · 当前状态 · 对应交付记录

0.3.0 新增 InstalledDevelopmentHostConfig（host.json version 2）：installationPath/trustPath/consumers，运行已安装精确能力、多版本共存、先编译再开放服务、任务持久租约和动态信任复核。v1 模板及 HTTP 路由兼容，v2 不启用收费 fixture。字段、路径/身份/权限约束、兼容迁移见[执行与租约参考](./execution.md)。

[持久授权与运行门禁](./authorizations.md)（包工具 0.8.0、开发宿主 0.5.0；可信管理与 opt-in v3）。

[显式业务健康检查](./health.md)（开发宿主/工具包 0.5.0，真实任务与预期结果比较；不是自动升级批准）。

三发布者共享运行参考提供仓库外独立构建与 CLI 消费端的完整重复执行流程；完整应用共享与故障验收已通过 E2 独立开发门禁。

0.6.0 新增已安装应用读取；响应与读取时签名/授权/完整计划复核见[应用发布物手册](./applications.md)，验证见 E3 第一批记录。0.7.0 新增[隔离页面与通用任务桥](./pages.md)，见E3 第二批记录；应用页面只经原任务服务运行已授权能力，对话规划见下方第三批；浏览器对话见下方第四批；SDK 与 Desktop 接入待后续。

[对话规划与无费用夹具](./conversation.md) · 第三批证据。普通 serve 保持确定性任务；显式 serve-conversation-fixture 才启用本地规划，客户端 conversation-client.mjs 保存提案后执行原任务。

0.9.0 增加可信 `/development/conversation` 和 `conversation-browser.mjs` 随包脚本，独立令牌、提案预览/显式提交/原任务查询，见第四批证据。

真实模型适配与确定性回退（0.10.0）：可信本机 New API、显式模型命令、手动提案与原任务链路。

[能力 SDK 与 Desktop 开发入口](./capability-sdk.md) · 第六批证据：SDK/Desktop 0.0.9、工具包 0.11.0；产品接入仍待后续。

0.14.0 同步能力包模块 0.10.0 的只读存储选项及产品账户手册；SDK 0.0.9、宿主 0.10.0 不变。产品普通窗口新增只读安装状态，见第七批证据。

工具包 0.14.0 同步能力包模块 0.11.0 的只读发布存储与[产品市场管理手册](./capability-sdk.md)；SDK 0.0.9、独立宿主 0.10.0 不变，产品 Desktop 0.0.11 的首次安装/授权管理见第八批。

工具包 0.14.0 同步[产品共享业务页面与原任务](./capability-sdk.md)文档，Desktop 0.0.12 构建从原工具包复制独立宿主/Worker/WASM/浏览器容器，宿主 0.11.0 增加页面历史任务只读门禁，SDK 0.0.9/wire 不变；不启用模型或生产认证。

工具包 0.15.0 同步[产品对话工具手册](./capability-sdk.md)；Desktop 0.0.13 复用原宿主 0.11.0 与两个独立入口，不新增 HTTP、SDK 或数据库 schema。产品入口本批未启用模型。

工具包 0.16.0 同步[Pi 共享工具接入手册](./capability-sdk.md)。独立 Node 工具仍不依赖 Pi/Electron；Desktop 0.0.14 的 Pi 适配属于产品内部桥，原宿主 0.11.0/SDK 0.0.9 与传输不变。

工具包 0.17.0 同步[产品生命周期手册](./capability-sdk.md)与第十二批验收；宿主 0.11.0、SDK 0.0.9 不变。本次工具包版本仅同步文档，产品入口由 Desktop 0.0.15 提供，独立宿主没有引入 Electron/Pi。

工具包 0.18.0 分发 product-reference/publisher.mjs 和 fixed-client.md，对应[固定客户端手册](./fixed-client.md)与第十三批证据。Desktop 固定0.0.15，业务更新不重建客户端；原宿主/SDK/便携包CLI保持版本与契约，公开工具独立发布，当前仍需可信操作者提供开发目录/信任。

工具包 0.19.0 同步[任务手册](./tasks.md)、[产品历史查询](./capability-sdk.md)和第十四批证据。本次工具包仅同步文档，原宿主 0.11.0/SDK 0.0.9 不变；产品入口由 Desktop 0.0.16 提供，没有新增独立宿主恢复执行命令。

工具包0.20.0同步[SDK/Desktop手册](./capability-sdk.md)与第十五批证据。仅更新文档，Node宿主0.11.0、SDK0.0.9和独立包CLI0.10.0不变；Pi候选和验收脚本不随工具包自动安装，没有新增Pi更新命令。

工具包0.21.0仅同步[SDK/Desktop手册](./capability-sdk.md)与第十六批证据。Node宿主/SDK/CLI不变，没有Pi自动安装或更新入口。

## 原上游暂不可查询与持久化门禁（工具包0.22.0）

同一仓库外进程验收新增：原模拟上游记录暂不可匹配时，reconcile 返回 RESULT_UNKNOWN，任务快照不变；恢复原账本后仅查询同一原请求，核对 completed，宿主再次强退重启与重复 reconcile/去重提交仍返回完全相同结果。模拟账本总数始终为2，不产生第三次模拟收费。未知结果不可猜测成功；真实收费上游、产品查询适配器仍待接入。宿主、SDK、路由和schema未变化，详见第十七批交付。

## 父进程管道（宿主0.14.0、工具包0.23.0）

可信启动器可运行 `node sitoo-capability.mjs serve <host.json> <data-directory> --parent-pipe`（serve-conversation-fixture 同样支持）。必须提供保持打开的 stdin 管道；EOF/管道错误触发原 close，正常close将原 queued/running 持久化unknown、保留pin，再关闭HTTP连接并退出；强退未完成写回时，只读原记录保持running/queued，显式重开原宿主恢复unknown。stdin字节被丢弃，不能承载身份、命令或确认。启动期间已断开则关闭刚创建宿主，不输出ready；启动失败关闭stdin并非零退出。原不带参数serve以及serve-conversation-model行为不变。仅可信进程生命期，不是应用IPC/生产认证，也不能撤回已发生副作用。验收见第十八批交付。

## 统一CI门禁（工具包0.24.0）

`node scripts/capability-ci.mjs` 或 `pnpm capability:ci` 运行固定Windows/Node24无费用门禁，源码重建工具包后执行仓库外host、installed与原生SQLite容量组合；失败即停止后续门禁，并留下失败报告和当前日志。命令属于仓库运维脚本，未随工具包分发，独立消费者继续使用原CLI。详见CI手册与第十九批交付。

工具包0.25.0携带design-studio-shared/payload、publisher.mjs与README。构建时从原应用业务源码生成；开发者可在仓库外签名发布。操作见共享校验手册。

## 从零创建共享生态项目（工具包0.28.0）

`node sitoo-project.mjs create <new-directory>`生成三个独立项目。创建不授权或安装；签名、发布、安装与入口授权仍各自执行。使用见接入教程，证据见第二十一批。

0.28.0随包携带verify-installed-services.mjs与扩展service-host.mjs，签名原生声明与可信Node参数见[服务手册](./public-services.md)和第二十三批。默认serve没有原生服务闭包；不会从包或host.json加载插件。独立验收同时复制包CLI0.10.0，保持原SDK/HTTP确认契约。

## 原请求持久账本（工具包0.32.0、宿主0.17.0）

service-host.mjs新增可信ModelRequestLedger/createDurableModelProvider；verify-model-ledger.mjs随包可在独立目录运行，另用SQLite上游进程、实际SIGKILL宿主并重开原库。只核对原请求，无证据保留unknown/pin。完整可信参数与限制见[服务手册](./public-services.md)，证据见R02交付。默认CLI不自动选择Provider或创建此库；SDK与原任务路由保持。

## 多应用仓库（0.35.0）

公开分发包含monorepo-template/init.mjs、product-reference发布示例和verify-request-services.mjs。初始化已存在目录时仅新增apps、capabilities、tooling、docs、.ci、vendor和.local，同名内容拒绝覆盖。应用/共享能力各自版本独立；vendor固定公开SDK/CLI，不包含账户、密钥或平台源码。构建与签名发布、安装/授权分别执行。接入步骤。

0.36.0仅新增可信已签名v3的test环境；v1/v2和production边界保持，见目录与测试接入。
