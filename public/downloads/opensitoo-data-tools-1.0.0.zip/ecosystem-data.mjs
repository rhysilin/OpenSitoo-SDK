// packages/ecosystem-data/cli.mjs
import { readFileSync as readFileSync2 } from "node:fs";

// packages/ecosystem-data/recovery.mjs
import { DatabaseSync } from "node:sqlite";
import { createHash, createPrivateKey, createPublicKey, randomUUID } from "node:crypto";
import {
  copyFileSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  realpathSync,
  renameSync,
  rmSync,
  writeFileSync,
  openSync,
  closeSync,
  fsyncSync
} from "node:fs";
import { dirname, isAbsolute, join, relative, resolve } from "node:path";
var digest = (value) => createHash("sha256").update(value).digest("hex");
var fail = (code) => {
  throw new Error(code);
};
var json = (file) => JSON.parse(readFileSync(file, "utf8"));
var inside = (root, file) => {
  const p = relative(root, file);
  return p !== ".." && !p.startsWith("..\\") && !p.startsWith("../") && !isAbsolute(p);
};
var id = (value) => typeof value === "string" && /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,95}$/.test(value);
function safeFile(root, name) {
  if (typeof name !== "string" || !name || name.includes("\\") || name.split("/").some((s) => !id(s)))
    fail("INVALID_PATH");
  const file = join(root, name);
  if (!inside(root, file)) fail("INVALID_PATH");
  let part = root;
  for (const segment of name.split("/")) {
    part = join(part, segment);
    if (lstatSync(part).isSymbolicLink()) fail("SYMLINK_DENIED");
  }
  if (!lstatSync(file).isFile()) fail("NOT_A_FILE");
  return file;
}
function writeDurable(file, data, exclusive = false) {
  const fd = openSync(file, exclusive ? "wx" : "w", 384);
  try {
    writeFileSync(fd, data);
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
}
function createRegistry(file, binding) {
  if (!id(binding)) fail("INVALID_BINDING");
  mkdirSync(dirname(resolve(file)), { recursive: true });
  writeDurable(file, JSON.stringify({ version: 1, binding, revision: 0, deleted: [] }), true);
}
function readRegistry(file, binding) {
  if (lstatSync(file).isSymbolicLink()) fail("SYMLINK_DENIED");
  const registry = json(file);
  if (registry.version !== 1 || registry.binding !== binding || !Number.isSafeInteger(registry.revision) || registry.revision < 0 || !Array.isArray(registry.deleted))
    fail("REGISTRY_REQUIRED");
  if (registry.revision !== registry.deleted.length || new Set(registry.deleted.map((r) => r.owner)).size !== registry.deleted.length || registry.deleted.some((r) => !id(r.owner) || !Number.isSafeInteger(r.at) || r.at < 0))
    fail("REGISTRY_REQUIRED");
  return registry;
}
function registerDeletion(file, binding, owner) {
  if (!id(owner)) fail("INVALID_OWNER");
  const lock = file + ".lock";
  const fd = openSync(lock, "wx");
  try {
    const registry = readRegistry(file, binding);
    if (registry.deleted.some((r) => r.owner === owner)) return registry;
    registry.revision++;
    registry.deleted.push({ owner, at: Date.now() });
    const temporary = file + "." + randomUUID();
    writeDurable(temporary, JSON.stringify(registry));
    renameSync(temporary, file);
    return registry;
  } finally {
    closeSync(fd);
    rmSync(lock);
  }
}
var schemas = {
  installations: [1396918606, [1, 2, 3], "installation_roots"],
  authorizations: [1396916565, [1], "authorizations"],
  releases: [1396920402, [1], "releases"],
  data: [1396917325, [1], "migration_data"],
  references: [null, [1], "capability_references"],
  models: [null, [1], "model_requests"]
};
function inspectDatabase(db, kind, environment) {
  if (db.prepare("PRAGMA integrity_check").get().integrity_check !== "ok" || db.prepare("PRAGMA foreign_key_check").all().length)
    fail("DATABASE_CORRUPT");
  const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map((r) => r.name);
  let version;
  if (kind === "center") {
    if (!tables.includes("schema_version") || !tables.includes("settings"))
      fail("SCHEMA_UNSUPPORTED");
    version = db.prepare("SELECT max(version) AS version FROM schema_version").get().version;
    if (![1, 2, 3, 4, 5, 6, 7].includes(version)) fail("SCHEMA_UNSUPPORTED");
    const stored = db.prepare("SELECT value FROM settings WHERE name='deployment_environment'").get()?.value ?? "development";
    if (stored !== environment) fail("ENVIRONMENT_MISMATCH");
  } else if (kind === "tasks") {
    if (!tables.includes("metadata") || !tables.includes("tasks")) fail("SCHEMA_UNSUPPORTED");
    version = db.prepare("SELECT version FROM metadata").get()?.version;
    if (![1, 2].includes(version) || version === 2 && !tables.includes("task_quota_binding"))
      fail("SCHEMA_UNSUPPORTED");
  } else if (kind === "quota") {
    if (!tables.includes("quota_config") || !tables.includes("reservations"))
      fail("SCHEMA_UNSUPPORTED");
    version = db.prepare("SELECT version FROM quota_config WHERE id=1").get()?.version;
    if (version !== 1) fail("SCHEMA_UNSUPPORTED");
  } else {
    const schema = schemas[kind];
    if (!schema || !tables.includes(schema[2])) fail("SCHEMA_UNSUPPORTED");
    version = db.prepare("PRAGMA user_version").get().user_version;
    if (!schema[1].includes(version) || schema[0] !== null && db.prepare("PRAGMA application_id").get().application_id !== schema[0])
      fail("SCHEMA_UNSUPPORTED");
  }
  return version;
}
function validatePlan(plan) {
  if (plan.version !== 1 || !id(plan.tenant) || !id(plan.binding) || !["development", "test", "production"].includes(plan.environment) || !Array.isArray(plan.resources) || !plan.resources.length || plan.resources.length > 256)
    fail("INVALID_PLAN");
  const seen = /* @__PURE__ */ new Set();
  const paths = /* @__PURE__ */ new Set();
  for (const resource of plan.resources) {
    if (!id(resource.id) || seen.has(resource.id) || !["center", "tasks", "quota", ...Object.keys(schemas), "asset"].includes(resource.kind))
      fail("INVALID_RESOURCE");
    seen.add(resource.id);
    const name = resource.path === void 0 ? resource.file : resolve(resource.path).toLowerCase();
    if (typeof name !== "string" || paths.has(name)) fail("DUPLICATE_RESOURCE");
    paths.add(name);
  }
  if (!Array.isArray(plan.keys) || plan.keys.some(
    (k) => typeof k.id !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(k.id) || typeof k.publicKey !== "string"
  ) || new Set(plan.keys.map((k) => k.id)).size !== plan.keys.length)
    fail("INVALID_KEYS");
}
function verifySigningInventory(db, kind, keys) {
  if (kind !== "center" || !db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='signing_keys'").get())
    return;
  for (const row of db.prepare("SELECT key_id,public_key FROM signing_keys").all()) {
    if (!keys.some((key) => key.id === row.key_id && key.publicKey === row.public_key))
      fail("KEY_INVENTORY_REQUIRED");
  }
}
function backup(plan, output) {
  validatePlan(plan);
  const registry = readRegistry(plan.registry, plan.binding);
  const directory = resolve(output);
  if (existsSync(directory)) fail("TARGET_EXISTS");
  if (plan.resources.some((r) => inside(realpathSync(dirname(resolve(r.path))), directory)))
    fail("TARGET_INSIDE_SOURCE");
  const started = Date.now(), locks = [], stage = directory + ".partial-" + randomUUID();
  try {
    for (const r of plan.resources) {
      const file = realpathSync(resolve(r.path));
      if (lstatSync(resolve(r.path)).isSymbolicLink() || !lstatSync(file).isFile())
        fail("SYMLINK_DENIED");
      if (r.kind !== "asset") {
        const db = new DatabaseSync(file, { timeout: 100 });
        locks.push(db);
        db.exec("BEGIN IMMEDIATE");
        inspectDatabase(db, r.kind, plan.environment);
        verifySigningInventory(db, r.kind, plan.keys);
      } else if (!/^[a-f0-9]{64}$/.test(r.sha256) || digest(readFileSync(file)) !== r.sha256)
        fail("ASSET_NOT_IMMUTABLE");
    }
    mkdirSync(stage, { recursive: false });
    const cutAt = Date.now(), resources = [];
    for (const r of plan.resources) {
      const file = resolve(r.path), name = r.id + (r.kind === "asset" ? ".asset" : ".sqlite"), target = join(stage, name);
      copyFileSync(file, target);
      let schema;
      if (r.kind !== "asset") {
        if (existsSync(file + "-wal")) copyFileSync(file + "-wal", target + "-wal");
        const db = new DatabaseSync(target);
        try {
          schema = inspectDatabase(db, r.kind, plan.environment);
          db.exec("PRAGMA wal_checkpoint(TRUNCATE); PRAGMA journal_mode=DELETE;");
          if (r.kind === "center") db.exec("DELETE FROM sessions;");
        } finally {
          db.close();
        }
        for (const suffix of ["-wal", "-shm"])
          if (existsSync(target + suffix)) rmSync(target + suffix);
      } else if (digest(readFileSync(file)) !== r.sha256) fail("ASSET_CHANGED");
      const fd = openSync(target, "r+");
      try {
        fsyncSync(fd);
      } finally {
        closeSync(fd);
      }
      resources.push({
        id: r.id,
        kind: r.kind,
        file: name,
        schema,
        ...r.kind === "tasks" ? { sourcePath: resolve(r.path) } : {},
        sha256: digest(readFileSync(target)),
        bytes: lstatSync(target).size
      });
    }
    if (readRegistry(plan.registry, plan.binding).revision !== registry.revision)
      fail("REGISTRY_CHANGED");
    const manifest = {
      version: 1,
      tenant: plan.tenant,
      environment: plan.environment,
      binding: plan.binding,
      registryRevision: registry.revision,
      createdAt: cutAt,
      keys: plan.keys,
      resources
    };
    const bytes = JSON.stringify(manifest, null, 2) + "\n";
    writeDurable(join(stage, "manifest.json"), bytes, true);
    renameSync(stage, directory);
    return {
      manifestSha256: digest(bytes),
      cutAt,
      elapsedMs: Date.now() - started,
      resources: resources.length
    };
  } finally {
    for (const db of locks.reverse()) {
      try {
        if (db.isTransaction) db.exec("ROLLBACK");
      } finally {
        db.close();
      }
    }
    if (existsSync(stage)) rmSync(stage, { recursive: true });
  }
}
function restore(bundle, target, policy) {
  const started = Date.now(), source = realpathSync(bundle), output = resolve(target);
  if (existsSync(output)) fail("TARGET_EXISTS");
  if (inside(source, output)) fail("TARGET_INSIDE_SOURCE");
  const bytes = readFileSync(safeFile(source, "manifest.json"));
  if (digest(bytes) !== policy.manifestSha256) fail("MANIFEST_DIGEST_MISMATCH");
  const manifest = JSON.parse(bytes);
  validatePlan({ ...manifest, registry: policy.registry });
  if (manifest.tenant !== policy.tenant || manifest.environment !== policy.environment || manifest.binding !== policy.binding)
    fail("OWNERSHIP_MISMATCH");
  const registry = readRegistry(policy.registry, policy.binding);
  if (registry.revision !== manifest.registryRevision) fail("BACKUP_QUARANTINED_BY_DELETION");
  for (const key of manifest.keys) {
    const file = policy.keyFiles?.[key.id];
    if (!file || createPublicKey(createPrivateKey(readFileSync(file))).export({
      type: "spki",
      format: "pem"
    }) !== key.publicKey)
      fail("KEY_REQUIRED");
  }
  const names = ["manifest.json", ...manifest.resources.map((r) => r.file)].sort();
  if (JSON.stringify(readdirSync(source).sort()) !== JSON.stringify(names))
    fail("FILE_SET_MISMATCH");
  for (const r of manifest.resources) {
    const file = safeFile(source, r.file);
    if (digest(readFileSync(file)) !== r.sha256 || lstatSync(file).size !== r.bytes)
      fail("FILE_DIGEST_MISMATCH");
    if (r.kind !== "asset") {
      const db = new DatabaseSync(file, { readOnly: true });
      try {
        if (inspectDatabase(db, r.kind, policy.environment) !== r.schema)
          fail("SCHEMA_UNSUPPORTED");
        verifySigningInventory(db, r.kind, manifest.keys);
      } finally {
        db.close();
      }
    }
  }
  const stage = output + ".partial-" + randomUUID();
  mkdirSync(stage);
  try {
    for (const r of manifest.resources) copyFileSync(safeFile(source, r.file), join(stage, r.file));
    const restoredReservations = /* @__PURE__ */ new Set();
    for (const r of manifest.resources.filter((r2) => r2.kind === "tasks" && r2.schema === 2)) {
      if (typeof r.sourcePath !== "string" || !isAbsolute(r.sourcePath))
        fail("TASK_SOURCE_REQUIRED");
      const db = new DatabaseSync(join(stage, r.file));
      try {
        const binding = db.prepare("SELECT path,identity FROM task_quota_binding").get();
        const matches = manifest.resources.filter((q) => q.kind === "quota").filter((q) => {
          const quota2 = new DatabaseSync(join(stage, q.file), { readOnly: true });
          try {
            return quota2.prepare("SELECT identity FROM quota_config WHERE id=1").get().identity === binding.identity;
          } finally {
            quota2.close();
          }
        });
        if (matches.length !== 1) fail("QUOTA_BINDING_MISSING");
        const quota = new DatabaseSync(join(stage, matches[0].file));
        try {
          for (const row of db.prepare("SELECT id,scope,data FROM tasks").all()) {
            const record = JSON.parse(row.data), oldId = JSON.stringify([r.sourcePath, row.id]), newId = JSON.stringify([join(output, r.file), row.id]);
            const reservation = quota.prepare("SELECT * FROM reservations WHERE id=?").get(oldId);
            if (!reservation) {
              if (!["completed", "failed", "cancelled"].includes(record.task.status))
                fail("QUOTA_RESERVATION_MISSING");
              continue;
            }
            if (reservation.scope !== row.scope || reservation.tenant !== record.quota?.tenant || reservation.account !== record.quota?.account)
              fail("QUOTA_IDENTITY_MISMATCH");
            quota.prepare("UPDATE reservations SET id=? WHERE id=?").run(newId, oldId);
            restoredReservations.add(matches[0].id + ":" + newId);
          }
        } finally {
          quota.close();
        }
        db.prepare("UPDATE task_quota_binding SET path=?").run(join(output, matches[0].file));
      } finally {
        db.close();
      }
    }
    for (const r of manifest.resources.filter((r2) => r2.kind === "quota")) {
      const quota = new DatabaseSync(join(stage, r.file), { readOnly: true });
      try {
        if (quota.prepare("SELECT id FROM reservations").all().some((row) => !restoredReservations.has(r.id + ":" + row.id)))
          fail("QUOTA_RESOURCE_SET_INCOMPLETE");
      } finally {
        quota.close();
      }
    }
    if (readRegistry(policy.registry, policy.binding).revision !== registry.revision)
      fail("REGISTRY_CHANGED");
    writeDurable(
      join(stage, "restore.json"),
      JSON.stringify({
        manifestSha256: policy.manifestSha256,
        restoredAt: Date.now(),
        registryRevision: registry.revision
      })
    );
    renameSync(stage, output);
    return {
      restored: manifest.resources.length,
      elapsedMs: Date.now() - started,
      snapshotAgeMs: Date.now() - manifest.createdAt
    };
  } finally {
    if (existsSync(stage)) rmSync(stage, { recursive: true });
  }
}
function previewRetention(directory, binding, now = Date.now()) {
  const root = realpathSync(directory), candidates = [];
  for (const name of readdirSync(root)) {
    if (!id(name)) continue;
    const child = join(root, name);
    if (lstatSync(child).isSymbolicLink() || !lstatSync(child).isDirectory() || !existsSync(join(child, "manifest.json")))
      continue;
    const bytes = readFileSync(safeFile(child, "manifest.json")), m = JSON.parse(bytes);
    if (m.version === 1 && m.binding === binding && Number.isSafeInteger(m.createdAt) && m.createdAt <= now - 30 * 864e5)
      candidates.push({ name, manifestSha256: digest(bytes) });
  }
  return {
    binding,
    directory: root,
    candidates,
    confirmation: digest(JSON.stringify({ binding, directory: root, candidates }))
  };
}
function applyRetention(preview, confirmation) {
  const current = previewRetention(preview.directory, preview.binding);
  if (current.confirmation !== confirmation || preview.confirmation !== confirmation)
    fail("PREVIEW_CHANGED");
  for (const item of current.candidates) {
    const target = join(current.directory, item.name);
    if (!inside(current.directory, target) || lstatSync(target).isSymbolicLink())
      fail("INVALID_PATH");
    rmSync(target, { recursive: true });
  }
  return { deleted: current.candidates.length };
}

// packages/ecosystem-data/account-data.mjs
import { DatabaseSync as DatabaseSync2 } from "node:sqlite";
import { resolve as resolve2 } from "node:path";
import { lstatSync as lstatSync2, realpathSync as realpathSync2 } from "node:fs";
var parse = (v) => JSON.parse(v);
var fail2 = (code) => {
  throw new Error(code);
};
var rootMatch = (scope, policy) => {
  const parts = parse(scope);
  return Array.isArray(parts) && parts[0] === policy.tenant && parts[1] === policy.account && parts[3] === policy.environment;
};
function openAccount(policy) {
  if (!/^[a-zA-Z0-9._-]{1,96}$/.test(policy.account) || !/^[a-zA-Z0-9._-]{1,96}$/.test(policy.tenant) || !Array.isArray(policy.databases))
    fail2("INVALID_ACCOUNT");
  const registry = readRegistry(policy.registry, policy.binding), handles = [];
  try {
    for (const item of policy.databases) {
      if (![
        "installations",
        "authorizations",
        "data",
        "tasks",
        "references",
        "quota",
        "models"
      ].includes(item.kind))
        fail2("INVALID_ACCOUNT_RESOURCE");
      if (!lstatSync2(item.path).isFile() || lstatSync2(item.path).isSymbolicLink() || realpathSync2(item.path) !== resolve2(item.path))
        fail2("SYMLINK_DENIED");
      const db = new DatabaseSync2(resolve2(item.path), { timeout: 100 });
      handles.push({ ...item, db });
      inspectDatabase(db, item.kind, policy.environment);
      db.exec("BEGIN IMMEDIATE");
    }
    const installations = handles.find((h) => h.kind === "installations");
    if (!installations) fail2("INSTALLATION_OWNER_REQUIRED");
    const knownRoots = installations.db.prepare("SELECT scope FROM installation_roots").all().map((r) => r.scope).filter((scope) => rootMatch(scope, policy));
    const rootSet = new Set(knownRoots);
    const acceptRoot = (value) => {
      if (rootMatch(value, policy)) rootSet.add(value);
    };
    const acceptScope = (value) => {
      const parts = parse(value);
      if (!Array.isArray(parts) || parts.length !== 4 || parts[0] !== policy.tenant || parts[1] !== policy.environment)
        return;
      const root = JSON.stringify([policy.tenant, policy.account, parts[3], policy.environment]);
      if (digest(root) === parts[2]) rootSet.add(root);
    };
    for (const { db, kind } of handles) {
      if (kind === "data")
        for (const row of db.prepare("SELECT scope FROM migration_data").all())
          acceptRoot(row.scope);
      if (kind === "authorizations")
        for (const row of db.prepare("SELECT scope FROM authorizations").all())
          acceptRoot(parse(row.scope)[0]);
      if (kind === "tasks")
        for (const row of db.prepare("SELECT scope FROM tasks").all()) acceptScope(row.scope);
      if (kind === "references")
        for (const row of db.prepare("SELECT owner FROM capability_references").all())
          acceptScope(row.owner);
      if (kind === "models")
        for (const row of db.prepare("SELECT owner FROM model_requests").all())
          acceptScope(row.owner);
      if (kind === "quota")
        for (const row of db.prepare("SELECT scope FROM reservations WHERE tenant=? AND account=?").all(policy.tenant, policy.account))
          acceptScope(row.scope);
    }
    const roots = [...rootSet].sort();
    const scopes = roots.map((root) => {
      const [tenant, , app, env] = parse(root);
      return JSON.stringify([tenant, env, digest(root), app]);
    });
    handles.sort((a, b) => Number(a.kind === "installations") - Number(b.kind === "installations"));
    return {
      registry,
      handles,
      roots,
      scopes,
      owner: digest(JSON.stringify([policy.tenant, policy.account, policy.environment]))
    };
  } catch (error) {
    close(handles);
    throw error;
  }
}
function close(handles) {
  for (const { db } of handles.reverse()) {
    try {
      if (db.isTransaction) db.exec("ROLLBACK");
    } finally {
      db.close();
    }
  }
}
function select(account) {
  const output = {
    roots: account.roots.map(parse),
    authorizations: [],
    data: [],
    tasks: [],
    references: [],
    models: []
  };
  for (const { db, kind } of account.handles) {
    if (kind === "authorizations")
      output.authorizations.push(
        ...db.prepare("SELECT scope,value FROM authorizations").all().filter((r) => account.roots.includes(parse(r.scope)[0])).map((r) => ({ scope: parse(r.scope), value: parse(r.value) }))
      );
    if (kind === "data")
      output.data.push(
        ...db.prepare("SELECT scope,snapshot FROM migration_data").all().filter((r) => account.roots.includes(r.scope)).map((r) => ({ scope: parse(r.scope), snapshot: parse(r.snapshot) }))
      );
    if (kind === "tasks")
      output.tasks.push(
        ...db.prepare("SELECT scope,data FROM tasks").all().filter((r) => account.scopes.includes(r.scope)).map((r) => parse(r.data).task)
      );
    if (kind === "references")
      output.references.push(
        ...db.prepare("SELECT id,owner,payload,revision,revoked FROM capability_references").all().filter((r) => account.scopes.includes(r.owner)).map((r) => ({
          id: r.id,
          owner: parse(r.owner),
          payload: parse(r.payload),
          revision: r.revision,
          revoked: r.revoked
        }))
      );
    if (kind === "models")
      output.models.push(
        ...db.prepare("SELECT request_id,owner,identity,upstream_id,result FROM model_requests").all().filter((r) => account.scopes.includes(r.owner)).map((r) => ({
          ...r,
          owner: parse(r.owner),
          identity: parse(r.identity),
          result: r.result === null ? null : parse(r.result)
        }))
      );
  }
  return output;
}
function exportAccount(policy) {
  const account = openAccount(policy);
  try {
    if (account.registry.deleted.some((r) => r.owner === account.owner)) fail2("OWNER_DATA_DELETED");
    return {
      version: 1,
      tenant: policy.tenant,
      account: policy.account,
      environment: policy.environment,
      ...select(account)
    };
  } finally {
    close(account.handles);
  }
}
function previewAccountDeletion(policy) {
  const account = openAccount(policy);
  try {
    const data = select(account);
    const review = {
      owner: account.owner,
      environment: policy.environment,
      roots: account.roots,
      taskIds: data.tasks.map((t) => t.taskId),
      referenceIds: data.references.map((r) => r.id),
      dataDigest: digest(JSON.stringify(data)),
      irreversible: true,
      retentionDays: 30
    };
    return { ...review, confirmation: digest(JSON.stringify(review)) };
  } finally {
    close(account.handles);
  }
}
function deleteAccount(policy, expected, confirmation) {
  const account = openAccount(policy);
  try {
    const data = select(account), review = {
      owner: account.owner,
      environment: policy.environment,
      roots: account.roots,
      taskIds: data.tasks.map((t) => t.taskId),
      referenceIds: data.references.map((r) => r.id),
      dataDigest: digest(JSON.stringify(data)),
      irreversible: true,
      retentionDays: 30
    };
    if (digest(JSON.stringify(review)) !== confirmation || expected.confirmation !== confirmation)
      fail2("DELETE_PREVIEW_CHANGED");
    for (const { db, kind } of account.handles)
      if (kind === "quota") {
        for (const row of db.prepare(
          "SELECT pid,scope FROM reservations WHERE tenant=? AND account=? AND (waiting=1 OR active=1)"
        ).all(policy.tenant, policy.account)) {
          if (!account.scopes.includes(row.scope)) continue;
          try {
            process.kill(row.pid, 0);
          } catch (error) {
            if (error.code === "ESRCH") continue;
          }
          fail2("ACCOUNT_HOST_RUNNING");
        }
      }
    registerDeletion(policy.registry, policy.binding, account.owner);
    for (const { db, kind } of account.handles) {
      if (kind === "installations") {
        for (const root of account.roots)
          for (const table of [
            "installation_references",
            "package_leases",
            "installation_operations",
            "installation_transactions",
            "installation_generations",
            "installation_roots"
          ]) {
            if (db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(table))
              db.prepare(`DELETE FROM ${table} WHERE scope=?`).run(root);
          }
      } else if (kind === "authorizations") {
        for (const { scope } of db.prepare("SELECT scope FROM authorizations").all())
          if (account.roots.includes(parse(scope)[0])) {
            db.prepare("DELETE FROM authorization_receipts WHERE scope=?").run(scope);
            db.prepare("DELETE FROM authorizations WHERE scope=?").run(scope);
          }
      } else if (kind === "data") {
        for (const root of account.roots)
          for (const table of ["data_migrations", "migration_data"])
            db.prepare(`DELETE FROM ${table} WHERE scope=?`).run(root);
      } else if (kind === "tasks") {
        for (const scope of account.scopes)
          db.prepare("DELETE FROM tasks WHERE scope=?").run(scope);
      } else if (kind === "references") {
        const trigger = db.prepare(
          "SELECT sql FROM sqlite_master WHERE type='trigger' AND name='preserve_reference'"
        ).get();
        if (!trigger) fail2("REFERENCE_SCHEMA_MISMATCH");
        db.exec("DROP TRIGGER preserve_reference");
        for (const scope of account.scopes)
          db.prepare("DELETE FROM capability_references WHERE owner=?").run(scope);
        db.exec(trigger.sql);
      } else if (kind === "models") {
        const trigger = db.prepare(
          "SELECT sql FROM sqlite_master WHERE type='trigger' AND name='preserve_model_request'"
        ).get();
        if (!trigger) fail2("MODEL_SCHEMA_MISMATCH");
        db.exec("DROP TRIGGER preserve_model_request");
        for (const scope of account.scopes)
          db.prepare("DELETE FROM model_requests WHERE owner=?").run(scope);
        db.exec(trigger.sql);
      } else if (kind === "quota") {
        for (const scope of account.scopes)
          db.prepare("DELETE FROM reservations WHERE tenant=? AND account=? AND scope=?").run(
            policy.tenant,
            policy.account,
            scope
          );
      }
      db.exec("COMMIT");
    }
    return {
      deleted: account.owner,
      tasks: data.tasks.length,
      references: data.references.length,
      backupPolicy: "quarantined"
    };
  } finally {
    close(account.handles);
  }
}

// packages/ecosystem-data/cli.mjs
var [operation, ...args] = process.argv.slice(2);
var input = (file) => JSON.parse(readFileSync2(file, "utf8"));
try {
  let result;
  if (operation === "registry-init" && args.length === 2)
    result = createRegistry(...args) ?? { created: true };
  else if (operation === "backup" && args.length === 2) result = backup(input(args[0]), args[1]);
  else if (operation === "restore" && args.length === 3)
    result = restore(args[0], args[1], input(args[2]));
  else if (operation === "account-export" && args.length === 1)
    result = exportAccount(input(args[0]));
  else if (operation === "account-deletion-preview" && args.length === 1)
    result = previewAccountDeletion(input(args[0]));
  else if (operation === "account-delete" && args.length === 3)
    result = deleteAccount(input(args[0]), input(args[1]), args[2]);
  else if (operation === "retention-preview" && args.length === 2)
    result = previewRetention(...args);
  else if (operation === "retention-apply" && args.length === 2)
    result = applyRetention(input(args[0]), args[1]);
  else throw new Error("INVALID_ARGUMENTS");
  console.log(JSON.stringify({ ok: true, value: result }));
} catch (error) {
  const code = /^[A-Z_]+$/.test(error.message) ? error.message : "DATA_OPERATION_FAILED";
  console.error(JSON.stringify({ ok: false, error: { code } }));
  process.exitCode = 1;
}
