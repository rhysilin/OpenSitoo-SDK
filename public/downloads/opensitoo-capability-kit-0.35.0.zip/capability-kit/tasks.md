# 持久能力任务（可信宿主）

E3-R04图片服务及原任务产物交付。

E3-R03产品宿主服务交付。

E3-R02原请求账本交付。

维护日期：2026-10-09。`@sitoo/capability-tasks@0.4.0` 为工作区 private Node 24 模块，非浏览器 SDK、REST、IPC 或已发布 npm。与 协议、代理、执行器 分开版本化。无 Pi/Electron/Desktop 依赖；SDK 旧结构只作类型引用。

## 构造与宿主职责

`new CapabilityTasks({path, broker, query?, maxTasks?, allowEffects?, packageLeases?})` 接宿主自选的 SQLite 文件和已注册的 CapabilityBroker。目录须已存在，路径、账户、session、查询端口仅由可信宿主设置。`broker` 属性返回同一实例；不是让应用设置身份或注册执行器的入口。

Node 原生 SQLite 使用 EXCLUSIVE 单连接所有权、DELETE journal、FULL 同步和 100ms busy timeout。第二个宿主打开同库失败，不能把仍在运行的任务当成崩溃任务恢复。初始化在独占事务中完成，数据库 schema version 为 1，不支持未知版本。构造/存储错误可抛出，宿主应停止受理并报告存储故障，不自动换数据库或重试业务。使用本机持久磁盘；网络文件系统、复制库双写、磁盘损坏、备份恢复和生产容量待专项验收。

默认最多 10000 条记录，可配置 1–1000000 的整数。满额拒绝新请求，原请求仍可查询/去重，不自动淘汰记录。请求/结果为本地业务数据，库不加密；宿主须按租户保护目录、权限与备份。诊断不输出原文、凭据或数据库内容。

## 方法

| 方法                                 | 返回与语义                                                                                                                  |
| ------------------------------------ | --------------------------------------------------------------------------------------------------------------------------- |
| `submit(session, request)`           | 同步 `ProtocolValidation<DurableTask>`；纯能力先落盘 queued，随后 microtask 经代理异步执行。结果尚未完成也可立即查 taskId。 |
| `get(session, taskId)`               | 同步任务快照；不存在或不属于调用者均 FORBIDDEN，避免泄漏其他人的 ID。                                                       |
| `list(session, {limit?,offset?}={})` | 同步任务数组；当前 scope，按创建顺序倒序。limit 默认 50，范围 1–100；offset 非负整数。                                      |
| `cancel(session, taskId)`            | 未分派 queued 可 cancelled；已分派/上游任务转 unknown 并取消本地信号。不会承诺上游撤销或退款。终态保持。                    |
| `reconcile(session, taskId)`         | 异步快照；已完成/失败/取消直接返回。其他状态仅调用构造时注入的 query-only 端口，不执行能力。                                |
| `close()`                            | 同步、幂等；queued/running 先记录 unknown，再中止活动信号并关闭库。之后返回 UNAVAILABLE。                                   |

scope 为 `(tenantId, environment, installationId, consumerAppId)`，由代理 session 获取，调用参数不能覆盖。application/conversation 入口共享相同 scope 的任务；安装身份变化不会继承旧数据，后续 E2 须显式迁移映射。读快照不要求旧版本仍安装，但宿主仍须签发有效的同 scope 会话。

`DurableTask` 包含协议 taskId/requestId/capabilityId/status，加 binding（packageId/version/sha256 等）、revision、createdAt/updatedAt ISO 时间，及可选 result（完整 CapabilityResponse）、upstreamTask（原上游 task reference）。快照可在客户端修改，不能回写状态；不返回内部原请求、scope 或凭据。

同 scope + requestId 唯一。JSON 对象 key 顺序不影响去重；数组顺序和实际值影响。相同 ID 但不同输入、能力或当前精确版本返回 CONFLICT。相同请求重提返回原任务，即使结果 unknown，也绝不再次执行。旧绑定已移除时仍返回原记录；新请求必须通过 prepare 的全部授权与输入校验。allowEffects 默认 false，仍拒绝 billable/externalWrite。可信宿主显式启用时，先落盘 needs-approval，不排执行队列；使用 getConfirmation(session, taskId) 读取原请求/绑定/revision，approve(session, taskId, revision) 验证后排队并消费短期凭证。原上游待确认任务不可借此再次执行。完整方法、一次确认与恢复语义见确认与引用参考。

## 状态和恢复

queued → running → completed/failed/unknown/cancelled；Provider accepted 时保存 upstreamTask，允许 queued/running/needs-input/needs-approval，其他引用状态映射 unknown。单凭 accepted 内的 completed 不表示已拿到真实结果。

启动遇到旧 queued/running 一律 unknown，不自动重新调执行器；其他持久状态保留。RESULT_UNKNOWN 错误保留原 requestId/taskId 和上游身份。业务级 error 转 failed，CANCELLED 转 cancelled。已经开始执行的 cancel 转 unknown，并拒绝迟到回调覆盖；这是保守策略，可能连纯计算取消也显示 unknown。

`TaskQuery(task: Readonly<DurableTask>, signal: AbortSignal, context: {request:CapabilityRequest;caller:CapabilityCallerPolicy}): Promise<unknown>` 是可信宿主只查原任务的端口。第三参数提供原请求副本与冻结调用政策，仅限可信查询器；旧两参数回调兼容。尚未确认的本地任务禁止 reconcile；不能用查询绕过确认。必须根据绑定和 taskId/upstreamTask 查询原服务，不能调用 generate、换请求 ID 或推测成功。没有端口返回 UNAVAILABLE。单次上限 1500ms，超时/异常返回 RESULT_UNKNOWN，保留记录，无自动轮询。相同任务正在执行/查询返回 CONFLICT。响应须通过代理的 wire 关联及业务 output schema 校验；查询期间会话撤销、版本变更或 revision 变化不能写入结果。恢复 old binding 需保留同版本的声明与可信绑定，不能借新版本解释旧结果。

## 旧文本/生图视图

`new LegacyTaskViews({broker, readers, map})`；readers 仅 `text?:Pick<AppTextProvider,'getTask'|'listTasks'>` 和 `image?:Pick<AppImageProvider,'getTask'|'listTasks'>`。map 是可信宿主显式 scope → `{textAppId?,imageCaller?}` 映射，未映射 FORBIDDEN，不能从用户输入构造 caller。

`get(session, source, id)` 返回异步 `ProtocolValidation<LegacyTaskView>`；`list(session, source)` 返回数组。source 仅 legacy-text/legacy-image；沿用旧 Provider list 的容量约束，无新分页接口。返回 source/taskId/status/createdAt/updatedAt，可选 text/value、gatewayTaskId、artifacts。submitting 规范为 running，unknown 保留。检查返回 appId/caller 和原 ID，异步查询后重新检查会话。异常使用固定 UNAVAILABLE，原错误、prompt、配置不回传。

此视图不复制旧数据库、不提交生图、不更换原 ID，也不提供 generate。旧 Provider 仍为状态真实来源，其 getTask 可以执行原有查询/规范化逻辑。尚未接入 Desktop 产品路由；可信宿主须按租户/环境建立映射，不能把同 appId 当作跨租户共享授权。

## 验证与后续

证据见 E1-04。本地去重保证不能替代上游幂等或收费对账，也不覆盖绕过服务直接 invoke 的调用；可信宿主应统一通过本服务受理任务。事务日志/快照/备份恢复后的重放策略、生产审批与预算、生产收费核对及 E2 安装生命周期仍需后续门禁。

返回文档总目录 · 当前状态 · 对应交付记录

0.3.0 新增可选可信 TaskPackageLeases acquire/release 端口，任务落盘/执行前保护整个依赖闭包，终态先持久化再释放，unknown 保留，重开补偿终态释放失败。没有端口时原行为兼容；具体类型、scope、顺序、失败与预算见执行与租约参考。

## 既有任务库只读视图（0.4.0）

`new CapabilityTaskViews({path, scope})` 仅供可信 Node 所有者读取既有 schema 1 库；scope 严格为 `{tenantId, environment, installationId, consumerAppId}`，沿用原代理校验，不含入口、grants、执行器或凭据。构造只读打开，不创建目录/数据库，不迁移、不恢复运行状态；缺库、未知 schema、原 EXCLUSIVE 宿主占用时构造失败，100ms busy timeout。

`get(taskId): ProtocolValidation<DurableTask>` 按原 scope/ID 查询；不存在或其他 scope 返回 FORBIDDEN。`list({limit=50,offset=0}={}): ProtocolValidation<DurableTask[]>` 按原 rowid 倒序，limit 为 1–100 整数，offset 为非负安全整数。非法参数 INVALID_INPUT，损坏记录/存储错误/已关闭返回 UNAVAILABLE；`close()` 同步幂等。原记录最大 256 KiB，复核 scope、请求关联、绑定、结果和状态；快照不返回内部 request 输入、fingerprint 或 scope。

此视图不调用执行/上游查询，不回写任务，不释放租约。unknown 保留；进程强退后未经原 CapabilityTasks 恢复的 running/queued 也原样返回，不能把记录状态当作仍在执行或最终失败。原宿主仍在运行时使用它的既有 GET 查询；不要另开执行宿主规避独占锁。执行授权撤销不替代原账户历史隔离。

产品适配、验收证据与剩余上游核对见第十四批交付和SDK/Desktop 手册。

## 原上游查询失败与恢复门禁

可信 query-only 原接口不变。仓库外宿主暂查不到原模拟请求时保留 unknown 和原快照；恢复后核对同一 requestId/taskId，完成结果跨宿主重启与重复查询保持一致，未再执行模型。此为本地模拟上游，非生产收费验证；见第十七批交付。

## 父进程退出的原任务收口

任务模块0.4.0与schema不变。开发宿主显式父管道断开时调用原close：正常close将queued/running落盘为unknown；强退未写回时只读记录仍为running/queued，原宿主启动后恢复unknown。已完成不变，原租约/pin不清理。产品重开读取同一原记录，不能把退出当作撤销副作用。流程与门禁见第十八批交付。

R02可信持久模型账本复用原query-only路径，实际宿主SIGKILL后恢复原unknown及完整pin；查询失败/撤权保留，显式恢复后只接受原结果。原Tasks0.4.0与旧schema保持。账本与上游职责见服务手册，真实本地进程与无费用夹具证据见R02交付。

[返回工具包说明](./README.md)
