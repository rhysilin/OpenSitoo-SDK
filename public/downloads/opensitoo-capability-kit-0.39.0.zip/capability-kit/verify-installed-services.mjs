import { pathToFileURL } from 'node:url';
// Zero-fee trusted operator integration; applications use only the copied SDK.
import assert from 'node:assert/strict';
import { generateKeyPairSync, randomUUID, randomBytes, createHash } from 'node:crypto';
import { mkdtemp, writeFile, rm, mkdir } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { join, relative, isAbsolute } from 'node:path';
import { tmpdir } from 'node:os';
import { setTimeout as delay } from 'node:timers/promises';
import {
  CapabilityReferences,
  CapabilityInstallationStore,
  CapabilityAuthorizationStore,
  CapabilityPackageTrust,
  CapabilityReleaseStore,
  verifyCapabilityPackage,
  signCapabilityPackage,
  startDevelopmentHost,
  createModelTaskQuery,
} from './service-host.mjs';
import { createCapabilityClient } from './capability-sdk.mjs';
const directory = await mkdtemp(join(tmpdir(), 'sitoo-installed-services-'));
const unwrap = (result) => {
  assert.ok(result.ok, JSON.stringify(result));
  return result.value;
};
const digest = (value) => createHash('sha256').update(value).digest('hex');
const references = new CapabilityReferences();
const dummy = (capabilityId) => ({
  capabilityId,
  packageId: 'platform/services',
  version: '1.0.0',
  sha256: 'a'.repeat(64),
});
const descriptors = references.createCapabilities({
  text: dummy('platform/read-text'),
  model: dummy('platform/infer'),
});
const capabilities = descriptors.map(({ declaration: { binding, ...contract } }) => ({
  capabilityId: binding.capabilityId,
  ...contract,
}));
const service = (version) =>
  unwrap(
    verifyCapabilityPackage(
      JSON.stringify({
        formatVersion: 1,
        execution: 'host-service-v1',
        packageId: 'platform/services',
        version,
        files: [],
        dependencies: [],
        capabilities,
      }),
      new Map(),
    ),
  );
const v1 = service('1.0.0'),
  v2 = service('1.1.0');
function guest() {
  const sources = {
    'text.guest':
      "const r=await invoke({protocolVersion:1,requestId:input.requestId,capabilityId:'platform/read-text',input:{referenceId:input.referenceId}});if(!r.ok||r.value.status!=='success')throw Error('read denied');return r.value.value.toUpperCase();",
    'nested.guest': "const r=await invoke(input);return r.ok?'unexpected':r.error.code;",
  };
  return unwrap(
    verifyCapabilityPackage(
      JSON.stringify({
        formatVersion: 1,
        execution: 'quickjs-function-v1',
        packageId: 'alice/core',
        version: '1.0.0',
        dependencies: [{ packageId: 'platform/services', range: '1' }],
        files: Object.entries(sources).map(([path, source]) => ({
          path,
          bytes: Buffer.byteLength(source),
          sha256: digest(source),
        })),
        capabilities: Object.keys(sources).map((path) => ({
          capabilityId: path === 'text.guest' ? 'alice/text' : 'alice/nested',
          source: path,
          interfaceVersion: 1,
          inputSchema: true,
          outputSchema: { type: 'string' },
          permissions: [path === 'text.guest' ? 'resource:read' : 'model:infer'],
          allowedEntries: ['application', 'conversation'],
          delegates: [path === 'text.guest' ? 'platform/read-text' : 'platform/infer'],
          effects: { billable: false, externalWrite: false },
        })),
      }),
      new Map(Object.entries(sources).map(([path, source]) => [path, Buffer.from(source)])),
    ),
  );
}
const core = guest();
const application = (name, version, nativeVersion) => {
  const source = '<!doctype html><title>Service integration sample</title>';
  return unwrap(
    verifyCapabilityPackage(
      JSON.stringify({
        formatVersion: 1,
        execution: 'static-application-v1',
        packageId: 'alice/' + name,
        version,
        application: { applicationId: 'alice.' + name, entry: 'index.html' },
        dependencies: [
          { packageId: 'alice/core', range: '1.0.0' },
          { packageId: 'platform/services', range: nativeVersion },
        ],
        capabilities: [],
        files: [{ path: 'index.html', bytes: Buffer.byteLength(source), sha256: digest(source) }],
      }),
      new Map([['index.html', Buffer.from(source)]]),
    ),
  );
};
const applications = [
    application('app-a', '1.0.0', '1.0.0'),
    application('app-b', '1.0.0', '1.0.0'),
  ],
  updated = application('app-a', '1.1.0', '1.1.0');
const keys = generateKeyPairSync('ed25519'),
  now = Date.now();
const trusted = ['platform', 'alice'].map((namespace) => ({
  keyId: namespace,
  namespace,
  environments: ['development'],
  publicKeyPem: keys.publicKey.export({ format: 'pem', type: 'spki' }).toString(),
  notBefore: now - 1000,
  notAfter: now + 300000,
  revoked: false,
}));
const trust = new CapabilityPackageTrust(trusted);
await writeFile(join(directory, 'trust.json'), JSON.stringify(trusted));
const releases = new CapabilityReleaseStore(join(directory, 'releases.sqlite'));
const published = [v1, v2, core, ...applications, updated].map((pkg) =>
  unwrap(
    releases.publish(
      pkg,
      unwrap(
        signCapabilityPackage(pkg, keys.privateKey, {
          keyId: pkg.manifest.packageId.split('/')[0],
          environment: 'development',
          issuedAt: now,
          expiresAt: now + 300000,
        }),
      ),
      trust,
    ),
  ),
);
const roots = applications.map((pkg) => ({
  tenantId: 'tenant',
  accountId: 'account',
  applicationId: pkg.manifest.application.applicationId,
  environment: 'development',
}));
const stores = roots.map(
  (root) => new CapabilityInstallationStore(join(directory, 'installation.sqlite'), root),
);
const authorization = [];
const consumers = [],
  ids = [];
let host,
  inferenceCalls = 0,
  queryCalls = 0,
  available = false,
  revokeDuringQuery;
const ledger = new Map();
const owner = (scope) =>
  JSON.stringify([scope.tenantId, scope.environment, scope.installationId, scope.consumerAppId]);
const servicesFor = (pkg) =>
  references.createCapabilities({
    text: pkg.bindings.find((b) => b.capabilityId === 'platform/read-text'),
    model: pkg.bindings.find((b) => b.capabilityId === 'platform/infer'),
  });
let selectedServices = servicesFor(v1);
const operatorToken = randomBytes(32).toString('hex');
// Optional trusted acceptance driver; never configured by packages or HTTP consumers.
const browser = process.env.SITOO_TEST_SERVICE_CLIENT
  ? await (
      await import(pathToFileURL(process.env.SITOO_TEST_SERVICE_CLIENT).href)
    ).createServiceClientAcceptance()
  : undefined;
const results = [];
const check = (name) => {
  results.push(name);
  console.log('PASS ' + name);
};
try {
  await mkdir(join(directory, 'native-package'));
  await writeFile(
    join(directory, 'native-package/capability-package.json'),
    JSON.stringify(v1.manifest),
  );
  const inspected = await promisify(execFile)(
    process.execPath,
    [
      join(import.meta.dirname, 'capability-packages.mjs'),
      'inspect',
      join(directory, 'native-package'),
    ],
    { windowsHide: true, timeout: 10000 },
  );
  assert.ok(JSON.parse(inspected.stdout).ok);
  check('copied public package CLI inspects a zero-payload signed-service contract');
  for (let index = 0; index < 2; index++) {
    unwrap(
      stores[index].prepare(
        'install',
        [{ packageId: applications[index].manifest.packageId, range: '1.0.0' }],
        [published[0], published[2], published[index + 3]],
        releases,
        trust,
      ),
    );
    unwrap(stores[index].commit('install', releases, trust));
    const plan = unwrap(stores[index].load(trust)).plan;
    assert.equal(plan.packages.length, 3);
    const scope = {
      tenantId: 'tenant',
      environment: 'development',
      installationId: digest(
        JSON.stringify([
          roots[index].tenantId,
          roots[index].accountId,
          roots[index].applicationId,
          roots[index].environment,
        ]),
      ),
      consumerAppId: roots[index].applicationId,
    };
    ids.push({
      text: references.issueText(scope, 'owned ' + index),
      model: references.issueModelProvider(scope, {
        infer: async (prompt, context, requestId) => {
          inferenceCalls++;
          const result = { text: prompt.toUpperCase() };
          ledger.set(owner(context) + requestId, { prompt, result });
          if (prompt === 'unknown') throw Error('response lost');
          return result;
        },
        query: async (prompt, context, requestId) => {
          queryCalls++;
          if (revokeDuringQuery) revokeDuringQuery();
          if (!available) throw Error('unavailable');
          const row = ledger.get(owner(context) + requestId);
          if (!row || row.prompt !== prompt) throw Error('original absent');
          return row.result;
        },
      }),
    });
    for (const entry of ['application', 'conversation']) {
      const auth = new CapabilityAuthorizationStore(
        join(directory, 'authorization.sqlite'),
        roots[index],
        entry,
      );
      unwrap(
        auth.set('grant', 0, {
          entry,
          bindings: plan.bindings,
          grants: ['resource:read', 'model:infer'],
        }),
      );
      authorization.push(auth);
      consumers.push({ token: randomBytes(32).toString('hex'), root: roots[index], entry });
    }
  }
  const config = {
    version: 3,
    installationPath: 'installation.sqlite',
    trustPath: 'trust.json',
    authorizationPath: 'authorization.sqlite',
    consumers,
  };
  const configPath = join(directory, 'host.json');
  await writeFile(configPath, JSON.stringify(config));
  const options = () => ({
    configPath,
    dataDirectory: join(directory, 'tasks'),
    installedServices: selectedServices,
    confirmationToken: operatorToken,
    taskQuery: createModelTaskQuery(references),
  });
  await assert.rejects(
    startDevelopmentHost({ configPath, dataDirectory: join(directory, 'missing') }),
  );
  await assert.rejects(
    startDevelopmentHost({
      ...options(),
      installedServices: selectedServices.map((item) => ({
        ...item,
        declaration: {
          ...item.declaration,
          binding: { ...item.declaration.binding, sha256: 'b'.repeat(64) },
        },
      })),
    }),
  );
  await assert.rejects(
    startDevelopmentHost({
      ...options(),
      installedServices: selectedServices.map((item) => ({
        ...item,
        declaration: { ...item.declaration, outputSchema: false },
      })),
    }),
  );
  check('signed complete plans reject absent, wrong digest and changed contract implementations');
  host = await startDevelopmentHost(options());
  const call = async (index, path, body, operator = false) => {
    const reply = await fetch(host.url + path, {
      method: body === undefined ? 'GET' : 'POST',
      headers: {
        authorization: 'Bearer ' + consumers[index].token,
        'content-type': 'application/json',
        ...(operator ? { 'x-fixture-confirmation': operatorToken } : {}),
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    return reply.json();
  };
  const client = (index) =>
    createCapabilityClient({
      submit: (request) => call(index, '/v1/tasks', request),
      get: (id) => call(index, '/v1/tasks/' + id),
      cancel: (id) => call(index, '/v1/tasks/' + id + '/cancel', {}),
      list: () => call(index, '/v1/tasks'),
    });
  const request = (capabilityId, input) => ({
    protocolVersion: 1,
    requestId: randomUUID(),
    capabilityId,
    input,
  });
  async function until(index, id, status) {
    for (let n = 0; n < 150; n++) {
      const value = unwrap(await client(index).get(id));
      if (value.status === status) return value;
      await delay(10);
    }
    throw Error('Task timeout ' + status);
  }
  for (let index = 0; index < 4; index++) {
    const text = unwrap(
      await client(index).submit(
        request('alice/text', {
          referenceId: ids[Math.floor(index / 2)].text,
          requestId: randomUUID(),
        }),
      ),
    );
    assert.equal(
      (await until(index, text.taskId, 'completed')).result.value,
      'OWNED ' + Math.floor(index / 2),
    );
    const modelRequest = request('platform/infer', {
      referenceId: ids[Math.floor(index / 2)].model,
      prompt: 'entry ' + index + (index === 3 ? ' <img src=x onerror=probe()>' : ''),
    });
    const pending = unwrap(await client(index).submit(modelRequest));
    assert.equal(pending.status, 'needs-approval');
    assert.equal(
      (await call(index, '/v1/confirmations/' + pending.taskId, { revision: pending.revision })).ok,
      false,
    );
    const before = inferenceCalls;
    assert.equal(before, index);
    if (browser)
      await browser.approve(host.url, consumers[index].token, operatorToken, pending.taskId);
    else
      unwrap(
        await call(
          index,
          '/v1/confirmations/' + pending.taskId,
          { revision: pending.revision },
          true,
        ),
      );
    assert.deepEqual((await until(index, pending.taskId, 'completed')).result.value, {
      text: modelRequest.input.prompt.toUpperCase(),
    });
    assert.equal(inferenceCalls, before + 1);
  }
  check(
    'two installed applications and both entries use real QuickJS text delegation and operator-approved model tasks',
  );
  const catalog = unwrap(await call(1, '/v1/conversation/tools'));
  assert.ok(catalog.tools.some((tool) => tool.binding.capabilityId === 'platform/infer'));
  const proposal = request('platform/infer', { referenceId: ids[0].model, prompt: 'prepared' });
  unwrap(await call(1, '/v1/conversation/prepare', proposal));
  assert.equal(inferenceCalls, 4);
  check('conversation discovery and preparation disclose billable plans without executing');
  const nested = unwrap(
    await client(0).submit(
      request(
        'alice/nested',
        request('platform/infer', { referenceId: ids[0].model, prompt: 'nested' }),
      ),
    ),
  );
  assert.equal((await until(0, nested.taskId, 'completed')).result.value, 'FORBIDDEN');
  assert.equal(inferenceCalls, 4);
  check('nested Guest cannot inherit or mint model approval');
  const original = request('platform/infer', { referenceId: ids[0].model, prompt: 'unknown' }),
    pending = unwrap(await client(0).submit(original));
  unwrap(
    await call(0, '/v1/confirmations/' + pending.taskId, { revision: pending.revision }, true),
  );
  await until(0, pending.taskId, 'unknown');
  assert.equal(unwrap(stores[0].getLease(pending.taskId)).plan.packages.length, 3);
  assert.equal(unwrap(await client(0).submit(original)).taskId, pending.taskId);
  assert.equal((await client(2).get(pending.taskId)).ok, false);
  const before = inferenceCalls;
  unwrap(
    stores[0].prepareUpdate(
      'update',
      [{ packageId: 'alice/app-a', range: '1.1.0' }],
      [published[1], published[2], published[5]],
      releases,
      trust,
    ),
  );
  assert.equal(stores[0].commit('update', releases, trust).ok, false);
  check(
    'unknown pins static application, Guest and native contract; duplicate and foreign read cannot re-execute',
  );
  await host.close();
  host = await startDevelopmentHost(options());
  if (browser)
    await browser.unavailable(host.url, consumers[0].token, operatorToken, pending.taskId);
  else assert.equal((await call(0, '/v1/tasks/' + pending.taskId + '/reconcile', {})).ok, false);
  await until(0, pending.taskId, 'unknown');
  assert.equal(unwrap(stores[0].getLease(pending.taskId)).status, 'active');
  available = true;
  const auth0 = authorization[0],
    snapshot = unwrap(auth0.read());
  revokeDuringQuery = () => {
    unwrap(
      auth0.set('query-revoke', snapshot.revision, { ...snapshot.policy, grants: [] }, 'revoked'),
    );
    revokeDuringQuery = undefined;
  };
  assert.equal((await call(0, '/v1/tasks/' + pending.taskId + '/reconcile', {})).ok, false);
  assert.equal(unwrap(stores[0].getLease(pending.taskId)).status, 'active');
  check(
    'restart/unavailable query and revocation during query preserve original unknown and full pin',
  );
  await host.close();
  unwrap(auth0.set('reauthorize', snapshot.revision + 1, snapshot.policy));
  host = await startDevelopmentHost(options());
  const completed = browser
    ? await browser.reconcile(host.url, consumers[0].token, operatorToken, pending.taskId)
    : unwrap(await call(0, '/v1/tasks/' + pending.taskId + '/reconcile', {}));
  assert.equal(completed.status, 'completed');
  assert.equal(inferenceCalls, before);
  assert.equal(unwrap(stores[0].getLease(pending.taskId)).status, 'released');
  unwrap(await call(0, '/v1/tasks/' + pending.taskId + '/reconcile', {}));
  assert.equal(queryCalls, 3);
  check('explicit reauthorization queries only original result and releases durable pin once');
  await host.close();
  host = undefined;
  unwrap(stores[0].commit('update', releases, trust));
  await assert.rejects(startDevelopmentHost(options()));
  const updatedPlan = unwrap(stores[0].load(trust)).plan;
  for (const auth of authorization.slice(0, 2)) {
    const current = unwrap(auth.read());
    unwrap(
      auth.set('update-auth', current.revision, {
        ...current.policy,
        bindings: updatedPlan.bindings,
      }),
    );
  }
  await assert.rejects(startDevelopmentHost(options()));
  selectedServices = [...servicesFor(v1), ...servicesFor(v2)];
  host = await startDevelopmentHost(options());
  for (const index of [0, 2]) {
    const task = unwrap(
      await client(index).submit(
        request('platform/read-text', { referenceId: ids[index / 2].text }),
      ),
    );
    const value = await until(index, task.taskId, 'completed');
    assert.equal(value.binding.version, index === 0 ? '1.1.0' : '1.0.0');
  }
  assert.equal(unwrap(await client(0).get(pending.taskId)).result.value.text, 'UNKNOWN');
  check(
    'native version update requires exact renewed authorization and implementation; another app retains original version/result',
  );
  const authB = authorization[2],
    previous = unwrap(authB.read());
  unwrap(authB.set('revoke-b', previous.revision, { ...previous.policy, grants: [] }, 'revoked'));
  assert.equal(
    (await client(2).submit(request('platform/read-text', { referenceId: ids[1].text }))).ok,
    false,
  );
  const survivor = unwrap(
    await client(1).submit(request('platform/read-text', { referenceId: ids[0].text })),
  );
  await until(1, survivor.taskId, 'completed');
  check(
    'entry revocation refuses new work while separately authorized application remains executable',
  );
  await host.close();
  host = undefined;
  unwrap(stores[0].prepareUninstall('uninstall'));
  unwrap(stores[0].commitUninstall('uninstall'));
  assert.equal(stores[0].load(trust).ok, false);
  assert.ok(stores[1].load(trust).ok);
  await writeFile(configPath, JSON.stringify({ ...config, consumers: [consumers[3]] }));
  selectedServices = servicesFor(v1);
  host = await startDevelopmentHost(options());
  const remaining = unwrap(
    await client(3).submit(
      request('alice/text', { referenceId: ids[1].text, requestId: randomUUID() }),
    ),
  );
  assert.equal((await until(3, remaining.taskId, 'completed')).result.value, 'OWNED 1');
  check('uninstall removes only one root and preserves other native version installation');
  console.log(
    JSON.stringify({
      passed: results.length,
      results,
      inferenceCalls,
      queryCalls,
      modelCharges: 0,
    }),
  );
} finally {
  await browser?.close();
  await host?.close();
  authorization.forEach((item) => item.close());
  stores.forEach((item) => item.close());
  releases.close();
  const target = relative(tmpdir(), directory);
  if (
    isAbsolute(target) ||
    target.startsWith('..') ||
    !target.startsWith('sitoo-installed-services-')
  )
    throw Error('Unsafe cleanup');
  await rm(directory, { recursive: true, force: true });
}
