const element = (id) => document.getElementById(id);
let current;
function controls(state) {
  element('history').disabled = !state || state.busy;
  element('approve').disabled = !state?.confirmation || state.busy;
  element('reconcile').disabled = state?.task?.status !== 'unknown' || state.busy;
}
function disconnect() {
  current?.abort.abort();
  current = undefined;
  for (const id of ['token', 'operator']) element(id).value = '';
  element('tasks').replaceChildren();
  element('result').textContent = '';
  element('result').removeAttribute('data-status');
  element('confirmation').textContent = '';
  controls();
}
async function call(state, path, input, operator = false) {
  const response = await fetch(path, {
    method: input === undefined ? 'GET' : 'POST',
    headers: {
      authorization: 'Bearer ' + state.token,
      'content-type': 'application/json',
      ...(state.pin ? { [state.pinHeader]: state.pin } : {}),
      ...(operator ? { 'x-fixture-confirmation': state.operator } : {}),
    },
    body: input === undefined ? undefined : JSON.stringify(input),
    signal: AbortSignal.any([state.abort.signal, AbortSignal.timeout(10000)]),
  });
  const reply = await response.json();
  if (current !== state || !reply.ok) throw new Error('Unavailable');
  return reply.value;
}
async function action(work) {
  const state = current;
  if (!state || state.busy) return;
  state.busy = true;
  controls(state);
  try {
    await work(state);
  } catch {
    if (current === state) {
      state.confirmation = undefined;
      element('confirmation').textContent = '';
      element('status').textContent =
        '请求未完成或授权已变化；刷新原任务后再操作，未知结果不会重跑';
    }
  } finally {
    state.busy = false;
    if (current === state) controls(state);
  }
}
async function select(state, id) {
  state.confirmation = undefined;
  element('confirmation').textContent = '';
  state.task = await call(state, '/v1/tasks/' + encodeURIComponent(id));
  element('result').dataset.status = state.task.status;
  element('result').textContent = JSON.stringify(state.task, null, 2);
  element('status').textContent = '原任务状态：' + state.task.status;
  if (state.task.status === 'needs-approval') {
    state.confirmation = await call(state, '/v1/confirmations/' + id, undefined, true);
    element('confirmation').textContent = JSON.stringify(state.confirmation, null, 2);
  }
}
async function history(state) {
  const tasks = await call(state, '/v1/tasks');
  element('tasks').replaceChildren();
  for (const task of tasks) {
    const item = document.createElement('li');
    const button = document.createElement('button');
    button.textContent = task.taskId + ' · ' + task.status;
    button.dataset.taskId = task.taskId;
    button.addEventListener('click', () => action((active) => select(active, task.taskId)));
    item.append(button);
    element('tasks').append(item);
  }
  if (state.task) await select(state, state.task.taskId);
}
element('connect').addEventListener('submit', async (event) => {
  event.preventDefault();
  const token = element('token').value.trim(),
    operator = element('operator').value.trim();
  disconnect();
  if (![token, operator].every((value) => /^[a-f0-9]{64}$/.test(value)) || token === operator) {
    element('status').textContent = '请输入独立的消费令牌与操作者密钥';
    return;
  }
  const state = { token, operator, abort: new AbortController() };
  current = state;
  await action(async () => {
    try {
      const page = await call(state, '/v1/application');
      state.pin = page.sha256;
      state.pinHeader = 'x-sitoo-application';
    } catch {
      const catalog = await call(state, '/v1/conversation/tools');
      state.pin = catalog.planSha256;
      state.pinHeader = 'x-sitoo-conversation';
    }
    await history(state);
    element('status').textContent = '已连接；请选择原任务查看确认内容或核对结果';
  });
});
element('history').addEventListener('click', () => action(history));
element('approve').addEventListener('click', () =>
  action(async (state) => {
    const confirmation = state.confirmation;
    state.confirmation = undefined;
    await call(
      state,
      '/v1/confirmations/' + confirmation.taskId,
      { revision: confirmation.revision },
      true,
    );
    await select(state, confirmation.taskId);
  }),
);
element('reconcile').addEventListener('click', () =>
  action(async (state) => {
    await call(state, '/v1/tasks/' + state.task.taskId + '/reconcile', {});
    await select(state, state.task.taskId);
  }),
);
element('disconnect').addEventListener('click', () => {
  disconnect();
  element('status').textContent = '已断开；原任务及其保护记录仍由宿主持久保存';
});
controls();
