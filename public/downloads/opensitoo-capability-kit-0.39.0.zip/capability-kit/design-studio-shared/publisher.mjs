import { mkdir, readFile, writeFile, cp } from 'node:fs/promises';
import { createHash, generateKeyPairSync } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { resolve, join, dirname } from 'node:path';
import { pathToFileURL } from 'node:url';

// Copy this file and the built payload outside the repository. No platform source imports.
const compatibility = process.argv.includes('--compat');
const [command, argument, ...args] = process.argv.slice(2).filter((arg) => arg !== '--compat');
const project = resolve(argument ?? '.');
const json = (file, value) =>
  writeFile(file, JSON.stringify(value, null, 2), { flag: 'wx', mode: 0o600 });
if (command === 'init' && args.length === 3) {
  await mkdir(project); // Refuse to overlay an existing project.
  await cp(resolve(args[0]), join(project, 'tools'), { recursive: true });
  if (compatibility)
    await cp(
      join(dirname(resolve(args[1])), 'service-host.mjs'),
      join(project, 'tools/service-host.mjs'),
    );
  await cp(resolve(args[1]), join(project, 'sdk.js'));
  await cp(resolve(args[2]), join(project, 'payload'), { recursive: true });
  await mkdir(join(project, 'keys'));
  const policies = [];
  for (const namespace of compatibility ? ['platform', 'design', 'sitoo'] : ['design', 'studio']) {
    const keys = generateKeyPairSync('ed25519');
    await writeFile(
      join(project, 'keys', namespace + '.pem'),
      keys.privateKey.export({ type: 'pkcs8', format: 'pem' }),
      { flag: 'wx', mode: 0o600 },
    );
    policies.push({
      keyId: namespace,
      namespace,
      environments: ['development'],
      publicKeyPem: keys.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
      notBefore: Date.now() - 1000,
      notAfter: Date.now() + 86400000,
      revoked: false,
    });
  }
  await json(join(project, 'trust.json'), policies);
  console.log(JSON.stringify({ initialized: true }));
} else if (command === 'publish' && args.length === 1) {
  const environment = { ...process.env };
  delete environment.NODE_PATH;
  delete environment.NODE_OPTIONS;
  const run = (...parameters) => {
    const reply = JSON.parse(
      execFileSync(
        process.execPath,
        [join(project, 'tools/capability-packages.mjs'), ...parameters],
        {
          cwd: project,
          env: environment,
          windowsHide: true,
          encoding: 'utf8',
          timeout: 20000,
          stdio: ['ignore', 'pipe', 'pipe'],
        },
      ),
    );
    if (!reply.ok) throw new Error(reply.error.code);
    return reply.value;
  };
  const example = {
    plan: {
      summary: '蓝色宣传海报',
      prompt: 'A blue poster',
      aspectRatio: '2:3',
      resolution: '1K',
      referenceIds: ['logo'],
      rationale: '使用当前品牌参考图',
    },
    capabilities: {
      configured: true,
      enabled: true,
      aspectRatios: ['2:3'],
      resolutions: ['1K'],
      maxReferences: 8,
    },
    references: [{ id: 'logo' }],
  };
  const published = [];
  const nativeContracts = compatibility
    ? await import(pathToFileURL(join(project, 'tools/service-host.mjs')).href)
    : undefined;
  for (const namespace of compatibility ? ['platform', 'design', 'sitoo'] : ['design', 'studio']) {
    const application = namespace === 'studio' || namespace === 'sitoo';
    const native = namespace === 'platform';
    const directory = join(project, namespace);
    await mkdir(directory);
    const sources = native
      ? {}
      : application
        ? {
            'index.html':
              '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>设计方案校验</title><h1>设计方案校验</h1><p>只检查输入快照，不生成图片，也不授予执行权限。</p><label>方案和当前参数<textarea id="input" rows="18" cols="70"></textarea></label><button id="run">校验方案</button><button id="history">原任务历史</button><pre id="result">等待操作</pre><script src="sdk.js"></script><script src="app.js"></script></html>',
            'sdk.js': await readFile(join(project, 'sdk.js'), 'utf8'),
            'app.js': `const client=SitooCapabilitySdk.createCapabilityClient(window.sitooDevelopmentTasks);const editor=document.querySelector('#input');editor.value=${JSON.stringify(JSON.stringify(example, null, 2))};const output=document.querySelector('#result');document.querySelector('#run').onclick=async()=>{try{window.lastReply=await client.submit({protocolVersion:1,requestId:crypto.randomUUID(),capabilityId:'design/validate-plan',input:JSON.parse(editor.value)});if(window.lastReply.ok){window.lastTask=window.lastReply.value.taskId;for(let i=0;i<100;i++){window.lastReply=await client.get(window.lastTask);if(!window.lastReply.ok||['completed','failed','unknown','cancelled'].includes(window.lastReply.value.status))break;await new Promise(r=>setTimeout(r,100));}}output.textContent=JSON.stringify(window.lastReply,null,2);}catch{output.textContent='输入必须是合法 JSON。';}};document.querySelector('#history').onclick=async()=>{window.historyReply=await client.list();output.textContent=JSON.stringify(window.historyReply,null,2);};`,
          }
        : { 'main.guest': await readFile(join(project, 'payload/main.guest'), 'utf8') };
    for (const [file, content] of Object.entries(sources))
      await writeFile(join(directory, file), content, { flag: 'wx' });
    const schemas = JSON.parse(await readFile(join(project, 'payload/schemas.json'), 'utf8'));
    await json(join(directory, 'capability-package.json'), {
      formatVersion: 1,
      execution: native
        ? 'host-service-v1'
        : application
          ? 'static-application-v1'
          : 'quickjs-function-v1',
      packageId: native
        ? 'platform/services'
        : application
          ? compatibility
            ? 'sitoo/design'
            : 'studio/application'
          : 'design/policy',
      version: '1.0.0',
      dependencies: application
        ? [
            { packageId: 'design/policy', range: '1.0.0' },
            ...(compatibility ? [{ packageId: 'platform/services', range: '1.0.0' }] : []),
          ]
        : [],
      ...(application
        ? {
            application: {
              applicationId: compatibility ? 'sitoo.design' : 'studio.product',
              entry: 'index.html',
            },
          }
        : {}),
      capabilities: native
        ? ['platform/text-request', 'platform/image-request'].map((capabilityId) => {
            const { binding, ...contract } = nativeContracts.requestCapabilityDeclaration({
              capabilityId,
              packageId: 'platform/services',
              version: '1.0.0',
              sha256: 'a'.repeat(64),
            });
            return { capabilityId: binding.capabilityId, ...contract };
          })
        : application
          ? []
          : [
              {
                capabilityId: 'design/validate-plan',
                source: 'main.guest',
                interfaceVersion: 1,
                ...schemas,
                permissions: ['text:read'],
                allowedEntries: ['application', 'conversation'],
                delegates: [],
                effects: { billable: false, externalWrite: false },
              },
            ],
      files: Object.entries(sources).map(([path, content]) => ({
        path,
        bytes: Buffer.byteLength(content),
        sha256: createHash('sha256').update(content).digest('hex'),
      })),
    });
    const metadata = join(project, namespace + '.signing.json');
    const attestation = join(project, namespace + '.attestation.json');
    await json(metadata, {
      keyId: namespace,
      environment: 'development',
      issuedAt: Date.now(),
      expiresAt: Date.now() + 3600000,
    });
    run('sign', directory, join(project, 'keys', namespace + '.pem'), metadata, attestation);
    published.push(
      run('publish', directory, attestation, join(project, 'trust.json'), resolve(args[0])),
    );
  }
  console.log(JSON.stringify({ published }));
} else {
  throw new Error(
    'Usage: init <new-project> <portable-package-tools> <browser-sdk.js> <built-payload> | publish <project> <release-db>',
  );
}
