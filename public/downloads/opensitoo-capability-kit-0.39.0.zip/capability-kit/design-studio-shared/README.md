# 设计方案共享校验示例

本目录是独立开发示例。设计工作室原校验源码生成 QuickJS 发布物，独立发布者只依赖 Node 内置模块、可搬运包 CLI、浏览器 SDK 和已构建的 payload，不导入平台源码。

仓库开发者先执行 `node examples/design-studio-shared/build.mjs`；`node scripts/capability-kit.mjs` 也会构建并携带本示例。把 publisher.mjs、payload、工具目录与 SDK 复制到仓库外后执行：

```powershell
node publisher.mjs init C:\Temp\new-design-project C:\tools\capability-packages C:\tools\capability-kit\capability-sdk.js C:\tools\capability-kit\design-studio-shared\payload
node publisher.mjs publish C:\Temp\new-design-project C:\Temp\design-releases.sqlite
```

init 拒绝覆盖已有项目，生成的私钥只保留在新项目 keys 中；开发信任不是生产身份认证。publish 生成 design/policy 与 studio/application 的签名 1.0.0 发布物。安装需可信宿主使用原 prepare/commit、精确引用和按入口授权，页面不能执行这些管理操作。

能力 design/validate-plan 接收方案、参数、参考图 ID 的输入快照。它没有模型、密钥、图片数据或执行生图权限；valid 只表示快照符合方案策略，不是当前平台授权。对话调用需要已确认的结构化参数，本例没有自然语言规划器。

仓库维护时执行 `node scripts/verify-design-studio-shared.mjs`；`--browser` 使用已有 SITOO_TEST_PLAYWRIGHT_MODULE/SITOO_TEST_CHROMIUM，不安装浏览器。共享页面是独立校验消费者。

R05 兼容模式在上述 `init` 和 `publish` 命令中都加 `--compat`，发布 `platform/services` 结构化请求声明、`design/policy` 与同应用 ID 的 `sitoo.design` 根包。声明通过随包 `tools/service-host.mjs` 的公共助手生成；发布者不携带或实现 Desktop 原生模型服务。原设计工作室 0.4.6 `.spkg` 使用这些已安装能力，安装根包与按入口授权仍由可信 Desktop 用户完成。开发信任密钥仅用于本地验收，不代表生产发布身份。完整原界面迁移验收见R05记录，本地无费用验收已通过。

仓库文档：共享校验手册 · 交付证据 · 总目录。随包副本不携带这些仓库相对链接。
