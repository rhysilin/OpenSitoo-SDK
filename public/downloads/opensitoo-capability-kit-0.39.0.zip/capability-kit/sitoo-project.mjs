import { cp, mkdir, access } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const [command, destination, ...extra] = process.argv.slice(2);
if (command !== 'create' || !destination || extra.length) {
  console.error('Usage: node sitoo-project.mjs create <new-directory>');
  process.exitCode = 1;
} else {
  // Distributed beside the SDK and starter template; no repository/package resolver.
  const kit = fileURLToPath(new URL('.', import.meta.url));
  const output = resolve(destination);
  for (const name of ['starter-template', 'capability-sdk.js', 'capability-sdk.mjs'])
    await access(join(kit, name));
  await mkdir(output); // EEXIST refuses existing directories and links before any copying.
  await cp(join(kit, 'starter-template/README.md'), join(output, 'README.md'));
  for (const project of ['core', 'app-a', 'app-b']) {
    await cp(join(kit, 'starter-template', project), join(output, project), {
      recursive: true,
      errorOnExist: true,
      force: false,
    });
    await cp(join(kit, 'starter-template/build.mjs'), join(output, project, 'build.mjs'));
  }
  for (const application of ['app-a', 'app-b']) {
    await cp(join(kit, 'capability-sdk.js'), join(output, application, 'src/sdk.js'));
    await cp(join(kit, 'capability-sdk.mjs'), join(output, application, 'capability-sdk.mjs'));
    await cp(join(kit, 'starter-template/client.mjs'), join(output, application, 'client.mjs'));
  }
  console.log(
    JSON.stringify({ created: output, projects: ['core', 'app-a', 'app-b'], grantsCreated: false }),
  );
}
