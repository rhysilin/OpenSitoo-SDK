# 可信公共服务适配

E3-R06独立多应用开发与CI。

E3-R04图片服务及原任务产物交付。

E3-R03产品宿主服务交付。

E3-R02原请求账本交付。

E3-R01持久引用交付。

第二十四批固定开发客户端确认与核对。

第二十三批签名宿主服务 · 服务适配。

返回总目录 · 当前状态 · 本批交付 · 引用与确认 · 工具包 · 独立样例

维护日期：2026-10-10。references0.5.1、开发宿主0.19.0、工具包0.34.0。以下是可信Node宿主接口，应用继续使用SDK任务。未发布公共npm；不是浏览器、Guest、HTTP或Desktop IPC接口。

## 两个独立端口

可信宿主用 `references.issueModelProvider(scope, {infer, query?}, referenceId?)` 选择提供者，返回四维scope绑定的不可变UUID。infer沿用 `(prompt, context, requestId, signal?) => Promise<JsonValue>`；context由Broker绑定，执行必须经过当前授权和原任务的一次确认。

query为 `(prompt, scope, requestId, signal?) => Promise<JsonValue>`，只查原请求。scope是冻结的tenantId/environment/installationId/consumerAppId，不带应用可覆盖的模型名、URL或凭据。实现须按原scope、requestId、引用对应的不可变服务配置和prompt找结果，不能调用infer/generate、重新提交或重新记费。找不到、结果尚未知、上游不可用时抛错；不要返回一个虚构的成功值或终态错误。

回调在签发时选定；后续改写传入对象不会替换引用的回调。原issueModel(scope,infer,id?)兼容，相当于仅有infer的Provider；没有query时无法恢复上游结果，保持unknown。

`references.queryModel(scope, request, signal?)` 返回原JsonValue；要求原platform/infer请求及仅有referenceId/prompt的合法输入。跨scope、错误kind、缺失/撤销、取消、查询异常或查询期间撤销均抛 `Error('Original model result unavailable.')`，不暴露上游错误、路径或凭据，不回退infer。该低层方法不负责会话授权、任务指纹或输出schema，应用不得直接调用。

## 可搬运宿主模块

工具包中的service-host.mjs合并导出CapabilityBroker、CapabilityTasks、CapabilityReferences和createModelTaskQuery，模块外部依赖仅Node24内置模块，无仓库、Desktop、Pi或node_modules依赖；实际Guest执行还需同工具包的worker.mjs与quickjs.wasm侧车。使用同一模块导出的Broker/Tasks，保持不透明会话和审批凭证属于同一实现实例。

```js
import {
  CapabilityBroker,
  CapabilityTasks,
  CapabilityReferences,
  createModelTaskQuery,
} from './service-host.mjs';
// 只在可信宿主配置层创建/注册；scope、绑定、授予和Provider均来自该层。
const references = new CapabilityReferences();
const broker = new CapabilityBroker();
references.registerCapabilities(broker, trustedBindings);
const modelId = references.issueModelProvider(trustedScope, trustedProvider);
const tasks = new CapabilityTasks({
  path: trustedTaskDatabase,
  broker,
  allowEffects: true,
  query: createModelTaskQuery(references),
});
```

createModelTaskQuery(references):TaskQuery仅处理platform/infer，检查任务/原请求ID与当前精确绑定，再交给queryModel。Task管理器先复核会话、owner、当前授权、原请求/绑定指纹，并在查询后复核revision和输出；查询失败返回RESULT_UNKNOWN，保留原任务/pin。其他能力若需要查询，宿主明确组合自己的查询端口，不把未知能力送入此模型端口。工作区对应导出路径为 `@sitoo/capability-dev-host/services`。

确认由可信操作者查看原计划后调用approve，不能把allowEffects、批准动作或Provider回调交给应用。端口不添加隐式grants、不继承父任务确认，也不改变SDK/wire/schema。旧API引用仍为内存表；显式持久引用见R01，持久原请求适配见下节；生产额度与真实上游结果保障需另外验证。

## 无费用验收与当前边界

复制工具包后运行 `node verify-service-provider.mjs`。样例使用真实Broker/Tasks/引用、SQLite原账本和模拟Provider，验证确认前拒绝、一次执行后丢响应、重开任务库、不可查询时保留unknown/pin、原结果恢复、去重、跨应用拒绝和撤销。它是可信服务集成样例，不能当成生产模型连接器。

仓库门禁 `node scripts/verify-service-provider.mjs` 只将两个mjs复制到仓库外再启动独立Node进程，清除NODE_PATH/NODE_OPTIONS。原init-fixtures HTTP账本也改用同一Provider/query适配，兼容重启、审批与原请求查询门禁。

已安装v3现在可显式依赖host-service-v1签名声明包；精确可信实现与原授权/租约已接入。默认CLI没有原生实现，缺失时拒绝启动。下一步验证旧应用的公共引用/结果兼容与真实平台适配。E3进行中，真实收费服务、完整旧应用迁移及托管CI仍待证据。

## 已安装宿主服务（0.14.0）

声明包execution为host-service-v1、formatVersion为1；files必须为空、capabilities非空且不含source，其余字段沿用原接口/schema/权限/入口/delegates/effects。无模块路径、凭据、URL或代码载荷。声明摘要只认证接口包内容，不是原生实现代码摘要；实现由可信宿主另行提供，宿主版本/配置和生产实现来源保障分别管理。应用manifest显式声明依赖，可信操作者用原inspect/sign/publish/install方法发布安装；来源签名不等于授权，原授权账本仍分别按application/conversation及完整精确bindings授予。声明包可和Guest代码处于同一闭包；Guest依旧通过invoke委托，没有直接Provider权限。

references.createCapabilities({text,model})返回原引用服务的{declaration,execute}数组，描述器仅供可信注册，registerCapabilities沿用它。先用接口声明构建签名包，再用已验证包的真实bindings创建描述器；不能用临时摘要注册实际服务。

prepareInstalledHost(rootDirectory,config,broker,runtime,services=[])新增InstalledHostService数组，最多32项、只在v3启用。每项declaration和execute匹配签名安装计划的完整声明及精确capabilityId/packageId/version/sha256；初始化固定回调和声明快照。缺失、重复、多余实现或声明不一致均拒绝。纯Guest继续实际编译；接口声明不送入QuickJS。原授权、信任、租约获取及执行检查保持；unknown租约保护应用、Guest和原生接口包，无TTL释放。返回的validateCaller(caller)检查授权修订、当前信任与完整bindings，供可信原结果查询复核。

便携service-host.mjs同时导出安装/授权/签名/发布类、CapabilityRuntime、prepareInstalledHost和startDevelopmentHost，均为可信Node端口。HTTP宿主使用以下可选参数：

```js
await startDevelopmentHost({
  configPath,
  dataDirectory, // 原v3文件，消费者不携带grants或服务实现
  installedServices: references.createCapabilities(trustedSignedBindings),
  taskQuery: createModelTaskQuery(references),
  confirmationToken: trustedOperatorToken,
});
```

installedServices非空时必须提供独立64位小写十六进制操作者token，不能等于任何消费token；taskQuery若给出必须为函数。它们只从可信函数参数读取，不允许host.json/包/HTTP body选择执行器。引用owner与原可信policy一致；installationId沿用原根tenantId/accountId/applicationId/environment四元组JSON的SHA256，不从应用输入采用身份。

GET/POST原/v1/confirmations/:taskId仍需消费Bearer和X-Fixture-Confirmation独立凭据，POST仅revision；该历史header在开发宿主保留，不代表生产审批。无批准时submit只持久化needs-approval。原/v1/conversation/tools可发现已授权原生收费声明，prepare/propose可校验副作用计划但不执行或批准。taskQuery调用前后复核当前授权/信任/完整bindings，查询期间撤权不接受结果、保留unknown/pin；跨入口单独grants不自动继承。撤权后只读原任务查询沿用既有规则，上游查询不重跑。

复制工具包以及包CLI后运行node verify-installed-services.mjs；仓库入口node scripts/verify-installed-services.mjs自动复制到仓库外。11项门禁使用真实签名安装、SQLite任务/租约、QuickJS与浏览器SDK协议，Provider及上游结果账本是零费用内存夹具；宿主在同一测试进程中关闭重建，不代表原生服务的真实进程强退或生产账本持久性。服务1.1.0更新须显式新授权和精确新实现，另一应用保留1.0.0；旧终态结果保留。真实模型/生图、正式生产确认和完整旧应用迁移继续单独验收。

## 固定开发客户端的任务确认与核对（0.15.0）

打开本机开发宿主的 /development/operator，或在未打包Desktop的能力开发窗口点击“打开任务确认与核对”。输入对应入口的消费令牌与独立操作者密钥，两者不得相同；连接后输入框清空，凭据只保留在模块内存，断开会中止窗口请求、清除任务与确认显示。该页面不加载应用代码，不提供生产管理桥或业务执行器。

选择原任务后，needs-approval显示原capability/package/version/hash、请求参数与revision；操作者逐次点击“确认本次调用”，复用GET/POST /v1/confirmations/:taskId和历史X-Fixture-Confirmation头。原任务unknown才开放“核对原结果”，复用POST /v1/tasks/:taskId/reconcile。查询失败保留unknown及租约，不调用infer；确认响应丢失时刷新原任务，不能重复提交新请求。结果均用textContent渲染，不执行参数或结果内的HTML。两入口分别读取当前应用摘要或对话计划摘要，原身份/安装/授权检查保持。

这是可信开发操作者界面；消费令牌没有自我确认能力，操作者密钥不传到应用iframe或SDK。此为第二十四批当时限制；普通产品当前由R03/R04接入签名原生服务。生产登录、计费额度、不可变引用持久映射和原生实现来源仍需后续接入。SDK0.0.9、Tasks0.4.0、wire/schema保持，无旧数据迁移。

仓库外真实服务验收：node scripts/verify-installed-services.mjs --client，需要已有SITOO_TEST_PLAYWRIGHT_MODULE和已构建Desktop；驱动仅用于验收，样例通过可信测试环境变量加载，不接受包/HTTP配置。无费用Provider账本仍在内存，宿主重建仍同进程，不能当成生产恢复证明。见第二十四批证据。

## 持久引用接入（references0.5.0）

service-host.mjs同步导出CapabilityReferenceStore。可信宿主显式配置独立引用库并签发持久UUID；重开后必须按原Provider标识/修订显式绑定回调，应用仍只通过原SDK提交任务。默认内存API不迁移，回调与凭据不落库。真实参数、schema/预算、撤销和兼容规则只在引用手册维护。

随包verify-persistent-references.mjs提供仓库外真实进程强退与引用重开门禁，费用0；见R01交付。该门禁只证明引用持久性；原请求结果恢复采用以下R02适配，普通产品Provider接入属于R03。

## 持久原请求适配（宿主0.17.0）

从 `@sitoo/capability-dev-host/services` 或随包 `service-host.mjs` 导入 ModelRequestLedger、createDurableModelProvider。它们只供可信Node初始化层使用；不能把文件路径、scope、精确binding、Provider回调、URL或凭据交由包、应用、Guest或HTTP body配置。旧内存Provider及引用API保持，无自动迁移。

ModelRequestIdentity字段：scope为tenantId/environment/installationId/consumerAppId，entry为application/conversation/service，binding为原platform/infer的capabilityId/packageId/version/sha256，referenceId与requestId为合法UUID，prompt最多2000个Unicode码点，providerId为1–192字符的字母数字及`._:/-`标识，providerRevision为正安全整数。账户隔离依赖可信宿主原四元组根身份派生的installationId。库规范化并复制这些字段，不保存函数或密钥。

| 方法                             | 结果与约束                                                                                                                                                                                                         |
| -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| new ModelRequestLedger(filename) | 独立SQLite schema1，WAL与synchronous=FULL；已有其他表或版本拒绝，不迁移旧任务/引用库                                                                                                                               |
| reserve(identity)                | 返回`{created,record}`；事务先持久化原身份、规范化`{referenceId,prompt}` JSON的inputSha256及新upstreamRequestId，再允许首次infer。原owner/requestId相同但任一身份字段变化时抛错；相同身份返回原记录且created=false |
| read(scope,requestId)            | 原owner记录快照或undefined；record含全部identity、inputSha256、upstreamRequestId、status以及completed时的result                                                                                                    |
| complete(identity,result)        | 只为匹配的原身份保存首个合法wire JsonValue结果并返回结果；相同结果幂等，不同结果抛错；对象快照不共享数据库可变值                                                                                                   |
| close()                          | 关闭库；由可信宿主负责生命周期                                                                                                                                                                                     |

每库4096条历史记录，包含completed；没有TTL、删除或自动回收接口。记录status=dispatched表示持久占用了派发机会，**不证明上游实际执行**；complete只记录可信适配器提供的原结果，无法认证上游来源。数据库保存明文prompt及result，需宿主已有文件访问保护；本版本没有生产加密、配额或原生实现来源保障。SQLite写入失败时不执行infer；若上游执行后本地complete失败，原任务沿Tasks失败路径保持unknown，需要query核对，不能新派发。

```js
const ledger = new ModelRequestLedger(trustedLedgerPath);
const provider = createDurableModelProvider({
  ledger,
  references: referenceStore, // R01 CapabilityReferenceStore
  scope: trustedScope,
  referenceId: originalModelId,
  binding: originalSignedModelBinding,
  upstream: {
    infer: (record, signal) => trustedInference(record, signal),
    query: (record, signal) => trustedOriginalLookup(record, signal),
  },
});
references.bindPersistentModelProvider(
  trustedScope,
  originalModelId,
  originalProviderId,
  originalProviderRevision,
  provider,
);
// 原startDevelopmentHost安装/授权/租约与createModelTaskQuery配置保持。
```

createDurableModelProvider要求活动且kind=model的持久引用，初始化固定原scope/binding及引用中的Provider标识/修订、infer/query两个函数。infer检查调用scope与执行包，reserve创建成功才调用upstream.infer；已有dispatched直接抛错，已有completed返回原结果，不会执行第二次。query检查原scope/requestId、prompt、引用、Provider和binding，仅向upstream.query传递原记录；已保存结果直接返回。缺失/异常/撤销/取消/冲突/超预算均抛Error；低层错误不作为公共协议，原References/Tasks继续转换FORBIDDEN或RESULT_UNKNOWN。

上游两函数必须使用record.upstreamRequestId关联同一原请求，query绝不执行infer、生成、重提交或重新记费。记录在网络派发前存在时即可查询；上游查不到意味着证据不足，不能补跑。该通用库不提供具体模型网络连接器，也不担保跨平台恰好一次执行；它保证本地原请求最多尝试一次infer，牺牲未派发原请求的自动重试来保留未知状态。

低层query只有四维scope，不单独认证登录/入口/授权；Tasks验证原请求、任务指纹与入口，v3 installed.validateCaller在query前后复核授权修订、签名信任及完整bindings。查询期间撤权即使库已保存原结果，也不能完成原任务或释放pin；显式重新授权并重建宿主后再次reconcile才可接受原结果。引用撤销则在库complete前再次检查，不接受返回。保留unknown时更新、卸载和回收继续遵循原完整租约，不能绕过pin。

完整工具包复制到仓库外运行 `node verify-model-ledger.mjs`；仓库入口 `node scripts/verify-model-ledger.mjs`。独立HTTP/SQLite上游保持运行，真实SIGKILL服务宿主两次并重开原引用、模型及任务库：分别验证上游效果已持久但本地无结果、派发占用已持久但上游无效果。还覆盖查询不可用、查询中撤权、显式重新授权、异主读/核对、重复提交、完整pin阻止更新/卸载/回收及单次释放；推理1次、查询3次、模型费用0。见R02交付。这是实际本地进程证据与无费用上游夹具，生产模型/计费与R03产品接入仍待验。

## 普通产品账户宿主（R03）

开发客户端的已签名 `platform/read-text` / `platform/infer` 包使用固定可信实现；原生服务由主进程账户拥有，纯Guest仍是独立子进程。业务页面/对话只有原SDK/HTTP消费者端口，主窗口才能发行、撤销引用及逐次确认。账户变化关闭窗口和服务；安装授权、信任及原绑定在实际模型转发前再次复核。

模型引用保存 `newapi/<AppTextModel.id>` 和适配修订1，不保存密钥或URL。id来自既有账户通道/模型选择；它不是远端提供商配置或价格的不可变快照。确认展示当前模型名、通道、价格和1024 tokens输出上限。R02账本保存原输入及上游UUID，query只读取原AppText任务，unknown没有证明不重发。

仅开发模式开放，正式打包默认拒绝。`PI_MARKET_SHARED_TEXT_FIXTURE=1` 仅供可信本机验收启动者选择无费用文本夹具；应用不能配置它，正式包忽略它。Electron验收通过真实安装授权、React引用管理、SDK及任务端口；原生对话框的取消/确认由测试进程替代回调，未声称点击操作系统按钮或生产收费对账。

## 通用图片及原任务产物（R04）

可信Node导出 `imageCapabilityDeclaration(binding)` 与 `createImageService({binding,store,ledger,upstream})`；binding必须是platform/generate-image，返回declaration/execute/query。声明接受{referenceId,prompt}，提示词1–2000字符；权限model:infer及resource:read，billable，页面/对话/service入口，不能委托收费操作。输出仅{imageTaskId,artifactId}，不得放URL/凭据/大图片。受控引用沿原kind:model、image/<配置SHA256>/修订1持久存储，配置由账户用户明确选择，应用只持有UUID。

复用原ModelRequestLedger，现允许platform/generate-image的精确绑定，schema1及旧模型行为不变。原任务占用和上游UUID在派发前保存；query只原关联。普通产品复用SitooImageService，内部generate第四参数{revision,authorize}仅可信已批准原调用使用，原AppImages三参数及旧工作台确认不变。图片配置SHA包含原revision/模型/分组/画幅/分辨率，变化拒绝旧引用的新生成；历史结果读取无需重新开启或生成。

startDevelopmentHost新增可信taskArtifact(task,scope)端口，仅已完成原platform/generate-image任务、当前resource:read与原安装授权/信任/完整绑定复核后调用，返回{mimeType:image/png,dataUrl}，前后校验，最多16MiB图片。应用不能注册回调或选择本机路径。读取不释放其他unknown任务pin，不重试生成。缺失缓存保留原结果，稍后只查/缓存，不生产第二次副作用。

开发验收env PI_MARKET_SHARED_IMAGE_FIXTURE=1选择零费本地图片传输夹具，应用/正式包不能启用；旧实际网关Provider保持。当前公共生成只传prompt和可信配置，设计参考图输入等迁移已由R05结构化请求补齐，旧短接口保持。

## R05 结构化旧请求

services模块新增createRequestService与requestCapabilityDeclaration，平台text-request/image-request承接原完整业务参数。短接口仍保持，账本schema1仍兼容；固定调用者/Provider/原上游关联及独立确认规则不变。详情见API及本轮兼容记录。

## 结构化请求公开分发验证

Node24在复制后的工具包执行node verify-request-services.mjs。text-request保持prompt/instructions/maxTokens/responseSchema，image-request保持prompt/aspectRatio/resolution/受控附件描述；opaque reference由可信调用者提供。原请求一次派发，账本重开只查询同一upstreamRequestId；不可查不补跑，错应用/撤销拒绝。本脚本零费用、同进程账本重开；真正宿主强退另见verify-model-ledger.mjs。SDK/HTTP接口保持原R05契约。

[返回工具包说明](./README.md)
