import { readFile, writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
const [url, proposalPath, text] = process.argv.slice(2);
const origin = new URL(url);
if (
  origin.protocol !== 'http:' ||
  origin.hostname !== '127.0.0.1' ||
  origin.pathname !== '/' ||
  origin.username ||
  origin.password ||
  origin.search ||
  origin.hash
)
  throw new Error('Expected loopback development host.');
const token = process.env.SITOO_CONVERSATION_TOKEN;
if (!/^[a-f0-9]{64}$/.test(token ?? '')) throw new Error('Missing conversation token.');
const call = async (path, input, pin) => {
  const response = await fetch(new URL(path, origin), {
    method: input === undefined ? 'GET' : 'POST',
    headers: {
      authorization: 'Bearer ' + token,
      'content-type': 'application/json',
      ...(pin ? { 'x-sitoo-conversation': pin } : {}),
    },
    body: input === undefined ? undefined : JSON.stringify(input),
    signal: AbortSignal.timeout(path === '/v1/conversation/plan' ? 35000 : 10000),
  });
  const result = await response.json();
  if (!result.ok) throw new Error(result.error?.code ?? 'UNAVAILABLE');
  return result.value;
};
let saved;
try {
  saved = JSON.parse(await readFile(proposalPath, 'utf8'));
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
  if (text === undefined) throw new Error('Text required for a new proposal.');
  saved = {
    text,
    proposal: await call('/v1/conversation/plan', { requestId: randomUUID(), text }),
  };
  // Persist the exact proposal before any business dispatch. A retry never replans.
  await writeFile(proposalPath, JSON.stringify(saved), { flag: 'wx', mode: 0o600 });
}
if (text !== undefined && text !== saved.text) throw new Error('Existing proposal cannot change.');
const task = await call('/v1/tasks', saved.proposal.request, saved.proposal.planSha256);
console.log(JSON.stringify({ ok: true, value: await call('/v1/tasks/' + task.taskId) }));
