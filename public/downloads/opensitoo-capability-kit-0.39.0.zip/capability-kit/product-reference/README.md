# 固定客户端的独立发布示例

[返回文档总目录](../README.md) · 当前状态 · [从零接入手册](../fixed-client.md) · 第十三批证据

Node 24；当前便携包工具 0.10.0、能力 SDK 0.0.11、开发工具包 0.35.0；用于未打包 Desktop 0.0.31 的 development 验收。原第十三批使用0.0.15的证据仍为历史快照。示例只使用 Node 内置模块、复制后的公开 CLI 和浏览器 SDK，没有平台源码、Pi/Electron 或 node_modules 依赖。当前随公开工具包分发，不从平台源码目录接入业务。

```powershell
node publisher.mjs init C:/dev/product-example C:/dev/capability-packages C:/dev/capability-kit/capability-sdk.js
node publisher.mjs publish C:/dev/product-example 1.0.0 C:/dev/product-example/releases.sqlite
# 用户已在固定客户端安装并运行 v1 后，独立开发者发布修复版本：
node publisher.mjs publish C:/dev/product-example 1.1.0 <可信操作者提供的开发发布库路径>
```

init 拒绝覆盖已有目录；publish 每版构建独立目录，重复构建拒绝覆盖。三名演示发布者独立签名：alice 发布共享文本能力，bob/carol 发布各自页面，精确依赖同一 alice 版本。1.1.0 将真实能力结果加上 V2；两个入口通过同一能力执行。每个发布物使用原包格式、完整摘要、现有 sign/publish；签名元数据和 attestation 留在包目录外，避免未声明文件污染包。

keys/ 中的私钥仅是本机测试凭据，不提交、不发送给应用；Windows mode 不代替 ACL。示例 trust.json 是开发演示信任，不能自行获得平台或生产信任。项目配置和发布库由可信操作者接入，应用不能选择账户目录、授权或令牌。出版不是安装、批准或自动更新，客户端仍分别确认代码操作和入口授权。

自动验收：`node scripts/verify-desktop-shared-installations.mjs --external`，需先生成工具包、包工具及 Desktop，并配置现有 Playwright 模块。脚本在专用临时目录执行本示例，CLI 子进程的 cwd/依赖都在仓库外，清除 NODE_PATH/NODE_OPTIONS。开发 SDK 使用公开分发文件；主窗口仍使用真实登录身份。完整操作流程、可信操作者初始化和恢复限制见手册。
