import { mkdir, readFile, writeFile, cp } from 'node:fs/promises';
import { createHash, generateKeyPairSync } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { resolve, join } from 'node:path';

// Independent developer example: Node built-ins and the copied public package CLI only.
const [command, projectArgument, ...args] = process.argv.slice(2);
const project = resolve(projectArgument ?? '.');
const json = async (file, value) =>
  writeFile(file, JSON.stringify(value, null, 2), { flag: 'wx', mode: 0o600 });
if (command === 'init' && args.length === 2) {
  await mkdir(project); // Never overlay an existing project.
  await cp(resolve(args[0]), join(project, 'tools'), { recursive: true });
  await cp(resolve(args[1]), join(project, 'capability-sdk.js'));
  await mkdir(join(project, 'keys'));
  const policies = [];
  for (const namespace of ['alice', 'bob', 'carol']) {
    const keys = generateKeyPairSync('ed25519');
    await writeFile(
      join(project, 'keys', namespace + '.pem'),
      keys.privateKey.export({ type: 'pkcs8', format: 'pem' }),
      { flag: 'wx', mode: 0o600 },
    );
    policies.push({
      keyId: namespace,
      namespace,
      environments: ['development'],
      publicKeyPem: keys.publicKey.export({ type: 'spki', format: 'pem' }).toString(),
      notBefore: Date.now() - 1000,
      notAfter: Date.now() + 86400000,
      revoked: false,
    });
  }
  await json(join(project, 'trust.json'), policies);
  console.log(JSON.stringify({ initialized: true }));
} else if (command === 'publish' && args.length === 2) {
  const [version, databaseArgument] = args;
  if (!['1.0.0', '1.1.0'].includes(version)) throw new Error('Expected 1.0.0 or 1.1.0.');
  const database = resolve(databaseArgument);
  const environment = { ...process.env };
  delete environment.NODE_PATH;
  delete environment.NODE_OPTIONS;
  const run = (...parameters) => {
    const result = JSON.parse(
      execFileSync(
        process.execPath,
        [join(project, 'tools/capability-packages.mjs'), ...parameters],
        {
          cwd: project,
          env: environment,
          windowsHide: true,
          encoding: 'utf8',
          timeout: 20000,
          stdio: ['ignore', 'pipe', 'pipe'],
        },
      ),
    );
    if (!result.ok) throw new Error(result.error.code);
    return result.value;
  };
  const published = [];
  for (const namespace of ['alice', 'bob', 'carol']) {
    const application = namespace !== 'alice';
    const directory = join(project, namespace + '-' + version);
    await mkdir(directory);
    const sources = application
      ? {
          'index.html': `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><h1>${namespace} 独立共享文本应用</h1><label>文本<input id="text" value=" hello shared "></label><button id="run">处理文本</button><button id="history">查看原任务</button><pre id="result">等待操作</pre><script src="sdk.js"></script><script src="app.js"></script></html>`,
          'sdk.js': await readFile(join(project, 'capability-sdk.js'), 'utf8'),
          'app.js': `const client=SitooCapabilitySdk.createCapabilityClient(window.sitooDevelopmentTasks);const result=document.querySelector('#result');document.querySelector('#run').onclick=async()=>{const reply=await client.submit({protocolVersion:1,requestId:crypto.randomUUID(),capabilityId:'alice/echo',input:{consumer:${JSON.stringify(namespace)},text:document.querySelector('#text').value}});window.lastReply=reply;if(reply.ok){window.lastTask=reply.value.taskId;for(let i=0;i<100;i++){const current=await client.get(window.lastTask);window.lastReply=current;if(!current.ok||['completed','failed','unknown','cancelled'].includes(current.value.status))break;await new Promise(r=>setTimeout(r,100))}}result.textContent=JSON.stringify(window.lastReply,null,2)};document.querySelector('#history').onclick=async()=>{window.historyReply=await client.list();result.textContent=JSON.stringify(window.historyReply,null,2)};`,
        }
      : {
          'main.guest': `return {consumer:input.consumer,text:${version === '1.1.0' ? '"V2 "+' : ''}input.text.trim().toUpperCase()};`,
        };
    for (const [file, content] of Object.entries(sources))
      await writeFile(join(directory, file), content, { flag: 'wx' });
    const schema = {
      type: 'object',
      properties: { text: { type: 'string' }, consumer: { type: 'string' } },
      required: ['text', 'consumer'],
      additionalProperties: false,
    };
    await json(join(directory, 'capability-package.json'), {
      formatVersion: 1,
      execution: application ? 'static-application-v1' : 'quickjs-function-v1',
      packageId: namespace + (application ? '/application' : '/shared'),
      version,
      dependencies: application ? [{ packageId: 'alice/shared', range: version }] : [],
      ...(application
        ? { application: { applicationId: namespace + '.product', entry: 'index.html' } }
        : {}),
      capabilities: application
        ? []
        : [
            {
              capabilityId: 'alice/echo',
              source: 'main.guest',
              interfaceVersion: 1,
              inputSchema: schema,
              outputSchema: schema,
              permissions: ['text:read'],
              allowedEntries: ['application', 'conversation'],
              delegates: [],
              effects: { billable: false, externalWrite: false },
            },
          ],
      files: Object.entries(sources).map(([path, content]) => ({
        path,
        bytes: Buffer.byteLength(content),
        sha256: createHash('sha256').update(content).digest('hex'),
      })),
    });
    const metadata = join(project, namespace + '-' + version + '.signing.json'),
      attestation = join(project, namespace + '-' + version + '.attestation.json');
    await json(metadata, {
      keyId: namespace,
      environment: 'development',
      issuedAt: Date.now(),
      expiresAt: Date.now() + 3600000,
    });
    run('sign', directory, join(project, 'keys', namespace + '.pem'), metadata, attestation);
    published.push(run('publish', directory, attestation, join(project, 'trust.json'), database));
  }
  console.log(JSON.stringify({ published }));
} else {
  throw new Error(
    'Usage: init <new-project> <portable-package-tools> <browser-sdk.js> | publish <project> <version> <release-db>',
  );
}
