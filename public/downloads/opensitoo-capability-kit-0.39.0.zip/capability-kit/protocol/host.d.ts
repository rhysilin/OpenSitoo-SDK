/** Trusted broker context only. Possessing these types does not grant authority. */
export interface CapabilityHostContext {
    tenantId: string;
    environment: 'development' | 'test' | 'production';
    installationId: string;
    consumerAppId: string;
    entry: 'application' | 'conversation' | 'service';
    resolvedPackage: {
        packageId: string;
        version: string;
        sha256: string;
    };
    grants: readonly string[];
    delegation: readonly {
        consumerAppId: string;
        capabilityId: string;
    }[];
}
