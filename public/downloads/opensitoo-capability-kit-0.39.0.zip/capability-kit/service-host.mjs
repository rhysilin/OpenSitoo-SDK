import{createRequire as __createRequire}from'node:module';const require=__createRequire(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/codegen/code.js
var require_code = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/codegen/code.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.regexpCode = exports.getEsmExportName = exports.getProperty = exports.safeStringify = exports.stringify = exports.strConcat = exports.addCodeArg = exports.str = exports._ = exports.nil = exports._Code = exports.Name = exports.IDENTIFIER = exports._CodeOrName = void 0;
    var _CodeOrName = class {
    };
    exports._CodeOrName = _CodeOrName;
    exports.IDENTIFIER = /^[a-z$_][a-z$_0-9]*$/i;
    var Name = class extends _CodeOrName {
      constructor(s) {
        super();
        if (!exports.IDENTIFIER.test(s))
          throw new Error("CodeGen: name must be a valid identifier");
        this.str = s;
      }
      toString() {
        return this.str;
      }
      emptyStr() {
        return false;
      }
      get names() {
        return { [this.str]: 1 };
      }
    };
    exports.Name = Name;
    var _Code = class extends _CodeOrName {
      constructor(code) {
        super();
        this._items = typeof code === "string" ? [code] : code;
      }
      toString() {
        return this.str;
      }
      emptyStr() {
        if (this._items.length > 1)
          return false;
        const item = this._items[0];
        return item === "" || item === '""';
      }
      get str() {
        var _a;
        return (_a = this._str) !== null && _a !== void 0 ? _a : this._str = this._items.reduce((s, c) => `${s}${c}`, "");
      }
      get names() {
        var _a;
        return (_a = this._names) !== null && _a !== void 0 ? _a : this._names = this._items.reduce((names, c) => {
          if (c instanceof Name)
            names[c.str] = (names[c.str] || 0) + 1;
          return names;
        }, {});
      }
    };
    exports._Code = _Code;
    exports.nil = new _Code("");
    function _(strs, ...args) {
      const code = [strs[0]];
      let i = 0;
      while (i < args.length) {
        addCodeArg(code, args[i]);
        code.push(strs[++i]);
      }
      return new _Code(code);
    }
    exports._ = _;
    var plus = new _Code("+");
    function str(strs, ...args) {
      const expr = [safeStringify(strs[0])];
      let i = 0;
      while (i < args.length) {
        expr.push(plus);
        addCodeArg(expr, args[i]);
        expr.push(plus, safeStringify(strs[++i]));
      }
      optimize(expr);
      return new _Code(expr);
    }
    exports.str = str;
    function addCodeArg(code, arg) {
      if (arg instanceof _Code)
        code.push(...arg._items);
      else if (arg instanceof Name)
        code.push(arg);
      else
        code.push(interpolate(arg));
    }
    exports.addCodeArg = addCodeArg;
    function optimize(expr) {
      let i = 1;
      while (i < expr.length - 1) {
        if (expr[i] === plus) {
          const res = mergeExprItems(expr[i - 1], expr[i + 1]);
          if (res !== void 0) {
            expr.splice(i - 1, 3, res);
            continue;
          }
          expr[i++] = "+";
        }
        i++;
      }
    }
    function mergeExprItems(a, b) {
      if (b === '""')
        return a;
      if (a === '""')
        return b;
      if (typeof a == "string") {
        if (b instanceof Name || a[a.length - 1] !== '"')
          return;
        if (typeof b != "string")
          return `${a.slice(0, -1)}${b}"`;
        if (b[0] === '"')
          return a.slice(0, -1) + b.slice(1);
        return;
      }
      if (typeof b == "string" && b[0] === '"' && !(a instanceof Name))
        return `"${a}${b.slice(1)}`;
      return;
    }
    function strConcat(c1, c2) {
      return c2.emptyStr() ? c1 : c1.emptyStr() ? c2 : str`${c1}${c2}`;
    }
    exports.strConcat = strConcat;
    function interpolate(x) {
      return typeof x == "number" || typeof x == "boolean" || x === null ? x : safeStringify(Array.isArray(x) ? x.join(",") : x);
    }
    function stringify(x) {
      return new _Code(safeStringify(x));
    }
    exports.stringify = stringify;
    function safeStringify(x) {
      return JSON.stringify(x).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
    }
    exports.safeStringify = safeStringify;
    function getProperty(key) {
      return typeof key == "string" && exports.IDENTIFIER.test(key) ? new _Code(`.${key}`) : _`[${key}]`;
    }
    exports.getProperty = getProperty;
    function getEsmExportName(key) {
      if (typeof key == "string" && exports.IDENTIFIER.test(key)) {
        return new _Code(`${key}`);
      }
      throw new Error(`CodeGen: invalid export name: ${key}, use explicit $id name mapping`);
    }
    exports.getEsmExportName = getEsmExportName;
    function regexpCode(rx) {
      return new _Code(rx.toString());
    }
    exports.regexpCode = regexpCode;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/codegen/scope.js
var require_scope = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/codegen/scope.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ValueScope = exports.ValueScopeName = exports.Scope = exports.varKinds = exports.UsedValueState = void 0;
    var code_1 = require_code();
    var ValueError = class extends Error {
      constructor(name) {
        super(`CodeGen: "code" for ${name} not defined`);
        this.value = name.value;
      }
    };
    var UsedValueState;
    (function(UsedValueState2) {
      UsedValueState2[UsedValueState2["Started"] = 0] = "Started";
      UsedValueState2[UsedValueState2["Completed"] = 1] = "Completed";
    })(UsedValueState || (exports.UsedValueState = UsedValueState = {}));
    exports.varKinds = {
      const: new code_1.Name("const"),
      let: new code_1.Name("let"),
      var: new code_1.Name("var")
    };
    var Scope = class {
      constructor({ prefixes, parent } = {}) {
        this._names = {};
        this._prefixes = prefixes;
        this._parent = parent;
      }
      toName(nameOrPrefix) {
        return nameOrPrefix instanceof code_1.Name ? nameOrPrefix : this.name(nameOrPrefix);
      }
      name(prefix) {
        return new code_1.Name(this._newName(prefix));
      }
      _newName(prefix) {
        const ng = this._names[prefix] || this._nameGroup(prefix);
        return `${prefix}${ng.index++}`;
      }
      _nameGroup(prefix) {
        var _a, _b;
        if (((_b = (_a = this._parent) === null || _a === void 0 ? void 0 : _a._prefixes) === null || _b === void 0 ? void 0 : _b.has(prefix)) || this._prefixes && !this._prefixes.has(prefix)) {
          throw new Error(`CodeGen: prefix "${prefix}" is not allowed in this scope`);
        }
        return this._names[prefix] = { prefix, index: 0 };
      }
    };
    exports.Scope = Scope;
    var ValueScopeName = class extends code_1.Name {
      constructor(prefix, nameStr) {
        super(nameStr);
        this.prefix = prefix;
      }
      setValue(value, { property, itemIndex }) {
        this.value = value;
        this.scopePath = (0, code_1._)`.${new code_1.Name(property)}[${itemIndex}]`;
      }
    };
    exports.ValueScopeName = ValueScopeName;
    var line = (0, code_1._)`\n`;
    var ValueScope = class extends Scope {
      constructor(opts) {
        super(opts);
        this._values = {};
        this._scope = opts.scope;
        this.opts = { ...opts, _n: opts.lines ? line : code_1.nil };
      }
      get() {
        return this._scope;
      }
      name(prefix) {
        return new ValueScopeName(prefix, this._newName(prefix));
      }
      value(nameOrPrefix, value) {
        var _a;
        if (value.ref === void 0)
          throw new Error("CodeGen: ref must be passed in value");
        const name = this.toName(nameOrPrefix);
        const { prefix } = name;
        const valueKey = (_a = value.key) !== null && _a !== void 0 ? _a : value.ref;
        let vs = this._values[prefix];
        if (vs) {
          const _name = vs.get(valueKey);
          if (_name)
            return _name;
        } else {
          vs = this._values[prefix] = /* @__PURE__ */ new Map();
        }
        vs.set(valueKey, name);
        const s = this._scope[prefix] || (this._scope[prefix] = []);
        const itemIndex = s.length;
        s[itemIndex] = value.ref;
        name.setValue(value, { property: prefix, itemIndex });
        return name;
      }
      getValue(prefix, keyOrRef) {
        const vs = this._values[prefix];
        if (!vs)
          return;
        return vs.get(keyOrRef);
      }
      scopeRefs(scopeName, values = this._values) {
        return this._reduceValues(values, (name) => {
          if (name.scopePath === void 0)
            throw new Error(`CodeGen: name "${name}" has no value`);
          return (0, code_1._)`${scopeName}${name.scopePath}`;
        });
      }
      scopeCode(values = this._values, usedValues, getCode) {
        return this._reduceValues(values, (name) => {
          if (name.value === void 0)
            throw new Error(`CodeGen: name "${name}" has no value`);
          return name.value.code;
        }, usedValues, getCode);
      }
      _reduceValues(values, valueCode, usedValues = {}, getCode) {
        let code = code_1.nil;
        for (const prefix in values) {
          const vs = values[prefix];
          if (!vs)
            continue;
          const nameSet = usedValues[prefix] = usedValues[prefix] || /* @__PURE__ */ new Map();
          vs.forEach((name) => {
            if (nameSet.has(name))
              return;
            nameSet.set(name, UsedValueState.Started);
            let c = valueCode(name);
            if (c) {
              const def = this.opts.es5 ? exports.varKinds.var : exports.varKinds.const;
              code = (0, code_1._)`${code}${def} ${name} = ${c};${this.opts._n}`;
            } else if (c = getCode === null || getCode === void 0 ? void 0 : getCode(name)) {
              code = (0, code_1._)`${code}${c}${this.opts._n}`;
            } else {
              throw new ValueError(name);
            }
            nameSet.set(name, UsedValueState.Completed);
          });
        }
        return code;
      }
    };
    exports.ValueScope = ValueScope;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/codegen/index.js
var require_codegen = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/codegen/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.or = exports.and = exports.not = exports.CodeGen = exports.operators = exports.varKinds = exports.ValueScopeName = exports.ValueScope = exports.Scope = exports.Name = exports.regexpCode = exports.stringify = exports.getProperty = exports.nil = exports.strConcat = exports.str = exports._ = void 0;
    var code_1 = require_code();
    var scope_1 = require_scope();
    var code_2 = require_code();
    Object.defineProperty(exports, "_", { enumerable: true, get: function() {
      return code_2._;
    } });
    Object.defineProperty(exports, "str", { enumerable: true, get: function() {
      return code_2.str;
    } });
    Object.defineProperty(exports, "strConcat", { enumerable: true, get: function() {
      return code_2.strConcat;
    } });
    Object.defineProperty(exports, "nil", { enumerable: true, get: function() {
      return code_2.nil;
    } });
    Object.defineProperty(exports, "getProperty", { enumerable: true, get: function() {
      return code_2.getProperty;
    } });
    Object.defineProperty(exports, "stringify", { enumerable: true, get: function() {
      return code_2.stringify;
    } });
    Object.defineProperty(exports, "regexpCode", { enumerable: true, get: function() {
      return code_2.regexpCode;
    } });
    Object.defineProperty(exports, "Name", { enumerable: true, get: function() {
      return code_2.Name;
    } });
    var scope_2 = require_scope();
    Object.defineProperty(exports, "Scope", { enumerable: true, get: function() {
      return scope_2.Scope;
    } });
    Object.defineProperty(exports, "ValueScope", { enumerable: true, get: function() {
      return scope_2.ValueScope;
    } });
    Object.defineProperty(exports, "ValueScopeName", { enumerable: true, get: function() {
      return scope_2.ValueScopeName;
    } });
    Object.defineProperty(exports, "varKinds", { enumerable: true, get: function() {
      return scope_2.varKinds;
    } });
    exports.operators = {
      GT: new code_1._Code(">"),
      GTE: new code_1._Code(">="),
      LT: new code_1._Code("<"),
      LTE: new code_1._Code("<="),
      EQ: new code_1._Code("==="),
      NEQ: new code_1._Code("!=="),
      NOT: new code_1._Code("!"),
      OR: new code_1._Code("||"),
      AND: new code_1._Code("&&"),
      ADD: new code_1._Code("+")
    };
    var Node = class {
      optimizeNodes() {
        return this;
      }
      optimizeNames(_names, _constants) {
        return this;
      }
    };
    var Def = class extends Node {
      constructor(varKind, name, rhs) {
        super();
        this.varKind = varKind;
        this.name = name;
        this.rhs = rhs;
      }
      render({ es5, _n }) {
        const varKind = es5 ? scope_1.varKinds.var : this.varKind;
        const rhs = this.rhs === void 0 ? "" : ` = ${this.rhs}`;
        return `${varKind} ${this.name}${rhs};` + _n;
      }
      optimizeNames(names, constants) {
        if (!names[this.name.str])
          return;
        if (this.rhs)
          this.rhs = optimizeExpr(this.rhs, names, constants);
        return this;
      }
      get names() {
        return this.rhs instanceof code_1._CodeOrName ? this.rhs.names : {};
      }
    };
    var Assign = class extends Node {
      constructor(lhs, rhs, sideEffects) {
        super();
        this.lhs = lhs;
        this.rhs = rhs;
        this.sideEffects = sideEffects;
      }
      render({ _n }) {
        return `${this.lhs} = ${this.rhs};` + _n;
      }
      optimizeNames(names, constants) {
        if (this.lhs instanceof code_1.Name && !names[this.lhs.str] && !this.sideEffects)
          return;
        this.rhs = optimizeExpr(this.rhs, names, constants);
        return this;
      }
      get names() {
        const names = this.lhs instanceof code_1.Name ? {} : { ...this.lhs.names };
        return addExprNames(names, this.rhs);
      }
    };
    var AssignOp = class extends Assign {
      constructor(lhs, op, rhs, sideEffects) {
        super(lhs, rhs, sideEffects);
        this.op = op;
      }
      render({ _n }) {
        return `${this.lhs} ${this.op}= ${this.rhs};` + _n;
      }
    };
    var Label = class extends Node {
      constructor(label) {
        super();
        this.label = label;
        this.names = {};
      }
      render({ _n }) {
        return `${this.label}:` + _n;
      }
    };
    var Break = class extends Node {
      constructor(label) {
        super();
        this.label = label;
        this.names = {};
      }
      render({ _n }) {
        const label = this.label ? ` ${this.label}` : "";
        return `break${label};` + _n;
      }
    };
    var Throw = class extends Node {
      constructor(error4) {
        super();
        this.error = error4;
      }
      render({ _n }) {
        return `throw ${this.error};` + _n;
      }
      get names() {
        return this.error.names;
      }
    };
    var AnyCode = class extends Node {
      constructor(code) {
        super();
        this.code = code;
      }
      render({ _n }) {
        return `${this.code};` + _n;
      }
      optimizeNodes() {
        return `${this.code}` ? this : void 0;
      }
      optimizeNames(names, constants) {
        this.code = optimizeExpr(this.code, names, constants);
        return this;
      }
      get names() {
        return this.code instanceof code_1._CodeOrName ? this.code.names : {};
      }
    };
    var ParentNode = class extends Node {
      constructor(nodes = []) {
        super();
        this.nodes = nodes;
      }
      render(opts) {
        return this.nodes.reduce((code, n) => code + n.render(opts), "");
      }
      optimizeNodes() {
        const { nodes } = this;
        let i = nodes.length;
        while (i--) {
          const n = nodes[i].optimizeNodes();
          if (Array.isArray(n))
            nodes.splice(i, 1, ...n);
          else if (n)
            nodes[i] = n;
          else
            nodes.splice(i, 1);
        }
        return nodes.length > 0 ? this : void 0;
      }
      optimizeNames(names, constants) {
        const { nodes } = this;
        let i = nodes.length;
        while (i--) {
          const n = nodes[i];
          if (n.optimizeNames(names, constants))
            continue;
          subtractNames(names, n.names);
          nodes.splice(i, 1);
        }
        return nodes.length > 0 ? this : void 0;
      }
      get names() {
        return this.nodes.reduce((names, n) => addNames(names, n.names), {});
      }
    };
    var BlockNode = class extends ParentNode {
      render(opts) {
        return "{" + opts._n + super.render(opts) + "}" + opts._n;
      }
    };
    var Root = class extends ParentNode {
    };
    var Else = class extends BlockNode {
    };
    Else.kind = "else";
    var If = class _If extends BlockNode {
      constructor(condition, nodes) {
        super(nodes);
        this.condition = condition;
      }
      render(opts) {
        let code = `if(${this.condition})` + super.render(opts);
        if (this.else)
          code += "else " + this.else.render(opts);
        return code;
      }
      optimizeNodes() {
        super.optimizeNodes();
        const cond = this.condition;
        if (cond === true)
          return this.nodes;
        let e = this.else;
        if (e) {
          const ns = e.optimizeNodes();
          e = this.else = Array.isArray(ns) ? new Else(ns) : ns;
        }
        if (e) {
          if (cond === false)
            return e instanceof _If ? e : e.nodes;
          if (this.nodes.length)
            return this;
          return new _If(not(cond), e instanceof _If ? [e] : e.nodes);
        }
        if (cond === false || !this.nodes.length)
          return void 0;
        return this;
      }
      optimizeNames(names, constants) {
        var _a;
        this.else = (_a = this.else) === null || _a === void 0 ? void 0 : _a.optimizeNames(names, constants);
        if (!(super.optimizeNames(names, constants) || this.else))
          return;
        this.condition = optimizeExpr(this.condition, names, constants);
        return this;
      }
      get names() {
        const names = super.names;
        addExprNames(names, this.condition);
        if (this.else)
          addNames(names, this.else.names);
        return names;
      }
    };
    If.kind = "if";
    var For = class extends BlockNode {
    };
    For.kind = "for";
    var ForLoop = class extends For {
      constructor(iteration) {
        super();
        this.iteration = iteration;
      }
      render(opts) {
        return `for(${this.iteration})` + super.render(opts);
      }
      optimizeNames(names, constants) {
        if (!super.optimizeNames(names, constants))
          return;
        this.iteration = optimizeExpr(this.iteration, names, constants);
        return this;
      }
      get names() {
        return addNames(super.names, this.iteration.names);
      }
    };
    var ForRange = class extends For {
      constructor(varKind, name, from, to) {
        super();
        this.varKind = varKind;
        this.name = name;
        this.from = from;
        this.to = to;
      }
      render(opts) {
        const varKind = opts.es5 ? scope_1.varKinds.var : this.varKind;
        const { name, from, to } = this;
        return `for(${varKind} ${name}=${from}; ${name}<${to}; ${name}++)` + super.render(opts);
      }
      get names() {
        const names = addExprNames(super.names, this.from);
        return addExprNames(names, this.to);
      }
    };
    var ForIter = class extends For {
      constructor(loop, varKind, name, iterable) {
        super();
        this.loop = loop;
        this.varKind = varKind;
        this.name = name;
        this.iterable = iterable;
      }
      render(opts) {
        return `for(${this.varKind} ${this.name} ${this.loop} ${this.iterable})` + super.render(opts);
      }
      optimizeNames(names, constants) {
        if (!super.optimizeNames(names, constants))
          return;
        this.iterable = optimizeExpr(this.iterable, names, constants);
        return this;
      }
      get names() {
        return addNames(super.names, this.iterable.names);
      }
    };
    var Func = class extends BlockNode {
      constructor(name, args, async) {
        super();
        this.name = name;
        this.args = args;
        this.async = async;
      }
      render(opts) {
        const _async = this.async ? "async " : "";
        return `${_async}function ${this.name}(${this.args})` + super.render(opts);
      }
    };
    Func.kind = "func";
    var Return = class extends ParentNode {
      render(opts) {
        return "return " + super.render(opts);
      }
    };
    Return.kind = "return";
    var Try = class extends BlockNode {
      render(opts) {
        let code = "try" + super.render(opts);
        if (this.catch)
          code += this.catch.render(opts);
        if (this.finally)
          code += this.finally.render(opts);
        return code;
      }
      optimizeNodes() {
        var _a, _b;
        super.optimizeNodes();
        (_a = this.catch) === null || _a === void 0 ? void 0 : _a.optimizeNodes();
        (_b = this.finally) === null || _b === void 0 ? void 0 : _b.optimizeNodes();
        return this;
      }
      optimizeNames(names, constants) {
        var _a, _b;
        super.optimizeNames(names, constants);
        (_a = this.catch) === null || _a === void 0 ? void 0 : _a.optimizeNames(names, constants);
        (_b = this.finally) === null || _b === void 0 ? void 0 : _b.optimizeNames(names, constants);
        return this;
      }
      get names() {
        const names = super.names;
        if (this.catch)
          addNames(names, this.catch.names);
        if (this.finally)
          addNames(names, this.finally.names);
        return names;
      }
    };
    var Catch = class extends BlockNode {
      constructor(error4) {
        super();
        this.error = error4;
      }
      render(opts) {
        return `catch(${this.error})` + super.render(opts);
      }
    };
    Catch.kind = "catch";
    var Finally = class extends BlockNode {
      render(opts) {
        return "finally" + super.render(opts);
      }
    };
    Finally.kind = "finally";
    var CodeGen = class {
      constructor(extScope, opts = {}) {
        this._values = {};
        this._blockStarts = [];
        this._constants = {};
        this.opts = { ...opts, _n: opts.lines ? "\n" : "" };
        this._extScope = extScope;
        this._scope = new scope_1.Scope({ parent: extScope });
        this._nodes = [new Root()];
      }
      toString() {
        return this._root.render(this.opts);
      }
      // returns unique name in the internal scope
      name(prefix) {
        return this._scope.name(prefix);
      }
      // reserves unique name in the external scope
      scopeName(prefix) {
        return this._extScope.name(prefix);
      }
      // reserves unique name in the external scope and assigns value to it
      scopeValue(prefixOrName, value) {
        const name = this._extScope.value(prefixOrName, value);
        const vs = this._values[name.prefix] || (this._values[name.prefix] = /* @__PURE__ */ new Set());
        vs.add(name);
        return name;
      }
      getScopeValue(prefix, keyOrRef) {
        return this._extScope.getValue(prefix, keyOrRef);
      }
      // return code that assigns values in the external scope to the names that are used internally
      // (same names that were returned by gen.scopeName or gen.scopeValue)
      scopeRefs(scopeName) {
        return this._extScope.scopeRefs(scopeName, this._values);
      }
      scopeCode() {
        return this._extScope.scopeCode(this._values);
      }
      _def(varKind, nameOrPrefix, rhs, constant) {
        const name = this._scope.toName(nameOrPrefix);
        if (rhs !== void 0 && constant)
          this._constants[name.str] = rhs;
        this._leafNode(new Def(varKind, name, rhs));
        return name;
      }
      // `const` declaration (`var` in es5 mode)
      const(nameOrPrefix, rhs, _constant) {
        return this._def(scope_1.varKinds.const, nameOrPrefix, rhs, _constant);
      }
      // `let` declaration with optional assignment (`var` in es5 mode)
      let(nameOrPrefix, rhs, _constant) {
        return this._def(scope_1.varKinds.let, nameOrPrefix, rhs, _constant);
      }
      // `var` declaration with optional assignment
      var(nameOrPrefix, rhs, _constant) {
        return this._def(scope_1.varKinds.var, nameOrPrefix, rhs, _constant);
      }
      // assignment code
      assign(lhs, rhs, sideEffects) {
        return this._leafNode(new Assign(lhs, rhs, sideEffects));
      }
      // `+=` code
      add(lhs, rhs) {
        return this._leafNode(new AssignOp(lhs, exports.operators.ADD, rhs));
      }
      // appends passed SafeExpr to code or executes Block
      code(c) {
        if (typeof c == "function")
          c();
        else if (c !== code_1.nil)
          this._leafNode(new AnyCode(c));
        return this;
      }
      // returns code for object literal for the passed argument list of key-value pairs
      object(...keyValues) {
        const code = ["{"];
        for (const [key, value] of keyValues) {
          if (code.length > 1)
            code.push(",");
          code.push(key);
          if (key !== value || this.opts.es5) {
            code.push(":");
            (0, code_1.addCodeArg)(code, value);
          }
        }
        code.push("}");
        return new code_1._Code(code);
      }
      // `if` clause (or statement if `thenBody` and, optionally, `elseBody` are passed)
      if(condition, thenBody, elseBody) {
        this._blockNode(new If(condition));
        if (thenBody && elseBody) {
          this.code(thenBody).else().code(elseBody).endIf();
        } else if (thenBody) {
          this.code(thenBody).endIf();
        } else if (elseBody) {
          throw new Error('CodeGen: "else" body without "then" body');
        }
        return this;
      }
      // `else if` clause - invalid without `if` or after `else` clauses
      elseIf(condition) {
        return this._elseNode(new If(condition));
      }
      // `else` clause - only valid after `if` or `else if` clauses
      else() {
        return this._elseNode(new Else());
      }
      // end `if` statement (needed if gen.if was used only with condition)
      endIf() {
        return this._endBlockNode(If, Else);
      }
      _for(node, forBody) {
        this._blockNode(node);
        if (forBody)
          this.code(forBody).endFor();
        return this;
      }
      // a generic `for` clause (or statement if `forBody` is passed)
      for(iteration, forBody) {
        return this._for(new ForLoop(iteration), forBody);
      }
      // `for` statement for a range of values
      forRange(nameOrPrefix, from, to, forBody, varKind = this.opts.es5 ? scope_1.varKinds.var : scope_1.varKinds.let) {
        const name = this._scope.toName(nameOrPrefix);
        return this._for(new ForRange(varKind, name, from, to), () => forBody(name));
      }
      // `for-of` statement (in es5 mode replace with a normal for loop)
      forOf(nameOrPrefix, iterable, forBody, varKind = scope_1.varKinds.const) {
        const name = this._scope.toName(nameOrPrefix);
        if (this.opts.es5) {
          const arr = iterable instanceof code_1.Name ? iterable : this.var("_arr", iterable);
          return this.forRange("_i", 0, (0, code_1._)`${arr}.length`, (i) => {
            this.var(name, (0, code_1._)`${arr}[${i}]`);
            forBody(name);
          });
        }
        return this._for(new ForIter("of", varKind, name, iterable), () => forBody(name));
      }
      // `for-in` statement.
      // With option `ownProperties` replaced with a `for-of` loop for object keys
      forIn(nameOrPrefix, obj, forBody, varKind = this.opts.es5 ? scope_1.varKinds.var : scope_1.varKinds.const) {
        if (this.opts.ownProperties) {
          return this.forOf(nameOrPrefix, (0, code_1._)`Object.keys(${obj})`, forBody);
        }
        const name = this._scope.toName(nameOrPrefix);
        return this._for(new ForIter("in", varKind, name, obj), () => forBody(name));
      }
      // end `for` loop
      endFor() {
        return this._endBlockNode(For);
      }
      // `label` statement
      label(label) {
        return this._leafNode(new Label(label));
      }
      // `break` statement
      break(label) {
        return this._leafNode(new Break(label));
      }
      // `return` statement
      return(value) {
        const node = new Return();
        this._blockNode(node);
        this.code(value);
        if (node.nodes.length !== 1)
          throw new Error('CodeGen: "return" should have one node');
        return this._endBlockNode(Return);
      }
      // `try` statement
      try(tryBody, catchCode, finallyCode) {
        if (!catchCode && !finallyCode)
          throw new Error('CodeGen: "try" without "catch" and "finally"');
        const node = new Try();
        this._blockNode(node);
        this.code(tryBody);
        if (catchCode) {
          const error4 = this.name("e");
          this._currNode = node.catch = new Catch(error4);
          catchCode(error4);
        }
        if (finallyCode) {
          this._currNode = node.finally = new Finally();
          this.code(finallyCode);
        }
        return this._endBlockNode(Catch, Finally);
      }
      // `throw` statement
      throw(error4) {
        return this._leafNode(new Throw(error4));
      }
      // start self-balancing block
      block(body2, nodeCount) {
        this._blockStarts.push(this._nodes.length);
        if (body2)
          this.code(body2).endBlock(nodeCount);
        return this;
      }
      // end the current self-balancing block
      endBlock(nodeCount) {
        const len = this._blockStarts.pop();
        if (len === void 0)
          throw new Error("CodeGen: not in self-balancing block");
        const toClose = this._nodes.length - len;
        if (toClose < 0 || nodeCount !== void 0 && toClose !== nodeCount) {
          throw new Error(`CodeGen: wrong number of nodes: ${toClose} vs ${nodeCount} expected`);
        }
        this._nodes.length = len;
        return this;
      }
      // `function` heading (or definition if funcBody is passed)
      func(name, args = code_1.nil, async, funcBody) {
        this._blockNode(new Func(name, args, async));
        if (funcBody)
          this.code(funcBody).endFunc();
        return this;
      }
      // end function definition
      endFunc() {
        return this._endBlockNode(Func);
      }
      optimize(n = 1) {
        while (n-- > 0) {
          this._root.optimizeNodes();
          this._root.optimizeNames(this._root.names, this._constants);
        }
      }
      _leafNode(node) {
        this._currNode.nodes.push(node);
        return this;
      }
      _blockNode(node) {
        this._currNode.nodes.push(node);
        this._nodes.push(node);
      }
      _endBlockNode(N1, N2) {
        const n = this._currNode;
        if (n instanceof N1 || N2 && n instanceof N2) {
          this._nodes.pop();
          return this;
        }
        throw new Error(`CodeGen: not in block "${N2 ? `${N1.kind}/${N2.kind}` : N1.kind}"`);
      }
      _elseNode(node) {
        const n = this._currNode;
        if (!(n instanceof If)) {
          throw new Error('CodeGen: "else" without "if"');
        }
        this._currNode = n.else = node;
        return this;
      }
      get _root() {
        return this._nodes[0];
      }
      get _currNode() {
        const ns = this._nodes;
        return ns[ns.length - 1];
      }
      set _currNode(node) {
        const ns = this._nodes;
        ns[ns.length - 1] = node;
      }
    };
    exports.CodeGen = CodeGen;
    function addNames(names, from) {
      for (const n in from)
        names[n] = (names[n] || 0) + (from[n] || 0);
      return names;
    }
    function addExprNames(names, from) {
      return from instanceof code_1._CodeOrName ? addNames(names, from.names) : names;
    }
    function optimizeExpr(expr, names, constants) {
      if (expr instanceof code_1.Name)
        return replaceName(expr);
      if (!canOptimize(expr))
        return expr;
      return new code_1._Code(expr._items.reduce((items, c) => {
        if (c instanceof code_1.Name)
          c = replaceName(c);
        if (c instanceof code_1._Code)
          items.push(...c._items);
        else
          items.push(c);
        return items;
      }, []));
      function replaceName(n) {
        const c = constants[n.str];
        if (c === void 0 || names[n.str] !== 1)
          return n;
        delete names[n.str];
        return c;
      }
      function canOptimize(e) {
        return e instanceof code_1._Code && e._items.some((c) => c instanceof code_1.Name && names[c.str] === 1 && constants[c.str] !== void 0);
      }
    }
    function subtractNames(names, from) {
      for (const n in from)
        names[n] = (names[n] || 0) - (from[n] || 0);
    }
    function not(x) {
      return typeof x == "boolean" || typeof x == "number" || x === null ? !x : (0, code_1._)`!${par(x)}`;
    }
    exports.not = not;
    var andCode = mappend(exports.operators.AND);
    function and(...args) {
      return args.reduce(andCode);
    }
    exports.and = and;
    var orCode = mappend(exports.operators.OR);
    function or(...args) {
      return args.reduce(orCode);
    }
    exports.or = or;
    function mappend(op) {
      return (x, y) => x === code_1.nil ? y : y === code_1.nil ? x : (0, code_1._)`${par(x)} ${op} ${par(y)}`;
    }
    function par(x) {
      return x instanceof code_1.Name ? x : (0, code_1._)`(${x})`;
    }
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/util.js
var require_util = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/util.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.checkStrictMode = exports.getErrorPath = exports.Type = exports.useFunc = exports.setEvaluated = exports.evaluatedPropsToName = exports.mergeEvaluated = exports.eachItem = exports.unescapeJsonPointer = exports.escapeJsonPointer = exports.escapeFragment = exports.unescapeFragment = exports.schemaRefOrVal = exports.schemaHasRulesButRef = exports.schemaHasRules = exports.checkUnknownRules = exports.alwaysValidSchema = exports.toHash = void 0;
    var codegen_1 = require_codegen();
    var code_1 = require_code();
    function toHash(arr) {
      const hash2 = {};
      for (const item of arr)
        hash2[item] = true;
      return hash2;
    }
    exports.toHash = toHash;
    function alwaysValidSchema(it, schema) {
      if (typeof schema == "boolean")
        return schema;
      if (Object.keys(schema).length === 0)
        return true;
      checkUnknownRules(it, schema);
      return !schemaHasRules(schema, it.self.RULES.all);
    }
    exports.alwaysValidSchema = alwaysValidSchema;
    function checkUnknownRules(it, schema = it.schema) {
      const { opts, self } = it;
      if (!opts.strictSchema)
        return;
      if (typeof schema === "boolean")
        return;
      const rules = self.RULES.keywords;
      for (const key in schema) {
        if (!rules[key])
          checkStrictMode(it, `unknown keyword: "${key}"`);
      }
    }
    exports.checkUnknownRules = checkUnknownRules;
    function schemaHasRules(schema, rules) {
      if (typeof schema == "boolean")
        return !schema;
      for (const key in schema)
        if (rules[key])
          return true;
      return false;
    }
    exports.schemaHasRules = schemaHasRules;
    function schemaHasRulesButRef(schema, RULES) {
      if (typeof schema == "boolean")
        return !schema;
      for (const key in schema)
        if (key !== "$ref" && RULES.all[key])
          return true;
      return false;
    }
    exports.schemaHasRulesButRef = schemaHasRulesButRef;
    function schemaRefOrVal({ topSchemaRef, schemaPath }, schema, keyword, $data) {
      if (!$data) {
        if (typeof schema == "number" || typeof schema == "boolean")
          return schema;
        if (typeof schema == "string")
          return (0, codegen_1._)`${schema}`;
      }
      return (0, codegen_1._)`${topSchemaRef}${schemaPath}${(0, codegen_1.getProperty)(keyword)}`;
    }
    exports.schemaRefOrVal = schemaRefOrVal;
    function unescapeFragment(str) {
      return unescapeJsonPointer(decodeURIComponent(str));
    }
    exports.unescapeFragment = unescapeFragment;
    function escapeFragment(str) {
      return encodeURIComponent(escapeJsonPointer(str));
    }
    exports.escapeFragment = escapeFragment;
    function escapeJsonPointer(str) {
      if (typeof str == "number")
        return `${str}`;
      return str.replace(/~/g, "~0").replace(/\//g, "~1");
    }
    exports.escapeJsonPointer = escapeJsonPointer;
    function unescapeJsonPointer(str) {
      return str.replace(/~1/g, "/").replace(/~0/g, "~");
    }
    exports.unescapeJsonPointer = unescapeJsonPointer;
    function eachItem(xs, f) {
      if (Array.isArray(xs)) {
        for (const x of xs)
          f(x);
      } else {
        f(xs);
      }
    }
    exports.eachItem = eachItem;
    function makeMergeEvaluated({ mergeNames, mergeToName, mergeValues, resultToName }) {
      return (gen, from, to, toName) => {
        const res = to === void 0 ? from : to instanceof codegen_1.Name ? (from instanceof codegen_1.Name ? mergeNames(gen, from, to) : mergeToName(gen, from, to), to) : from instanceof codegen_1.Name ? (mergeToName(gen, to, from), from) : mergeValues(from, to);
        return toName === codegen_1.Name && !(res instanceof codegen_1.Name) ? resultToName(gen, res) : res;
      };
    }
    exports.mergeEvaluated = {
      props: makeMergeEvaluated({
        mergeNames: (gen, from, to) => gen.if((0, codegen_1._)`${to} !== true && ${from} !== undefined`, () => {
          gen.if((0, codegen_1._)`${from} === true`, () => gen.assign(to, true), () => gen.assign(to, (0, codegen_1._)`${to} || {}`).code((0, codegen_1._)`Object.assign(${to}, ${from})`));
        }),
        mergeToName: (gen, from, to) => gen.if((0, codegen_1._)`${to} !== true`, () => {
          if (from === true) {
            gen.assign(to, true);
          } else {
            gen.assign(to, (0, codegen_1._)`${to} || {}`);
            setEvaluated(gen, to, from);
          }
        }),
        mergeValues: (from, to) => from === true ? true : { ...from, ...to },
        resultToName: evaluatedPropsToName
      }),
      items: makeMergeEvaluated({
        mergeNames: (gen, from, to) => gen.if((0, codegen_1._)`${to} !== true && ${from} !== undefined`, () => gen.assign(to, (0, codegen_1._)`${from} === true ? true : ${to} > ${from} ? ${to} : ${from}`)),
        mergeToName: (gen, from, to) => gen.if((0, codegen_1._)`${to} !== true`, () => gen.assign(to, from === true ? true : (0, codegen_1._)`${to} > ${from} ? ${to} : ${from}`)),
        mergeValues: (from, to) => from === true ? true : Math.max(from, to),
        resultToName: (gen, items) => gen.var("items", items)
      })
    };
    function evaluatedPropsToName(gen, ps) {
      if (ps === true)
        return gen.var("props", true);
      const props = gen.var("props", (0, codegen_1._)`{}`);
      if (ps !== void 0)
        setEvaluated(gen, props, ps);
      return props;
    }
    exports.evaluatedPropsToName = evaluatedPropsToName;
    function setEvaluated(gen, props, ps) {
      Object.keys(ps).forEach((p) => gen.assign((0, codegen_1._)`${props}${(0, codegen_1.getProperty)(p)}`, true));
    }
    exports.setEvaluated = setEvaluated;
    var snippets = {};
    function useFunc(gen, f) {
      return gen.scopeValue("func", {
        ref: f,
        code: snippets[f.code] || (snippets[f.code] = new code_1._Code(f.code))
      });
    }
    exports.useFunc = useFunc;
    var Type;
    (function(Type2) {
      Type2[Type2["Num"] = 0] = "Num";
      Type2[Type2["Str"] = 1] = "Str";
    })(Type || (exports.Type = Type = {}));
    function getErrorPath(dataProp, dataPropType, jsPropertySyntax) {
      if (dataProp instanceof codegen_1.Name) {
        const isNumber = dataPropType === Type.Num;
        return jsPropertySyntax ? isNumber ? (0, codegen_1._)`"[" + ${dataProp} + "]"` : (0, codegen_1._)`"['" + ${dataProp} + "']"` : isNumber ? (0, codegen_1._)`"/" + ${dataProp}` : (0, codegen_1._)`"/" + ${dataProp}.replace(/~/g, "~0").replace(/\\//g, "~1")`;
      }
      return jsPropertySyntax ? (0, codegen_1.getProperty)(dataProp).toString() : "/" + escapeJsonPointer(dataProp);
    }
    exports.getErrorPath = getErrorPath;
    function checkStrictMode(it, msg, mode = it.opts.strictSchema) {
      if (!mode)
        return;
      msg = `strict mode: ${msg}`;
      if (mode === true)
        throw new Error(msg);
      it.self.logger.warn(msg);
    }
    exports.checkStrictMode = checkStrictMode;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/names.js
var require_names = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/names.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var names = {
      // validation function arguments
      data: new codegen_1.Name("data"),
      // data passed to validation function
      // args passed from referencing schema
      valCxt: new codegen_1.Name("valCxt"),
      // validation/data context - should not be used directly, it is destructured to the names below
      instancePath: new codegen_1.Name("instancePath"),
      parentData: new codegen_1.Name("parentData"),
      parentDataProperty: new codegen_1.Name("parentDataProperty"),
      rootData: new codegen_1.Name("rootData"),
      // root data - same as the data passed to the first/top validation function
      dynamicAnchors: new codegen_1.Name("dynamicAnchors"),
      // used to support recursiveRef and dynamicRef
      // function scoped variables
      vErrors: new codegen_1.Name("vErrors"),
      // null or array of validation errors
      errors: new codegen_1.Name("errors"),
      // counter of validation errors
      this: new codegen_1.Name("this"),
      // "globals"
      self: new codegen_1.Name("self"),
      scope: new codegen_1.Name("scope"),
      // JTD serialize/parse name for JSON string and position
      json: new codegen_1.Name("json"),
      jsonPos: new codegen_1.Name("jsonPos"),
      jsonLen: new codegen_1.Name("jsonLen"),
      jsonPart: new codegen_1.Name("jsonPart")
    };
    exports.default = names;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/errors.js
var require_errors = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/errors.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.extendErrors = exports.resetErrorsCount = exports.reportExtraError = exports.reportError = exports.keyword$DataError = exports.keywordError = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var names_1 = require_names();
    exports.keywordError = {
      message: ({ keyword }) => (0, codegen_1.str)`must pass "${keyword}" keyword validation`
    };
    exports.keyword$DataError = {
      message: ({ keyword, schemaType }) => schemaType ? (0, codegen_1.str)`"${keyword}" keyword must be ${schemaType} ($data)` : (0, codegen_1.str)`"${keyword}" keyword is invalid ($data)`
    };
    function reportError(cxt, error4 = exports.keywordError, errorPaths, overrideAllErrors) {
      const { it } = cxt;
      const { gen, compositeRule, allErrors } = it;
      const errObj = errorObjectCode(cxt, error4, errorPaths);
      if (overrideAllErrors !== null && overrideAllErrors !== void 0 ? overrideAllErrors : compositeRule || allErrors) {
        addError(gen, errObj);
      } else {
        returnErrors(it, (0, codegen_1._)`[${errObj}]`);
      }
    }
    exports.reportError = reportError;
    function reportExtraError(cxt, error4 = exports.keywordError, errorPaths) {
      const { it } = cxt;
      const { gen, compositeRule, allErrors } = it;
      const errObj = errorObjectCode(cxt, error4, errorPaths);
      addError(gen, errObj);
      if (!(compositeRule || allErrors)) {
        returnErrors(it, names_1.default.vErrors);
      }
    }
    exports.reportExtraError = reportExtraError;
    function resetErrorsCount(gen, errsCount) {
      gen.assign(names_1.default.errors, errsCount);
      gen.if((0, codegen_1._)`${names_1.default.vErrors} !== null`, () => gen.if(errsCount, () => gen.assign((0, codegen_1._)`${names_1.default.vErrors}.length`, errsCount), () => gen.assign(names_1.default.vErrors, null)));
    }
    exports.resetErrorsCount = resetErrorsCount;
    function extendErrors({ gen, keyword, schemaValue, data, errsCount, it }) {
      if (errsCount === void 0)
        throw new Error("ajv implementation error");
      const err = gen.name("err");
      gen.forRange("i", errsCount, names_1.default.errors, (i) => {
        gen.const(err, (0, codegen_1._)`${names_1.default.vErrors}[${i}]`);
        gen.if((0, codegen_1._)`${err}.instancePath === undefined`, () => gen.assign((0, codegen_1._)`${err}.instancePath`, (0, codegen_1.strConcat)(names_1.default.instancePath, it.errorPath)));
        gen.assign((0, codegen_1._)`${err}.schemaPath`, (0, codegen_1.str)`${it.errSchemaPath}/${keyword}`);
        if (it.opts.verbose) {
          gen.assign((0, codegen_1._)`${err}.schema`, schemaValue);
          gen.assign((0, codegen_1._)`${err}.data`, data);
        }
      });
    }
    exports.extendErrors = extendErrors;
    function addError(gen, errObj) {
      const err = gen.const("err", errObj);
      gen.if((0, codegen_1._)`${names_1.default.vErrors} === null`, () => gen.assign(names_1.default.vErrors, (0, codegen_1._)`[${err}]`), (0, codegen_1._)`${names_1.default.vErrors}.push(${err})`);
      gen.code((0, codegen_1._)`${names_1.default.errors}++`);
    }
    function returnErrors(it, errs) {
      const { gen, validateName, schemaEnv } = it;
      if (schemaEnv.$async) {
        gen.throw((0, codegen_1._)`new ${it.ValidationError}(${errs})`);
      } else {
        gen.assign((0, codegen_1._)`${validateName}.errors`, errs);
        gen.return(false);
      }
    }
    var E = {
      keyword: new codegen_1.Name("keyword"),
      schemaPath: new codegen_1.Name("schemaPath"),
      // also used in JTD errors
      params: new codegen_1.Name("params"),
      propertyName: new codegen_1.Name("propertyName"),
      message: new codegen_1.Name("message"),
      schema: new codegen_1.Name("schema"),
      parentSchema: new codegen_1.Name("parentSchema")
    };
    function errorObjectCode(cxt, error4, errorPaths) {
      const { createErrors } = cxt.it;
      if (createErrors === false)
        return (0, codegen_1._)`{}`;
      return errorObject(cxt, error4, errorPaths);
    }
    function errorObject(cxt, error4, errorPaths = {}) {
      const { gen, it } = cxt;
      const keyValues = [
        errorInstancePath(it, errorPaths),
        errorSchemaPath(cxt, errorPaths)
      ];
      extraErrorProps(cxt, error4, keyValues);
      return gen.object(...keyValues);
    }
    function errorInstancePath({ errorPath }, { instancePath }) {
      const instPath = instancePath ? (0, codegen_1.str)`${errorPath}${(0, util_1.getErrorPath)(instancePath, util_1.Type.Str)}` : errorPath;
      return [names_1.default.instancePath, (0, codegen_1.strConcat)(names_1.default.instancePath, instPath)];
    }
    function errorSchemaPath({ keyword, it: { errSchemaPath } }, { schemaPath, parentSchema }) {
      let schPath = parentSchema ? errSchemaPath : (0, codegen_1.str)`${errSchemaPath}/${keyword}`;
      if (schemaPath) {
        schPath = (0, codegen_1.str)`${schPath}${(0, util_1.getErrorPath)(schemaPath, util_1.Type.Str)}`;
      }
      return [E.schemaPath, schPath];
    }
    function extraErrorProps(cxt, { params, message }, keyValues) {
      const { keyword, data, schemaValue, it } = cxt;
      const { opts, propertyName, topSchemaRef, schemaPath } = it;
      keyValues.push([E.keyword, keyword], [E.params, typeof params == "function" ? params(cxt) : params || (0, codegen_1._)`{}`]);
      if (opts.messages) {
        keyValues.push([E.message, typeof message == "function" ? message(cxt) : message]);
      }
      if (opts.verbose) {
        keyValues.push([E.schema, schemaValue], [E.parentSchema, (0, codegen_1._)`${topSchemaRef}${schemaPath}`], [names_1.default.data, data]);
      }
      if (propertyName)
        keyValues.push([E.propertyName, propertyName]);
    }
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/boolSchema.js
var require_boolSchema = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/boolSchema.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.boolOrEmptySchema = exports.topBoolOrEmptySchema = void 0;
    var errors_1 = require_errors();
    var codegen_1 = require_codegen();
    var names_1 = require_names();
    var boolError = {
      message: "boolean schema is false"
    };
    function topBoolOrEmptySchema(it) {
      const { gen, schema, validateName } = it;
      if (schema === false) {
        falseSchemaError(it, false);
      } else if (typeof schema == "object" && schema.$async === true) {
        gen.return(names_1.default.data);
      } else {
        gen.assign((0, codegen_1._)`${validateName}.errors`, null);
        gen.return(true);
      }
    }
    exports.topBoolOrEmptySchema = topBoolOrEmptySchema;
    function boolOrEmptySchema(it, valid) {
      const { gen, schema } = it;
      if (schema === false) {
        gen.var(valid, false);
        falseSchemaError(it);
      } else {
        gen.var(valid, true);
      }
    }
    exports.boolOrEmptySchema = boolOrEmptySchema;
    function falseSchemaError(it, overrideAllErrors) {
      const { gen, data } = it;
      const cxt = {
        gen,
        keyword: "false schema",
        data,
        schema: false,
        schemaCode: false,
        schemaValue: false,
        params: {},
        it
      };
      (0, errors_1.reportError)(cxt, boolError, void 0, overrideAllErrors);
    }
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/rules.js
var require_rules = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/rules.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getRules = exports.isJSONType = void 0;
    var _jsonTypes = ["string", "number", "integer", "boolean", "null", "object", "array"];
    var jsonTypes = new Set(_jsonTypes);
    function isJSONType(x) {
      return typeof x == "string" && jsonTypes.has(x);
    }
    exports.isJSONType = isJSONType;
    function getRules() {
      const groups = {
        number: { type: "number", rules: [] },
        string: { type: "string", rules: [] },
        array: { type: "array", rules: [] },
        object: { type: "object", rules: [] }
      };
      return {
        types: { ...groups, integer: true, boolean: true, null: true },
        rules: [{ rules: [] }, groups.number, groups.string, groups.array, groups.object],
        post: { rules: [] },
        all: {},
        keywords: {}
      };
    }
    exports.getRules = getRules;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/applicability.js
var require_applicability = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/applicability.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.shouldUseRule = exports.shouldUseGroup = exports.schemaHasRulesForType = void 0;
    function schemaHasRulesForType({ schema, self }, type) {
      const group = self.RULES.types[type];
      return group && group !== true && shouldUseGroup(schema, group);
    }
    exports.schemaHasRulesForType = schemaHasRulesForType;
    function shouldUseGroup(schema, group) {
      return group.rules.some((rule) => shouldUseRule(schema, rule));
    }
    exports.shouldUseGroup = shouldUseGroup;
    function shouldUseRule(schema, rule) {
      var _a;
      return schema[rule.keyword] !== void 0 || ((_a = rule.definition.implements) === null || _a === void 0 ? void 0 : _a.some((kwd) => schema[kwd] !== void 0));
    }
    exports.shouldUseRule = shouldUseRule;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/dataType.js
var require_dataType = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/dataType.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.reportTypeError = exports.checkDataTypes = exports.checkDataType = exports.coerceAndCheckDataType = exports.getJSONTypes = exports.getSchemaTypes = exports.DataType = void 0;
    var rules_1 = require_rules();
    var applicability_1 = require_applicability();
    var errors_1 = require_errors();
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var DataType;
    (function(DataType2) {
      DataType2[DataType2["Correct"] = 0] = "Correct";
      DataType2[DataType2["Wrong"] = 1] = "Wrong";
    })(DataType || (exports.DataType = DataType = {}));
    function getSchemaTypes(schema) {
      const types = getJSONTypes(schema.type);
      const hasNull = types.includes("null");
      if (hasNull) {
        if (schema.nullable === false)
          throw new Error("type: null contradicts nullable: false");
      } else {
        if (!types.length && schema.nullable !== void 0) {
          throw new Error('"nullable" cannot be used without "type"');
        }
        if (schema.nullable === true)
          types.push("null");
      }
      return types;
    }
    exports.getSchemaTypes = getSchemaTypes;
    function getJSONTypes(ts) {
      const types = Array.isArray(ts) ? ts : ts ? [ts] : [];
      if (types.every(rules_1.isJSONType))
        return types;
      throw new Error("type must be JSONType or JSONType[]: " + types.join(","));
    }
    exports.getJSONTypes = getJSONTypes;
    function coerceAndCheckDataType(it, types) {
      const { gen, data, opts } = it;
      const coerceTo = coerceToTypes(types, opts.coerceTypes);
      const checkTypes = types.length > 0 && !(coerceTo.length === 0 && types.length === 1 && (0, applicability_1.schemaHasRulesForType)(it, types[0]));
      if (checkTypes) {
        const wrongType = checkDataTypes(types, data, opts.strictNumbers, DataType.Wrong);
        gen.if(wrongType, () => {
          if (coerceTo.length)
            coerceData(it, types, coerceTo);
          else
            reportTypeError(it);
        });
      }
      return checkTypes;
    }
    exports.coerceAndCheckDataType = coerceAndCheckDataType;
    var COERCIBLE = /* @__PURE__ */ new Set(["string", "number", "integer", "boolean", "null"]);
    function coerceToTypes(types, coerceTypes) {
      return coerceTypes ? types.filter((t) => COERCIBLE.has(t) || coerceTypes === "array" && t === "array") : [];
    }
    function coerceData(it, types, coerceTo) {
      const { gen, data, opts } = it;
      const dataType = gen.let("dataType", (0, codegen_1._)`typeof ${data}`);
      const coerced = gen.let("coerced", (0, codegen_1._)`undefined`);
      if (opts.coerceTypes === "array") {
        gen.if((0, codegen_1._)`${dataType} == 'object' && Array.isArray(${data}) && ${data}.length == 1`, () => gen.assign(data, (0, codegen_1._)`${data}[0]`).assign(dataType, (0, codegen_1._)`typeof ${data}`).if(checkDataTypes(types, data, opts.strictNumbers), () => gen.assign(coerced, data)));
      }
      gen.if((0, codegen_1._)`${coerced} !== undefined`);
      for (const t of coerceTo) {
        if (COERCIBLE.has(t) || t === "array" && opts.coerceTypes === "array") {
          coerceSpecificType(t);
        }
      }
      gen.else();
      reportTypeError(it);
      gen.endIf();
      gen.if((0, codegen_1._)`${coerced} !== undefined`, () => {
        gen.assign(data, coerced);
        assignParentData(it, coerced);
      });
      function coerceSpecificType(t) {
        switch (t) {
          case "string":
            gen.elseIf((0, codegen_1._)`${dataType} == "number" || ${dataType} == "boolean"`).assign(coerced, (0, codegen_1._)`"" + ${data}`).elseIf((0, codegen_1._)`${data} === null`).assign(coerced, (0, codegen_1._)`""`);
            return;
          case "number":
            gen.elseIf((0, codegen_1._)`${dataType} == "boolean" || ${data} === null
              || (${dataType} == "string" && ${data} && ${data} == +${data})`).assign(coerced, (0, codegen_1._)`+${data}`);
            return;
          case "integer":
            gen.elseIf((0, codegen_1._)`${dataType} === "boolean" || ${data} === null
              || (${dataType} === "string" && ${data} && ${data} == +${data} && !(${data} % 1))`).assign(coerced, (0, codegen_1._)`+${data}`);
            return;
          case "boolean":
            gen.elseIf((0, codegen_1._)`${data} === "false" || ${data} === 0 || ${data} === null`).assign(coerced, false).elseIf((0, codegen_1._)`${data} === "true" || ${data} === 1`).assign(coerced, true);
            return;
          case "null":
            gen.elseIf((0, codegen_1._)`${data} === "" || ${data} === 0 || ${data} === false`);
            gen.assign(coerced, null);
            return;
          case "array":
            gen.elseIf((0, codegen_1._)`${dataType} === "string" || ${dataType} === "number"
              || ${dataType} === "boolean" || ${data} === null`).assign(coerced, (0, codegen_1._)`[${data}]`);
        }
      }
    }
    function assignParentData({ gen, parentData, parentDataProperty }, expr) {
      gen.if((0, codegen_1._)`${parentData} !== undefined`, () => gen.assign((0, codegen_1._)`${parentData}[${parentDataProperty}]`, expr));
    }
    function checkDataType(dataType, data, strictNums, correct = DataType.Correct) {
      const EQ = correct === DataType.Correct ? codegen_1.operators.EQ : codegen_1.operators.NEQ;
      let cond;
      switch (dataType) {
        case "null":
          return (0, codegen_1._)`${data} ${EQ} null`;
        case "array":
          cond = (0, codegen_1._)`Array.isArray(${data})`;
          break;
        case "object":
          cond = (0, codegen_1._)`${data} && typeof ${data} == "object" && !Array.isArray(${data})`;
          break;
        case "integer":
          cond = numCond((0, codegen_1._)`!(${data} % 1) && !isNaN(${data})`);
          break;
        case "number":
          cond = numCond();
          break;
        default:
          return (0, codegen_1._)`typeof ${data} ${EQ} ${dataType}`;
      }
      return correct === DataType.Correct ? cond : (0, codegen_1.not)(cond);
      function numCond(_cond = codegen_1.nil) {
        return (0, codegen_1.and)((0, codegen_1._)`typeof ${data} == "number"`, _cond, strictNums ? (0, codegen_1._)`isFinite(${data})` : codegen_1.nil);
      }
    }
    exports.checkDataType = checkDataType;
    function checkDataTypes(dataTypes, data, strictNums, correct) {
      if (dataTypes.length === 1) {
        return checkDataType(dataTypes[0], data, strictNums, correct);
      }
      let cond;
      const types = (0, util_1.toHash)(dataTypes);
      if (types.array && types.object) {
        const notObj = (0, codegen_1._)`typeof ${data} != "object"`;
        cond = types.null ? notObj : (0, codegen_1._)`!${data} || ${notObj}`;
        delete types.null;
        delete types.array;
        delete types.object;
      } else {
        cond = codegen_1.nil;
      }
      if (types.number)
        delete types.integer;
      for (const t in types)
        cond = (0, codegen_1.and)(cond, checkDataType(t, data, strictNums, correct));
      return cond;
    }
    exports.checkDataTypes = checkDataTypes;
    var typeError = {
      message: ({ schema }) => `must be ${schema}`,
      params: ({ schema, schemaValue }) => typeof schema == "string" ? (0, codegen_1._)`{type: ${schema}}` : (0, codegen_1._)`{type: ${schemaValue}}`
    };
    function reportTypeError(it) {
      const cxt = getTypeErrorContext(it);
      (0, errors_1.reportError)(cxt, typeError);
    }
    exports.reportTypeError = reportTypeError;
    function getTypeErrorContext(it) {
      const { gen, data, schema } = it;
      const schemaCode = (0, util_1.schemaRefOrVal)(it, schema, "type");
      return {
        gen,
        keyword: "type",
        data,
        schema: schema.type,
        schemaCode,
        schemaValue: schemaCode,
        parentSchema: schema,
        params: {},
        it
      };
    }
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/defaults.js
var require_defaults = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/defaults.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.assignDefaults = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    function assignDefaults(it, ty) {
      const { properties, items } = it.schema;
      if (ty === "object" && properties) {
        for (const key in properties) {
          assignDefault(it, key, properties[key].default);
        }
      } else if (ty === "array" && Array.isArray(items)) {
        items.forEach((sch, i) => assignDefault(it, i, sch.default));
      }
    }
    exports.assignDefaults = assignDefaults;
    function assignDefault(it, prop, defaultValue) {
      const { gen, compositeRule, data, opts } = it;
      if (defaultValue === void 0)
        return;
      const childData = (0, codegen_1._)`${data}${(0, codegen_1.getProperty)(prop)}`;
      if (compositeRule) {
        (0, util_1.checkStrictMode)(it, `default is ignored for: ${childData}`);
        return;
      }
      let condition = (0, codegen_1._)`${childData} === undefined`;
      if (opts.useDefaults === "empty") {
        condition = (0, codegen_1._)`${condition} || ${childData} === null || ${childData} === ""`;
      }
      gen.if(condition, (0, codegen_1._)`${childData} = ${(0, codegen_1.stringify)(defaultValue)}`);
    }
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/code.js
var require_code2 = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/code.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateUnion = exports.validateArray = exports.usePattern = exports.callValidateCode = exports.schemaProperties = exports.allSchemaProperties = exports.noPropertyInData = exports.propertyInData = exports.isOwnProperty = exports.hasPropFunc = exports.reportMissingProp = exports.checkMissingProp = exports.checkReportMissingProp = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var names_1 = require_names();
    var util_2 = require_util();
    function checkReportMissingProp(cxt, prop) {
      const { gen, data, it } = cxt;
      gen.if(noPropertyInData(gen, data, prop, it.opts.ownProperties), () => {
        cxt.setParams({ missingProperty: (0, codegen_1._)`${prop}` }, true);
        cxt.error();
      });
    }
    exports.checkReportMissingProp = checkReportMissingProp;
    function checkMissingProp({ gen, data, it: { opts } }, properties, missing) {
      return (0, codegen_1.or)(...properties.map((prop) => (0, codegen_1.and)(noPropertyInData(gen, data, prop, opts.ownProperties), (0, codegen_1._)`${missing} = ${prop}`)));
    }
    exports.checkMissingProp = checkMissingProp;
    function reportMissingProp(cxt, missing) {
      cxt.setParams({ missingProperty: missing }, true);
      cxt.error();
    }
    exports.reportMissingProp = reportMissingProp;
    function hasPropFunc(gen) {
      return gen.scopeValue("func", {
        // eslint-disable-next-line @typescript-eslint/unbound-method
        ref: Object.prototype.hasOwnProperty,
        code: (0, codegen_1._)`Object.prototype.hasOwnProperty`
      });
    }
    exports.hasPropFunc = hasPropFunc;
    function isOwnProperty(gen, data, property) {
      return (0, codegen_1._)`${hasPropFunc(gen)}.call(${data}, ${property})`;
    }
    exports.isOwnProperty = isOwnProperty;
    function propertyInData(gen, data, property, ownProperties) {
      const cond = (0, codegen_1._)`${data}${(0, codegen_1.getProperty)(property)} !== undefined`;
      return ownProperties ? (0, codegen_1._)`${cond} && ${isOwnProperty(gen, data, property)}` : cond;
    }
    exports.propertyInData = propertyInData;
    function noPropertyInData(gen, data, property, ownProperties) {
      const cond = (0, codegen_1._)`${data}${(0, codegen_1.getProperty)(property)} === undefined`;
      return ownProperties ? (0, codegen_1.or)(cond, (0, codegen_1.not)(isOwnProperty(gen, data, property))) : cond;
    }
    exports.noPropertyInData = noPropertyInData;
    function allSchemaProperties(schemaMap) {
      return schemaMap ? Object.keys(schemaMap).filter((p) => p !== "__proto__") : [];
    }
    exports.allSchemaProperties = allSchemaProperties;
    function schemaProperties(it, schemaMap) {
      return allSchemaProperties(schemaMap).filter((p) => !(0, util_1.alwaysValidSchema)(it, schemaMap[p]));
    }
    exports.schemaProperties = schemaProperties;
    function callValidateCode({ schemaCode, data, it: { gen, topSchemaRef, schemaPath, errorPath }, it }, func, context, passSchema) {
      const dataAndSchema = passSchema ? (0, codegen_1._)`${schemaCode}, ${data}, ${topSchemaRef}${schemaPath}` : data;
      const valCxt = [
        [names_1.default.instancePath, (0, codegen_1.strConcat)(names_1.default.instancePath, errorPath)],
        [names_1.default.parentData, it.parentData],
        [names_1.default.parentDataProperty, it.parentDataProperty],
        [names_1.default.rootData, names_1.default.rootData]
      ];
      if (it.opts.dynamicRef)
        valCxt.push([names_1.default.dynamicAnchors, names_1.default.dynamicAnchors]);
      const args = (0, codegen_1._)`${dataAndSchema}, ${gen.object(...valCxt)}`;
      return context !== codegen_1.nil ? (0, codegen_1._)`${func}.call(${context}, ${args})` : (0, codegen_1._)`${func}(${args})`;
    }
    exports.callValidateCode = callValidateCode;
    var newRegExp = (0, codegen_1._)`new RegExp`;
    function usePattern({ gen, it: { opts } }, pattern) {
      const u = opts.unicodeRegExp ? "u" : "";
      const { regExp } = opts.code;
      const rx = regExp(pattern, u);
      return gen.scopeValue("pattern", {
        key: rx.toString(),
        ref: rx,
        code: (0, codegen_1._)`${regExp.code === "new RegExp" ? newRegExp : (0, util_2.useFunc)(gen, regExp)}(${pattern}, ${u})`
      });
    }
    exports.usePattern = usePattern;
    function validateArray(cxt) {
      const { gen, data, keyword, it } = cxt;
      const valid = gen.name("valid");
      if (it.allErrors) {
        const validArr = gen.let("valid", true);
        validateItems(() => gen.assign(validArr, false));
        return validArr;
      }
      gen.var(valid, true);
      validateItems(() => gen.break());
      return valid;
      function validateItems(notValid) {
        const len = gen.const("len", (0, codegen_1._)`${data}.length`);
        gen.forRange("i", 0, len, (i) => {
          cxt.subschema({
            keyword,
            dataProp: i,
            dataPropType: util_1.Type.Num
          }, valid);
          gen.if((0, codegen_1.not)(valid), notValid);
        });
      }
    }
    exports.validateArray = validateArray;
    function validateUnion(cxt) {
      const { gen, schema, keyword, it } = cxt;
      if (!Array.isArray(schema))
        throw new Error("ajv implementation error");
      const alwaysValid = schema.some((sch) => (0, util_1.alwaysValidSchema)(it, sch));
      if (alwaysValid && !it.opts.unevaluated)
        return;
      const valid = gen.let("valid", false);
      const schValid = gen.name("_valid");
      gen.block(() => schema.forEach((_sch, i) => {
        const schCxt = cxt.subschema({
          keyword,
          schemaProp: i,
          compositeRule: true
        }, schValid);
        gen.assign(valid, (0, codegen_1._)`${valid} || ${schValid}`);
        const merged = cxt.mergeValidEvaluated(schCxt, schValid);
        if (!merged)
          gen.if((0, codegen_1.not)(valid));
      }));
      cxt.result(valid, () => cxt.reset(), () => cxt.error(true));
    }
    exports.validateUnion = validateUnion;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/keyword.js
var require_keyword = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/keyword.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateKeywordUsage = exports.validSchemaType = exports.funcKeywordCode = exports.macroKeywordCode = void 0;
    var codegen_1 = require_codegen();
    var names_1 = require_names();
    var code_1 = require_code2();
    var errors_1 = require_errors();
    function macroKeywordCode(cxt, def) {
      const { gen, keyword, schema, parentSchema, it } = cxt;
      const macroSchema = def.macro.call(it.self, schema, parentSchema, it);
      const schemaRef = useKeyword(gen, keyword, macroSchema);
      if (it.opts.validateSchema !== false)
        it.self.validateSchema(macroSchema, true);
      const valid = gen.name("valid");
      cxt.subschema({
        schema: macroSchema,
        schemaPath: codegen_1.nil,
        errSchemaPath: `${it.errSchemaPath}/${keyword}`,
        topSchemaRef: schemaRef,
        compositeRule: true
      }, valid);
      cxt.pass(valid, () => cxt.error(true));
    }
    exports.macroKeywordCode = macroKeywordCode;
    function funcKeywordCode(cxt, def) {
      var _a;
      const { gen, keyword, schema, parentSchema, $data, it } = cxt;
      checkAsyncKeyword(it, def);
      const validate2 = !$data && def.compile ? def.compile.call(it.self, schema, parentSchema, it) : def.validate;
      const validateRef = useKeyword(gen, keyword, validate2);
      const valid = gen.let("valid");
      cxt.block$data(valid, validateKeyword);
      cxt.ok((_a = def.valid) !== null && _a !== void 0 ? _a : valid);
      function validateKeyword() {
        if (def.errors === false) {
          assignValid();
          if (def.modifying)
            modifyData(cxt);
          reportErrs(() => cxt.error());
        } else {
          const ruleErrs = def.async ? validateAsync() : validateSync();
          if (def.modifying)
            modifyData(cxt);
          reportErrs(() => addErrs(cxt, ruleErrs));
        }
      }
      function validateAsync() {
        const ruleErrs = gen.let("ruleErrs", null);
        gen.try(() => assignValid((0, codegen_1._)`await `), (e) => gen.assign(valid, false).if((0, codegen_1._)`${e} instanceof ${it.ValidationError}`, () => gen.assign(ruleErrs, (0, codegen_1._)`${e}.errors`), () => gen.throw(e)));
        return ruleErrs;
      }
      function validateSync() {
        const validateErrs = (0, codegen_1._)`${validateRef}.errors`;
        gen.assign(validateErrs, null);
        assignValid(codegen_1.nil);
        return validateErrs;
      }
      function assignValid(_await = def.async ? (0, codegen_1._)`await ` : codegen_1.nil) {
        const passCxt = it.opts.passContext ? names_1.default.this : names_1.default.self;
        const passSchema = !("compile" in def && !$data || def.schema === false);
        gen.assign(valid, (0, codegen_1._)`${_await}${(0, code_1.callValidateCode)(cxt, validateRef, passCxt, passSchema)}`, def.modifying);
      }
      function reportErrs(errors) {
        var _a2;
        gen.if((0, codegen_1.not)((_a2 = def.valid) !== null && _a2 !== void 0 ? _a2 : valid), errors);
      }
    }
    exports.funcKeywordCode = funcKeywordCode;
    function modifyData(cxt) {
      const { gen, data, it } = cxt;
      gen.if(it.parentData, () => gen.assign(data, (0, codegen_1._)`${it.parentData}[${it.parentDataProperty}]`));
    }
    function addErrs(cxt, errs) {
      const { gen } = cxt;
      gen.if((0, codegen_1._)`Array.isArray(${errs})`, () => {
        gen.assign(names_1.default.vErrors, (0, codegen_1._)`${names_1.default.vErrors} === null ? ${errs} : ${names_1.default.vErrors}.concat(${errs})`).assign(names_1.default.errors, (0, codegen_1._)`${names_1.default.vErrors}.length`);
        (0, errors_1.extendErrors)(cxt);
      }, () => cxt.error());
    }
    function checkAsyncKeyword({ schemaEnv }, def) {
      if (def.async && !schemaEnv.$async)
        throw new Error("async keyword in sync schema");
    }
    function useKeyword(gen, keyword, result) {
      if (result === void 0)
        throw new Error(`keyword "${keyword}" failed to compile`);
      return gen.scopeValue("keyword", typeof result == "function" ? { ref: result } : { ref: result, code: (0, codegen_1.stringify)(result) });
    }
    function validSchemaType(schema, schemaType, allowUndefined = false) {
      return !schemaType.length || schemaType.some((st) => st === "array" ? Array.isArray(schema) : st === "object" ? schema && typeof schema == "object" && !Array.isArray(schema) : typeof schema == st || allowUndefined && typeof schema == "undefined");
    }
    exports.validSchemaType = validSchemaType;
    function validateKeywordUsage({ schema, opts, self, errSchemaPath }, def, keyword) {
      if (Array.isArray(def.keyword) ? !def.keyword.includes(keyword) : def.keyword !== keyword) {
        throw new Error("ajv implementation error");
      }
      const deps = def.dependencies;
      if (deps === null || deps === void 0 ? void 0 : deps.some((kwd) => !Object.prototype.hasOwnProperty.call(schema, kwd))) {
        throw new Error(`parent schema must have dependencies of ${keyword}: ${deps.join(",")}`);
      }
      if (def.validateSchema) {
        const valid = def.validateSchema(schema[keyword]);
        if (!valid) {
          const msg = `keyword "${keyword}" value is invalid at path "${errSchemaPath}": ` + self.errorsText(def.validateSchema.errors);
          if (opts.validateSchema === "log")
            self.logger.error(msg);
          else
            throw new Error(msg);
        }
      }
    }
    exports.validateKeywordUsage = validateKeywordUsage;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/subschema.js
var require_subschema = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/subschema.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.extendSubschemaMode = exports.extendSubschemaData = exports.getSubschema = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    function getSubschema(it, { keyword, schemaProp, schema, schemaPath, errSchemaPath, topSchemaRef }) {
      if (keyword !== void 0 && schema !== void 0) {
        throw new Error('both "keyword" and "schema" passed, only one allowed');
      }
      if (keyword !== void 0) {
        const sch = it.schema[keyword];
        return schemaProp === void 0 ? {
          schema: sch,
          schemaPath: (0, codegen_1._)`${it.schemaPath}${(0, codegen_1.getProperty)(keyword)}`,
          errSchemaPath: `${it.errSchemaPath}/${keyword}`
        } : {
          schema: sch[schemaProp],
          schemaPath: (0, codegen_1._)`${it.schemaPath}${(0, codegen_1.getProperty)(keyword)}${(0, codegen_1.getProperty)(schemaProp)}`,
          errSchemaPath: `${it.errSchemaPath}/${keyword}/${(0, util_1.escapeFragment)(schemaProp)}`
        };
      }
      if (schema !== void 0) {
        if (schemaPath === void 0 || errSchemaPath === void 0 || topSchemaRef === void 0) {
          throw new Error('"schemaPath", "errSchemaPath" and "topSchemaRef" are required with "schema"');
        }
        return {
          schema,
          schemaPath,
          topSchemaRef,
          errSchemaPath
        };
      }
      throw new Error('either "keyword" or "schema" must be passed');
    }
    exports.getSubschema = getSubschema;
    function extendSubschemaData(subschema, it, { dataProp, dataPropType: dpType, data, dataTypes, propertyName }) {
      if (data !== void 0 && dataProp !== void 0) {
        throw new Error('both "data" and "dataProp" passed, only one allowed');
      }
      const { gen } = it;
      if (dataProp !== void 0) {
        const { errorPath, dataPathArr, opts } = it;
        const nextData = gen.let("data", (0, codegen_1._)`${it.data}${(0, codegen_1.getProperty)(dataProp)}`, true);
        dataContextProps(nextData);
        subschema.errorPath = (0, codegen_1.str)`${errorPath}${(0, util_1.getErrorPath)(dataProp, dpType, opts.jsPropertySyntax)}`;
        subschema.parentDataProperty = (0, codegen_1._)`${dataProp}`;
        subschema.dataPathArr = [...dataPathArr, subschema.parentDataProperty];
      }
      if (data !== void 0) {
        const nextData = data instanceof codegen_1.Name ? data : gen.let("data", data, true);
        dataContextProps(nextData);
        if (propertyName !== void 0)
          subschema.propertyName = propertyName;
      }
      if (dataTypes)
        subschema.dataTypes = dataTypes;
      function dataContextProps(_nextData) {
        subschema.data = _nextData;
        subschema.dataLevel = it.dataLevel + 1;
        subschema.dataTypes = [];
        it.definedProperties = /* @__PURE__ */ new Set();
        subschema.parentData = it.data;
        subschema.dataNames = [...it.dataNames, _nextData];
      }
    }
    exports.extendSubschemaData = extendSubschemaData;
    function extendSubschemaMode(subschema, { jtdDiscriminator, jtdMetadata, compositeRule, createErrors, allErrors }) {
      if (compositeRule !== void 0)
        subschema.compositeRule = compositeRule;
      if (createErrors !== void 0)
        subschema.createErrors = createErrors;
      if (allErrors !== void 0)
        subschema.allErrors = allErrors;
      subschema.jtdDiscriminator = jtdDiscriminator;
      subschema.jtdMetadata = jtdMetadata;
    }
    exports.extendSubschemaMode = extendSubschemaMode;
  }
});

// ../../node_modules/.pnpm/fast-deep-equal@3.1.3/node_modules/fast-deep-equal/index.js
var require_fast_deep_equal = __commonJS({
  "../../node_modules/.pnpm/fast-deep-equal@3.1.3/node_modules/fast-deep-equal/index.js"(exports, module) {
    "use strict";
    module.exports = function equal(a, b) {
      if (a === b) return true;
      if (a && b && typeof a == "object" && typeof b == "object") {
        if (a.constructor !== b.constructor) return false;
        var length, i, keys;
        if (Array.isArray(a)) {
          length = a.length;
          if (length != b.length) return false;
          for (i = length; i-- !== 0; )
            if (!equal(a[i], b[i])) return false;
          return true;
        }
        if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
        if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
        if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
        keys = Object.keys(a);
        length = keys.length;
        if (length !== Object.keys(b).length) return false;
        for (i = length; i-- !== 0; )
          if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
        for (i = length; i-- !== 0; ) {
          var key = keys[i];
          if (!equal(a[key], b[key])) return false;
        }
        return true;
      }
      return a !== a && b !== b;
    };
  }
});

// ../../node_modules/.pnpm/json-schema-traverse@1.0.0/node_modules/json-schema-traverse/index.js
var require_json_schema_traverse = __commonJS({
  "../../node_modules/.pnpm/json-schema-traverse@1.0.0/node_modules/json-schema-traverse/index.js"(exports, module) {
    "use strict";
    var traverse = module.exports = function(schema, opts, cb) {
      if (typeof opts == "function") {
        cb = opts;
        opts = {};
      }
      cb = opts.cb || cb;
      var pre = typeof cb == "function" ? cb : cb.pre || function() {
      };
      var post = cb.post || function() {
      };
      _traverse(opts, pre, post, schema, "", schema);
    };
    traverse.keywords = {
      additionalItems: true,
      items: true,
      contains: true,
      additionalProperties: true,
      propertyNames: true,
      not: true,
      if: true,
      then: true,
      else: true
    };
    traverse.arrayKeywords = {
      items: true,
      allOf: true,
      anyOf: true,
      oneOf: true
    };
    traverse.propsKeywords = {
      $defs: true,
      definitions: true,
      properties: true,
      patternProperties: true,
      dependencies: true
    };
    traverse.skipKeywords = {
      default: true,
      enum: true,
      const: true,
      required: true,
      maximum: true,
      minimum: true,
      exclusiveMaximum: true,
      exclusiveMinimum: true,
      multipleOf: true,
      maxLength: true,
      minLength: true,
      pattern: true,
      format: true,
      maxItems: true,
      minItems: true,
      uniqueItems: true,
      maxProperties: true,
      minProperties: true
    };
    function _traverse(opts, pre, post, schema, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex) {
      if (schema && typeof schema == "object" && !Array.isArray(schema)) {
        pre(schema, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex);
        for (var key in schema) {
          var sch = schema[key];
          if (Array.isArray(sch)) {
            if (key in traverse.arrayKeywords) {
              for (var i = 0; i < sch.length; i++)
                _traverse(opts, pre, post, sch[i], jsonPtr + "/" + key + "/" + i, rootSchema, jsonPtr, key, schema, i);
            }
          } else if (key in traverse.propsKeywords) {
            if (sch && typeof sch == "object") {
              for (var prop in sch)
                _traverse(opts, pre, post, sch[prop], jsonPtr + "/" + key + "/" + escapeJsonPtr(prop), rootSchema, jsonPtr, key, schema, prop);
            }
          } else if (key in traverse.keywords || opts.allKeys && !(key in traverse.skipKeywords)) {
            _traverse(opts, pre, post, sch, jsonPtr + "/" + key, rootSchema, jsonPtr, key, schema);
          }
        }
        post(schema, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex);
      }
    }
    function escapeJsonPtr(str) {
      return str.replace(/~/g, "~0").replace(/\//g, "~1");
    }
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/resolve.js
var require_resolve = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/resolve.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getSchemaRefs = exports.resolveUrl = exports.normalizeId = exports._getFullPath = exports.getFullPath = exports.inlineRef = void 0;
    var util_1 = require_util();
    var equal = require_fast_deep_equal();
    var traverse = require_json_schema_traverse();
    var SIMPLE_INLINED = /* @__PURE__ */ new Set([
      "type",
      "format",
      "pattern",
      "maxLength",
      "minLength",
      "maxProperties",
      "minProperties",
      "maxItems",
      "minItems",
      "maximum",
      "minimum",
      "uniqueItems",
      "multipleOf",
      "required",
      "enum",
      "const"
    ]);
    function inlineRef(schema, limit = true) {
      if (typeof schema == "boolean")
        return true;
      if (limit === true)
        return !hasRef(schema);
      if (!limit)
        return false;
      return countKeys(schema) <= limit;
    }
    exports.inlineRef = inlineRef;
    var REF_KEYWORDS = /* @__PURE__ */ new Set([
      "$ref",
      "$recursiveRef",
      "$recursiveAnchor",
      "$dynamicRef",
      "$dynamicAnchor"
    ]);
    function hasRef(schema) {
      for (const key in schema) {
        if (REF_KEYWORDS.has(key))
          return true;
        const sch = schema[key];
        if (Array.isArray(sch) && sch.some(hasRef))
          return true;
        if (typeof sch == "object" && hasRef(sch))
          return true;
      }
      return false;
    }
    function countKeys(schema) {
      let count = 0;
      for (const key in schema) {
        if (key === "$ref")
          return Infinity;
        count++;
        if (SIMPLE_INLINED.has(key))
          continue;
        if (typeof schema[key] == "object") {
          (0, util_1.eachItem)(schema[key], (sch) => count += countKeys(sch));
        }
        if (count === Infinity)
          return Infinity;
      }
      return count;
    }
    function getFullPath(resolver, id2 = "", normalize) {
      if (normalize !== false)
        id2 = normalizeId(id2);
      const p = resolver.parse(id2);
      return _getFullPath(resolver, p);
    }
    exports.getFullPath = getFullPath;
    function _getFullPath(resolver, p) {
      const serialized = resolver.serialize(p);
      return serialized.split("#")[0] + "#";
    }
    exports._getFullPath = _getFullPath;
    var TRAILING_SLASH_HASH = /#\/?$/;
    function normalizeId(id2) {
      return id2 ? id2.replace(TRAILING_SLASH_HASH, "") : "";
    }
    exports.normalizeId = normalizeId;
    function resolveUrl(resolver, baseId, id2) {
      id2 = normalizeId(id2);
      return resolver.resolve(baseId, id2);
    }
    exports.resolveUrl = resolveUrl;
    var ANCHOR = /^[a-z_][-a-z0-9._]*$/i;
    function getSchemaRefs(schema, baseId) {
      if (typeof schema == "boolean")
        return {};
      const { schemaId, uriResolver } = this.opts;
      const schId = normalizeId(schema[schemaId] || baseId);
      const baseIds = { "": schId };
      const pathPrefix = getFullPath(uriResolver, schId, false);
      const localRefs = {};
      const schemaRefs = /* @__PURE__ */ new Set();
      traverse(schema, { allKeys: true }, (sch, jsonPtr, _, parentJsonPtr) => {
        if (parentJsonPtr === void 0)
          return;
        const fullPath = pathPrefix + jsonPtr;
        let innerBaseId = baseIds[parentJsonPtr];
        if (typeof sch[schemaId] == "string")
          innerBaseId = addRef.call(this, sch[schemaId]);
        addAnchor.call(this, sch.$anchor);
        addAnchor.call(this, sch.$dynamicAnchor);
        baseIds[jsonPtr] = innerBaseId;
        function addRef(ref) {
          const _resolve = this.opts.uriResolver.resolve;
          ref = normalizeId(innerBaseId ? _resolve(innerBaseId, ref) : ref);
          if (schemaRefs.has(ref))
            throw ambiguos(ref);
          schemaRefs.add(ref);
          let schOrRef = this.refs[ref];
          if (typeof schOrRef == "string")
            schOrRef = this.refs[schOrRef];
          if (typeof schOrRef == "object") {
            checkAmbiguosRef(sch, schOrRef.schema, ref);
          } else if (ref !== normalizeId(fullPath)) {
            if (ref[0] === "#") {
              checkAmbiguosRef(sch, localRefs[ref], ref);
              localRefs[ref] = sch;
            } else {
              this.refs[ref] = fullPath;
            }
          }
          return ref;
        }
        function addAnchor(anchor) {
          if (typeof anchor == "string") {
            if (!ANCHOR.test(anchor))
              throw new Error(`invalid anchor "${anchor}"`);
            addRef.call(this, `#${anchor}`);
          }
        }
      });
      return localRefs;
      function checkAmbiguosRef(sch1, sch2, ref) {
        if (sch2 !== void 0 && !equal(sch1, sch2))
          throw ambiguos(ref);
      }
      function ambiguos(ref) {
        return new Error(`reference "${ref}" resolves to more than one schema`);
      }
    }
    exports.getSchemaRefs = getSchemaRefs;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/index.js
var require_validate = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getData = exports.KeywordCxt = exports.validateFunctionCode = void 0;
    var boolSchema_1 = require_boolSchema();
    var dataType_1 = require_dataType();
    var applicability_1 = require_applicability();
    var dataType_2 = require_dataType();
    var defaults_1 = require_defaults();
    var keyword_1 = require_keyword();
    var subschema_1 = require_subschema();
    var codegen_1 = require_codegen();
    var names_1 = require_names();
    var resolve_1 = require_resolve();
    var util_1 = require_util();
    var errors_1 = require_errors();
    function validateFunctionCode(it) {
      if (isSchemaObj(it)) {
        checkKeywords(it);
        if (schemaCxtHasRules(it)) {
          topSchemaObjCode(it);
          return;
        }
      }
      validateFunction(it, () => (0, boolSchema_1.topBoolOrEmptySchema)(it));
    }
    exports.validateFunctionCode = validateFunctionCode;
    function validateFunction({ gen, validateName, schema, schemaEnv, opts }, body2) {
      if (opts.code.es5) {
        gen.func(validateName, (0, codegen_1._)`${names_1.default.data}, ${names_1.default.valCxt}`, schemaEnv.$async, () => {
          gen.code((0, codegen_1._)`"use strict"; ${funcSourceUrl(schema, opts)}`);
          destructureValCxtES5(gen, opts);
          gen.code(body2);
        });
      } else {
        gen.func(validateName, (0, codegen_1._)`${names_1.default.data}, ${destructureValCxt(opts)}`, schemaEnv.$async, () => gen.code(funcSourceUrl(schema, opts)).code(body2));
      }
    }
    function destructureValCxt(opts) {
      return (0, codegen_1._)`{${names_1.default.instancePath}="", ${names_1.default.parentData}, ${names_1.default.parentDataProperty}, ${names_1.default.rootData}=${names_1.default.data}${opts.dynamicRef ? (0, codegen_1._)`, ${names_1.default.dynamicAnchors}={}` : codegen_1.nil}}={}`;
    }
    function destructureValCxtES5(gen, opts) {
      gen.if(names_1.default.valCxt, () => {
        gen.var(names_1.default.instancePath, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.instancePath}`);
        gen.var(names_1.default.parentData, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.parentData}`);
        gen.var(names_1.default.parentDataProperty, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.parentDataProperty}`);
        gen.var(names_1.default.rootData, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.rootData}`);
        if (opts.dynamicRef)
          gen.var(names_1.default.dynamicAnchors, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.dynamicAnchors}`);
      }, () => {
        gen.var(names_1.default.instancePath, (0, codegen_1._)`""`);
        gen.var(names_1.default.parentData, (0, codegen_1._)`undefined`);
        gen.var(names_1.default.parentDataProperty, (0, codegen_1._)`undefined`);
        gen.var(names_1.default.rootData, names_1.default.data);
        if (opts.dynamicRef)
          gen.var(names_1.default.dynamicAnchors, (0, codegen_1._)`{}`);
      });
    }
    function topSchemaObjCode(it) {
      const { schema, opts, gen } = it;
      validateFunction(it, () => {
        if (opts.$comment && schema.$comment)
          commentKeyword(it);
        checkNoDefault(it);
        gen.let(names_1.default.vErrors, null);
        gen.let(names_1.default.errors, 0);
        if (opts.unevaluated)
          resetEvaluated(it);
        typeAndKeywords(it);
        returnResults(it);
      });
      return;
    }
    function resetEvaluated(it) {
      const { gen, validateName } = it;
      it.evaluated = gen.const("evaluated", (0, codegen_1._)`${validateName}.evaluated`);
      gen.if((0, codegen_1._)`${it.evaluated}.dynamicProps`, () => gen.assign((0, codegen_1._)`${it.evaluated}.props`, (0, codegen_1._)`undefined`));
      gen.if((0, codegen_1._)`${it.evaluated}.dynamicItems`, () => gen.assign((0, codegen_1._)`${it.evaluated}.items`, (0, codegen_1._)`undefined`));
    }
    function funcSourceUrl(schema, opts) {
      const schId = typeof schema == "object" && schema[opts.schemaId];
      return schId && (opts.code.source || opts.code.process) ? (0, codegen_1._)`/*# sourceURL=${schId} */` : codegen_1.nil;
    }
    function subschemaCode(it, valid) {
      if (isSchemaObj(it)) {
        checkKeywords(it);
        if (schemaCxtHasRules(it)) {
          subSchemaObjCode(it, valid);
          return;
        }
      }
      (0, boolSchema_1.boolOrEmptySchema)(it, valid);
    }
    function schemaCxtHasRules({ schema, self }) {
      if (typeof schema == "boolean")
        return !schema;
      for (const key in schema)
        if (self.RULES.all[key])
          return true;
      return false;
    }
    function isSchemaObj(it) {
      return typeof it.schema != "boolean";
    }
    function subSchemaObjCode(it, valid) {
      const { schema, gen, opts } = it;
      if (opts.$comment && schema.$comment)
        commentKeyword(it);
      updateContext(it);
      checkAsyncSchema(it);
      const errsCount = gen.const("_errs", names_1.default.errors);
      typeAndKeywords(it, errsCount);
      gen.var(valid, (0, codegen_1._)`${errsCount} === ${names_1.default.errors}`);
    }
    function checkKeywords(it) {
      (0, util_1.checkUnknownRules)(it);
      checkRefsAndKeywords(it);
    }
    function typeAndKeywords(it, errsCount) {
      if (it.opts.jtd)
        return schemaKeywords(it, [], false, errsCount);
      const types = (0, dataType_1.getSchemaTypes)(it.schema);
      const checkedTypes = (0, dataType_1.coerceAndCheckDataType)(it, types);
      schemaKeywords(it, types, !checkedTypes, errsCount);
    }
    function checkRefsAndKeywords(it) {
      const { schema, errSchemaPath, opts, self } = it;
      if (schema.$ref && opts.ignoreKeywordsWithRef && (0, util_1.schemaHasRulesButRef)(schema, self.RULES)) {
        self.logger.warn(`$ref: keywords ignored in schema at path "${errSchemaPath}"`);
      }
    }
    function checkNoDefault(it) {
      const { schema, opts } = it;
      if (schema.default !== void 0 && opts.useDefaults && opts.strictSchema) {
        (0, util_1.checkStrictMode)(it, "default is ignored in the schema root");
      }
    }
    function updateContext(it) {
      const schId = it.schema[it.opts.schemaId];
      if (schId)
        it.baseId = (0, resolve_1.resolveUrl)(it.opts.uriResolver, it.baseId, schId);
    }
    function checkAsyncSchema(it) {
      if (it.schema.$async && !it.schemaEnv.$async)
        throw new Error("async schema in sync schema");
    }
    function commentKeyword({ gen, schemaEnv, schema, errSchemaPath, opts }) {
      const msg = schema.$comment;
      if (opts.$comment === true) {
        gen.code((0, codegen_1._)`${names_1.default.self}.logger.log(${msg})`);
      } else if (typeof opts.$comment == "function") {
        const schemaPath = (0, codegen_1.str)`${errSchemaPath}/$comment`;
        const rootName = gen.scopeValue("root", { ref: schemaEnv.root });
        gen.code((0, codegen_1._)`${names_1.default.self}.opts.$comment(${msg}, ${schemaPath}, ${rootName}.schema)`);
      }
    }
    function returnResults(it) {
      const { gen, schemaEnv, validateName, ValidationError, opts } = it;
      if (schemaEnv.$async) {
        gen.if((0, codegen_1._)`${names_1.default.errors} === 0`, () => gen.return(names_1.default.data), () => gen.throw((0, codegen_1._)`new ${ValidationError}(${names_1.default.vErrors})`));
      } else {
        gen.assign((0, codegen_1._)`${validateName}.errors`, names_1.default.vErrors);
        if (opts.unevaluated)
          assignEvaluated(it);
        gen.return((0, codegen_1._)`${names_1.default.errors} === 0`);
      }
    }
    function assignEvaluated({ gen, evaluated, props, items }) {
      if (props instanceof codegen_1.Name)
        gen.assign((0, codegen_1._)`${evaluated}.props`, props);
      if (items instanceof codegen_1.Name)
        gen.assign((0, codegen_1._)`${evaluated}.items`, items);
    }
    function schemaKeywords(it, types, typeErrors, errsCount) {
      const { gen, schema, data, allErrors, opts, self } = it;
      const { RULES } = self;
      if (schema.$ref && (opts.ignoreKeywordsWithRef || !(0, util_1.schemaHasRulesButRef)(schema, RULES))) {
        gen.block(() => keywordCode(it, "$ref", RULES.all.$ref.definition));
        return;
      }
      if (!opts.jtd)
        checkStrictTypes(it, types);
      gen.block(() => {
        for (const group of RULES.rules)
          groupKeywords(group);
        groupKeywords(RULES.post);
      });
      function groupKeywords(group) {
        if (!(0, applicability_1.shouldUseGroup)(schema, group))
          return;
        if (group.type) {
          gen.if((0, dataType_2.checkDataType)(group.type, data, opts.strictNumbers));
          iterateKeywords(it, group);
          if (types.length === 1 && types[0] === group.type && typeErrors) {
            gen.else();
            (0, dataType_2.reportTypeError)(it);
          }
          gen.endIf();
        } else {
          iterateKeywords(it, group);
        }
        if (!allErrors)
          gen.if((0, codegen_1._)`${names_1.default.errors} === ${errsCount || 0}`);
      }
    }
    function iterateKeywords(it, group) {
      const { gen, schema, opts: { useDefaults } } = it;
      if (useDefaults)
        (0, defaults_1.assignDefaults)(it, group.type);
      gen.block(() => {
        for (const rule of group.rules) {
          if ((0, applicability_1.shouldUseRule)(schema, rule)) {
            keywordCode(it, rule.keyword, rule.definition, group.type);
          }
        }
      });
    }
    function checkStrictTypes(it, types) {
      if (it.schemaEnv.meta || !it.opts.strictTypes)
        return;
      checkContextTypes(it, types);
      if (!it.opts.allowUnionTypes)
        checkMultipleTypes(it, types);
      checkKeywordTypes(it, it.dataTypes);
    }
    function checkContextTypes(it, types) {
      if (!types.length)
        return;
      if (!it.dataTypes.length) {
        it.dataTypes = types;
        return;
      }
      types.forEach((t) => {
        if (!includesType(it.dataTypes, t)) {
          strictTypesError(it, `type "${t}" not allowed by context "${it.dataTypes.join(",")}"`);
        }
      });
      narrowSchemaTypes(it, types);
    }
    function checkMultipleTypes(it, ts) {
      if (ts.length > 1 && !(ts.length === 2 && ts.includes("null"))) {
        strictTypesError(it, "use allowUnionTypes to allow union type keyword");
      }
    }
    function checkKeywordTypes(it, ts) {
      const rules = it.self.RULES.all;
      for (const keyword in rules) {
        const rule = rules[keyword];
        if (typeof rule == "object" && (0, applicability_1.shouldUseRule)(it.schema, rule)) {
          const { type } = rule.definition;
          if (type.length && !type.some((t) => hasApplicableType(ts, t))) {
            strictTypesError(it, `missing type "${type.join(",")}" for keyword "${keyword}"`);
          }
        }
      }
    }
    function hasApplicableType(schTs, kwdT) {
      return schTs.includes(kwdT) || kwdT === "number" && schTs.includes("integer");
    }
    function includesType(ts, t) {
      return ts.includes(t) || t === "integer" && ts.includes("number");
    }
    function narrowSchemaTypes(it, withTypes) {
      const ts = [];
      for (const t of it.dataTypes) {
        if (includesType(withTypes, t))
          ts.push(t);
        else if (withTypes.includes("integer") && t === "number")
          ts.push("integer");
      }
      it.dataTypes = ts;
    }
    function strictTypesError(it, msg) {
      const schemaPath = it.schemaEnv.baseId + it.errSchemaPath;
      msg += ` at "${schemaPath}" (strictTypes)`;
      (0, util_1.checkStrictMode)(it, msg, it.opts.strictTypes);
    }
    var KeywordCxt = class {
      constructor(it, def, keyword) {
        (0, keyword_1.validateKeywordUsage)(it, def, keyword);
        this.gen = it.gen;
        this.allErrors = it.allErrors;
        this.keyword = keyword;
        this.data = it.data;
        this.schema = it.schema[keyword];
        this.$data = def.$data && it.opts.$data && this.schema && this.schema.$data;
        this.schemaValue = (0, util_1.schemaRefOrVal)(it, this.schema, keyword, this.$data);
        this.schemaType = def.schemaType;
        this.parentSchema = it.schema;
        this.params = {};
        this.it = it;
        this.def = def;
        if (this.$data) {
          this.schemaCode = it.gen.const("vSchema", getData(this.$data, it));
        } else {
          this.schemaCode = this.schemaValue;
          if (!(0, keyword_1.validSchemaType)(this.schema, def.schemaType, def.allowUndefined)) {
            throw new Error(`${keyword} value must be ${JSON.stringify(def.schemaType)}`);
          }
        }
        if ("code" in def ? def.trackErrors : def.errors !== false) {
          this.errsCount = it.gen.const("_errs", names_1.default.errors);
        }
      }
      result(condition, successAction, failAction) {
        this.failResult((0, codegen_1.not)(condition), successAction, failAction);
      }
      failResult(condition, successAction, failAction) {
        this.gen.if(condition);
        if (failAction)
          failAction();
        else
          this.error();
        if (successAction) {
          this.gen.else();
          successAction();
          if (this.allErrors)
            this.gen.endIf();
        } else {
          if (this.allErrors)
            this.gen.endIf();
          else
            this.gen.else();
        }
      }
      pass(condition, failAction) {
        this.failResult((0, codegen_1.not)(condition), void 0, failAction);
      }
      fail(condition) {
        if (condition === void 0) {
          this.error();
          if (!this.allErrors)
            this.gen.if(false);
          return;
        }
        this.gen.if(condition);
        this.error();
        if (this.allErrors)
          this.gen.endIf();
        else
          this.gen.else();
      }
      fail$data(condition) {
        if (!this.$data)
          return this.fail(condition);
        const { schemaCode } = this;
        this.fail((0, codegen_1._)`${schemaCode} !== undefined && (${(0, codegen_1.or)(this.invalid$data(), condition)})`);
      }
      error(append, errorParams, errorPaths) {
        if (errorParams) {
          this.setParams(errorParams);
          this._error(append, errorPaths);
          this.setParams({});
          return;
        }
        this._error(append, errorPaths);
      }
      _error(append, errorPaths) {
        ;
        (append ? errors_1.reportExtraError : errors_1.reportError)(this, this.def.error, errorPaths);
      }
      $dataError() {
        (0, errors_1.reportError)(this, this.def.$dataError || errors_1.keyword$DataError);
      }
      reset() {
        if (this.errsCount === void 0)
          throw new Error('add "trackErrors" to keyword definition');
        (0, errors_1.resetErrorsCount)(this.gen, this.errsCount);
      }
      ok(cond) {
        if (!this.allErrors)
          this.gen.if(cond);
      }
      setParams(obj, assign) {
        if (assign)
          Object.assign(this.params, obj);
        else
          this.params = obj;
      }
      block$data(valid, codeBlock, $dataValid = codegen_1.nil) {
        this.gen.block(() => {
          this.check$data(valid, $dataValid);
          codeBlock();
        });
      }
      check$data(valid = codegen_1.nil, $dataValid = codegen_1.nil) {
        if (!this.$data)
          return;
        const { gen, schemaCode, schemaType, def } = this;
        gen.if((0, codegen_1.or)((0, codegen_1._)`${schemaCode} === undefined`, $dataValid));
        if (valid !== codegen_1.nil)
          gen.assign(valid, true);
        if (schemaType.length || def.validateSchema) {
          gen.elseIf(this.invalid$data());
          this.$dataError();
          if (valid !== codegen_1.nil)
            gen.assign(valid, false);
        }
        gen.else();
      }
      invalid$data() {
        const { gen, schemaCode, schemaType, def, it } = this;
        return (0, codegen_1.or)(wrong$DataType(), invalid$DataSchema());
        function wrong$DataType() {
          if (schemaType.length) {
            if (!(schemaCode instanceof codegen_1.Name))
              throw new Error("ajv implementation error");
            const st = Array.isArray(schemaType) ? schemaType : [schemaType];
            return (0, codegen_1._)`${(0, dataType_2.checkDataTypes)(st, schemaCode, it.opts.strictNumbers, dataType_2.DataType.Wrong)}`;
          }
          return codegen_1.nil;
        }
        function invalid$DataSchema() {
          if (def.validateSchema) {
            const validateSchemaRef = gen.scopeValue("validate$data", { ref: def.validateSchema });
            return (0, codegen_1._)`!${validateSchemaRef}(${schemaCode})`;
          }
          return codegen_1.nil;
        }
      }
      subschema(appl, valid) {
        const subschema = (0, subschema_1.getSubschema)(this.it, appl);
        (0, subschema_1.extendSubschemaData)(subschema, this.it, appl);
        (0, subschema_1.extendSubschemaMode)(subschema, appl);
        const nextContext = { ...this.it, ...subschema, items: void 0, props: void 0 };
        subschemaCode(nextContext, valid);
        return nextContext;
      }
      mergeEvaluated(schemaCxt, toName) {
        const { it, gen } = this;
        if (!it.opts.unevaluated)
          return;
        if (it.props !== true && schemaCxt.props !== void 0) {
          it.props = util_1.mergeEvaluated.props(gen, schemaCxt.props, it.props, toName);
        }
        if (it.items !== true && schemaCxt.items !== void 0) {
          it.items = util_1.mergeEvaluated.items(gen, schemaCxt.items, it.items, toName);
        }
      }
      mergeValidEvaluated(schemaCxt, valid) {
        const { it, gen } = this;
        if (it.opts.unevaluated && (it.props !== true || it.items !== true)) {
          gen.if(valid, () => this.mergeEvaluated(schemaCxt, codegen_1.Name));
          return true;
        }
      }
    };
    exports.KeywordCxt = KeywordCxt;
    function keywordCode(it, keyword, def, ruleType) {
      const cxt = new KeywordCxt(it, def, keyword);
      if ("code" in def) {
        def.code(cxt, ruleType);
      } else if (cxt.$data && def.validate) {
        (0, keyword_1.funcKeywordCode)(cxt, def);
      } else if ("macro" in def) {
        (0, keyword_1.macroKeywordCode)(cxt, def);
      } else if (def.compile || def.validate) {
        (0, keyword_1.funcKeywordCode)(cxt, def);
      }
    }
    var JSON_POINTER = /^\/(?:[^~]|~0|~1)*$/;
    var RELATIVE_JSON_POINTER = /^([0-9]+)(#|\/(?:[^~]|~0|~1)*)?$/;
    function getData($data, { dataLevel, dataNames, dataPathArr }) {
      let jsonPointer;
      let data;
      if ($data === "")
        return names_1.default.rootData;
      if ($data[0] === "/") {
        if (!JSON_POINTER.test($data))
          throw new Error(`Invalid JSON-pointer: ${$data}`);
        jsonPointer = $data;
        data = names_1.default.rootData;
      } else {
        const matches2 = RELATIVE_JSON_POINTER.exec($data);
        if (!matches2)
          throw new Error(`Invalid JSON-pointer: ${$data}`);
        const up = +matches2[1];
        jsonPointer = matches2[2];
        if (jsonPointer === "#") {
          if (up >= dataLevel)
            throw new Error(errorMsg("property/index", up));
          return dataPathArr[dataLevel - up];
        }
        if (up > dataLevel)
          throw new Error(errorMsg("data", up));
        data = dataNames[dataLevel - up];
        if (!jsonPointer)
          return data;
      }
      let expr = data;
      const segments = jsonPointer.split("/");
      for (const segment of segments) {
        if (segment) {
          data = (0, codegen_1._)`${data}${(0, codegen_1.getProperty)((0, util_1.unescapeJsonPointer)(segment))}`;
          expr = (0, codegen_1._)`${expr} && ${data}`;
        }
      }
      return expr;
      function errorMsg(pointerType, up) {
        return `Cannot access ${pointerType} ${up} levels up, current level is ${dataLevel}`;
      }
    }
    exports.getData = getData;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/validation_error.js
var require_validation_error = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/validation_error.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var ValidationError = class extends Error {
      constructor(errors) {
        super("validation failed");
        this.errors = errors;
        this.ajv = this.validation = true;
      }
    };
    exports.default = ValidationError;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/ref_error.js
var require_ref_error = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/ref_error.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var resolve_1 = require_resolve();
    var MissingRefError = class extends Error {
      constructor(resolver, baseId, ref, msg) {
        super(msg || `can't resolve reference ${ref} from id ${baseId}`);
        this.missingRef = (0, resolve_1.resolveUrl)(resolver, baseId, ref);
        this.missingSchema = (0, resolve_1.normalizeId)((0, resolve_1.getFullPath)(resolver, this.missingRef));
      }
    };
    exports.default = MissingRefError;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/index.js
var require_compile = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.resolveSchema = exports.getCompilingSchema = exports.resolveRef = exports.compileSchema = exports.SchemaEnv = void 0;
    var codegen_1 = require_codegen();
    var validation_error_1 = require_validation_error();
    var names_1 = require_names();
    var resolve_1 = require_resolve();
    var util_1 = require_util();
    var validate_1 = require_validate();
    var SchemaEnv = class {
      constructor(env) {
        var _a;
        this.refs = {};
        this.dynamicAnchors = {};
        let schema;
        if (typeof env.schema == "object")
          schema = env.schema;
        this.schema = env.schema;
        this.schemaId = env.schemaId;
        this.root = env.root || this;
        this.baseId = (_a = env.baseId) !== null && _a !== void 0 ? _a : (0, resolve_1.normalizeId)(schema === null || schema === void 0 ? void 0 : schema[env.schemaId || "$id"]);
        this.schemaPath = env.schemaPath;
        this.localRefs = env.localRefs;
        this.meta = env.meta;
        this.$async = schema === null || schema === void 0 ? void 0 : schema.$async;
        this.refs = {};
      }
    };
    exports.SchemaEnv = SchemaEnv;
    function compileSchema(sch) {
      const _sch = getCompilingSchema.call(this, sch);
      if (_sch)
        return _sch;
      const rootId = (0, resolve_1.getFullPath)(this.opts.uriResolver, sch.root.baseId);
      const { es5, lines } = this.opts.code;
      const { ownProperties } = this.opts;
      const gen = new codegen_1.CodeGen(this.scope, { es5, lines, ownProperties });
      let _ValidationError;
      if (sch.$async) {
        _ValidationError = gen.scopeValue("Error", {
          ref: validation_error_1.default,
          code: (0, codegen_1._)`require("ajv/dist/runtime/validation_error").default`
        });
      }
      const validateName = gen.scopeName("validate");
      sch.validateName = validateName;
      const schemaCxt = {
        gen,
        allErrors: this.opts.allErrors,
        data: names_1.default.data,
        parentData: names_1.default.parentData,
        parentDataProperty: names_1.default.parentDataProperty,
        dataNames: [names_1.default.data],
        dataPathArr: [codegen_1.nil],
        // TODO can its length be used as dataLevel if nil is removed?
        dataLevel: 0,
        dataTypes: [],
        definedProperties: /* @__PURE__ */ new Set(),
        topSchemaRef: gen.scopeValue("schema", this.opts.code.source === true ? { ref: sch.schema, code: (0, codegen_1.stringify)(sch.schema) } : { ref: sch.schema }),
        validateName,
        ValidationError: _ValidationError,
        schema: sch.schema,
        schemaEnv: sch,
        rootId,
        baseId: sch.baseId || rootId,
        schemaPath: codegen_1.nil,
        errSchemaPath: sch.schemaPath || (this.opts.jtd ? "" : "#"),
        errorPath: (0, codegen_1._)`""`,
        opts: this.opts,
        self: this
      };
      let sourceCode;
      try {
        this._compilations.add(sch);
        (0, validate_1.validateFunctionCode)(schemaCxt);
        gen.optimize(this.opts.code.optimize);
        const validateCode = gen.toString();
        sourceCode = `${gen.scopeRefs(names_1.default.scope)}return ${validateCode}`;
        if (this.opts.code.process)
          sourceCode = this.opts.code.process(sourceCode, sch);
        const makeValidate = new Function(`${names_1.default.self}`, `${names_1.default.scope}`, sourceCode);
        const validate2 = makeValidate(this, this.scope.get());
        this.scope.value(validateName, { ref: validate2 });
        validate2.errors = null;
        validate2.schema = sch.schema;
        validate2.schemaEnv = sch;
        if (sch.$async)
          validate2.$async = true;
        if (this.opts.code.source === true) {
          validate2.source = { validateName, validateCode, scopeValues: gen._values };
        }
        if (this.opts.unevaluated) {
          const { props, items } = schemaCxt;
          validate2.evaluated = {
            props: props instanceof codegen_1.Name ? void 0 : props,
            items: items instanceof codegen_1.Name ? void 0 : items,
            dynamicProps: props instanceof codegen_1.Name,
            dynamicItems: items instanceof codegen_1.Name
          };
          if (validate2.source)
            validate2.source.evaluated = (0, codegen_1.stringify)(validate2.evaluated);
        }
        sch.validate = validate2;
        return sch;
      } catch (e) {
        delete sch.validate;
        delete sch.validateName;
        if (sourceCode)
          this.logger.error("Error compiling schema, function code:", sourceCode);
        throw e;
      } finally {
        this._compilations.delete(sch);
      }
    }
    exports.compileSchema = compileSchema;
    function resolveRef(root, baseId, ref) {
      var _a;
      ref = (0, resolve_1.resolveUrl)(this.opts.uriResolver, baseId, ref);
      const schOrFunc = root.refs[ref];
      if (schOrFunc)
        return schOrFunc;
      let _sch = resolve3.call(this, root, ref);
      if (_sch === void 0) {
        const schema = (_a = root.localRefs) === null || _a === void 0 ? void 0 : _a[ref];
        const { schemaId } = this.opts;
        if (schema)
          _sch = new SchemaEnv({ schema, schemaId, root, baseId });
      }
      if (_sch === void 0)
        return;
      return root.refs[ref] = inlineOrCompile.call(this, _sch);
    }
    exports.resolveRef = resolveRef;
    function inlineOrCompile(sch) {
      if ((0, resolve_1.inlineRef)(sch.schema, this.opts.inlineRefs))
        return sch.schema;
      return sch.validate ? sch : compileSchema.call(this, sch);
    }
    function getCompilingSchema(schEnv) {
      for (const sch of this._compilations) {
        if (sameSchemaEnv(sch, schEnv))
          return sch;
      }
    }
    exports.getCompilingSchema = getCompilingSchema;
    function sameSchemaEnv(s1, s2) {
      return s1.schema === s2.schema && s1.root === s2.root && s1.baseId === s2.baseId;
    }
    function resolve3(root, ref) {
      let sch;
      while (typeof (sch = this.refs[ref]) == "string")
        ref = sch;
      return sch || this.schemas[ref] || resolveSchema.call(this, root, ref);
    }
    function resolveSchema(root, ref) {
      const p = this.opts.uriResolver.parse(ref);
      const refPath = (0, resolve_1._getFullPath)(this.opts.uriResolver, p);
      let baseId = (0, resolve_1.getFullPath)(this.opts.uriResolver, root.baseId, void 0);
      if (Object.keys(root.schema).length > 0 && refPath === baseId) {
        return getJsonPointer.call(this, p, root);
      }
      const id2 = (0, resolve_1.normalizeId)(refPath);
      const schOrRef = this.refs[id2] || this.schemas[id2];
      if (typeof schOrRef == "string") {
        const sch = resolveSchema.call(this, root, schOrRef);
        if (typeof (sch === null || sch === void 0 ? void 0 : sch.schema) !== "object")
          return;
        return getJsonPointer.call(this, p, sch);
      }
      if (typeof (schOrRef === null || schOrRef === void 0 ? void 0 : schOrRef.schema) !== "object")
        return;
      if (!schOrRef.validate)
        compileSchema.call(this, schOrRef);
      if (id2 === (0, resolve_1.normalizeId)(ref)) {
        const { schema } = schOrRef;
        const { schemaId } = this.opts;
        const schId = schema[schemaId];
        if (schId)
          baseId = (0, resolve_1.resolveUrl)(this.opts.uriResolver, baseId, schId);
        return new SchemaEnv({ schema, schemaId, root, baseId });
      }
      return getJsonPointer.call(this, p, schOrRef);
    }
    exports.resolveSchema = resolveSchema;
    var PREVENT_SCOPE_CHANGE = /* @__PURE__ */ new Set([
      "properties",
      "patternProperties",
      "enum",
      "dependencies",
      "definitions"
    ]);
    function getJsonPointer(parsedRef, { baseId, schema, root }) {
      var _a;
      if (((_a = parsedRef.fragment) === null || _a === void 0 ? void 0 : _a[0]) !== "/")
        return;
      for (const part of parsedRef.fragment.slice(1).split("/")) {
        if (typeof schema === "boolean")
          return;
        const partSchema = schema[(0, util_1.unescapeFragment)(part)];
        if (partSchema === void 0)
          return;
        schema = partSchema;
        const schId = typeof schema === "object" && schema[this.opts.schemaId];
        if (!PREVENT_SCOPE_CHANGE.has(part) && schId) {
          baseId = (0, resolve_1.resolveUrl)(this.opts.uriResolver, baseId, schId);
        }
      }
      let env;
      if (typeof schema != "boolean" && schema.$ref && !(0, util_1.schemaHasRulesButRef)(schema, this.RULES)) {
        const $ref = (0, resolve_1.resolveUrl)(this.opts.uriResolver, baseId, schema.$ref);
        env = resolveSchema.call(this, root, $ref);
      }
      const { schemaId } = this.opts;
      env = env || new SchemaEnv({ schema, schemaId, root, baseId });
      if (env.schema !== env.root.schema)
        return env;
      return void 0;
    }
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/refs/data.json
var require_data = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/refs/data.json"(exports, module) {
    module.exports = {
      $id: "https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#",
      description: "Meta-schema for $data reference (JSON AnySchema extension proposal)",
      type: "object",
      required: ["$data"],
      properties: {
        $data: {
          type: "string",
          anyOf: [{ format: "relative-json-pointer" }, { format: "json-pointer" }]
        }
      },
      additionalProperties: false
    };
  }
});

// ../../node_modules/.pnpm/fast-uri@3.1.8/node_modules/fast-uri/lib/utils.js
var require_utils = __commonJS({
  "../../node_modules/.pnpm/fast-uri@3.1.8/node_modules/fast-uri/lib/utils.js"(exports, module) {
    "use strict";
    var isUUID = RegExp.prototype.test.bind(/^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/iu);
    var isIPv4 = RegExp.prototype.test.bind(/^(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)$/u);
    var isPort = RegExp.prototype.test.bind(/^\d*$/u);
    var isHexPair = RegExp.prototype.test.bind(/^[\da-f]{2}$/iu);
    var isUnreserved = RegExp.prototype.test.bind(/^[\da-z\-._~]$/iu);
    var isPathCharacter = RegExp.prototype.test.bind(/^[A-Za-z0-9\-._~!$&'()*+,;=:@/]$/u);
    var isQueryFragmentCharacter = RegExp.prototype.test.bind(/^[A-Za-z0-9\-._~!$&'()*+,;=:@/?]$/u);
    var isUserinfoCharacter = RegExp.prototype.test.bind(/^[A-Za-z0-9\-._~!$&'()*+,;=:]$/u);
    var BYTE_HEX = new Array(256);
    {
      const HEX_DIGITS = "0123456789ABCDEF";
      for (let i = 0; i < 256; i++) {
        BYTE_HEX[i] = "%" + HEX_DIGITS[i >> 4] + HEX_DIGITS[i & 15];
      }
    }
    function percentEncodeNonAscii(cp) {
      if (cp < 2048) {
        return BYTE_HEX[192 | cp >> 6] + BYTE_HEX[128 | cp & 63];
      }
      if (cp < 65536) {
        return BYTE_HEX[224 | cp >> 12] + BYTE_HEX[128 | cp >> 6 & 63] + BYTE_HEX[128 | cp & 63];
      }
      return BYTE_HEX[240 | cp >> 18] + BYTE_HEX[128 | cp >> 12 & 63] + BYTE_HEX[128 | cp >> 6 & 63] + BYTE_HEX[128 | cp & 63];
    }
    function stringArrayToHexStripped(input) {
      let acc = "";
      let code = 0;
      let i = 0;
      for (i = 0; i < input.length; i++) {
        code = input[i].charCodeAt(0);
        if (code === 48) {
          continue;
        }
        if (!(code >= 48 && code <= 57 || code >= 65 && code <= 70 || code >= 97 && code <= 102)) {
          return "";
        }
        acc += input[i];
        break;
      }
      for (i += 1; i < input.length; i++) {
        code = input[i].charCodeAt(0);
        if (!(code >= 48 && code <= 57 || code >= 65 && code <= 70 || code >= 97 && code <= 102)) {
          return "";
        }
        acc += input[i];
      }
      return acc;
    }
    var isHextet = RegExp.prototype.test.bind(/^[\dA-Fa-f]{1,4}$/);
    var isIPvFuture = RegExp.prototype.test.bind(/^[vV][\dA-Fa-f]+\.[A-Za-z\d\-._~!$&'()*+,;=:]+$/);
    var isZoneCharacter = RegExp.prototype.test.bind(/^[A-Za-z\d\-._~]$/);
    var nonSimpleDomain = RegExp.prototype.test.bind(/[^!"$&'()*+,\-.;=_`a-z{}~]/u);
    function isZoneIdentifier(zone) {
      if (zone.length === 0) return false;
      for (let i = 0; i < zone.length; i++) {
        if (isZoneCharacter(zone[i])) continue;
        if (zone[i] === "%" && i + 2 < zone.length && isHexPair(zone.slice(i + 1, i + 3))) {
          i += 2;
          continue;
        }
        return false;
      }
      return true;
    }
    function compressIPv6ZeroRun(hextets) {
      let bestStart = -1;
      let bestLength = 0;
      let runStart = -1;
      let runLength = 0;
      for (let i = 0; i < hextets.length; i++) {
        if (hextets[i] === "0") {
          if (runStart === -1) runStart = i;
          runLength++;
          if (runLength > bestLength) {
            bestLength = runLength;
            bestStart = runStart;
          }
        } else {
          runStart = -1;
          runLength = 0;
        }
      }
      if (bestLength < 2) return hextets.join(":");
      const head = hextets.slice(0, bestStart).join(":");
      const tail = hextets.slice(bestStart + bestLength).join(":");
      return head + "::" + tail;
    }
    function normalizeIPv6Address(input) {
      const compression = input.indexOf("::");
      if (compression !== -1 && input.indexOf("::", compression + 1) !== -1) return void 0;
      const left = compression === -1 ? input.split(":") : input.slice(0, compression).split(":");
      const right = compression === -1 ? [] : input.slice(compression + 2).split(":");
      if (compression !== -1) {
        if (left.length === 1 && left[0] === "") left.length = 0;
        if (right.length === 1 && right[0] === "") right.length = 0;
      }
      const parts = left.concat(right);
      let hextetCount = 0;
      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        if (part === "") return void 0;
        if (part.indexOf(".") !== -1) {
          if (i !== parts.length - 1 || compression !== -1 && right.length === 0 || !isIPv4(part)) return void 0;
          hextetCount += 2;
          continue;
        }
        if (!isHextet(part)) return void 0;
        parts[i] = parseInt(part, 16).toString(16);
        hextetCount++;
      }
      if (compression === -1) {
        if (hextetCount !== 8) return void 0;
        return compressIPv6ZeroRun(parts);
      }
      if (hextetCount >= 8) return void 0;
      const expanded = parts.slice(0, left.length);
      for (let i = hextetCount; i < 8; i++) expanded.push("0");
      for (let i = left.length; i < parts.length; i++) expanded.push(parts[i]);
      return compressIPv6ZeroRun(expanded);
    }
    function normalizeIPv6(host) {
      const bracketed = host[0] === "[" && host[host.length - 1] === "]";
      const hasBracket = host[0] === "[" || host[host.length - 1] === "]";
      if (hasBracket && !bracketed) return { host, isIPV6: false, error: true };
      let input = bracketed ? host.slice(1, -1) : host;
      if (bracketed && isIPvFuture(input)) {
        input = input.toLowerCase();
        return { host: `[${input}]`, escapedHost: input, isIPV6: false, isIPVFuture: true };
      }
      if (findToken(input, ":") < 2) {
        return { host, isIPV6: false, error: bracketed };
      }
      let zoneIdentifier = "";
      const zoneSeparator = input.indexOf("%");
      if (zoneSeparator !== -1) {
        const separatorLength = input.slice(zoneSeparator, zoneSeparator + 3).toLowerCase() === "%25" ? 3 : 1;
        zoneIdentifier = input.slice(zoneSeparator + separatorLength);
        if (!isZoneIdentifier(zoneIdentifier)) return { host, isIPV6: false, error: true };
        input = input.slice(0, zoneSeparator);
      }
      const address = normalizeIPv6Address(input);
      if (address === void 0) return { host, isIPV6: false, error: true };
      return {
        host: address + (zoneIdentifier ? "%" + zoneIdentifier : ""),
        escapedHost: address + (zoneIdentifier ? "%25" + zoneIdentifier : ""),
        isIPV6: true
      };
    }
    function findToken(str, token) {
      let ind = 0;
      for (let i = 0; i < str.length; i++) {
        if (str[i] === token) ind++;
      }
      return ind;
    }
    function removeDotSegments(path5) {
      let input = path5;
      const output2 = [];
      let nextSlash = -1;
      let len = 0;
      while (len = input.length) {
        if (len === 1) {
          if (input === ".") {
            break;
          } else if (input === "/") {
            output2.push("/");
            break;
          } else {
            output2.push(input);
            break;
          }
        } else if (len === 2) {
          if (input[0] === ".") {
            if (input[1] === ".") {
              break;
            } else if (input[1] === "/") {
              input = input.slice(2);
              continue;
            }
          } else if (input[0] === "/") {
            if (input[1] === "." || input[1] === "/") {
              output2.push("/");
              break;
            }
          }
        } else if (len === 3) {
          if (input === "/..") {
            if (output2.length !== 0) {
              output2.pop();
            }
            output2.push("/");
            break;
          }
        }
        if (input[0] === ".") {
          if (input[1] === ".") {
            if (input[2] === "/") {
              input = input.slice(3);
              continue;
            }
          } else if (input[1] === "/") {
            input = input.slice(2);
            continue;
          }
        } else if (input[0] === "/") {
          if (input[1] === ".") {
            if (input[2] === "/") {
              input = input.slice(2);
              continue;
            } else if (input[2] === ".") {
              if (input[3] === "/") {
                input = input.slice(3);
                if (output2.length !== 0) {
                  output2.pop();
                }
                continue;
              }
            }
          }
        }
        if ((nextSlash = input.indexOf("/", 1)) === -1) {
          output2.push(input);
          break;
        } else {
          output2.push(input.slice(0, nextSlash));
          input = input.slice(nextSlash);
        }
      }
      return output2.join("");
    }
    var HOST_DELIMS = { "@": "%40", "/": "%2F", "?": "%3F", "#": "%23", ":": "%3A" };
    var HOST_DELIM_RE = /[@/?#:]/g;
    var HOST_DELIM_NO_COLON_RE = /[@/?#]/g;
    function reescapeHostDelimiters(host, isIP) {
      const re = isIP ? HOST_DELIM_NO_COLON_RE : HOST_DELIM_RE;
      re.lastIndex = 0;
      return host.replace(re, (ch) => HOST_DELIMS[ch]);
    }
    function normalizePercentEncoding(input, decodeUnreserved = false) {
      if (input.indexOf("%") === -1) {
        return input;
      }
      let output2 = "";
      for (let i = 0; i < input.length; i++) {
        if (input[i] === "%" && i + 2 < input.length) {
          const hex = input.slice(i + 1, i + 3);
          if (isHexPair(hex)) {
            const normalizedHex = hex.toUpperCase();
            const decoded = String.fromCharCode(parseInt(normalizedHex, 16));
            if (decodeUnreserved && isUnreserved(decoded)) {
              output2 += decoded;
            } else {
              output2 += "%" + normalizedHex;
            }
            i += 2;
            continue;
          }
        }
        output2 += input[i];
      }
      return output2;
    }
    function normalizePathEncoding(input) {
      let output2 = "";
      for (let i = 0; i < input.length; i++) {
        const ch = input[i];
        if (ch === "%" && i + 2 < input.length) {
          const hex = input.slice(i + 1, i + 3);
          if (isHexPair(hex)) {
            const normalizedHex = hex.toUpperCase();
            const decoded = String.fromCharCode(parseInt(normalizedHex, 16));
            if (decoded !== "." && isUnreserved(decoded)) {
              output2 += decoded;
            } else {
              output2 += "%" + normalizedHex;
            }
            i += 2;
            continue;
          }
        }
        if (isPathCharacter(ch)) {
          output2 += ch;
        } else {
          const code = input.charCodeAt(i);
          if (code < 128) {
            output2 += isEscapeSafe(code) ? ch : BYTE_HEX[code];
          } else if (code < 55296 || code > 57343) {
            output2 += percentEncodeNonAscii(code);
          } else if (code <= 56319 && i + 1 < input.length) {
            const low = input.charCodeAt(i + 1);
            if (low >= 56320 && low <= 57343) {
              output2 += percentEncodeNonAscii(65536 + (code - 55296 << 10) + (low - 56320));
              i++;
            } else {
              output2 += percentEncodeNonAscii(65533);
            }
          } else {
            output2 += percentEncodeNonAscii(65533);
          }
        }
      }
      return output2;
    }
    function serializePathEncoding(input, pathNoScheme = false) {
      let output2 = "";
      let firstSegment = pathNoScheme && input[0] !== "/";
      for (let i = 0; i < input.length; i++) {
        const ch = input[i];
        if (ch === "%" && i + 2 < input.length) {
          const hex = input.slice(i + 1, i + 3);
          if (isHexPair(hex)) {
            output2 += "%" + hex.toUpperCase();
            i += 2;
            continue;
          }
        }
        if (ch === "/") {
          firstSegment = false;
        }
        if (isPathCharacter(ch) && (ch !== ":" || !firstSegment)) {
          output2 += ch;
        } else {
          const code = input.charCodeAt(i);
          if (code < 128) {
            output2 += BYTE_HEX[code];
          } else if (code < 55296 || code > 57343) {
            output2 += percentEncodeNonAscii(code);
          } else if (code <= 56319 && i + 1 < input.length) {
            const low = input.charCodeAt(i + 1);
            if (low >= 56320 && low <= 57343) {
              output2 += percentEncodeNonAscii(65536 + (code - 55296 << 10) + (low - 56320));
              i++;
            } else {
              output2 += percentEncodeNonAscii(65533);
            }
          } else {
            output2 += percentEncodeNonAscii(65533);
          }
        }
      }
      return output2;
    }
    function encodeComponent(input, isAllowed) {
      let output2 = "";
      for (let i = 0; i < input.length; i++) {
        const ch = input[i];
        if (ch === "%" && i + 2 < input.length) {
          const hex = input.slice(i + 1, i + 3);
          if (isHexPair(hex)) {
            output2 += "%" + hex.toUpperCase();
            i += 2;
            continue;
          }
        }
        if (isAllowed(ch)) {
          output2 += ch;
        } else {
          const code = input.charCodeAt(i);
          if (code < 128) {
            output2 += BYTE_HEX[code];
          } else if (code < 55296 || code > 57343) {
            output2 += percentEncodeNonAscii(code);
          } else if (code <= 56319 && i + 1 < input.length) {
            const low = input.charCodeAt(i + 1);
            if (low >= 56320 && low <= 57343) {
              output2 += percentEncodeNonAscii(65536 + (code - 55296 << 10) + (low - 56320));
              i++;
            } else {
              output2 += percentEncodeNonAscii(65533);
            }
          } else {
            output2 += percentEncodeNonAscii(65533);
          }
        }
      }
      return output2;
    }
    function encodeUserinfo(input) {
      return encodeComponent(input, isUserinfoCharacter);
    }
    function encodeQuery(input) {
      return encodeComponent(input, isQueryFragmentCharacter);
    }
    function encodeFragment(input) {
      return encodeComponent(input, isQueryFragmentCharacter);
    }
    function isEscapeSafe(cp) {
      return cp >= 48 && cp <= 57 || cp >= 65 && cp <= 90 || cp >= 97 && cp <= 122 || cp === 42 || cp === 43 || cp === 45 || cp === 46 || cp === 47 || cp === 64 || cp === 95;
    }
    function normalizeQueryFragmentEncoding(input) {
      let output2 = "";
      for (let i = 0; i < input.length; i++) {
        const ch = input[i];
        if (ch === "%" && i + 2 < input.length) {
          const hex = input.slice(i + 1, i + 3);
          if (isHexPair(hex)) {
            const normalizedHex = hex.toUpperCase();
            const decoded = String.fromCharCode(parseInt(normalizedHex, 16));
            if (isUnreserved(decoded)) {
              output2 += decoded;
            } else {
              output2 += "%" + normalizedHex;
            }
            i += 2;
            continue;
          }
        }
        if (isQueryFragmentCharacter(ch)) {
          output2 += ch;
        } else {
          const code = input.charCodeAt(i);
          if (code < 128) {
            output2 += isEscapeSafe(code) ? ch : BYTE_HEX[code];
          } else if (code < 55296 || code > 57343) {
            output2 += percentEncodeNonAscii(code);
          } else if (code <= 56319 && i + 1 < input.length) {
            const low = input.charCodeAt(i + 1);
            if (low >= 56320 && low <= 57343) {
              output2 += percentEncodeNonAscii(65536 + (code - 55296 << 10) + (low - 56320));
              i++;
            } else {
              output2 += percentEncodeNonAscii(65533);
            }
          } else {
            output2 += percentEncodeNonAscii(65533);
          }
        }
      }
      return output2;
    }
    function escapePreservingEscapes(input) {
      let output2 = "";
      for (let i = 0; i < input.length; i++) {
        if (input[i] === "%" && i + 2 < input.length) {
          const hex = input.slice(i + 1, i + 3);
          if (isHexPair(hex)) {
            output2 += "%" + hex.toUpperCase();
            i += 2;
            continue;
          }
        }
        output2 += escape(input[i]);
      }
      return output2;
    }
    function recomposeAuthority(component) {
      const uriTokens = [];
      if (component.userinfo !== void 0) {
        uriTokens.push(encodeUserinfo(component.userinfo));
        uriTokens.push("@");
      }
      if (component.host !== void 0) {
        let host = component.host;
        if (!isIPv4(host)) {
          let ipV6res = normalizeIPv6(host);
          if (ipV6res.isIPV6 !== true && ipV6res.isIPVFuture !== true) {
            host = normalizePercentEncoding(host, true);
            ipV6res = normalizeIPv6(host);
          }
          if (ipV6res.isIPV6 === true || ipV6res.isIPVFuture === true) {
            host = `[${ipV6res.escapedHost}]`;
          } else {
            host = reescapeHostDelimiters(host, false);
          }
        }
        uriTokens.push(host);
      }
      if (typeof component.port === "number" || typeof component.port === "string") {
        const port = String(component.port);
        if (!isPort(port)) {
          throw new TypeError("URI port is malformed.");
        }
        uriTokens.push(":");
        uriTokens.push(port);
      }
      return uriTokens.length ? uriTokens.join("") : void 0;
    }
    module.exports = {
      nonSimpleDomain,
      recomposeAuthority,
      reescapeHostDelimiters,
      normalizePercentEncoding,
      normalizePathEncoding,
      serializePathEncoding,
      normalizeQueryFragmentEncoding,
      encodeUserinfo,
      encodeQuery,
      encodeFragment,
      escapePreservingEscapes,
      removeDotSegments,
      isIPv4,
      isUUID,
      normalizeIPv6,
      stringArrayToHexStripped
    };
  }
});

// ../../node_modules/.pnpm/fast-uri@3.1.8/node_modules/fast-uri/lib/schemes.js
var require_schemes = __commonJS({
  "../../node_modules/.pnpm/fast-uri@3.1.8/node_modules/fast-uri/lib/schemes.js"(exports, module) {
    "use strict";
    var { isUUID } = require_utils();
    var URN_REG = /^([\da-z][\d\-a-z]{0,31}):((?:[\w!$'()*+,\-./:;=@]|%[\da-f]{2})+)$/iu;
    var supportedSchemeNames = (
      /** @type {const} */
      [
        "http",
        "https",
        "ws",
        "wss",
        "urn",
        "urn:uuid"
      ]
    );
    function isValidSchemeName(name) {
      return supportedSchemeNames.indexOf(
        /** @type {*} */
        name
      ) !== -1;
    }
    function wsIsSecure(wsComponent) {
      if (wsComponent.secure === true) {
        return true;
      } else if (wsComponent.secure === false) {
        return false;
      } else if (wsComponent.scheme) {
        return wsComponent.scheme.length === 3 && (wsComponent.scheme[0] === "w" || wsComponent.scheme[0] === "W") && (wsComponent.scheme[1] === "s" || wsComponent.scheme[1] === "S") && (wsComponent.scheme[2] === "s" || wsComponent.scheme[2] === "S");
      } else {
        return false;
      }
    }
    function httpParse(component) {
      if (!component.host) {
        component.error = component.error || "HTTP URIs must have a host.";
      }
      return component;
    }
    function httpSerialize(component) {
      const secure = String(component.scheme).toLowerCase() === "https";
      if (component.port === (secure ? 443 : 80) || component.port === "") {
        component.port = void 0;
      }
      if (!component.path) {
        component.path = "/";
      }
      return component;
    }
    function wsParse(wsComponent) {
      wsComponent.secure = wsIsSecure(wsComponent);
      wsComponent.resourceName = (wsComponent.path || "/") + (wsComponent.query ? "?" + wsComponent.query : "");
      wsComponent.path = void 0;
      wsComponent.query = void 0;
      return wsComponent;
    }
    function wsSerialize(wsComponent) {
      if (wsComponent.port === (wsIsSecure(wsComponent) ? 443 : 80) || wsComponent.port === "") {
        wsComponent.port = void 0;
      }
      if (typeof wsComponent.secure === "boolean") {
        wsComponent.scheme = wsComponent.secure ? "wss" : "ws";
        wsComponent.secure = void 0;
      }
      if (wsComponent.resourceName) {
        const queryIndex = wsComponent.resourceName.indexOf("?");
        const path5 = queryIndex === -1 ? wsComponent.resourceName : wsComponent.resourceName.slice(0, queryIndex);
        wsComponent.path = path5 && path5 !== "/" ? path5 : void 0;
        wsComponent.query = queryIndex === -1 ? void 0 : wsComponent.resourceName.slice(queryIndex + 1);
        wsComponent.resourceName = void 0;
      }
      wsComponent.fragment = void 0;
      return wsComponent;
    }
    function urnParse(urnComponent, options) {
      if (!urnComponent.path) {
        urnComponent.error = "URN can not be parsed";
        return urnComponent;
      }
      const matches2 = urnComponent.path.match(URN_REG);
      if (matches2 && matches2[0] === urnComponent.path) {
        const scheme = options.scheme || urnComponent.scheme || "urn";
        urnComponent.nid = matches2[1].toLowerCase();
        urnComponent.nss = matches2[2];
        const urnScheme = `${scheme}:${options.nid || urnComponent.nid}`;
        const schemeHandler = getSchemeHandler(urnScheme);
        urnComponent.path = void 0;
        if (schemeHandler) {
          urnComponent = schemeHandler.parse(urnComponent, options);
        }
      } else {
        urnComponent.error = urnComponent.error || "URN can not be parsed.";
      }
      return urnComponent;
    }
    function urnSerialize(urnComponent, options) {
      if (urnComponent.nid === void 0) {
        throw new Error("URN without nid cannot be serialized");
      }
      const scheme = options.scheme || urnComponent.scheme || "urn";
      const nid = urnComponent.nid.toLowerCase();
      const urnScheme = `${scheme}:${options.nid || nid}`;
      const schemeHandler = getSchemeHandler(urnScheme);
      if (schemeHandler) {
        urnComponent = schemeHandler.serialize(urnComponent, options);
      }
      const uriComponent = urnComponent;
      const nss = urnComponent.nss;
      uriComponent.path = `${nid || options.nid}:${nss}`;
      options.skipEscape = true;
      return uriComponent;
    }
    function urnuuidParse(urnComponent, options) {
      const uuidComponent = urnComponent;
      uuidComponent.uuid = uuidComponent.nss;
      uuidComponent.nss = void 0;
      if (!options.tolerant && (!uuidComponent.uuid || !isUUID(uuidComponent.uuid))) {
        uuidComponent.error = uuidComponent.error || "UUID is not valid.";
      }
      return uuidComponent;
    }
    function urnuuidSerialize(uuidComponent) {
      const urnComponent = uuidComponent;
      urnComponent.nss = (uuidComponent.uuid || "").toLowerCase();
      return urnComponent;
    }
    var http = (
      /** @type {SchemeHandler} */
      {
        scheme: "http",
        domainHost: true,
        parse: httpParse,
        serialize: httpSerialize
      }
    );
    var https = (
      /** @type {SchemeHandler} */
      {
        scheme: "https",
        domainHost: http.domainHost,
        parse: httpParse,
        serialize: httpSerialize
      }
    );
    var ws = (
      /** @type {SchemeHandler} */
      {
        scheme: "ws",
        domainHost: true,
        parse: wsParse,
        serialize: wsSerialize
      }
    );
    var wss = (
      /** @type {SchemeHandler} */
      {
        scheme: "wss",
        domainHost: ws.domainHost,
        parse: ws.parse,
        serialize: ws.serialize
      }
    );
    var urn = (
      /** @type {SchemeHandler} */
      {
        scheme: "urn",
        parse: urnParse,
        serialize: urnSerialize,
        skipNormalize: true
      }
    );
    var urnuuid = (
      /** @type {SchemeHandler} */
      {
        scheme: "urn:uuid",
        parse: urnuuidParse,
        serialize: urnuuidSerialize,
        skipNormalize: true
      }
    );
    var SCHEMES = (
      /** @type {Record<SchemeName, SchemeHandler>} */
      {
        http,
        https,
        ws,
        wss,
        urn,
        "urn:uuid": urnuuid
      }
    );
    Object.setPrototypeOf(SCHEMES, null);
    function getSchemeHandler(scheme) {
      return scheme && (SCHEMES[
        /** @type {SchemeName} */
        scheme
      ] || SCHEMES[
        /** @type {SchemeName} */
        scheme.toLowerCase()
      ]) || void 0;
    }
    module.exports = {
      wsIsSecure,
      SCHEMES,
      isValidSchemeName,
      getSchemeHandler
    };
  }
});

// ../../node_modules/.pnpm/fast-uri@3.1.8/node_modules/fast-uri/index.js
var require_fast_uri = __commonJS({
  "../../node_modules/.pnpm/fast-uri@3.1.8/node_modules/fast-uri/index.js"(exports, module) {
    "use strict";
    var { normalizeIPv6, removeDotSegments, recomposeAuthority, normalizePercentEncoding, normalizePathEncoding, serializePathEncoding, normalizeQueryFragmentEncoding, encodeQuery, encodeFragment, reescapeHostDelimiters, isIPv4, nonSimpleDomain } = require_utils();
    var { SCHEMES, getSchemeHandler } = require_schemes();
    var VALID_SCHEME = /^[A-Za-z][A-Za-z0-9+.-]*$/u;
    var MALFORMED_SCHEME_ERROR = "URI scheme is malformed.";
    function decodeValidScheme(scheme) {
      const decodedScheme = unescape(String(scheme));
      if (!VALID_SCHEME.test(decodedScheme)) {
        throw new TypeError(MALFORMED_SCHEME_ERROR);
      }
      return decodedScheme;
    }
    function normalize(uri, options) {
      if (typeof uri === "string") {
        uri = /** @type {T} */
        normalizeString(uri, options);
      } else if (typeof uri === "object") {
        uri = /** @type {T} */
        parse2(serialize(uri, options), options);
      }
      return uri;
    }
    function resolve3(baseURI, relativeURI, options) {
      const schemelessOptions = options ? Object.assign({ scheme: "null" }, options) : { scheme: "null" };
      const {
        parsed: baseParsed,
        malformedAuthorityOrPort: baseMalformed,
        malformedPercentEncoding: baseMalformedPercentEncoding,
        malformedSchemeSpecific: baseMalformedSchemeSpecific,
        malformedHost: baseMalformedHost,
        malformedScheme: baseMalformedScheme
      } = parseWithStatus(baseURI, schemelessOptions);
      const {
        parsed: relativeParsed,
        malformedAuthorityOrPort: relativeMalformed,
        malformedPercentEncoding: relativeMalformedPercentEncoding,
        malformedSchemeSpecific: relativeMalformedSchemeSpecific,
        malformedHost: relativeMalformedHost,
        malformedScheme: relativeMalformedScheme
      } = parseWithStatus(relativeURI, schemelessOptions);
      if (baseMalformed || relativeMalformed || baseMalformedPercentEncoding || relativeMalformedPercentEncoding || baseMalformedSchemeSpecific || relativeMalformedSchemeSpecific || baseMalformedHost || relativeMalformedHost || baseMalformedScheme || relativeMalformedScheme) {
        throw new Error(baseParsed.error || relativeParsed.error || "URI is malformed.");
      }
      const resolved = resolveComponent(baseParsed, relativeParsed, schemelessOptions, true);
      const resolvedSchemeHandler = getSchemeHandler(options && options.scheme || resolved.scheme);
      const resolvedHost = resolved.host;
      const resolvedHostIsIP = resolvedHost !== void 0 && resolvedHost !== "" && (isIPv4(resolvedHost) || normalizeIPv6(resolvedHost).isIPV6);
      canonicalizeHost(resolved, options || {}, resolvedSchemeHandler, resolvedHostIsIP);
      const encodedASCIIHost = resolvedHost && resolvedHost.indexOf("%") !== -1 && !/\P{ASCII}/u.test(resolvedHost);
      if (resolved.error && !encodedASCIIHost) {
        throw new Error(resolved.error);
      }
      schemelessOptions.skipEscape = true;
      return serialize(resolved, schemelessOptions);
    }
    function resolveComponent(base, relative3, options, skipNormalization) {
      const target = {};
      if (!skipNormalization) {
        base = parse2(serialize(base, options), options);
        relative3 = parse2(serialize(relative3, options), options);
      }
      options = options || {};
      if (!options.tolerant && relative3.scheme) {
        target.scheme = relative3.scheme;
        target.userinfo = relative3.userinfo;
        target.host = relative3.host;
        target.port = relative3.port;
        target.path = removeDotSegments(relative3.path || "");
        target.query = relative3.query;
      } else {
        if (relative3.userinfo !== void 0 || relative3.host !== void 0 || relative3.port !== void 0) {
          target.userinfo = relative3.userinfo;
          target.host = relative3.host;
          target.port = relative3.port;
          target.path = removeDotSegments(relative3.path || "");
          target.query = relative3.query;
        } else {
          if (!relative3.path) {
            target.path = base.path;
            if (relative3.query !== void 0) {
              target.query = relative3.query;
            } else {
              target.query = base.query;
            }
          } else {
            if (relative3.path[0] === "/") {
              target.path = removeDotSegments(relative3.path);
            } else {
              if ((base.userinfo !== void 0 || base.host !== void 0 || base.port !== void 0) && !base.path) {
                target.path = "/" + relative3.path;
              } else if (!base.path) {
                target.path = relative3.path;
              } else {
                target.path = base.path.slice(0, base.path.lastIndexOf("/") + 1) + relative3.path;
              }
              target.path = removeDotSegments(target.path);
            }
            target.query = relative3.query;
          }
          target.userinfo = base.userinfo;
          target.host = base.host;
          target.port = base.port;
        }
        target.scheme = base.scheme;
      }
      target.fragment = relative3.fragment;
      return target;
    }
    function equal(uriA, uriB, options) {
      const normalizedA = normalizeComparableURI(uriA, options);
      const normalizedB = normalizeComparableURI(uriB, options);
      return normalizedA !== void 0 && normalizedB !== void 0 && normalizedA === normalizedB;
    }
    function serialize(cmpts, opts) {
      const component = {
        host: cmpts.host,
        scheme: cmpts.scheme,
        userinfo: cmpts.userinfo,
        port: cmpts.port,
        path: cmpts.path,
        query: cmpts.query,
        nid: cmpts.nid,
        nss: cmpts.nss,
        uuid: cmpts.uuid,
        fragment: cmpts.fragment,
        reference: cmpts.reference,
        resourceName: cmpts.resourceName,
        secure: cmpts.secure,
        error: ""
      };
      const options = Object.assign({}, opts);
      const uriTokens = [];
      if (component.scheme) {
        component.scheme = decodeValidScheme(component.scheme);
      }
      const schemeHandler = getSchemeHandler(options.scheme || component.scheme);
      if (schemeHandler && schemeHandler.serialize) schemeHandler.serialize(component, options);
      const hasAuthority = component.userinfo !== void 0 || component.host !== void 0 || component.port !== void 0;
      const pathNoScheme = !options.skipEscape && component.scheme === void 0 && !hasAuthority;
      if (component.path !== void 0) {
        if (!options.skipEscape) {
          component.path = serializePathEncoding(component.path, pathNoScheme);
        } else {
          component.path = normalizePercentEncoding(component.path);
        }
      }
      if (options.reference !== "suffix" && component.scheme) {
        component.scheme = decodeValidScheme(component.scheme);
        uriTokens.push(component.scheme, ":");
      }
      const authority = recomposeAuthority(component);
      if (authority !== void 0) {
        if (options.reference !== "suffix") {
          uriTokens.push("//");
        }
        uriTokens.push(authority);
        if (component.path && component.path[0] !== "/") {
          uriTokens.push("/");
        }
      }
      if (component.path !== void 0) {
        let s = component.path;
        if (!options.absolutePath && (!schemeHandler || !schemeHandler.absolutePath)) {
          s = removeDotSegments(s);
        }
        if (pathNoScheme) {
          s = serializePathEncoding(s, true);
        }
        if (authority === void 0 && s[0] === "/" && s[1] === "/") {
          s = "/%2F" + s.slice(2);
        }
        uriTokens.push(s);
      }
      if (component.query !== void 0) {
        uriTokens.push("?", encodeQuery(component.query));
      }
      if (component.fragment !== void 0) {
        uriTokens.push("#", encodeFragment(component.fragment));
      }
      return uriTokens.join("");
    }
    var URI_PARSE = /^(?:([^#/:?]+):)?(?:\/\/((?:([^#/?@]*)@)?(\[[^#/?\]]+\]|[^#/:?]*)(?::(\d*))?))?([^#?]*)(?:\?([^#]*))?(?:#((?:.|[\n\r])*))?/u;
    var AUTHORITY_PREFIX = /^(?:[^#/:?]+:)?\/\/([^/?#]*)/;
    var AUTHORITY_INTRODUCER_REGION = /^(?:[^#/:?]+:)?([/\\\t\n\r]*)/;
    function getParseError(parsed, matches2) {
      if (matches2[2] !== void 0 && parsed.path && parsed.path[0] !== "/") {
        return 'URI path must start with "/" when authority is present.';
      }
      if (typeof parsed.port === "number" && (parsed.port < 0 || parsed.port > 65535)) {
        return "URI port is malformed.";
      }
      return void 0;
    }
    function hasMalformedPercentEncoding(component) {
      if (component === void 0) return false;
      let percent = component.indexOf("%");
      while (percent !== -1) {
        if (percent + 2 >= component.length || !/^[\da-f]{2}$/iu.test(component.slice(percent + 1, percent + 3))) {
          return true;
        }
        percent = component.indexOf("%", percent + 3);
      }
      return false;
    }
    function isIPLiteral(host) {
      return host[0] === "[" && host[host.length - 1] === "]";
    }
    function hasMalformedComponentPercentEncoding(matches2) {
      const host = matches2[4];
      return hasMalformedPercentEncoding(matches2[3]) || host !== void 0 && !isIPLiteral(host) && hasMalformedPercentEncoding(host) || hasMalformedPercentEncoding(matches2[6]) || hasMalformedPercentEncoding(matches2[7]) || hasMalformedPercentEncoding(matches2[8]);
    }
    function canonicalizeHost(parsed, options, schemeHandler, isIP) {
      if (!options.unicodeSupport && (!schemeHandler || !schemeHandler.unicodeSupport) && parsed.host && !isIPLiteral(parsed.host) && (options.domainHost || schemeHandler && schemeHandler.domainHost) && isIP === false && nonSimpleDomain(parsed.host)) {
        try {
          parsed.host = new URL("http://" + parsed.host).hostname;
        } catch (e) {
          parsed.error = parsed.error || "Host's domain name can not be converted to ASCII: " + e;
          return true;
        }
      }
      return false;
    }
    function parseWithStatus(uri, opts) {
      const options = Object.assign({}, opts);
      const parsed = {
        scheme: void 0,
        userinfo: void 0,
        host: "",
        port: void 0,
        path: "",
        query: void 0,
        fragment: void 0
      };
      let malformedAuthorityOrPort = false;
      let malformedPercentEncoding = false;
      let malformedSchemeSpecific = false;
      let malformedHost = false;
      let malformedIPLiteral = false;
      let malformedScheme = false;
      let isIP = false;
      if (options.reference === "suffix") {
        if (options.scheme) {
          uri = options.scheme + ":" + uri;
        } else {
          uri = "//" + uri;
        }
      }
      const authorityMatch = uri.match(AUTHORITY_PREFIX);
      if (authorityMatch !== null && authorityMatch[1].indexOf("\\") !== -1) {
        parsed.error = "URI authority must not contain a literal backslash.";
        malformedAuthorityOrPort = true;
      }
      const introducerMatch = uri.match(AUTHORITY_INTRODUCER_REGION);
      if (introducerMatch !== null) {
        const region = introducerMatch[1];
        const normalizedRegion = region.replace(/[\t\n\r]/g, "");
        if (normalizedRegion.length >= 2) {
          if (normalizedRegion.slice(0, 2) !== "//") {
            parsed.error = parsed.error || "URI authority must not contain a literal backslash.";
            malformedAuthorityOrPort = true;
          } else if (region.length !== normalizedRegion.length) {
            parsed.error = parsed.error || "URI authority introducer must not contain whitespace.";
            malformedAuthorityOrPort = true;
          }
        }
      }
      const matches2 = uri.match(URI_PARSE);
      if (matches2) {
        parsed.scheme = matches2[1];
        parsed.userinfo = matches2[3];
        parsed.host = matches2[4];
        parsed.port = parseInt(matches2[5], 10);
        parsed.path = matches2[6] || "";
        parsed.query = matches2[7];
        parsed.fragment = matches2[8];
        if (parsed.scheme !== void 0) {
          const decodedScheme = unescape(parsed.scheme);
          if (VALID_SCHEME.test(decodedScheme)) {
            parsed.scheme = decodedScheme.toLowerCase();
          } else {
            parsed.error = parsed.error || MALFORMED_SCHEME_ERROR;
            malformedScheme = true;
          }
        }
        malformedPercentEncoding = hasMalformedComponentPercentEncoding(matches2);
        if (malformedPercentEncoding) {
          parsed.error = parsed.error || "URI contains malformed percent-encoding.";
        }
        if (isNaN(parsed.port)) {
          parsed.port = matches2[5];
        }
        const parseError = getParseError(parsed, matches2);
        if (parseError !== void 0) {
          parsed.error = parsed.error || parseError;
          malformedAuthorityOrPort = true;
        }
        if (parsed.host) {
          const ipv4result = isIPv4(parsed.host);
          if (ipv4result === false) {
            const bracketedIPLiteral = isIPLiteral(parsed.host);
            const hasIPLiteralBracket = parsed.host.indexOf("[") !== -1 || parsed.host.indexOf("]") !== -1;
            const ipv6result = normalizeIPv6(parsed.host);
            isIP = ipv6result.isIPV6 || ipv6result.isIPVFuture === true;
            malformedIPLiteral = hasIPLiteralBracket && (!bracketedIPLiteral || ipv6result.error === true);
            parsed.host = isIP ? ipv6result.host : ipv6result.host.toLowerCase();
            if (malformedIPLiteral) {
              parsed.error = parsed.error || "URI host is malformed.";
              malformedAuthorityOrPort = true;
            }
          } else {
            isIP = true;
          }
        }
        if (parsed.scheme === void 0 && parsed.userinfo === void 0 && parsed.host === void 0 && parsed.port === void 0 && parsed.query === void 0 && !parsed.path) {
          parsed.reference = "same-document";
        } else if (parsed.scheme === void 0) {
          parsed.reference = "relative";
        } else if (parsed.fragment === void 0) {
          parsed.reference = "absolute";
        } else {
          parsed.reference = "uri";
        }
        if (options.reference && options.reference !== "suffix" && options.reference !== parsed.reference) {
          parsed.error = parsed.error || "URI is not a " + options.reference + " reference.";
        }
        const schemeHandler = getSchemeHandler(options.scheme || parsed.scheme);
        if (!malformedIPLiteral) {
          malformedHost = canonicalizeHost(parsed, options, schemeHandler, isIP);
        }
        if (uri.indexOf("%") !== -1 && parsed.host !== void 0 && !malformedIPLiteral) {
          let host = isIP ? parsed.host : normalizePercentEncoding(parsed.host, true);
          if (!isIP) {
            host = normalizePercentEncoding(host.toLowerCase());
          }
          parsed.host = reescapeHostDelimiters(host, isIP);
        }
        if (!schemeHandler || schemeHandler && !schemeHandler.skipNormalize) {
          if (parsed.path) {
            parsed.path = normalizePathEncoding(parsed.path);
          }
          if (parsed.query) {
            parsed.query = normalizeQueryFragmentEncoding(parsed.query);
          }
          if (parsed.fragment) {
            parsed.fragment = normalizeQueryFragmentEncoding(parsed.fragment);
          }
        }
        if (schemeHandler && schemeHandler.parse) {
          schemeHandler.parse(parsed, options);
          if (schemeHandler === SCHEMES.urn && parsed.nid === void 0) {
            malformedSchemeSpecific = true;
          }
        }
      } else {
        parsed.error = parsed.error || "URI can not be parsed.";
      }
      return { parsed, malformedAuthorityOrPort, malformedPercentEncoding, malformedSchemeSpecific, malformedHost, malformedScheme };
    }
    function parse2(uri, opts) {
      return parseWithStatus(uri, opts).parsed;
    }
    function normalizeString(uri, opts) {
      return normalizeStringWithStatus(uri, opts).normalized;
    }
    function normalizeStringWithStatus(uri, opts) {
      const { parsed, malformedAuthorityOrPort, malformedPercentEncoding, malformedSchemeSpecific, malformedHost, malformedScheme } = parseWithStatus(uri, opts);
      return {
        normalized: malformedAuthorityOrPort || malformedPercentEncoding || malformedSchemeSpecific || malformedHost || malformedScheme ? uri : serialize(parsed, opts),
        malformedAuthorityOrPort,
        malformedPercentEncoding,
        malformedSchemeSpecific,
        malformedHost,
        malformedScheme
      };
    }
    function normalizeComparableURI(uri, opts) {
      if (typeof uri !== "string" && typeof uri !== "object") {
        return void 0;
      }
      let value;
      try {
        value = typeof uri === "string" ? uri : serialize(uri, opts);
      } catch {
        return void 0;
      }
      const { normalized, malformedAuthorityOrPort, malformedPercentEncoding, malformedSchemeSpecific, malformedHost, malformedScheme } = normalizeStringWithStatus(value, opts);
      return malformedAuthorityOrPort || malformedPercentEncoding || malformedSchemeSpecific || malformedHost || malformedScheme ? void 0 : normalized;
    }
    var fastUri = {
      SCHEMES,
      normalize,
      resolve: resolve3,
      resolveComponent,
      equal,
      serialize,
      parse: parse2
    };
    module.exports = fastUri;
    module.exports.default = fastUri;
    module.exports.fastUri = fastUri;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/uri.js
var require_uri = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/uri.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var uri = require_fast_uri();
    uri.code = 'require("ajv/dist/runtime/uri").default';
    exports.default = uri;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/core.js
var require_core = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/core.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CodeGen = exports.Name = exports.nil = exports.stringify = exports.str = exports._ = exports.KeywordCxt = void 0;
    var validate_1 = require_validate();
    Object.defineProperty(exports, "KeywordCxt", { enumerable: true, get: function() {
      return validate_1.KeywordCxt;
    } });
    var codegen_1 = require_codegen();
    Object.defineProperty(exports, "_", { enumerable: true, get: function() {
      return codegen_1._;
    } });
    Object.defineProperty(exports, "str", { enumerable: true, get: function() {
      return codegen_1.str;
    } });
    Object.defineProperty(exports, "stringify", { enumerable: true, get: function() {
      return codegen_1.stringify;
    } });
    Object.defineProperty(exports, "nil", { enumerable: true, get: function() {
      return codegen_1.nil;
    } });
    Object.defineProperty(exports, "Name", { enumerable: true, get: function() {
      return codegen_1.Name;
    } });
    Object.defineProperty(exports, "CodeGen", { enumerable: true, get: function() {
      return codegen_1.CodeGen;
    } });
    var validation_error_1 = require_validation_error();
    var ref_error_1 = require_ref_error();
    var rules_1 = require_rules();
    var compile_1 = require_compile();
    var codegen_2 = require_codegen();
    var resolve_1 = require_resolve();
    var dataType_1 = require_dataType();
    var util_1 = require_util();
    var $dataRefSchema = require_data();
    var uri_1 = require_uri();
    var defaultRegExp = (str, flags) => new RegExp(str, flags);
    defaultRegExp.code = "new RegExp";
    var META_IGNORE_OPTIONS = ["removeAdditional", "useDefaults", "coerceTypes"];
    var EXT_SCOPE_NAMES = /* @__PURE__ */ new Set([
      "validate",
      "serialize",
      "parse",
      "wrapper",
      "root",
      "schema",
      "keyword",
      "pattern",
      "formats",
      "validate$data",
      "func",
      "obj",
      "Error"
    ]);
    var removedOptions = {
      errorDataPath: "",
      format: "`validateFormats: false` can be used instead.",
      nullable: '"nullable" keyword is supported by default.',
      jsonPointers: "Deprecated jsPropertySyntax can be used instead.",
      extendRefs: "Deprecated ignoreKeywordsWithRef can be used instead.",
      missingRefs: "Pass empty schema with $id that should be ignored to ajv.addSchema.",
      processCode: "Use option `code: {process: (code, schemaEnv: object) => string}`",
      sourceCode: "Use option `code: {source: true}`",
      strictDefaults: "It is default now, see option `strict`.",
      strictKeywords: "It is default now, see option `strict`.",
      uniqueItems: '"uniqueItems" keyword is always validated.',
      unknownFormats: "Disable strict mode or pass `true` to `ajv.addFormat` (or `formats` option).",
      cache: "Map is used as cache, schema object as key.",
      serialize: "Map is used as cache, schema object as key.",
      ajvErrors: "It is default now."
    };
    var deprecatedOptions = {
      ignoreKeywordsWithRef: "",
      jsPropertySyntax: "",
      unicode: '"minLength"/"maxLength" account for unicode characters by default.'
    };
    var MAX_EXPRESSION = 200;
    function requiredOptions(o) {
      var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0;
      const s = o.strict;
      const _optz = (_a = o.code) === null || _a === void 0 ? void 0 : _a.optimize;
      const optimize = _optz === true || _optz === void 0 ? 1 : _optz || 0;
      const regExp = (_c = (_b = o.code) === null || _b === void 0 ? void 0 : _b.regExp) !== null && _c !== void 0 ? _c : defaultRegExp;
      const uriResolver = (_d = o.uriResolver) !== null && _d !== void 0 ? _d : uri_1.default;
      return {
        strictSchema: (_f = (_e = o.strictSchema) !== null && _e !== void 0 ? _e : s) !== null && _f !== void 0 ? _f : true,
        strictNumbers: (_h = (_g = o.strictNumbers) !== null && _g !== void 0 ? _g : s) !== null && _h !== void 0 ? _h : true,
        strictTypes: (_k = (_j = o.strictTypes) !== null && _j !== void 0 ? _j : s) !== null && _k !== void 0 ? _k : "log",
        strictTuples: (_m = (_l = o.strictTuples) !== null && _l !== void 0 ? _l : s) !== null && _m !== void 0 ? _m : "log",
        strictRequired: (_p = (_o = o.strictRequired) !== null && _o !== void 0 ? _o : s) !== null && _p !== void 0 ? _p : false,
        code: o.code ? { ...o.code, optimize, regExp } : { optimize, regExp },
        loopRequired: (_q = o.loopRequired) !== null && _q !== void 0 ? _q : MAX_EXPRESSION,
        loopEnum: (_r = o.loopEnum) !== null && _r !== void 0 ? _r : MAX_EXPRESSION,
        meta: (_s = o.meta) !== null && _s !== void 0 ? _s : true,
        messages: (_t = o.messages) !== null && _t !== void 0 ? _t : true,
        inlineRefs: (_u = o.inlineRefs) !== null && _u !== void 0 ? _u : true,
        schemaId: (_v = o.schemaId) !== null && _v !== void 0 ? _v : "$id",
        addUsedSchema: (_w = o.addUsedSchema) !== null && _w !== void 0 ? _w : true,
        validateSchema: (_x = o.validateSchema) !== null && _x !== void 0 ? _x : true,
        validateFormats: (_y = o.validateFormats) !== null && _y !== void 0 ? _y : true,
        unicodeRegExp: (_z = o.unicodeRegExp) !== null && _z !== void 0 ? _z : true,
        int32range: (_0 = o.int32range) !== null && _0 !== void 0 ? _0 : true,
        uriResolver
      };
    }
    var Ajv2 = class {
      constructor(opts = {}) {
        this.schemas = {};
        this.refs = {};
        this.formats = /* @__PURE__ */ Object.create(null);
        this._compilations = /* @__PURE__ */ new Set();
        this._loading = {};
        this._cache = /* @__PURE__ */ new Map();
        opts = this.opts = { ...opts, ...requiredOptions(opts) };
        const { es5, lines } = this.opts.code;
        this.scope = new codegen_2.ValueScope({ scope: {}, prefixes: EXT_SCOPE_NAMES, es5, lines });
        this.logger = getLogger(opts.logger);
        const formatOpt = opts.validateFormats;
        opts.validateFormats = false;
        this.RULES = (0, rules_1.getRules)();
        checkOptions.call(this, removedOptions, opts, "NOT SUPPORTED");
        checkOptions.call(this, deprecatedOptions, opts, "DEPRECATED", "warn");
        this._metaOpts = getMetaSchemaOptions.call(this);
        if (opts.formats)
          addInitialFormats.call(this);
        this._addVocabularies();
        this._addDefaultMetaSchema();
        if (opts.keywords)
          addInitialKeywords.call(this, opts.keywords);
        if (typeof opts.meta == "object")
          this.addMetaSchema(opts.meta);
        addInitialSchemas.call(this);
        opts.validateFormats = formatOpt;
      }
      _addVocabularies() {
        this.addKeyword("$async");
      }
      _addDefaultMetaSchema() {
        const { $data, meta, schemaId } = this.opts;
        let _dataRefSchema = $dataRefSchema;
        if (schemaId === "id") {
          _dataRefSchema = { ...$dataRefSchema };
          _dataRefSchema.id = _dataRefSchema.$id;
          delete _dataRefSchema.$id;
        }
        if (meta && $data)
          this.addMetaSchema(_dataRefSchema, _dataRefSchema[schemaId], false);
      }
      defaultMeta() {
        const { meta, schemaId } = this.opts;
        return this.opts.defaultMeta = typeof meta == "object" ? meta[schemaId] || meta : void 0;
      }
      validate(schemaKeyRef, data) {
        let v;
        if (typeof schemaKeyRef == "string") {
          v = this.getSchema(schemaKeyRef);
          if (!v)
            throw new Error(`no schema with key or ref "${schemaKeyRef}"`);
        } else {
          v = this.compile(schemaKeyRef);
        }
        const valid = v(data);
        if (!("$async" in v))
          this.errors = v.errors;
        return valid;
      }
      compile(schema, _meta) {
        const sch = this._addSchema(schema, _meta);
        return sch.validate || this._compileSchemaEnv(sch);
      }
      compileAsync(schema, meta) {
        if (typeof this.opts.loadSchema != "function") {
          throw new Error("options.loadSchema should be a function");
        }
        const { loadSchema } = this.opts;
        return runCompileAsync.call(this, schema, meta);
        async function runCompileAsync(_schema, _meta) {
          await loadMetaSchema.call(this, _schema.$schema);
          const sch = this._addSchema(_schema, _meta);
          return sch.validate || _compileAsync.call(this, sch);
        }
        async function loadMetaSchema($ref) {
          if ($ref && !this.getSchema($ref)) {
            await runCompileAsync.call(this, { $ref }, true);
          }
        }
        async function _compileAsync(sch) {
          try {
            return this._compileSchemaEnv(sch);
          } catch (e) {
            if (!(e instanceof ref_error_1.default))
              throw e;
            checkLoaded.call(this, e);
            await loadMissingSchema.call(this, e.missingSchema);
            return _compileAsync.call(this, sch);
          }
        }
        function checkLoaded({ missingSchema: ref, missingRef }) {
          if (this.refs[ref]) {
            throw new Error(`AnySchema ${ref} is loaded but ${missingRef} cannot be resolved`);
          }
        }
        async function loadMissingSchema(ref) {
          const _schema = await _loadSchema.call(this, ref);
          if (!this.refs[ref])
            await loadMetaSchema.call(this, _schema.$schema);
          if (!this.refs[ref])
            this.addSchema(_schema, ref, meta);
        }
        async function _loadSchema(ref) {
          const p = this._loading[ref];
          if (p)
            return p;
          try {
            return await (this._loading[ref] = loadSchema(ref));
          } finally {
            delete this._loading[ref];
          }
        }
      }
      // Adds schema to the instance
      addSchema(schema, key, _meta, _validateSchema = this.opts.validateSchema) {
        if (Array.isArray(schema)) {
          for (const sch of schema)
            this.addSchema(sch, void 0, _meta, _validateSchema);
          return this;
        }
        let id2;
        if (typeof schema === "object") {
          const { schemaId } = this.opts;
          id2 = schema[schemaId];
          if (id2 !== void 0 && typeof id2 != "string") {
            throw new Error(`schema ${schemaId} must be string`);
          }
        }
        key = (0, resolve_1.normalizeId)(key || id2);
        this._checkUnique(key);
        this.schemas[key] = this._addSchema(schema, _meta, key, _validateSchema, true);
        return this;
      }
      // Add schema that will be used to validate other schemas
      // options in META_IGNORE_OPTIONS are alway set to false
      addMetaSchema(schema, key, _validateSchema = this.opts.validateSchema) {
        this.addSchema(schema, key, true, _validateSchema);
        return this;
      }
      //  Validate schema against its meta-schema
      validateSchema(schema, throwOrLogError) {
        if (typeof schema == "boolean")
          return true;
        let $schema;
        $schema = schema.$schema;
        if ($schema !== void 0 && typeof $schema != "string") {
          throw new Error("$schema must be a string");
        }
        $schema = $schema || this.opts.defaultMeta || this.defaultMeta();
        if (!$schema) {
          this.logger.warn("meta-schema not available");
          this.errors = null;
          return true;
        }
        const valid = this.validate($schema, schema);
        if (!valid && throwOrLogError) {
          const message = "schema is invalid: " + this.errorsText();
          if (this.opts.validateSchema === "log")
            this.logger.error(message);
          else
            throw new Error(message);
        }
        return valid;
      }
      // Get compiled schema by `key` or `ref`.
      // (`key` that was passed to `addSchema` or full schema reference - `schema.$id` or resolved id)
      getSchema(keyRef) {
        let sch;
        while (typeof (sch = getSchEnv.call(this, keyRef)) == "string")
          keyRef = sch;
        if (sch === void 0) {
          const { schemaId } = this.opts;
          const root = new compile_1.SchemaEnv({ schema: {}, schemaId });
          sch = compile_1.resolveSchema.call(this, root, keyRef);
          if (!sch)
            return;
          this.refs[keyRef] = sch;
        }
        return sch.validate || this._compileSchemaEnv(sch);
      }
      // Remove cached schema(s).
      // If no parameter is passed all schemas but meta-schemas are removed.
      // If RegExp is passed all schemas with key/id matching pattern but meta-schemas are removed.
      // Even if schema is referenced by other schemas it still can be removed as other schemas have local references.
      removeSchema(schemaKeyRef) {
        if (schemaKeyRef instanceof RegExp) {
          this._removeAllSchemas(this.schemas, schemaKeyRef);
          this._removeAllSchemas(this.refs, schemaKeyRef);
          return this;
        }
        switch (typeof schemaKeyRef) {
          case "undefined":
            this._removeAllSchemas(this.schemas);
            this._removeAllSchemas(this.refs);
            this._cache.clear();
            return this;
          case "string": {
            const sch = getSchEnv.call(this, schemaKeyRef);
            if (typeof sch == "object")
              this._cache.delete(sch.schema);
            delete this.schemas[schemaKeyRef];
            delete this.refs[schemaKeyRef];
            return this;
          }
          case "object": {
            const cacheKey = schemaKeyRef;
            this._cache.delete(cacheKey);
            let id2 = schemaKeyRef[this.opts.schemaId];
            if (id2) {
              id2 = (0, resolve_1.normalizeId)(id2);
              delete this.schemas[id2];
              delete this.refs[id2];
            }
            return this;
          }
          default:
            throw new Error("ajv.removeSchema: invalid parameter");
        }
      }
      // add "vocabulary" - a collection of keywords
      addVocabulary(definitions) {
        for (const def of definitions)
          this.addKeyword(def);
        return this;
      }
      addKeyword(kwdOrDef, def) {
        let keyword;
        if (typeof kwdOrDef == "string") {
          keyword = kwdOrDef;
          if (typeof def == "object") {
            this.logger.warn("these parameters are deprecated, see docs for addKeyword");
            def.keyword = keyword;
          }
        } else if (typeof kwdOrDef == "object" && def === void 0) {
          def = kwdOrDef;
          keyword = def.keyword;
          if (Array.isArray(keyword) && !keyword.length) {
            throw new Error("addKeywords: keyword must be string or non-empty array");
          }
        } else {
          throw new Error("invalid addKeywords parameters");
        }
        checkKeyword.call(this, keyword, def);
        if (!def) {
          (0, util_1.eachItem)(keyword, (kwd) => addRule.call(this, kwd));
          return this;
        }
        keywordMetaschema.call(this, def);
        const definition = {
          ...def,
          type: (0, dataType_1.getJSONTypes)(def.type),
          schemaType: (0, dataType_1.getJSONTypes)(def.schemaType)
        };
        (0, util_1.eachItem)(keyword, definition.type.length === 0 ? (k) => addRule.call(this, k, definition) : (k) => definition.type.forEach((t) => addRule.call(this, k, definition, t)));
        return this;
      }
      getKeyword(keyword) {
        const rule = this.RULES.all[keyword];
        return typeof rule == "object" ? rule.definition : !!rule;
      }
      // Remove keyword
      removeKeyword(keyword) {
        const { RULES } = this;
        delete RULES.keywords[keyword];
        delete RULES.all[keyword];
        for (const group of RULES.rules) {
          const i = group.rules.findIndex((rule) => rule.keyword === keyword);
          if (i >= 0)
            group.rules.splice(i, 1);
        }
        return this;
      }
      // Add format
      addFormat(name, format) {
        if (typeof format == "string")
          format = new RegExp(format);
        this.formats[name] = format;
        return this;
      }
      errorsText(errors = this.errors, { separator = ", ", dataVar = "data" } = {}) {
        if (!errors || errors.length === 0)
          return "No errors";
        return errors.map((e) => `${dataVar}${e.instancePath} ${e.message}`).reduce((text, msg) => text + separator + msg);
      }
      $dataMetaSchema(metaSchema, keywordsJsonPointers) {
        const rules = this.RULES.all;
        metaSchema = JSON.parse(JSON.stringify(metaSchema));
        for (const jsonPointer of keywordsJsonPointers) {
          const segments = jsonPointer.split("/").slice(1);
          let keywords = metaSchema;
          for (const seg of segments)
            keywords = keywords[seg];
          for (const key in rules) {
            const rule = rules[key];
            if (typeof rule != "object")
              continue;
            const { $data } = rule.definition;
            const schema = keywords[key];
            if ($data && schema)
              keywords[key] = schemaOrData(schema);
          }
        }
        return metaSchema;
      }
      _removeAllSchemas(schemas, regex) {
        for (const keyRef in schemas) {
          const sch = schemas[keyRef];
          if (!regex || regex.test(keyRef)) {
            if (typeof sch == "string") {
              delete schemas[keyRef];
            } else if (sch && !sch.meta) {
              this._cache.delete(sch.schema);
              delete schemas[keyRef];
            }
          }
        }
      }
      _addSchema(schema, meta, baseId, validateSchema = this.opts.validateSchema, addSchema = this.opts.addUsedSchema) {
        let id2;
        const { schemaId } = this.opts;
        if (typeof schema == "object") {
          id2 = schema[schemaId];
        } else {
          if (this.opts.jtd)
            throw new Error("schema must be object");
          else if (typeof schema != "boolean")
            throw new Error("schema must be object or boolean");
        }
        let sch = this._cache.get(schema);
        if (sch !== void 0)
          return sch;
        baseId = (0, resolve_1.normalizeId)(id2 || baseId);
        const localRefs = resolve_1.getSchemaRefs.call(this, schema, baseId);
        sch = new compile_1.SchemaEnv({ schema, schemaId, meta, baseId, localRefs });
        this._cache.set(sch.schema, sch);
        if (addSchema && !baseId.startsWith("#")) {
          if (baseId)
            this._checkUnique(baseId);
          this.refs[baseId] = sch;
        }
        if (validateSchema)
          this.validateSchema(schema, true);
        return sch;
      }
      _checkUnique(id2) {
        if (this.schemas[id2] || this.refs[id2]) {
          throw new Error(`schema with key or id "${id2}" already exists`);
        }
      }
      _compileSchemaEnv(sch) {
        if (sch.meta)
          this._compileMetaSchema(sch);
        else
          compile_1.compileSchema.call(this, sch);
        if (!sch.validate)
          throw new Error("ajv implementation error");
        return sch.validate;
      }
      _compileMetaSchema(sch) {
        const currentOpts = this.opts;
        this.opts = this._metaOpts;
        try {
          compile_1.compileSchema.call(this, sch);
        } finally {
          this.opts = currentOpts;
        }
      }
    };
    Ajv2.ValidationError = validation_error_1.default;
    Ajv2.MissingRefError = ref_error_1.default;
    exports.default = Ajv2;
    function checkOptions(checkOpts, options, msg, log = "error") {
      for (const key in checkOpts) {
        const opt = key;
        if (opt in options)
          this.logger[log](`${msg}: option ${key}. ${checkOpts[opt]}`);
      }
    }
    function getSchEnv(keyRef) {
      keyRef = (0, resolve_1.normalizeId)(keyRef);
      return this.schemas[keyRef] || this.refs[keyRef];
    }
    function addInitialSchemas() {
      const optsSchemas = this.opts.schemas;
      if (!optsSchemas)
        return;
      if (Array.isArray(optsSchemas))
        this.addSchema(optsSchemas);
      else
        for (const key in optsSchemas)
          this.addSchema(optsSchemas[key], key);
    }
    function addInitialFormats() {
      for (const name in this.opts.formats) {
        const format = this.opts.formats[name];
        if (format)
          this.addFormat(name, format);
      }
    }
    function addInitialKeywords(defs) {
      if (Array.isArray(defs)) {
        this.addVocabulary(defs);
        return;
      }
      this.logger.warn("keywords option as map is deprecated, pass array");
      for (const keyword in defs) {
        const def = defs[keyword];
        if (!def.keyword)
          def.keyword = keyword;
        this.addKeyword(def);
      }
    }
    function getMetaSchemaOptions() {
      const metaOpts = { ...this.opts };
      for (const opt of META_IGNORE_OPTIONS)
        delete metaOpts[opt];
      return metaOpts;
    }
    var noLogs = { log() {
    }, warn() {
    }, error() {
    } };
    function getLogger(logger) {
      if (logger === false)
        return noLogs;
      if (logger === void 0)
        return console;
      if (logger.log && logger.warn && logger.error)
        return logger;
      throw new Error("logger must implement log, warn and error methods");
    }
    var KEYWORD_NAME = /^[a-z_$][a-z0-9_$:-]*$/i;
    function checkKeyword(keyword, def) {
      const { RULES } = this;
      (0, util_1.eachItem)(keyword, (kwd) => {
        if (RULES.keywords[kwd])
          throw new Error(`Keyword ${kwd} is already defined`);
        if (!KEYWORD_NAME.test(kwd))
          throw new Error(`Keyword ${kwd} has invalid name`);
      });
      if (!def)
        return;
      if (def.$data && !("code" in def || "validate" in def)) {
        throw new Error('$data keyword must have "code" or "validate" function');
      }
    }
    function addRule(keyword, definition, dataType) {
      var _a;
      const post = definition === null || definition === void 0 ? void 0 : definition.post;
      if (dataType && post)
        throw new Error('keyword with "post" flag cannot have "type"');
      const { RULES } = this;
      let ruleGroup = post ? RULES.post : RULES.rules.find(({ type: t }) => t === dataType);
      if (!ruleGroup) {
        ruleGroup = { type: dataType, rules: [] };
        RULES.rules.push(ruleGroup);
      }
      RULES.keywords[keyword] = true;
      if (!definition)
        return;
      const rule = {
        keyword,
        definition: {
          ...definition,
          type: (0, dataType_1.getJSONTypes)(definition.type),
          schemaType: (0, dataType_1.getJSONTypes)(definition.schemaType)
        }
      };
      if (definition.before)
        addBeforeRule.call(this, ruleGroup, rule, definition.before);
      else
        ruleGroup.rules.push(rule);
      RULES.all[keyword] = rule;
      (_a = definition.implements) === null || _a === void 0 ? void 0 : _a.forEach((kwd) => this.addKeyword(kwd));
    }
    function addBeforeRule(ruleGroup, rule, before) {
      const i = ruleGroup.rules.findIndex((_rule) => _rule.keyword === before);
      if (i >= 0) {
        ruleGroup.rules.splice(i, 0, rule);
      } else {
        ruleGroup.rules.push(rule);
        this.logger.warn(`rule ${before} is not defined`);
      }
    }
    function keywordMetaschema(def) {
      let { metaSchema } = def;
      if (metaSchema === void 0)
        return;
      if (def.$data && this.opts.$data)
        metaSchema = schemaOrData(metaSchema);
      def.validateSchema = this.compile(metaSchema, true);
    }
    var $dataRef = {
      $ref: "https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#"
    };
    function schemaOrData(schema) {
      return { anyOf: [schema, $dataRef] };
    }
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/core/id.js
var require_id = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/core/id.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var def = {
      keyword: "id",
      code() {
        throw new Error('NOT SUPPORTED: keyword "id", use "$id" for schema ID');
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/core/ref.js
var require_ref = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/core/ref.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.callRef = exports.getValidate = void 0;
    var ref_error_1 = require_ref_error();
    var code_1 = require_code2();
    var codegen_1 = require_codegen();
    var names_1 = require_names();
    var compile_1 = require_compile();
    var util_1 = require_util();
    var def = {
      keyword: "$ref",
      schemaType: "string",
      code(cxt) {
        const { gen, schema: $ref, it } = cxt;
        const { baseId, schemaEnv: env, validateName, opts, self } = it;
        const { root } = env;
        if (($ref === "#" || $ref === "#/") && baseId === root.baseId)
          return callRootRef();
        const schOrEnv = compile_1.resolveRef.call(self, root, baseId, $ref);
        if (schOrEnv === void 0)
          throw new ref_error_1.default(it.opts.uriResolver, baseId, $ref);
        if (schOrEnv instanceof compile_1.SchemaEnv)
          return callValidate(schOrEnv);
        return inlineRefSchema(schOrEnv);
        function callRootRef() {
          if (env === root)
            return callRef(cxt, validateName, env, env.$async);
          const rootName = gen.scopeValue("root", { ref: root });
          return callRef(cxt, (0, codegen_1._)`${rootName}.validate`, root, root.$async);
        }
        function callValidate(sch) {
          const v = getValidate(cxt, sch);
          callRef(cxt, v, sch, sch.$async);
        }
        function inlineRefSchema(sch) {
          const schName = gen.scopeValue("schema", opts.code.source === true ? { ref: sch, code: (0, codegen_1.stringify)(sch) } : { ref: sch });
          const valid = gen.name("valid");
          const schCxt = cxt.subschema({
            schema: sch,
            dataTypes: [],
            schemaPath: codegen_1.nil,
            topSchemaRef: schName,
            errSchemaPath: $ref
          }, valid);
          cxt.mergeEvaluated(schCxt);
          cxt.ok(valid);
        }
      }
    };
    function getValidate(cxt, sch) {
      const { gen } = cxt;
      return sch.validate ? gen.scopeValue("validate", { ref: sch.validate }) : (0, codegen_1._)`${gen.scopeValue("wrapper", { ref: sch })}.validate`;
    }
    exports.getValidate = getValidate;
    function callRef(cxt, v, sch, $async) {
      const { gen, it } = cxt;
      const { allErrors, schemaEnv: env, opts } = it;
      const passCxt = opts.passContext ? names_1.default.this : codegen_1.nil;
      if ($async)
        callAsyncRef();
      else
        callSyncRef();
      function callAsyncRef() {
        if (!env.$async)
          throw new Error("async schema referenced by sync schema");
        const valid = gen.let("valid");
        gen.try(() => {
          gen.code((0, codegen_1._)`await ${(0, code_1.callValidateCode)(cxt, v, passCxt)}`);
          addEvaluatedFrom(v);
          if (!allErrors)
            gen.assign(valid, true);
        }, (e) => {
          gen.if((0, codegen_1._)`!(${e} instanceof ${it.ValidationError})`, () => gen.throw(e));
          addErrorsFrom(e);
          if (!allErrors)
            gen.assign(valid, false);
        });
        cxt.ok(valid);
      }
      function callSyncRef() {
        cxt.result((0, code_1.callValidateCode)(cxt, v, passCxt), () => addEvaluatedFrom(v), () => addErrorsFrom(v));
      }
      function addErrorsFrom(source) {
        const errs = (0, codegen_1._)`${source}.errors`;
        gen.assign(names_1.default.vErrors, (0, codegen_1._)`${names_1.default.vErrors} === null ? ${errs} : ${names_1.default.vErrors}.concat(${errs})`);
        gen.assign(names_1.default.errors, (0, codegen_1._)`${names_1.default.vErrors}.length`);
      }
      function addEvaluatedFrom(source) {
        var _a;
        if (!it.opts.unevaluated)
          return;
        const schEvaluated = (_a = sch === null || sch === void 0 ? void 0 : sch.validate) === null || _a === void 0 ? void 0 : _a.evaluated;
        if (it.props !== true) {
          if (schEvaluated && !schEvaluated.dynamicProps) {
            if (schEvaluated.props !== void 0) {
              it.props = util_1.mergeEvaluated.props(gen, schEvaluated.props, it.props);
            }
          } else {
            const props = gen.var("props", (0, codegen_1._)`${source}.evaluated.props`);
            it.props = util_1.mergeEvaluated.props(gen, props, it.props, codegen_1.Name);
          }
        }
        if (it.items !== true) {
          if (schEvaluated && !schEvaluated.dynamicItems) {
            if (schEvaluated.items !== void 0) {
              it.items = util_1.mergeEvaluated.items(gen, schEvaluated.items, it.items);
            }
          } else {
            const items = gen.var("items", (0, codegen_1._)`${source}.evaluated.items`);
            it.items = util_1.mergeEvaluated.items(gen, items, it.items, codegen_1.Name);
          }
        }
      }
    }
    exports.callRef = callRef;
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/core/index.js
var require_core2 = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/core/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var id_1 = require_id();
    var ref_1 = require_ref();
    var core = [
      "$schema",
      "$id",
      "$defs",
      "$vocabulary",
      { keyword: "$comment" },
      "definitions",
      id_1.default,
      ref_1.default
    ];
    exports.default = core;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitNumber.js
var require_limitNumber = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitNumber.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var ops = codegen_1.operators;
    var KWDs = {
      maximum: { okStr: "<=", ok: ops.LTE, fail: ops.GT },
      minimum: { okStr: ">=", ok: ops.GTE, fail: ops.LT },
      exclusiveMaximum: { okStr: "<", ok: ops.LT, fail: ops.GTE },
      exclusiveMinimum: { okStr: ">", ok: ops.GT, fail: ops.LTE }
    };
    var error4 = {
      message: ({ keyword, schemaCode }) => (0, codegen_1.str)`must be ${KWDs[keyword].okStr} ${schemaCode}`,
      params: ({ keyword, schemaCode }) => (0, codegen_1._)`{comparison: ${KWDs[keyword].okStr}, limit: ${schemaCode}}`
    };
    var def = {
      keyword: Object.keys(KWDs),
      type: "number",
      schemaType: "number",
      $data: true,
      error: error4,
      code(cxt) {
        const { keyword, data, schemaCode } = cxt;
        cxt.fail$data((0, codegen_1._)`${data} ${KWDs[keyword].fail} ${schemaCode} || isNaN(${data})`);
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/multipleOf.js
var require_multipleOf = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/multipleOf.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var error4 = {
      message: ({ schemaCode }) => (0, codegen_1.str)`must be multiple of ${schemaCode}`,
      params: ({ schemaCode }) => (0, codegen_1._)`{multipleOf: ${schemaCode}}`
    };
    var def = {
      keyword: "multipleOf",
      type: "number",
      schemaType: "number",
      $data: true,
      error: error4,
      code(cxt) {
        const { gen, data, schemaCode, it } = cxt;
        const prec = it.opts.multipleOfPrecision;
        const res = gen.let("res");
        const invalid = prec ? (0, codegen_1._)`Math.abs(Math.round(${res}) - ${res}) > 1e-${prec}` : (0, codegen_1._)`${res} !== parseInt(${res})`;
        cxt.fail$data((0, codegen_1._)`(${schemaCode} === 0 || (${res} = ${data}/${schemaCode}, ${invalid}))`);
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/ucs2length.js
var require_ucs2length = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/ucs2length.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function ucs2length(str) {
      const len = str.length;
      let length = 0;
      let pos = 0;
      let value;
      while (pos < len) {
        length++;
        value = str.charCodeAt(pos++);
        if (value >= 55296 && value <= 56319 && pos < len) {
          value = str.charCodeAt(pos);
          if ((value & 64512) === 56320)
            pos++;
        }
      }
      return length;
    }
    exports.default = ucs2length;
    ucs2length.code = 'require("ajv/dist/runtime/ucs2length").default';
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitLength.js
var require_limitLength = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitLength.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var ucs2length_1 = require_ucs2length();
    var error4 = {
      message({ keyword, schemaCode }) {
        const comp = keyword === "maxLength" ? "more" : "fewer";
        return (0, codegen_1.str)`must NOT have ${comp} than ${schemaCode} characters`;
      },
      params: ({ schemaCode }) => (0, codegen_1._)`{limit: ${schemaCode}}`
    };
    var def = {
      keyword: ["maxLength", "minLength"],
      type: "string",
      schemaType: "number",
      $data: true,
      error: error4,
      code(cxt) {
        const { keyword, data, schemaCode, it } = cxt;
        const op = keyword === "maxLength" ? codegen_1.operators.GT : codegen_1.operators.LT;
        const len = it.opts.unicode === false ? (0, codegen_1._)`${data}.length` : (0, codegen_1._)`${(0, util_1.useFunc)(cxt.gen, ucs2length_1.default)}(${data})`;
        cxt.fail$data((0, codegen_1._)`${len} ${op} ${schemaCode}`);
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/pattern.js
var require_pattern = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/pattern.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var code_1 = require_code2();
    var util_1 = require_util();
    var codegen_1 = require_codegen();
    var error4 = {
      message: ({ schemaCode }) => (0, codegen_1.str)`must match pattern "${schemaCode}"`,
      params: ({ schemaCode }) => (0, codegen_1._)`{pattern: ${schemaCode}}`
    };
    var def = {
      keyword: "pattern",
      type: "string",
      schemaType: "string",
      $data: true,
      error: error4,
      code(cxt) {
        const { gen, data, $data, schema, schemaCode, it } = cxt;
        const u = it.opts.unicodeRegExp ? "u" : "";
        if ($data) {
          const { regExp } = it.opts.code;
          const regExpCode = regExp.code === "new RegExp" ? (0, codegen_1._)`new RegExp` : (0, util_1.useFunc)(gen, regExp);
          const valid = gen.let("valid");
          gen.try(() => gen.assign(valid, (0, codegen_1._)`${regExpCode}(${schemaCode}, ${u}).test(${data})`), () => gen.assign(valid, false));
          cxt.fail$data((0, codegen_1._)`!${valid}`);
        } else {
          const regExp = (0, code_1.usePattern)(cxt, schema);
          cxt.fail$data((0, codegen_1._)`!${regExp}.test(${data})`);
        }
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitProperties.js
var require_limitProperties = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitProperties.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var error4 = {
      message({ keyword, schemaCode }) {
        const comp = keyword === "maxProperties" ? "more" : "fewer";
        return (0, codegen_1.str)`must NOT have ${comp} than ${schemaCode} properties`;
      },
      params: ({ schemaCode }) => (0, codegen_1._)`{limit: ${schemaCode}}`
    };
    var def = {
      keyword: ["maxProperties", "minProperties"],
      type: "object",
      schemaType: "number",
      $data: true,
      error: error4,
      code(cxt) {
        const { keyword, data, schemaCode } = cxt;
        const op = keyword === "maxProperties" ? codegen_1.operators.GT : codegen_1.operators.LT;
        cxt.fail$data((0, codegen_1._)`Object.keys(${data}).length ${op} ${schemaCode}`);
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/required.js
var require_required = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/required.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var code_1 = require_code2();
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var error4 = {
      message: ({ params: { missingProperty } }) => (0, codegen_1.str)`must have required property '${missingProperty}'`,
      params: ({ params: { missingProperty } }) => (0, codegen_1._)`{missingProperty: ${missingProperty}}`
    };
    var def = {
      keyword: "required",
      type: "object",
      schemaType: "array",
      $data: true,
      error: error4,
      code(cxt) {
        const { gen, schema, schemaCode, data, $data, it } = cxt;
        const { opts } = it;
        if (!$data && schema.length === 0)
          return;
        const useLoop = schema.length >= opts.loopRequired;
        if (it.allErrors)
          allErrorsMode();
        else
          exitOnErrorMode();
        if (opts.strictRequired) {
          const props = cxt.parentSchema.properties;
          const { definedProperties } = cxt.it;
          for (const requiredKey of schema) {
            if ((props === null || props === void 0 ? void 0 : props[requiredKey]) === void 0 && !definedProperties.has(requiredKey)) {
              const schemaPath = it.schemaEnv.baseId + it.errSchemaPath;
              const msg = `required property "${requiredKey}" is not defined at "${schemaPath}" (strictRequired)`;
              (0, util_1.checkStrictMode)(it, msg, it.opts.strictRequired);
            }
          }
        }
        function allErrorsMode() {
          if (useLoop || $data) {
            cxt.block$data(codegen_1.nil, loopAllRequired);
          } else {
            for (const prop of schema) {
              (0, code_1.checkReportMissingProp)(cxt, prop);
            }
          }
        }
        function exitOnErrorMode() {
          const missing = gen.let("missing");
          if (useLoop || $data) {
            const valid = gen.let("valid", true);
            cxt.block$data(valid, () => loopUntilMissing(missing, valid));
            cxt.ok(valid);
          } else {
            gen.if((0, code_1.checkMissingProp)(cxt, schema, missing));
            (0, code_1.reportMissingProp)(cxt, missing);
            gen.else();
          }
        }
        function loopAllRequired() {
          gen.forOf("prop", schemaCode, (prop) => {
            cxt.setParams({ missingProperty: prop });
            gen.if((0, code_1.noPropertyInData)(gen, data, prop, opts.ownProperties), () => cxt.error());
          });
        }
        function loopUntilMissing(missing, valid) {
          cxt.setParams({ missingProperty: missing });
          gen.forOf(missing, schemaCode, () => {
            gen.assign(valid, (0, code_1.propertyInData)(gen, data, missing, opts.ownProperties));
            gen.if((0, codegen_1.not)(valid), () => {
              cxt.error();
              gen.break();
            });
          }, codegen_1.nil);
        }
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitItems.js
var require_limitItems = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitItems.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var error4 = {
      message({ keyword, schemaCode }) {
        const comp = keyword === "maxItems" ? "more" : "fewer";
        return (0, codegen_1.str)`must NOT have ${comp} than ${schemaCode} items`;
      },
      params: ({ schemaCode }) => (0, codegen_1._)`{limit: ${schemaCode}}`
    };
    var def = {
      keyword: ["maxItems", "minItems"],
      type: "array",
      schemaType: "number",
      $data: true,
      error: error4,
      code(cxt) {
        const { keyword, data, schemaCode } = cxt;
        const op = keyword === "maxItems" ? codegen_1.operators.GT : codegen_1.operators.LT;
        cxt.fail$data((0, codegen_1._)`${data}.length ${op} ${schemaCode}`);
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/equal.js
var require_equal = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/equal.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var equal = require_fast_deep_equal();
    equal.code = 'require("ajv/dist/runtime/equal").default';
    exports.default = equal;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/uniqueItems.js
var require_uniqueItems = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/uniqueItems.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var dataType_1 = require_dataType();
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var equal_1 = require_equal();
    var error4 = {
      message: ({ params: { i, j } }) => (0, codegen_1.str)`must NOT have duplicate items (items ## ${j} and ${i} are identical)`,
      params: ({ params: { i, j } }) => (0, codegen_1._)`{i: ${i}, j: ${j}}`
    };
    var def = {
      keyword: "uniqueItems",
      type: "array",
      schemaType: "boolean",
      $data: true,
      error: error4,
      code(cxt) {
        const { gen, data, $data, schema, parentSchema, schemaCode, it } = cxt;
        if (!$data && !schema)
          return;
        const valid = gen.let("valid");
        const itemTypes = parentSchema.items ? (0, dataType_1.getSchemaTypes)(parentSchema.items) : [];
        cxt.block$data(valid, validateUniqueItems, (0, codegen_1._)`${schemaCode} === false`);
        cxt.ok(valid);
        function validateUniqueItems() {
          const i = gen.let("i", (0, codegen_1._)`${data}.length`);
          const j = gen.let("j");
          cxt.setParams({ i, j });
          gen.assign(valid, true);
          gen.if((0, codegen_1._)`${i} > 1`, () => (canOptimize() ? loopN : loopN2)(i, j));
        }
        function canOptimize() {
          return itemTypes.length > 0 && !itemTypes.some((t) => t === "object" || t === "array");
        }
        function loopN(i, j) {
          const item = gen.name("item");
          const wrongType = (0, dataType_1.checkDataTypes)(itemTypes, item, it.opts.strictNumbers, dataType_1.DataType.Wrong);
          const indices = gen.const("indices", (0, codegen_1._)`{}`);
          gen.for((0, codegen_1._)`;${i}--;`, () => {
            gen.let(item, (0, codegen_1._)`${data}[${i}]`);
            gen.if(wrongType, (0, codegen_1._)`continue`);
            if (itemTypes.length > 1)
              gen.if((0, codegen_1._)`typeof ${item} == "string"`, (0, codegen_1._)`${item} += "_"`);
            gen.if((0, codegen_1._)`typeof ${indices}[${item}] == "number"`, () => {
              gen.assign(j, (0, codegen_1._)`${indices}[${item}]`);
              cxt.error();
              gen.assign(valid, false).break();
            }).code((0, codegen_1._)`${indices}[${item}] = ${i}`);
          });
        }
        function loopN2(i, j) {
          const eql = (0, util_1.useFunc)(gen, equal_1.default);
          const outer = gen.name("outer");
          gen.label(outer).for((0, codegen_1._)`;${i}--;`, () => gen.for((0, codegen_1._)`${j} = ${i}; ${j}--;`, () => gen.if((0, codegen_1._)`${eql}(${data}[${i}], ${data}[${j}])`, () => {
            cxt.error();
            gen.assign(valid, false).break(outer);
          })));
        }
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/const.js
var require_const = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/const.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var equal_1 = require_equal();
    var error4 = {
      message: "must be equal to constant",
      params: ({ schemaCode }) => (0, codegen_1._)`{allowedValue: ${schemaCode}}`
    };
    var def = {
      keyword: "const",
      $data: true,
      error: error4,
      code(cxt) {
        const { gen, data, $data, schemaCode, schema } = cxt;
        if ($data || schema && typeof schema == "object") {
          cxt.fail$data((0, codegen_1._)`!${(0, util_1.useFunc)(gen, equal_1.default)}(${data}, ${schemaCode})`);
        } else {
          cxt.fail((0, codegen_1._)`${schema} !== ${data}`);
        }
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/enum.js
var require_enum = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/enum.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var equal_1 = require_equal();
    var error4 = {
      message: "must be equal to one of the allowed values",
      params: ({ schemaCode }) => (0, codegen_1._)`{allowedValues: ${schemaCode}}`
    };
    var def = {
      keyword: "enum",
      schemaType: "array",
      $data: true,
      error: error4,
      code(cxt) {
        const { gen, data, $data, schema, schemaCode, it } = cxt;
        if (!$data && schema.length === 0)
          throw new Error("enum must have non-empty array");
        const useLoop = schema.length >= it.opts.loopEnum;
        let eql;
        const getEql = () => eql !== null && eql !== void 0 ? eql : eql = (0, util_1.useFunc)(gen, equal_1.default);
        let valid;
        if (useLoop || $data) {
          valid = gen.let("valid");
          cxt.block$data(valid, loopEnum);
        } else {
          if (!Array.isArray(schema))
            throw new Error("ajv implementation error");
          const vSchema = gen.const("vSchema", schemaCode);
          valid = (0, codegen_1.or)(...schema.map((_x, i) => equalCode(vSchema, i)));
        }
        cxt.pass(valid);
        function loopEnum() {
          gen.assign(valid, false);
          gen.forOf("v", schemaCode, (v) => gen.if((0, codegen_1._)`${getEql()}(${data}, ${v})`, () => gen.assign(valid, true).break()));
        }
        function equalCode(vSchema, i) {
          const sch = schema[i];
          return typeof sch === "object" && sch !== null ? (0, codegen_1._)`${getEql()}(${data}, ${vSchema}[${i}])` : (0, codegen_1._)`${data} === ${sch}`;
        }
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/index.js
var require_validation = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var limitNumber_1 = require_limitNumber();
    var multipleOf_1 = require_multipleOf();
    var limitLength_1 = require_limitLength();
    var pattern_1 = require_pattern();
    var limitProperties_1 = require_limitProperties();
    var required_1 = require_required();
    var limitItems_1 = require_limitItems();
    var uniqueItems_1 = require_uniqueItems();
    var const_1 = require_const();
    var enum_1 = require_enum();
    var validation3 = [
      // number
      limitNumber_1.default,
      multipleOf_1.default,
      // string
      limitLength_1.default,
      pattern_1.default,
      // object
      limitProperties_1.default,
      required_1.default,
      // array
      limitItems_1.default,
      uniqueItems_1.default,
      // any
      { keyword: "type", schemaType: ["string", "array"] },
      { keyword: "nullable", schemaType: "boolean" },
      const_1.default,
      enum_1.default
    ];
    exports.default = validation3;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/additionalItems.js
var require_additionalItems = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/additionalItems.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateAdditionalItems = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var error4 = {
      message: ({ params: { len } }) => (0, codegen_1.str)`must NOT have more than ${len} items`,
      params: ({ params: { len } }) => (0, codegen_1._)`{limit: ${len}}`
    };
    var def = {
      keyword: "additionalItems",
      type: "array",
      schemaType: ["boolean", "object"],
      before: "uniqueItems",
      error: error4,
      code(cxt) {
        const { parentSchema, it } = cxt;
        const { items } = parentSchema;
        if (!Array.isArray(items)) {
          (0, util_1.checkStrictMode)(it, '"additionalItems" is ignored when "items" is not an array of schemas');
          return;
        }
        validateAdditionalItems(cxt, items);
      }
    };
    function validateAdditionalItems(cxt, items) {
      const { gen, schema, data, keyword, it } = cxt;
      it.items = true;
      const len = gen.const("len", (0, codegen_1._)`${data}.length`);
      if (schema === false) {
        cxt.setParams({ len: items.length });
        cxt.pass((0, codegen_1._)`${len} <= ${items.length}`);
      } else if (typeof schema == "object" && !(0, util_1.alwaysValidSchema)(it, schema)) {
        const valid = gen.var("valid", (0, codegen_1._)`${len} <= ${items.length}`);
        gen.if((0, codegen_1.not)(valid), () => validateItems(valid));
        cxt.ok(valid);
      }
      function validateItems(valid) {
        gen.forRange("i", items.length, len, (i) => {
          cxt.subschema({ keyword, dataProp: i, dataPropType: util_1.Type.Num }, valid);
          if (!it.allErrors)
            gen.if((0, codegen_1.not)(valid), () => gen.break());
        });
      }
    }
    exports.validateAdditionalItems = validateAdditionalItems;
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/items.js
var require_items = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/items.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateTuple = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var code_1 = require_code2();
    var def = {
      keyword: "items",
      type: "array",
      schemaType: ["object", "array", "boolean"],
      before: "uniqueItems",
      code(cxt) {
        const { schema, it } = cxt;
        if (Array.isArray(schema))
          return validateTuple(cxt, "additionalItems", schema);
        it.items = true;
        if ((0, util_1.alwaysValidSchema)(it, schema))
          return;
        cxt.ok((0, code_1.validateArray)(cxt));
      }
    };
    function validateTuple(cxt, extraItems, schArr = cxt.schema) {
      const { gen, parentSchema, data, keyword, it } = cxt;
      checkStrictTuple(parentSchema);
      if (it.opts.unevaluated && schArr.length && it.items !== true) {
        it.items = util_1.mergeEvaluated.items(gen, schArr.length, it.items);
      }
      const valid = gen.name("valid");
      const len = gen.const("len", (0, codegen_1._)`${data}.length`);
      schArr.forEach((sch, i) => {
        if ((0, util_1.alwaysValidSchema)(it, sch))
          return;
        gen.if((0, codegen_1._)`${len} > ${i}`, () => cxt.subschema({
          keyword,
          schemaProp: i,
          dataProp: i
        }, valid));
        cxt.ok(valid);
      });
      function checkStrictTuple(sch) {
        const { opts, errSchemaPath } = it;
        const l = schArr.length;
        const fullTuple = l === sch.minItems && (l === sch.maxItems || sch[extraItems] === false);
        if (opts.strictTuples && !fullTuple) {
          const msg = `"${keyword}" is ${l}-tuple, but minItems or maxItems/${extraItems} are not specified or different at path "${errSchemaPath}"`;
          (0, util_1.checkStrictMode)(it, msg, opts.strictTuples);
        }
      }
    }
    exports.validateTuple = validateTuple;
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/prefixItems.js
var require_prefixItems = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/prefixItems.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var items_1 = require_items();
    var def = {
      keyword: "prefixItems",
      type: "array",
      schemaType: ["array"],
      before: "uniqueItems",
      code: (cxt) => (0, items_1.validateTuple)(cxt, "items")
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/items2020.js
var require_items2020 = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/items2020.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var code_1 = require_code2();
    var additionalItems_1 = require_additionalItems();
    var error4 = {
      message: ({ params: { len } }) => (0, codegen_1.str)`must NOT have more than ${len} items`,
      params: ({ params: { len } }) => (0, codegen_1._)`{limit: ${len}}`
    };
    var def = {
      keyword: "items",
      type: "array",
      schemaType: ["object", "boolean"],
      before: "uniqueItems",
      error: error4,
      code(cxt) {
        const { schema, parentSchema, it } = cxt;
        const { prefixItems } = parentSchema;
        it.items = true;
        if ((0, util_1.alwaysValidSchema)(it, schema))
          return;
        if (prefixItems)
          (0, additionalItems_1.validateAdditionalItems)(cxt, prefixItems);
        else
          cxt.ok((0, code_1.validateArray)(cxt));
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/contains.js
var require_contains = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/contains.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var error4 = {
      message: ({ params: { min, max } }) => max === void 0 ? (0, codegen_1.str)`must contain at least ${min} valid item(s)` : (0, codegen_1.str)`must contain at least ${min} and no more than ${max} valid item(s)`,
      params: ({ params: { min, max } }) => max === void 0 ? (0, codegen_1._)`{minContains: ${min}}` : (0, codegen_1._)`{minContains: ${min}, maxContains: ${max}}`
    };
    var def = {
      keyword: "contains",
      type: "array",
      schemaType: ["object", "boolean"],
      before: "uniqueItems",
      trackErrors: true,
      error: error4,
      code(cxt) {
        const { gen, schema, parentSchema, data, it } = cxt;
        let min;
        let max;
        const { minContains, maxContains } = parentSchema;
        if (it.opts.next) {
          min = minContains === void 0 ? 1 : minContains;
          max = maxContains;
        } else {
          min = 1;
        }
        const len = gen.const("len", (0, codegen_1._)`${data}.length`);
        cxt.setParams({ min, max });
        if (max === void 0 && min === 0) {
          (0, util_1.checkStrictMode)(it, `"minContains" == 0 without "maxContains": "contains" keyword ignored`);
          return;
        }
        if (max !== void 0 && min > max) {
          (0, util_1.checkStrictMode)(it, `"minContains" > "maxContains" is always invalid`);
          cxt.fail();
          return;
        }
        if ((0, util_1.alwaysValidSchema)(it, schema)) {
          let cond = (0, codegen_1._)`${len} >= ${min}`;
          if (max !== void 0)
            cond = (0, codegen_1._)`${cond} && ${len} <= ${max}`;
          cxt.pass(cond);
          return;
        }
        it.items = true;
        const valid = gen.name("valid");
        if (max === void 0 && min === 1) {
          validateItems(valid, () => gen.if(valid, () => gen.break()));
        } else if (min === 0) {
          gen.let(valid, true);
          if (max !== void 0)
            gen.if((0, codegen_1._)`${data}.length > 0`, validateItemsWithCount);
        } else {
          gen.let(valid, false);
          validateItemsWithCount();
        }
        cxt.result(valid, () => cxt.reset());
        function validateItemsWithCount() {
          const schValid = gen.name("_valid");
          const count = gen.let("count", 0);
          validateItems(schValid, () => gen.if(schValid, () => checkLimits(count)));
        }
        function validateItems(_valid, block) {
          gen.forRange("i", 0, len, (i) => {
            cxt.subschema({
              keyword: "contains",
              dataProp: i,
              dataPropType: util_1.Type.Num,
              compositeRule: true
            }, _valid);
            block();
          });
        }
        function checkLimits(count) {
          gen.code((0, codegen_1._)`${count}++`);
          if (max === void 0) {
            gen.if((0, codegen_1._)`${count} >= ${min}`, () => gen.assign(valid, true).break());
          } else {
            gen.if((0, codegen_1._)`${count} > ${max}`, () => gen.assign(valid, false).break());
            if (min === 1)
              gen.assign(valid, true);
            else
              gen.if((0, codegen_1._)`${count} >= ${min}`, () => gen.assign(valid, true));
          }
        }
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/dependencies.js
var require_dependencies = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/dependencies.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateSchemaDeps = exports.validatePropertyDeps = exports.error = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var code_1 = require_code2();
    exports.error = {
      message: ({ params: { property, depsCount, deps } }) => {
        const property_ies = depsCount === 1 ? "property" : "properties";
        return (0, codegen_1.str)`must have ${property_ies} ${deps} when property ${property} is present`;
      },
      params: ({ params: { property, depsCount, deps, missingProperty } }) => (0, codegen_1._)`{property: ${property},
    missingProperty: ${missingProperty},
    depsCount: ${depsCount},
    deps: ${deps}}`
      // TODO change to reference
    };
    var def = {
      keyword: "dependencies",
      type: "object",
      schemaType: "object",
      error: exports.error,
      code(cxt) {
        const [propDeps, schDeps] = splitDependencies(cxt);
        validatePropertyDeps(cxt, propDeps);
        validateSchemaDeps(cxt, schDeps);
      }
    };
    function splitDependencies({ schema }) {
      const propertyDeps = {};
      const schemaDeps = {};
      for (const key in schema) {
        if (key === "__proto__")
          continue;
        const deps = Array.isArray(schema[key]) ? propertyDeps : schemaDeps;
        deps[key] = schema[key];
      }
      return [propertyDeps, schemaDeps];
    }
    function validatePropertyDeps(cxt, propertyDeps = cxt.schema) {
      const { gen, data, it } = cxt;
      if (Object.keys(propertyDeps).length === 0)
        return;
      const missing = gen.let("missing");
      for (const prop in propertyDeps) {
        const deps = propertyDeps[prop];
        if (deps.length === 0)
          continue;
        const hasProperty = (0, code_1.propertyInData)(gen, data, prop, it.opts.ownProperties);
        cxt.setParams({
          property: prop,
          depsCount: deps.length,
          deps: deps.join(", ")
        });
        if (it.allErrors) {
          gen.if(hasProperty, () => {
            for (const depProp of deps) {
              (0, code_1.checkReportMissingProp)(cxt, depProp);
            }
          });
        } else {
          gen.if((0, codegen_1._)`${hasProperty} && (${(0, code_1.checkMissingProp)(cxt, deps, missing)})`);
          (0, code_1.reportMissingProp)(cxt, missing);
          gen.else();
        }
      }
    }
    exports.validatePropertyDeps = validatePropertyDeps;
    function validateSchemaDeps(cxt, schemaDeps = cxt.schema) {
      const { gen, data, keyword, it } = cxt;
      const valid = gen.name("valid");
      for (const prop in schemaDeps) {
        if ((0, util_1.alwaysValidSchema)(it, schemaDeps[prop]))
          continue;
        gen.if(
          (0, code_1.propertyInData)(gen, data, prop, it.opts.ownProperties),
          () => {
            const schCxt = cxt.subschema({ keyword, schemaProp: prop }, valid);
            cxt.mergeValidEvaluated(schCxt, valid);
          },
          () => gen.var(valid, true)
          // TODO var
        );
        cxt.ok(valid);
      }
    }
    exports.validateSchemaDeps = validateSchemaDeps;
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/propertyNames.js
var require_propertyNames = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/propertyNames.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var error4 = {
      message: "property name must be valid",
      params: ({ params }) => (0, codegen_1._)`{propertyName: ${params.propertyName}}`
    };
    var def = {
      keyword: "propertyNames",
      type: "object",
      schemaType: ["object", "boolean"],
      error: error4,
      code(cxt) {
        const { gen, schema, data, it } = cxt;
        if ((0, util_1.alwaysValidSchema)(it, schema))
          return;
        const valid = gen.name("valid");
        gen.forIn("key", data, (key) => {
          cxt.setParams({ propertyName: key });
          cxt.subschema({
            keyword: "propertyNames",
            data: key,
            dataTypes: ["string"],
            propertyName: key,
            compositeRule: true
          }, valid);
          gen.if((0, codegen_1.not)(valid), () => {
            cxt.error(true);
            if (!it.allErrors)
              gen.break();
          });
        });
        cxt.ok(valid);
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/additionalProperties.js
var require_additionalProperties = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/additionalProperties.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var code_1 = require_code2();
    var codegen_1 = require_codegen();
    var names_1 = require_names();
    var util_1 = require_util();
    var error4 = {
      message: "must NOT have additional properties",
      params: ({ params }) => (0, codegen_1._)`{additionalProperty: ${params.additionalProperty}}`
    };
    var def = {
      keyword: "additionalProperties",
      type: ["object"],
      schemaType: ["boolean", "object"],
      allowUndefined: true,
      trackErrors: true,
      error: error4,
      code(cxt) {
        const { gen, schema, parentSchema, data, errsCount, it } = cxt;
        if (!errsCount)
          throw new Error("ajv implementation error");
        const { allErrors, opts } = it;
        it.props = true;
        if (opts.removeAdditional !== "all" && (0, util_1.alwaysValidSchema)(it, schema))
          return;
        const props = (0, code_1.allSchemaProperties)(parentSchema.properties);
        const patProps = (0, code_1.allSchemaProperties)(parentSchema.patternProperties);
        checkAdditionalProperties();
        cxt.ok((0, codegen_1._)`${errsCount} === ${names_1.default.errors}`);
        function checkAdditionalProperties() {
          gen.forIn("key", data, (key) => {
            if (!props.length && !patProps.length)
              additionalPropertyCode(key);
            else
              gen.if(isAdditional(key), () => additionalPropertyCode(key));
          });
        }
        function isAdditional(key) {
          let definedProp;
          if (props.length > 8) {
            const propsSchema = (0, util_1.schemaRefOrVal)(it, parentSchema.properties, "properties");
            definedProp = (0, code_1.isOwnProperty)(gen, propsSchema, key);
          } else if (props.length) {
            definedProp = (0, codegen_1.or)(...props.map((p) => (0, codegen_1._)`${key} === ${p}`));
          } else {
            definedProp = codegen_1.nil;
          }
          if (patProps.length) {
            definedProp = (0, codegen_1.or)(definedProp, ...patProps.map((p) => (0, codegen_1._)`${(0, code_1.usePattern)(cxt, p)}.test(${key})`));
          }
          return (0, codegen_1.not)(definedProp);
        }
        function deleteAdditional(key) {
          gen.code((0, codegen_1._)`delete ${data}[${key}]`);
        }
        function additionalPropertyCode(key) {
          if (opts.removeAdditional === "all" || opts.removeAdditional && schema === false) {
            deleteAdditional(key);
            return;
          }
          if (schema === false) {
            cxt.setParams({ additionalProperty: key });
            cxt.error();
            if (!allErrors)
              gen.break();
            return;
          }
          if (typeof schema == "object" && !(0, util_1.alwaysValidSchema)(it, schema)) {
            const valid = gen.name("valid");
            if (opts.removeAdditional === "failing") {
              applyAdditionalSchema(key, valid, false);
              gen.if((0, codegen_1.not)(valid), () => {
                cxt.reset();
                deleteAdditional(key);
              });
            } else {
              applyAdditionalSchema(key, valid);
              if (!allErrors)
                gen.if((0, codegen_1.not)(valid), () => gen.break());
            }
          }
        }
        function applyAdditionalSchema(key, valid, errors) {
          const subschema = {
            keyword: "additionalProperties",
            dataProp: key,
            dataPropType: util_1.Type.Str
          };
          if (errors === false) {
            Object.assign(subschema, {
              compositeRule: true,
              createErrors: false,
              allErrors: false
            });
          }
          cxt.subschema(subschema, valid);
        }
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/properties.js
var require_properties = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/properties.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var validate_1 = require_validate();
    var code_1 = require_code2();
    var util_1 = require_util();
    var additionalProperties_1 = require_additionalProperties();
    var def = {
      keyword: "properties",
      type: "object",
      schemaType: "object",
      code(cxt) {
        const { gen, schema, parentSchema, data, it } = cxt;
        if (it.opts.removeAdditional === "all" && parentSchema.additionalProperties === void 0) {
          additionalProperties_1.default.code(new validate_1.KeywordCxt(it, additionalProperties_1.default, "additionalProperties"));
        }
        const allProps = (0, code_1.allSchemaProperties)(schema);
        for (const prop of allProps) {
          it.definedProperties.add(prop);
        }
        if (it.opts.unevaluated && allProps.length && it.props !== true) {
          it.props = util_1.mergeEvaluated.props(gen, (0, util_1.toHash)(allProps), it.props);
        }
        const properties = allProps.filter((p) => !(0, util_1.alwaysValidSchema)(it, schema[p]));
        if (properties.length === 0)
          return;
        const valid = gen.name("valid");
        for (const prop of properties) {
          if (hasDefault(prop)) {
            applyPropertySchema(prop);
          } else {
            gen.if((0, code_1.propertyInData)(gen, data, prop, it.opts.ownProperties));
            applyPropertySchema(prop);
            if (!it.allErrors)
              gen.else().var(valid, true);
            gen.endIf();
          }
          cxt.it.definedProperties.add(prop);
          cxt.ok(valid);
        }
        function hasDefault(prop) {
          return it.opts.useDefaults && !it.compositeRule && schema[prop].default !== void 0;
        }
        function applyPropertySchema(prop) {
          cxt.subschema({
            keyword: "properties",
            schemaProp: prop,
            dataProp: prop
          }, valid);
        }
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/patternProperties.js
var require_patternProperties = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/patternProperties.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var code_1 = require_code2();
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var util_2 = require_util();
    var def = {
      keyword: "patternProperties",
      type: "object",
      schemaType: "object",
      code(cxt) {
        const { gen, schema, data, parentSchema, it } = cxt;
        const { opts } = it;
        const patterns = (0, code_1.allSchemaProperties)(schema);
        const alwaysValidPatterns = patterns.filter((p) => (0, util_1.alwaysValidSchema)(it, schema[p]));
        if (patterns.length === 0 || alwaysValidPatterns.length === patterns.length && (!it.opts.unevaluated || it.props === true)) {
          return;
        }
        const checkProperties = opts.strictSchema && !opts.allowMatchingProperties && parentSchema.properties;
        const valid = gen.name("valid");
        if (it.props !== true && !(it.props instanceof codegen_1.Name)) {
          it.props = (0, util_2.evaluatedPropsToName)(gen, it.props);
        }
        const { props } = it;
        validatePatternProperties();
        function validatePatternProperties() {
          for (const pat of patterns) {
            if (checkProperties)
              checkMatchingProperties(pat);
            if (it.allErrors) {
              validateProperties(pat);
            } else {
              gen.var(valid, true);
              validateProperties(pat);
              gen.if(valid);
            }
          }
        }
        function checkMatchingProperties(pat) {
          for (const prop in checkProperties) {
            if (new RegExp(pat).test(prop)) {
              (0, util_1.checkStrictMode)(it, `property ${prop} matches pattern ${pat} (use allowMatchingProperties)`);
            }
          }
        }
        function validateProperties(pat) {
          gen.forIn("key", data, (key) => {
            gen.if((0, codegen_1._)`${(0, code_1.usePattern)(cxt, pat)}.test(${key})`, () => {
              const alwaysValid = alwaysValidPatterns.includes(pat);
              if (!alwaysValid) {
                cxt.subschema({
                  keyword: "patternProperties",
                  schemaProp: pat,
                  dataProp: key,
                  dataPropType: util_2.Type.Str
                }, valid);
              }
              if (it.opts.unevaluated && props !== true) {
                gen.assign((0, codegen_1._)`${props}[${key}]`, true);
              } else if (!alwaysValid && !it.allErrors) {
                gen.if((0, codegen_1.not)(valid), () => gen.break());
              }
            });
          });
        }
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/not.js
var require_not = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/not.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var util_1 = require_util();
    var def = {
      keyword: "not",
      schemaType: ["object", "boolean"],
      trackErrors: true,
      code(cxt) {
        const { gen, schema, it } = cxt;
        if ((0, util_1.alwaysValidSchema)(it, schema)) {
          cxt.fail();
          return;
        }
        const valid = gen.name("valid");
        cxt.subschema({
          keyword: "not",
          compositeRule: true,
          createErrors: false,
          allErrors: false
        }, valid);
        cxt.failResult(valid, () => cxt.reset(), () => cxt.error());
      },
      error: { message: "must NOT be valid" }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/anyOf.js
var require_anyOf = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/anyOf.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var code_1 = require_code2();
    var def = {
      keyword: "anyOf",
      schemaType: "array",
      trackErrors: true,
      code: code_1.validateUnion,
      error: { message: "must match a schema in anyOf" }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/oneOf.js
var require_oneOf = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/oneOf.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var error4 = {
      message: "must match exactly one schema in oneOf",
      params: ({ params }) => (0, codegen_1._)`{passingSchemas: ${params.passing}}`
    };
    var def = {
      keyword: "oneOf",
      schemaType: "array",
      trackErrors: true,
      error: error4,
      code(cxt) {
        const { gen, schema, parentSchema, it } = cxt;
        if (!Array.isArray(schema))
          throw new Error("ajv implementation error");
        if (it.opts.discriminator && parentSchema.discriminator)
          return;
        const schArr = schema;
        const valid = gen.let("valid", false);
        const passing = gen.let("passing", null);
        const schValid = gen.name("_valid");
        cxt.setParams({ passing });
        gen.block(validateOneOf);
        cxt.result(valid, () => cxt.reset(), () => cxt.error(true));
        function validateOneOf() {
          schArr.forEach((sch, i) => {
            let schCxt;
            if ((0, util_1.alwaysValidSchema)(it, sch)) {
              gen.var(schValid, true);
            } else {
              schCxt = cxt.subschema({
                keyword: "oneOf",
                schemaProp: i,
                compositeRule: true
              }, schValid);
            }
            if (i > 0) {
              gen.if((0, codegen_1._)`${schValid} && ${valid}`).assign(valid, false).assign(passing, (0, codegen_1._)`[${passing}, ${i}]`).else();
            }
            gen.if(schValid, () => {
              gen.assign(valid, true);
              gen.assign(passing, i);
              if (schCxt)
                cxt.mergeEvaluated(schCxt, codegen_1.Name);
            });
          });
        }
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/allOf.js
var require_allOf = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/allOf.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var util_1 = require_util();
    var def = {
      keyword: "allOf",
      schemaType: "array",
      code(cxt) {
        const { gen, schema, it } = cxt;
        if (!Array.isArray(schema))
          throw new Error("ajv implementation error");
        const valid = gen.name("valid");
        schema.forEach((sch, i) => {
          if ((0, util_1.alwaysValidSchema)(it, sch))
            return;
          const schCxt = cxt.subschema({ keyword: "allOf", schemaProp: i }, valid);
          cxt.ok(valid);
          cxt.mergeEvaluated(schCxt);
        });
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/if.js
var require_if = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/if.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var error4 = {
      message: ({ params }) => (0, codegen_1.str)`must match "${params.ifClause}" schema`,
      params: ({ params }) => (0, codegen_1._)`{failingKeyword: ${params.ifClause}}`
    };
    var def = {
      keyword: "if",
      schemaType: ["object", "boolean"],
      trackErrors: true,
      error: error4,
      code(cxt) {
        const { gen, parentSchema, it } = cxt;
        if (parentSchema.then === void 0 && parentSchema.else === void 0) {
          (0, util_1.checkStrictMode)(it, '"if" without "then" and "else" is ignored');
        }
        const hasThen = hasSchema(it, "then");
        const hasElse = hasSchema(it, "else");
        if (!hasThen && !hasElse)
          return;
        const valid = gen.let("valid", true);
        const schValid = gen.name("_valid");
        validateIf();
        cxt.reset();
        if (hasThen && hasElse) {
          const ifClause = gen.let("ifClause");
          cxt.setParams({ ifClause });
          gen.if(schValid, validateClause("then", ifClause), validateClause("else", ifClause));
        } else if (hasThen) {
          gen.if(schValid, validateClause("then"));
        } else {
          gen.if((0, codegen_1.not)(schValid), validateClause("else"));
        }
        cxt.pass(valid, () => cxt.error(true));
        function validateIf() {
          const schCxt = cxt.subschema({
            keyword: "if",
            compositeRule: true,
            createErrors: false,
            allErrors: false
          }, schValid);
          cxt.mergeEvaluated(schCxt);
        }
        function validateClause(keyword, ifClause) {
          return () => {
            const schCxt = cxt.subschema({ keyword }, schValid);
            gen.assign(valid, schValid);
            cxt.mergeValidEvaluated(schCxt, valid);
            if (ifClause)
              gen.assign(ifClause, (0, codegen_1._)`${keyword}`);
            else
              cxt.setParams({ ifClause: keyword });
          };
        }
      }
    };
    function hasSchema(it, keyword) {
      const schema = it.schema[keyword];
      return schema !== void 0 && !(0, util_1.alwaysValidSchema)(it, schema);
    }
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/thenElse.js
var require_thenElse = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/thenElse.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var util_1 = require_util();
    var def = {
      keyword: ["then", "else"],
      schemaType: ["object", "boolean"],
      code({ keyword, parentSchema, it }) {
        if (parentSchema.if === void 0)
          (0, util_1.checkStrictMode)(it, `"${keyword}" without "if" is ignored`);
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/index.js
var require_applicator = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var additionalItems_1 = require_additionalItems();
    var prefixItems_1 = require_prefixItems();
    var items_1 = require_items();
    var items2020_1 = require_items2020();
    var contains_1 = require_contains();
    var dependencies_1 = require_dependencies();
    var propertyNames_1 = require_propertyNames();
    var additionalProperties_1 = require_additionalProperties();
    var properties_1 = require_properties();
    var patternProperties_1 = require_patternProperties();
    var not_1 = require_not();
    var anyOf_1 = require_anyOf();
    var oneOf_1 = require_oneOf();
    var allOf_1 = require_allOf();
    var if_1 = require_if();
    var thenElse_1 = require_thenElse();
    function getApplicator(draft2020 = false) {
      const applicator = [
        // any
        not_1.default,
        anyOf_1.default,
        oneOf_1.default,
        allOf_1.default,
        if_1.default,
        thenElse_1.default,
        // object
        propertyNames_1.default,
        additionalProperties_1.default,
        dependencies_1.default,
        properties_1.default,
        patternProperties_1.default
      ];
      if (draft2020)
        applicator.push(prefixItems_1.default, items2020_1.default);
      else
        applicator.push(additionalItems_1.default, items_1.default);
      applicator.push(contains_1.default);
      return applicator;
    }
    exports.default = getApplicator;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/format/format.js
var require_format = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/format/format.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var error4 = {
      message: ({ schemaCode }) => (0, codegen_1.str)`must match format "${schemaCode}"`,
      params: ({ schemaCode }) => (0, codegen_1._)`{format: ${schemaCode}}`
    };
    var def = {
      keyword: "format",
      type: ["number", "string"],
      schemaType: "string",
      $data: true,
      error: error4,
      code(cxt, ruleType) {
        const { gen, data, $data, schema, schemaCode, it } = cxt;
        const { opts, errSchemaPath, schemaEnv, self } = it;
        if (!opts.validateFormats)
          return;
        if ($data)
          validate$DataFormat();
        else
          validateFormat();
        function validate$DataFormat() {
          const fmts = gen.scopeValue("formats", {
            ref: self.formats,
            code: opts.code.formats
          });
          const fDef = gen.const("fDef", (0, codegen_1._)`${fmts}[${schemaCode}]`);
          const fType = gen.let("fType");
          const format = gen.let("format");
          gen.if((0, codegen_1._)`typeof ${fDef} == "object" && !(${fDef} instanceof RegExp)`, () => gen.assign(fType, (0, codegen_1._)`${fDef}.type || "string"`).assign(format, (0, codegen_1._)`${fDef}.validate`), () => gen.assign(fType, (0, codegen_1._)`"string"`).assign(format, fDef));
          cxt.fail$data((0, codegen_1.or)(unknownFmt(), invalidFmt()));
          function unknownFmt() {
            if (opts.strictSchema === false)
              return codegen_1.nil;
            return (0, codegen_1._)`${schemaCode} && !${format}`;
          }
          function invalidFmt() {
            const callFormat = schemaEnv.$async ? (0, codegen_1._)`(${fDef}.async ? await ${format}(${data}) : ${format}(${data}))` : (0, codegen_1._)`${format}(${data})`;
            const validData = (0, codegen_1._)`(typeof ${format} == "function" ? ${callFormat} : ${format}.test(${data}))`;
            return (0, codegen_1._)`${format} && ${format} !== true && ${fType} === ${ruleType} && !${validData}`;
          }
        }
        function validateFormat() {
          const formatDef = self.formats[schema];
          if (!formatDef) {
            unknownFormat();
            return;
          }
          if (formatDef === true)
            return;
          const [fmtType, format, fmtRef] = getFormat(formatDef);
          if (fmtType === ruleType)
            cxt.pass(validCondition());
          function unknownFormat() {
            if (opts.strictSchema === false) {
              self.logger.warn(unknownMsg());
              return;
            }
            throw new Error(unknownMsg());
            function unknownMsg() {
              return `unknown format "${schema}" ignored in schema at path "${errSchemaPath}"`;
            }
          }
          function getFormat(fmtDef) {
            const code = fmtDef instanceof RegExp ? (0, codegen_1.regexpCode)(fmtDef) : opts.code.formats ? (0, codegen_1._)`${opts.code.formats}${(0, codegen_1.getProperty)(schema)}` : void 0;
            const fmt = gen.scopeValue("formats", { key: schema, ref: fmtDef, code });
            if (typeof fmtDef == "object" && !(fmtDef instanceof RegExp)) {
              return [fmtDef.type || "string", fmtDef.validate, (0, codegen_1._)`${fmt}.validate`];
            }
            return ["string", fmtDef, fmt];
          }
          function validCondition() {
            if (typeof formatDef == "object" && !(formatDef instanceof RegExp) && formatDef.async) {
              if (!schemaEnv.$async)
                throw new Error("async format in sync schema");
              return (0, codegen_1._)`await ${fmtRef}(${data})`;
            }
            return typeof format == "function" ? (0, codegen_1._)`${fmtRef}(${data})` : (0, codegen_1._)`${fmtRef}.test(${data})`;
          }
        }
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/format/index.js
var require_format2 = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/format/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var format_1 = require_format();
    var format = [format_1.default];
    exports.default = format;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/metadata.js
var require_metadata = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/metadata.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.contentVocabulary = exports.metadataVocabulary = void 0;
    exports.metadataVocabulary = [
      "title",
      "description",
      "default",
      "deprecated",
      "readOnly",
      "writeOnly",
      "examples"
    ];
    exports.contentVocabulary = [
      "contentMediaType",
      "contentEncoding",
      "contentSchema"
    ];
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/draft7.js
var require_draft7 = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/draft7.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var core_1 = require_core2();
    var validation_1 = require_validation();
    var applicator_1 = require_applicator();
    var format_1 = require_format2();
    var metadata_1 = require_metadata();
    var draft7Vocabularies = [
      core_1.default,
      validation_1.default,
      (0, applicator_1.default)(),
      format_1.default,
      metadata_1.metadataVocabulary,
      metadata_1.contentVocabulary
    ];
    exports.default = draft7Vocabularies;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/discriminator/types.js
var require_types = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/discriminator/types.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.DiscrError = void 0;
    var DiscrError;
    (function(DiscrError2) {
      DiscrError2["Tag"] = "tag";
      DiscrError2["Mapping"] = "mapping";
    })(DiscrError || (exports.DiscrError = DiscrError = {}));
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/discriminator/index.js
var require_discriminator = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/discriminator/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var types_1 = require_types();
    var compile_1 = require_compile();
    var ref_error_1 = require_ref_error();
    var util_1 = require_util();
    var error4 = {
      message: ({ params: { discrError, tagName } }) => discrError === types_1.DiscrError.Tag ? `tag "${tagName}" must be string` : `value of tag "${tagName}" must be in oneOf`,
      params: ({ params: { discrError, tag, tagName } }) => (0, codegen_1._)`{error: ${discrError}, tag: ${tagName}, tagValue: ${tag}}`
    };
    var def = {
      keyword: "discriminator",
      type: "object",
      schemaType: "object",
      error: error4,
      code(cxt) {
        const { gen, data, schema, parentSchema, it } = cxt;
        const { oneOf } = parentSchema;
        if (!it.opts.discriminator) {
          throw new Error("discriminator: requires discriminator option");
        }
        const tagName = schema.propertyName;
        if (typeof tagName != "string")
          throw new Error("discriminator: requires propertyName");
        if (schema.mapping)
          throw new Error("discriminator: mapping is not supported");
        if (!oneOf)
          throw new Error("discriminator: requires oneOf keyword");
        const valid = gen.let("valid", false);
        const tag = gen.const("tag", (0, codegen_1._)`${data}${(0, codegen_1.getProperty)(tagName)}`);
        gen.if((0, codegen_1._)`typeof ${tag} == "string"`, () => validateMapping(), () => cxt.error(false, { discrError: types_1.DiscrError.Tag, tag, tagName }));
        cxt.ok(valid);
        function validateMapping() {
          const mapping = getMapping();
          gen.if(false);
          for (const tagValue in mapping) {
            gen.elseIf((0, codegen_1._)`${tag} === ${tagValue}`);
            gen.assign(valid, applyTagSchema(mapping[tagValue]));
          }
          gen.else();
          cxt.error(false, { discrError: types_1.DiscrError.Mapping, tag, tagName });
          gen.endIf();
        }
        function applyTagSchema(schemaProp) {
          const _valid = gen.name("valid");
          const schCxt = cxt.subschema({ keyword: "oneOf", schemaProp }, _valid);
          cxt.mergeEvaluated(schCxt, codegen_1.Name);
          return _valid;
        }
        function getMapping() {
          var _a;
          const oneOfMapping = {};
          const topRequired = hasRequired(parentSchema);
          let tagRequired = true;
          for (let i = 0; i < oneOf.length; i++) {
            let sch = oneOf[i];
            if ((sch === null || sch === void 0 ? void 0 : sch.$ref) && !(0, util_1.schemaHasRulesButRef)(sch, it.self.RULES)) {
              const ref = sch.$ref;
              sch = compile_1.resolveRef.call(it.self, it.schemaEnv.root, it.baseId, ref);
              if (sch instanceof compile_1.SchemaEnv)
                sch = sch.schema;
              if (sch === void 0)
                throw new ref_error_1.default(it.opts.uriResolver, it.baseId, ref);
            }
            const propSch = (_a = sch === null || sch === void 0 ? void 0 : sch.properties) === null || _a === void 0 ? void 0 : _a[tagName];
            if (typeof propSch != "object") {
              throw new Error(`discriminator: oneOf subschemas (or referenced schemas) must have "properties/${tagName}"`);
            }
            tagRequired = tagRequired && (topRequired || hasRequired(sch));
            addMappings(propSch, i);
          }
          if (!tagRequired)
            throw new Error(`discriminator: "${tagName}" must be required`);
          return oneOfMapping;
          function hasRequired({ required }) {
            return Array.isArray(required) && required.includes(tagName);
          }
          function addMappings(sch, i) {
            if (sch.const) {
              addMapping(sch.const, i);
            } else if (sch.enum) {
              for (const tagValue of sch.enum) {
                addMapping(tagValue, i);
              }
            } else {
              throw new Error(`discriminator: "properties/${tagName}" must have "const" or "enum"`);
            }
          }
          function addMapping(tagValue, i) {
            if (typeof tagValue != "string" || tagValue in oneOfMapping) {
              throw new Error(`discriminator: "${tagName}" values must be unique strings`);
            }
            oneOfMapping[tagValue] = i;
          }
        }
      }
    };
    exports.default = def;
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/refs/json-schema-draft-07.json
var require_json_schema_draft_07 = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/refs/json-schema-draft-07.json"(exports, module) {
    module.exports = {
      $schema: "http://json-schema.org/draft-07/schema#",
      $id: "http://json-schema.org/draft-07/schema#",
      title: "Core schema meta-schema",
      definitions: {
        schemaArray: {
          type: "array",
          minItems: 1,
          items: { $ref: "#" }
        },
        nonNegativeInteger: {
          type: "integer",
          minimum: 0
        },
        nonNegativeIntegerDefault0: {
          allOf: [{ $ref: "#/definitions/nonNegativeInteger" }, { default: 0 }]
        },
        simpleTypes: {
          enum: ["array", "boolean", "integer", "null", "number", "object", "string"]
        },
        stringArray: {
          type: "array",
          items: { type: "string" },
          uniqueItems: true,
          default: []
        }
      },
      type: ["object", "boolean"],
      properties: {
        $id: {
          type: "string",
          format: "uri-reference"
        },
        $schema: {
          type: "string",
          format: "uri"
        },
        $ref: {
          type: "string",
          format: "uri-reference"
        },
        $comment: {
          type: "string"
        },
        title: {
          type: "string"
        },
        description: {
          type: "string"
        },
        default: true,
        readOnly: {
          type: "boolean",
          default: false
        },
        examples: {
          type: "array",
          items: true
        },
        multipleOf: {
          type: "number",
          exclusiveMinimum: 0
        },
        maximum: {
          type: "number"
        },
        exclusiveMaximum: {
          type: "number"
        },
        minimum: {
          type: "number"
        },
        exclusiveMinimum: {
          type: "number"
        },
        maxLength: { $ref: "#/definitions/nonNegativeInteger" },
        minLength: { $ref: "#/definitions/nonNegativeIntegerDefault0" },
        pattern: {
          type: "string",
          format: "regex"
        },
        additionalItems: { $ref: "#" },
        items: {
          anyOf: [{ $ref: "#" }, { $ref: "#/definitions/schemaArray" }],
          default: true
        },
        maxItems: { $ref: "#/definitions/nonNegativeInteger" },
        minItems: { $ref: "#/definitions/nonNegativeIntegerDefault0" },
        uniqueItems: {
          type: "boolean",
          default: false
        },
        contains: { $ref: "#" },
        maxProperties: { $ref: "#/definitions/nonNegativeInteger" },
        minProperties: { $ref: "#/definitions/nonNegativeIntegerDefault0" },
        required: { $ref: "#/definitions/stringArray" },
        additionalProperties: { $ref: "#" },
        definitions: {
          type: "object",
          additionalProperties: { $ref: "#" },
          default: {}
        },
        properties: {
          type: "object",
          additionalProperties: { $ref: "#" },
          default: {}
        },
        patternProperties: {
          type: "object",
          additionalProperties: { $ref: "#" },
          propertyNames: { format: "regex" },
          default: {}
        },
        dependencies: {
          type: "object",
          additionalProperties: {
            anyOf: [{ $ref: "#" }, { $ref: "#/definitions/stringArray" }]
          }
        },
        propertyNames: { $ref: "#" },
        const: true,
        enum: {
          type: "array",
          items: true,
          minItems: 1,
          uniqueItems: true
        },
        type: {
          anyOf: [
            { $ref: "#/definitions/simpleTypes" },
            {
              type: "array",
              items: { $ref: "#/definitions/simpleTypes" },
              minItems: 1,
              uniqueItems: true
            }
          ]
        },
        format: { type: "string" },
        contentMediaType: { type: "string" },
        contentEncoding: { type: "string" },
        if: { $ref: "#" },
        then: { $ref: "#" },
        else: { $ref: "#" },
        allOf: { $ref: "#/definitions/schemaArray" },
        anyOf: { $ref: "#/definitions/schemaArray" },
        oneOf: { $ref: "#/definitions/schemaArray" },
        not: { $ref: "#" }
      },
      default: true
    };
  }
});

// ../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/ajv.js
var require_ajv = __commonJS({
  "../../node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/ajv.js"(exports, module) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.MissingRefError = exports.ValidationError = exports.CodeGen = exports.Name = exports.nil = exports.stringify = exports.str = exports._ = exports.KeywordCxt = exports.Ajv = void 0;
    var core_1 = require_core();
    var draft7_1 = require_draft7();
    var discriminator_1 = require_discriminator();
    var draft7MetaSchema = require_json_schema_draft_07();
    var META_SUPPORT_DATA = ["/properties"];
    var META_SCHEMA_ID = "http://json-schema.org/draft-07/schema";
    var Ajv2 = class extends core_1.default {
      _addVocabularies() {
        super._addVocabularies();
        draft7_1.default.forEach((v) => this.addVocabulary(v));
        if (this.opts.discriminator)
          this.addKeyword(discriminator_1.default);
      }
      _addDefaultMetaSchema() {
        super._addDefaultMetaSchema();
        if (!this.opts.meta)
          return;
        const metaSchema = this.opts.$data ? this.$dataMetaSchema(draft7MetaSchema, META_SUPPORT_DATA) : draft7MetaSchema;
        this.addMetaSchema(metaSchema, META_SCHEMA_ID, false);
        this.refs["http://json-schema.org/schema"] = META_SCHEMA_ID;
      }
      defaultMeta() {
        return this.opts.defaultMeta = super.defaultMeta() || (this.getSchema(META_SCHEMA_ID) ? META_SCHEMA_ID : void 0);
      }
    };
    exports.Ajv = Ajv2;
    module.exports = exports = Ajv2;
    module.exports.Ajv = Ajv2;
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = Ajv2;
    var validate_1 = require_validate();
    Object.defineProperty(exports, "KeywordCxt", { enumerable: true, get: function() {
      return validate_1.KeywordCxt;
    } });
    var codegen_1 = require_codegen();
    Object.defineProperty(exports, "_", { enumerable: true, get: function() {
      return codegen_1._;
    } });
    Object.defineProperty(exports, "str", { enumerable: true, get: function() {
      return codegen_1.str;
    } });
    Object.defineProperty(exports, "stringify", { enumerable: true, get: function() {
      return codegen_1.stringify;
    } });
    Object.defineProperty(exports, "nil", { enumerable: true, get: function() {
      return codegen_1.nil;
    } });
    Object.defineProperty(exports, "Name", { enumerable: true, get: function() {
      return codegen_1.Name;
    } });
    Object.defineProperty(exports, "CodeGen", { enumerable: true, get: function() {
      return codegen_1.CodeGen;
    } });
    var validation_error_1 = require_validation_error();
    Object.defineProperty(exports, "ValidationError", { enumerable: true, get: function() {
      return validation_error_1.default;
    } });
    var ref_error_1 = require_ref_error();
    Object.defineProperty(exports, "MissingRefError", { enumerable: true, get: function() {
      return ref_error_1.default;
    } });
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/constants.js
var require_constants = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/constants.js"(exports, module) {
    "use strict";
    var SEMVER_SPEC_VERSION = "2.0.0";
    var MAX_LENGTH = 256;
    var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || /* istanbul ignore next */
    9007199254740991;
    var MAX_SAFE_COMPONENT_LENGTH = 16;
    var MAX_SAFE_BUILD_LENGTH = MAX_LENGTH - 6;
    var RELEASE_TYPES = [
      "major",
      "premajor",
      "minor",
      "preminor",
      "patch",
      "prepatch",
      "prerelease"
    ];
    module.exports = {
      MAX_LENGTH,
      MAX_SAFE_COMPONENT_LENGTH,
      MAX_SAFE_BUILD_LENGTH,
      MAX_SAFE_INTEGER,
      RELEASE_TYPES,
      SEMVER_SPEC_VERSION,
      FLAG_INCLUDE_PRERELEASE: 1,
      FLAG_LOOSE: 2
    };
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/debug.js
var require_debug = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/debug.js"(exports, module) {
    "use strict";
    var debug = typeof process === "object" && process.env && process.env.NODE_DEBUG && /\bsemver\b/i.test(process.env.NODE_DEBUG) ? (...args) => console.error("SEMVER", ...args) : () => {
    };
    module.exports = debug;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/re.js
var require_re = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/re.js"(exports, module) {
    "use strict";
    var {
      MAX_SAFE_COMPONENT_LENGTH,
      MAX_SAFE_BUILD_LENGTH,
      MAX_LENGTH
    } = require_constants();
    var debug = require_debug();
    exports = module.exports = {};
    var re = exports.re = [];
    var safeRe = exports.safeRe = [];
    var src = exports.src = [];
    var safeSrc = exports.safeSrc = [];
    var t = exports.t = {};
    var R = 0;
    var LETTERDASHNUMBER = "[a-zA-Z0-9-]";
    var safeRegexReplacements = [
      ["\\s", 1],
      ["\\d", MAX_LENGTH],
      [LETTERDASHNUMBER, MAX_SAFE_BUILD_LENGTH]
    ];
    var makeSafeRegex = (value) => {
      for (const [token, max] of safeRegexReplacements) {
        value = value.split(`${token}*`).join(`${token}{0,${max}}`).split(`${token}+`).join(`${token}{1,${max}}`);
      }
      return value;
    };
    var createToken = (name, value, isGlobal) => {
      const safe = makeSafeRegex(value);
      const index = R++;
      debug(name, index, value);
      t[name] = index;
      src[index] = value;
      safeSrc[index] = safe;
      re[index] = new RegExp(value, isGlobal ? "g" : void 0);
      safeRe[index] = new RegExp(safe, isGlobal ? "g" : void 0);
    };
    createToken("NUMERICIDENTIFIER", "0|[1-9]\\d*");
    createToken("NUMERICIDENTIFIERLOOSE", "\\d+");
    createToken("NONNUMERICIDENTIFIER", `\\d*[a-zA-Z-]${LETTERDASHNUMBER}*`);
    createToken("MAINVERSION", `(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})`);
    createToken("MAINVERSIONLOOSE", `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})`);
    createToken("PRERELEASEIDENTIFIER", `(?:${src[t.NONNUMERICIDENTIFIER]}|${src[t.NUMERICIDENTIFIER]})`);
    createToken("PRERELEASEIDENTIFIERLOOSE", `(?:${src[t.NONNUMERICIDENTIFIER]}|${src[t.NUMERICIDENTIFIERLOOSE]})`);
    createToken("PRERELEASE", `(?:-(${src[t.PRERELEASEIDENTIFIER]}(?:\\.${src[t.PRERELEASEIDENTIFIER]})*))`);
    createToken("PRERELEASELOOSE", `(?:-?(${src[t.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${src[t.PRERELEASEIDENTIFIERLOOSE]})*))`);
    createToken("BUILDIDENTIFIER", `${LETTERDASHNUMBER}+`);
    createToken("BUILD", `(?:\\+(${src[t.BUILDIDENTIFIER]}(?:\\.${src[t.BUILDIDENTIFIER]})*))`);
    createToken("FULLPLAIN", `v?${src[t.MAINVERSION]}${src[t.PRERELEASE]}?${src[t.BUILD]}?`);
    createToken("FULL", `^${src[t.FULLPLAIN]}$`);
    createToken("LOOSEPLAIN", `[v=\\s]*${src[t.MAINVERSIONLOOSE]}${src[t.PRERELEASELOOSE]}?${src[t.BUILD]}?`);
    createToken("LOOSE", `^${src[t.LOOSEPLAIN]}$`);
    createToken("GTLT", "((?:<|>)?=?)");
    createToken("XRANGEIDENTIFIERLOOSE", `${src[t.NUMERICIDENTIFIERLOOSE]}|x|X|\\*`);
    createToken("XRANGEIDENTIFIER", `${src[t.NUMERICIDENTIFIER]}|x|X|\\*`);
    createToken("XRANGEPLAIN", `[v=\\s]*(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:${src[t.PRERELEASE]})?${src[t.BUILD]}?)?)?`);
    createToken("XRANGEPLAINLOOSE", `[v=\\s]*(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:${src[t.PRERELEASELOOSE]})?${src[t.BUILD]}?)?)?`);
    createToken("XRANGE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAIN]}$`);
    createToken("XRANGELOOSE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("COERCEPLAIN", `${"(^|[^\\d])(\\d{1,"}${MAX_SAFE_COMPONENT_LENGTH}})(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?`);
    createToken("COERCE", `${src[t.COERCEPLAIN]}(?:$|[^\\d])`);
    createToken("COERCEFULL", src[t.COERCEPLAIN] + `(?:${src[t.PRERELEASE]})?(?:${src[t.BUILD]})?(?:$|[^\\d])`);
    createToken("COERCERTL", src[t.COERCE], true);
    createToken("COERCERTLFULL", src[t.COERCEFULL], true);
    createToken("LONETILDE", "(?:~>?)");
    createToken("TILDETRIM", `(\\s*)${src[t.LONETILDE]}\\s+`, true);
    exports.tildeTrimReplace = "$1~";
    createToken("TILDE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAIN]}$`);
    createToken("TILDELOOSE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("LONECARET", "(?:\\^)");
    createToken("CARETTRIM", `(\\s*)${src[t.LONECARET]}\\s+`, true);
    exports.caretTrimReplace = "$1^";
    createToken("CARET", `^${src[t.LONECARET]}${src[t.XRANGEPLAIN]}$`);
    createToken("CARETLOOSE", `^${src[t.LONECARET]}${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("COMPARATORLOOSE", `^${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]})$|^$`);
    createToken("COMPARATOR", `^${src[t.GTLT]}\\s*(${src[t.FULLPLAIN]})$|^$`);
    createToken("COMPARATORTRIM", `(\\s*)${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]}|${src[t.XRANGEPLAIN]})`, true);
    exports.comparatorTrimReplace = "$1$2$3";
    createToken("HYPHENRANGE", `^\\s*(${src[t.XRANGEPLAIN]})\\s+-\\s+(${src[t.XRANGEPLAIN]})\\s*$`);
    createToken("HYPHENRANGELOOSE", `^\\s*(${src[t.XRANGEPLAINLOOSE]})\\s+-\\s+(${src[t.XRANGEPLAINLOOSE]})\\s*$`);
    createToken("STAR", "(<|>)?=?\\s*\\*");
    createToken("GTE0", "^\\s*>=\\s*0\\.0\\.0\\s*$");
    createToken("GTE0PRE", "^\\s*>=\\s*0\\.0\\.0-0\\s*$");
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/parse-options.js
var require_parse_options = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/parse-options.js"(exports, module) {
    "use strict";
    var looseOption = Object.freeze({ loose: true });
    var emptyOpts = Object.freeze({});
    var parseOptions = (options) => {
      if (!options) {
        return emptyOpts;
      }
      if (typeof options !== "object") {
        return looseOption;
      }
      return options;
    };
    module.exports = parseOptions;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/identifiers.js
var require_identifiers = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/identifiers.js"(exports, module) {
    "use strict";
    var numeric = /^[0-9]+$/;
    var compareIdentifiers = (a, b) => {
      if (typeof a === "number" && typeof b === "number") {
        return a === b ? 0 : a < b ? -1 : 1;
      }
      const anum = numeric.test(a);
      const bnum = numeric.test(b);
      if (anum && bnum) {
        a = +a;
        b = +b;
      }
      return a === b ? 0 : anum && !bnum ? -1 : bnum && !anum ? 1 : a < b ? -1 : 1;
    };
    var rcompareIdentifiers = (a, b) => compareIdentifiers(b, a);
    module.exports = {
      compareIdentifiers,
      rcompareIdentifiers
    };
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/semver.js
var require_semver = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/semver.js"(exports, module) {
    "use strict";
    var debug = require_debug();
    var { MAX_LENGTH, MAX_SAFE_INTEGER } = require_constants();
    var { safeRe: re, t } = require_re();
    var parseOptions = require_parse_options();
    var { compareIdentifiers } = require_identifiers();
    var isPrereleaseIdentifier = (prerelease, identifier4) => {
      const identifiers = identifier4.split(".");
      if (identifiers.length > prerelease.length) {
        return false;
      }
      for (let i = 0; i < identifiers.length; i++) {
        if (compareIdentifiers(prerelease[i], identifiers[i]) !== 0) {
          return false;
        }
      }
      return true;
    };
    var SemVer = class _SemVer {
      constructor(version, options) {
        options = parseOptions(options);
        if (version instanceof _SemVer) {
          if (version.loose === !!options.loose && version.includePrerelease === !!options.includePrerelease) {
            return version;
          } else {
            version = version.version;
          }
        } else if (typeof version !== "string") {
          throw new TypeError(`Invalid version. Must be a string. Got type "${typeof version}".`);
        }
        if (version.length > MAX_LENGTH) {
          throw new TypeError(
            `version is longer than ${MAX_LENGTH} characters`
          );
        }
        debug("SemVer", version, options);
        this.options = options;
        this.loose = !!options.loose;
        this.includePrerelease = !!options.includePrerelease;
        const m = version.trim().match(options.loose ? re[t.LOOSE] : re[t.FULL]);
        if (!m) {
          throw new TypeError(`Invalid Version: ${version}`);
        }
        this.raw = version;
        this.major = +m[1];
        this.minor = +m[2];
        this.patch = +m[3];
        if (this.major > MAX_SAFE_INTEGER || this.major < 0) {
          throw new TypeError("Invalid major version");
        }
        if (this.minor > MAX_SAFE_INTEGER || this.minor < 0) {
          throw new TypeError("Invalid minor version");
        }
        if (this.patch > MAX_SAFE_INTEGER || this.patch < 0) {
          throw new TypeError("Invalid patch version");
        }
        if (!m[4]) {
          this.prerelease = [];
        } else {
          this.prerelease = m[4].split(".").map((id2) => {
            if (/^[0-9]+$/.test(id2)) {
              const num = +id2;
              if (num >= 0 && num < MAX_SAFE_INTEGER) {
                return num;
              }
            }
            return id2;
          });
        }
        this.build = m[5] ? m[5].split(".") : [];
        this.format();
      }
      format() {
        this.version = `${this.major}.${this.minor}.${this.patch}`;
        if (this.prerelease.length) {
          this.version += `-${this.prerelease.join(".")}`;
        }
        return this.version;
      }
      toString() {
        return this.version;
      }
      compare(other) {
        debug("SemVer.compare", this.version, this.options, other);
        if (!(other instanceof _SemVer)) {
          if (typeof other === "string" && other === this.version) {
            return 0;
          }
          other = new _SemVer(other, this.options);
        }
        if (other.version === this.version) {
          return 0;
        }
        return this.compareMain(other) || this.comparePre(other);
      }
      compareMain(other) {
        if (!(other instanceof _SemVer)) {
          other = new _SemVer(other, this.options);
        }
        if (this.major < other.major) {
          return -1;
        }
        if (this.major > other.major) {
          return 1;
        }
        if (this.minor < other.minor) {
          return -1;
        }
        if (this.minor > other.minor) {
          return 1;
        }
        if (this.patch < other.patch) {
          return -1;
        }
        if (this.patch > other.patch) {
          return 1;
        }
        return 0;
      }
      comparePre(other) {
        if (!(other instanceof _SemVer)) {
          other = new _SemVer(other, this.options);
        }
        if (this.prerelease.length && !other.prerelease.length) {
          return -1;
        } else if (!this.prerelease.length && other.prerelease.length) {
          return 1;
        } else if (!this.prerelease.length && !other.prerelease.length) {
          return 0;
        }
        let i = 0;
        do {
          const a = this.prerelease[i];
          const b = other.prerelease[i];
          debug("prerelease compare", i, a, b);
          if (a === void 0 && b === void 0) {
            return 0;
          } else if (b === void 0) {
            return 1;
          } else if (a === void 0) {
            return -1;
          } else if (a === b) {
            continue;
          } else {
            return compareIdentifiers(a, b);
          }
        } while (++i);
      }
      compareBuild(other) {
        if (!(other instanceof _SemVer)) {
          other = new _SemVer(other, this.options);
        }
        let i = 0;
        do {
          const a = this.build[i];
          const b = other.build[i];
          debug("build compare", i, a, b);
          if (a === void 0 && b === void 0) {
            return 0;
          } else if (b === void 0) {
            return 1;
          } else if (a === void 0) {
            return -1;
          } else if (a === b) {
            continue;
          } else {
            return compareIdentifiers(a, b);
          }
        } while (++i);
      }
      // preminor will bump the version up to the next minor release, and immediately
      // down to pre-release. premajor and prepatch work the same way.
      inc(release, identifier4, identifierBase) {
        if (release.startsWith("pre")) {
          if (!identifier4 && identifierBase === false) {
            throw new Error("invalid increment argument: identifier is empty");
          }
          if (identifier4) {
            const match = `-${identifier4}`.match(this.options.loose ? re[t.PRERELEASELOOSE] : re[t.PRERELEASE]);
            if (!match || match[1] !== identifier4) {
              throw new Error(`invalid identifier: ${identifier4}`);
            }
          }
        }
        switch (release) {
          case "premajor":
            this.prerelease.length = 0;
            this.patch = 0;
            this.minor = 0;
            this.major++;
            this.inc("pre", identifier4, identifierBase);
            break;
          case "preminor":
            this.prerelease.length = 0;
            this.patch = 0;
            this.minor++;
            this.inc("pre", identifier4, identifierBase);
            break;
          case "prepatch":
            this.prerelease.length = 0;
            this.inc("patch", identifier4, identifierBase);
            this.inc("pre", identifier4, identifierBase);
            break;
          // If the input is a non-prerelease version, this acts the same as
          // prepatch.
          case "prerelease":
            if (this.prerelease.length === 0) {
              this.inc("patch", identifier4, identifierBase);
            }
            this.inc("pre", identifier4, identifierBase);
            break;
          case "release":
            if (this.prerelease.length === 0) {
              throw new Error(`version ${this.raw} is not a prerelease`);
            }
            this.prerelease.length = 0;
            break;
          case "major":
            if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0) {
              this.major++;
            }
            this.minor = 0;
            this.patch = 0;
            this.prerelease = [];
            break;
          case "minor":
            if (this.patch !== 0 || this.prerelease.length === 0) {
              this.minor++;
            }
            this.patch = 0;
            this.prerelease = [];
            break;
          case "patch":
            if (this.prerelease.length === 0) {
              this.patch++;
            }
            this.prerelease = [];
            break;
          // This probably shouldn't be used publicly.
          // 1.0.0 'pre' would become 1.0.0-0 which is the wrong direction.
          case "pre": {
            const base = Number(identifierBase) ? 1 : 0;
            if (this.prerelease.length === 0) {
              this.prerelease = [base];
            } else {
              let i = this.prerelease.length;
              while (--i >= 0) {
                if (typeof this.prerelease[i] === "number") {
                  this.prerelease[i]++;
                  i = -2;
                }
              }
              if (i === -1) {
                if (identifier4 === this.prerelease.join(".") && identifierBase === false) {
                  throw new Error("invalid increment argument: identifier already exists");
                }
                this.prerelease.push(base);
              }
            }
            if (identifier4) {
              let prerelease = [identifier4, base];
              if (identifierBase === false) {
                prerelease = [identifier4];
              }
              if (isPrereleaseIdentifier(this.prerelease, identifier4)) {
                const prereleaseBase = this.prerelease[identifier4.split(".").length];
                if (isNaN(prereleaseBase)) {
                  this.prerelease = prerelease;
                }
              } else {
                this.prerelease = prerelease;
              }
            }
            break;
          }
          default:
            throw new Error(`invalid increment argument: ${release}`);
        }
        this.raw = this.format();
        if (this.build.length) {
          this.raw += `+${this.build.join(".")}`;
        }
        return this;
      }
    };
    module.exports = SemVer;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/parse.js
var require_parse = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/parse.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var parse2 = (version, options, throwErrors = false) => {
      if (version instanceof SemVer) {
        return version;
      }
      try {
        return new SemVer(version, options);
      } catch (er) {
        if (!throwErrors) {
          return null;
        }
        throw er;
      }
    };
    module.exports = parse2;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/valid.js
var require_valid = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/valid.js"(exports, module) {
    "use strict";
    var parse2 = require_parse();
    var valid = (version, options) => {
      const v = parse2(version, options);
      return v ? v.version : null;
    };
    module.exports = valid;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/clean.js
var require_clean = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/clean.js"(exports, module) {
    "use strict";
    var parse2 = require_parse();
    var clean = (version, options) => {
      const s = parse2(version.trim().replace(/^[=v]+/, ""), options);
      return s ? s.version : null;
    };
    module.exports = clean;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/inc.js
var require_inc = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/inc.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var inc = (version, release, options, identifier4, identifierBase) => {
      if (typeof options === "string") {
        identifierBase = identifier4;
        identifier4 = options;
        options = void 0;
      }
      try {
        return new SemVer(
          version instanceof SemVer ? version.version : version,
          options
        ).inc(release, identifier4, identifierBase).version;
      } catch (er) {
        return null;
      }
    };
    module.exports = inc;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/diff.js
var require_diff = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/diff.js"(exports, module) {
    "use strict";
    var parse2 = require_parse();
    var diff = (version1, version2) => {
      const v1 = parse2(version1, null, true);
      const v2 = parse2(version2, null, true);
      const comparison = v1.compare(v2);
      if (comparison === 0) {
        return null;
      }
      const v1Higher = comparison > 0;
      const highVersion = v1Higher ? v1 : v2;
      const lowVersion = v1Higher ? v2 : v1;
      const highHasPre = !!highVersion.prerelease.length;
      const lowHasPre = !!lowVersion.prerelease.length;
      if (lowHasPre && !highHasPre) {
        if (!lowVersion.patch && !lowVersion.minor) {
          return "major";
        }
        if (lowVersion.compareMain(highVersion) === 0) {
          if (lowVersion.minor && !lowVersion.patch) {
            return "minor";
          }
          return "patch";
        }
      }
      const prefix = highHasPre ? "pre" : "";
      if (v1.major !== v2.major) {
        return prefix + "major";
      }
      if (v1.minor !== v2.minor) {
        return prefix + "minor";
      }
      if (v1.patch !== v2.patch) {
        return prefix + "patch";
      }
      return "prerelease";
    };
    module.exports = diff;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/major.js
var require_major = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/major.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var major = (a, loose) => new SemVer(a, loose).major;
    module.exports = major;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/minor.js
var require_minor = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/minor.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var minor = (a, loose) => new SemVer(a, loose).minor;
    module.exports = minor;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/patch.js
var require_patch = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/patch.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var patch = (a, loose) => new SemVer(a, loose).patch;
    module.exports = patch;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/prerelease.js
var require_prerelease = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/prerelease.js"(exports, module) {
    "use strict";
    var parse2 = require_parse();
    var prerelease = (version, options) => {
      const parsed = parse2(version, options);
      return parsed && parsed.prerelease.length ? parsed.prerelease : null;
    };
    module.exports = prerelease;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare.js
var require_compare = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var compare2 = (a, b, loose) => new SemVer(a, loose).compare(new SemVer(b, loose));
    module.exports = compare2;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rcompare.js
var require_rcompare = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rcompare.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var rcompare = (a, b, loose) => compare2(b, a, loose);
    module.exports = rcompare;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-loose.js
var require_compare_loose = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-loose.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var compareLoose = (a, b) => compare2(a, b, true);
    module.exports = compareLoose;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-build.js
var require_compare_build = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-build.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var compareBuild = (a, b, loose) => {
      const versionA = new SemVer(a, loose);
      const versionB = new SemVer(b, loose);
      return versionA.compare(versionB) || versionA.compareBuild(versionB);
    };
    module.exports = compareBuild;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/sort.js
var require_sort = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/sort.js"(exports, module) {
    "use strict";
    var compareBuild = require_compare_build();
    var sort = (list, loose) => list.sort((a, b) => compareBuild(a, b, loose));
    module.exports = sort;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rsort.js
var require_rsort = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rsort.js"(exports, module) {
    "use strict";
    var compareBuild = require_compare_build();
    var rsort = (list, loose) => list.sort((a, b) => compareBuild(b, a, loose));
    module.exports = rsort;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gt.js
var require_gt = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gt.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var gt = (a, b, loose) => compare2(a, b, loose) > 0;
    module.exports = gt;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lt.js
var require_lt = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lt.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var lt = (a, b, loose) => compare2(a, b, loose) < 0;
    module.exports = lt;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/eq.js
var require_eq = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/eq.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var eq = (a, b, loose) => compare2(a, b, loose) === 0;
    module.exports = eq;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/neq.js
var require_neq = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/neq.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var neq = (a, b, loose) => compare2(a, b, loose) !== 0;
    module.exports = neq;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gte.js
var require_gte = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gte.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var gte = (a, b, loose) => compare2(a, b, loose) >= 0;
    module.exports = gte;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lte.js
var require_lte = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lte.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var lte = (a, b, loose) => compare2(a, b, loose) <= 0;
    module.exports = lte;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/cmp.js
var require_cmp = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/cmp.js"(exports, module) {
    "use strict";
    var eq = require_eq();
    var neq = require_neq();
    var gt = require_gt();
    var gte = require_gte();
    var lt = require_lt();
    var lte = require_lte();
    var cmp = (a, op, b, loose) => {
      switch (op) {
        case "===":
          if (typeof a === "object") {
            a = a.version;
          }
          if (typeof b === "object") {
            b = b.version;
          }
          return a === b;
        case "!==":
          if (typeof a === "object") {
            a = a.version;
          }
          if (typeof b === "object") {
            b = b.version;
          }
          return a !== b;
        case "":
        case "=":
        case "==":
          return eq(a, b, loose);
        case "!=":
          return neq(a, b, loose);
        case ">":
          return gt(a, b, loose);
        case ">=":
          return gte(a, b, loose);
        case "<":
          return lt(a, b, loose);
        case "<=":
          return lte(a, b, loose);
        default:
          throw new TypeError(`Invalid operator: ${op}`);
      }
    };
    module.exports = cmp;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/coerce.js
var require_coerce = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/coerce.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var parse2 = require_parse();
    var { safeRe: re, t } = require_re();
    var coerce = (version, options) => {
      if (version instanceof SemVer) {
        return version;
      }
      if (typeof version === "number") {
        version = String(version);
      }
      if (typeof version !== "string") {
        return null;
      }
      options = options || {};
      let match = null;
      if (!options.rtl) {
        match = version.match(options.includePrerelease ? re[t.COERCEFULL] : re[t.COERCE]);
      } else {
        const coerceRtlRegex = options.includePrerelease ? re[t.COERCERTLFULL] : re[t.COERCERTL];
        let next;
        while ((next = coerceRtlRegex.exec(version)) && (!match || match.index + match[0].length !== version.length)) {
          if (!match || next.index + next[0].length !== match.index + match[0].length) {
            match = next;
          }
          coerceRtlRegex.lastIndex = next.index + next[1].length + next[2].length;
        }
        coerceRtlRegex.lastIndex = -1;
      }
      if (match === null) {
        return null;
      }
      const major = match[2];
      const minor = match[3] || "0";
      const patch = match[4] || "0";
      const prerelease = options.includePrerelease && match[5] ? `-${match[5]}` : "";
      const build = options.includePrerelease && match[6] ? `+${match[6]}` : "";
      return parse2(`${major}.${minor}.${patch}${prerelease}${build}`, options);
    };
    module.exports = coerce;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/truncate.js
var require_truncate = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/truncate.js"(exports, module) {
    "use strict";
    var parse2 = require_parse();
    var constants = require_constants();
    var SemVer = require_semver();
    var truncate = (version, truncation, options) => {
      if (!constants.RELEASE_TYPES.includes(truncation)) {
        return null;
      }
      const clonedVersion = cloneInputVersion(version, options);
      return clonedVersion && doTruncation(clonedVersion, truncation);
    };
    var cloneInputVersion = (version, options) => {
      const versionStringToParse = version instanceof SemVer ? version.version : version;
      return parse2(versionStringToParse, options);
    };
    var doTruncation = (version, truncation) => {
      if (isPrerelease(truncation)) {
        return version.version;
      }
      version.prerelease = [];
      switch (truncation) {
        case "major":
          version.minor = 0;
          version.patch = 0;
          break;
        case "minor":
          version.patch = 0;
          break;
      }
      return version.format();
    };
    var isPrerelease = (type) => {
      return type.startsWith("pre");
    };
    module.exports = truncate;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/lrucache.js
var require_lrucache = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/lrucache.js"(exports, module) {
    "use strict";
    var LRUCache = class {
      constructor() {
        this.max = 1e3;
        this.map = /* @__PURE__ */ new Map();
      }
      get(key) {
        const value = this.map.get(key);
        if (value === void 0) {
          return void 0;
        } else {
          this.map.delete(key);
          this.map.set(key, value);
          return value;
        }
      }
      delete(key) {
        return this.map.delete(key);
      }
      set(key, value) {
        const deleted = this.delete(key);
        if (!deleted && value !== void 0) {
          if (this.map.size >= this.max) {
            const firstKey = this.map.keys().next().value;
            this.delete(firstKey);
          }
          this.map.set(key, value);
        }
        return this;
      }
    };
    module.exports = LRUCache;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/range.js
var require_range = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/range.js"(exports, module) {
    "use strict";
    var SPACE_CHARACTERS = /\s+/g;
    var Range = class _Range {
      constructor(range, options) {
        options = parseOptions(options);
        if (range instanceof _Range) {
          if (range.loose === !!options.loose && range.includePrerelease === !!options.includePrerelease) {
            return range;
          } else {
            return new _Range(range.raw, options);
          }
        }
        if (range instanceof Comparator) {
          this.raw = range.value;
          this.set = [[range]];
          this.formatted = void 0;
          return this;
        }
        this.options = options;
        this.loose = !!options.loose;
        this.includePrerelease = !!options.includePrerelease;
        this.raw = range.trim().replace(SPACE_CHARACTERS, " ");
        this.set = this.raw.split("||").map((r) => this.parseRange(r.trim())).filter((c) => c.length);
        if (!this.set.length) {
          throw new TypeError(`Invalid SemVer Range: ${this.raw}`);
        }
        if (this.set.length > 1) {
          const first = this.set[0];
          this.set = this.set.filter((c) => !isNullSet(c[0]));
          if (this.set.length === 0) {
            this.set = [first];
          } else if (this.set.length > 1) {
            for (const c of this.set) {
              if (c.length === 1 && isAny(c[0])) {
                this.set = [c];
                break;
              }
            }
          }
        }
        this.formatted = void 0;
      }
      get range() {
        if (this.formatted === void 0) {
          this.formatted = "";
          for (let i = 0; i < this.set.length; i++) {
            if (i > 0) {
              this.formatted += "||";
            }
            const comps = this.set[i];
            for (let k = 0; k < comps.length; k++) {
              if (k > 0) {
                this.formatted += " ";
              }
              this.formatted += comps[k].toString().trim();
            }
          }
        }
        return this.formatted;
      }
      format() {
        return this.range;
      }
      toString() {
        return this.range;
      }
      parseRange(range) {
        range = range.replace(BUILDSTRIPRE, "");
        const memoOpts = (this.options.includePrerelease && FLAG_INCLUDE_PRERELEASE) | (this.options.loose && FLAG_LOOSE);
        const memoKey = memoOpts + ":" + range;
        const cached = cache.get(memoKey);
        if (cached) {
          return cached;
        }
        const loose = this.options.loose;
        const hr = loose ? re[t.HYPHENRANGELOOSE] : re[t.HYPHENRANGE];
        range = range.replace(hr, hyphenReplace(this.options.includePrerelease));
        debug("hyphen replace", range);
        range = range.replace(re[t.COMPARATORTRIM], comparatorTrimReplace);
        debug("comparator trim", range);
        range = range.replace(re[t.TILDETRIM], tildeTrimReplace);
        debug("tilde trim", range);
        range = range.replace(re[t.CARETTRIM], caretTrimReplace);
        debug("caret trim", range);
        let rangeList = range.split(" ").map((comp) => parseComparator(comp, this.options)).join(" ").split(/\s+/).map((comp) => replaceGTE0(comp, this.options));
        if (loose) {
          rangeList = rangeList.filter((comp) => {
            debug("loose invalid filter", comp, this.options);
            return !!comp.match(re[t.COMPARATORLOOSE]);
          });
        }
        debug("range list", rangeList);
        const rangeMap = /* @__PURE__ */ new Map();
        const comparators = rangeList.map((comp) => new Comparator(comp, this.options));
        for (const comp of comparators) {
          if (isNullSet(comp)) {
            return [comp];
          }
          rangeMap.set(comp.value, comp);
        }
        if (rangeMap.size > 1 && rangeMap.has("")) {
          rangeMap.delete("");
        }
        const result = [...rangeMap.values()];
        cache.set(memoKey, result);
        return result;
      }
      intersects(range, options) {
        if (!(range instanceof _Range)) {
          throw new TypeError("a Range is required");
        }
        return this.set.some((thisComparators) => {
          return isSatisfiable(thisComparators, options) && range.set.some((rangeComparators) => {
            return isSatisfiable(rangeComparators, options) && thisComparators.every((thisComparator) => {
              return rangeComparators.every((rangeComparator) => {
                return thisComparator.intersects(rangeComparator, options);
              });
            });
          });
        });
      }
      // if ANY of the sets match ALL of its comparators, then pass
      test(version) {
        if (!version) {
          return false;
        }
        if (typeof version === "string") {
          try {
            version = new SemVer(version, this.options);
          } catch (er) {
            return false;
          }
        }
        for (let i = 0; i < this.set.length; i++) {
          if (testSet(this.set[i], version, this.options)) {
            return true;
          }
        }
        return false;
      }
    };
    module.exports = Range;
    var LRU = require_lrucache();
    var cache = new LRU();
    var parseOptions = require_parse_options();
    var Comparator = require_comparator();
    var debug = require_debug();
    var SemVer = require_semver();
    var {
      safeRe: re,
      src,
      t,
      comparatorTrimReplace,
      tildeTrimReplace,
      caretTrimReplace
    } = require_re();
    var { FLAG_INCLUDE_PRERELEASE, FLAG_LOOSE } = require_constants();
    var BUILDSTRIPRE = new RegExp(src[t.BUILD], "g");
    var isNullSet = (c) => c.value === "<0.0.0-0";
    var isAny = (c) => c.value === "";
    var isSatisfiable = (comparators, options) => {
      let result = true;
      const remainingComparators = comparators.slice();
      let testComparator = remainingComparators.pop();
      while (result && remainingComparators.length) {
        result = remainingComparators.every((otherComparator) => {
          return testComparator.intersects(otherComparator, options);
        });
        testComparator = remainingComparators.pop();
      }
      return result;
    };
    var parseComparator = (comp, options) => {
      comp = comp.replace(re[t.BUILD], "");
      debug("comp", comp, options);
      comp = replaceCarets(comp, options);
      debug("caret", comp);
      comp = replaceTildes(comp, options);
      debug("tildes", comp);
      comp = replaceXRanges(comp, options);
      debug("xrange", comp);
      comp = replaceStars(comp, options);
      debug("stars", comp);
      return comp;
    };
    var isX = (id2) => !id2 || id2.toLowerCase() === "x" || id2 === "*";
    var invalidXRangeOrder = (M, m, p) => isX(M) && !isX(m) || isX(m) && p && !isX(p);
    var replaceTildes = (comp, options) => {
      return comp.trim().split(/\s+/).map((c) => replaceTilde(c, options)).join(" ");
    };
    var replaceTilde = (comp, options) => {
      const r = options.loose ? re[t.TILDELOOSE] : re[t.TILDE];
      const z = options.includePrerelease ? "-0" : "";
      return comp.replace(r, (_, M, m, p, pr) => {
        debug("tilde", comp, _, M, m, p, pr);
        let ret;
        if (isX(M)) {
          ret = "";
        } else if (isX(m)) {
          ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
        } else if (isX(p)) {
          ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
        } else if (pr) {
          debug("replaceTilde pr", pr);
          ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
        } else {
          ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
        }
        debug("tilde return", ret);
        return ret;
      });
    };
    var replaceCarets = (comp, options) => {
      return comp.trim().split(/\s+/).map((c) => replaceCaret(c, options)).join(" ");
    };
    var replaceCaret = (comp, options) => {
      debug("caret", comp, options);
      const r = options.loose ? re[t.CARETLOOSE] : re[t.CARET];
      const z = options.includePrerelease ? "-0" : "";
      return comp.replace(r, (_, M, m, p, pr) => {
        debug("caret", comp, _, M, m, p, pr);
        let ret;
        if (isX(M)) {
          ret = "";
        } else if (isX(m)) {
          ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
        } else if (isX(p)) {
          if (M === "0") {
            ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
          } else {
            ret = `>=${M}.${m}.0${z} <${+M + 1}.0.0-0`;
          }
        } else if (pr) {
          debug("replaceCaret pr", pr);
          if (M === "0") {
            if (m === "0") {
              ret = `>=${M}.${m}.${p}-${pr} <${M}.${m}.${+p + 1}-0`;
            } else {
              ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
            }
          } else {
            ret = `>=${M}.${m}.${p}-${pr} <${+M + 1}.0.0-0`;
          }
        } else {
          debug("no pr");
          if (M === "0") {
            if (m === "0") {
              ret = `>=${M}.${m}.${p} <${M}.${m}.${+p + 1}-0`;
            } else {
              ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
            }
          } else {
            ret = `>=${M}.${m}.${p} <${+M + 1}.0.0-0`;
          }
        }
        debug("caret return", ret);
        return ret;
      });
    };
    var replaceXRanges = (comp, options) => {
      debug("replaceXRanges", comp, options);
      return comp.split(/\s+/).map((c) => replaceXRange(c, options)).join(" ");
    };
    var replaceXRange = (comp, options) => {
      comp = comp.trim();
      const r = options.loose ? re[t.XRANGELOOSE] : re[t.XRANGE];
      return comp.replace(r, (ret, gtlt, M, m, p, pr) => {
        debug("xRange", comp, ret, gtlt, M, m, p, pr);
        if (invalidXRangeOrder(M, m, p)) {
          return comp;
        }
        const xM = isX(M);
        const xm = xM || isX(m);
        const xp = xm || isX(p);
        const anyX = xp;
        if (gtlt === "=" && anyX) {
          gtlt = "";
        }
        pr = options.includePrerelease ? "-0" : "";
        if (xM) {
          if (gtlt === ">" || gtlt === "<") {
            ret = "<0.0.0-0";
          } else {
            ret = "*";
          }
        } else if (gtlt && anyX) {
          if (xm) {
            m = 0;
          }
          p = 0;
          if (gtlt === ">") {
            gtlt = ">=";
            if (xm) {
              M = +M + 1;
              m = 0;
              p = 0;
            } else {
              m = +m + 1;
              p = 0;
            }
          } else if (gtlt === "<=") {
            gtlt = "<";
            if (xm) {
              M = +M + 1;
            } else {
              m = +m + 1;
            }
          }
          if (gtlt === "<") {
            pr = "-0";
          }
          ret = `${gtlt + M}.${m}.${p}${pr}`;
        } else if (xm) {
          ret = `>=${M}.0.0${pr} <${+M + 1}.0.0-0`;
        } else if (xp) {
          ret = `>=${M}.${m}.0${pr} <${M}.${+m + 1}.0-0`;
        }
        debug("xRange return", ret);
        return ret;
      });
    };
    var replaceStars = (comp, options) => {
      debug("replaceStars", comp, options);
      return comp.trim().replace(re[t.STAR], "");
    };
    var replaceGTE0 = (comp, options) => {
      debug("replaceGTE0", comp, options);
      return comp.trim().replace(re[options.includePrerelease ? t.GTE0PRE : t.GTE0], "");
    };
    var hyphenReplace = (incPr) => ($0, from, fM, fm, fp, fpr, fb, to, tM, tm, tp, tpr) => {
      if (isX(fM)) {
        from = "";
      } else if (isX(fm)) {
        from = `>=${fM}.0.0${incPr ? "-0" : ""}`;
      } else if (isX(fp)) {
        from = `>=${fM}.${fm}.0${incPr ? "-0" : ""}`;
      } else if (fpr) {
        from = `>=${from}`;
      } else {
        from = `>=${from}${incPr ? "-0" : ""}`;
      }
      if (isX(tM)) {
        to = "";
      } else if (isX(tm)) {
        to = `<${+tM + 1}.0.0-0`;
      } else if (isX(tp)) {
        to = `<${tM}.${+tm + 1}.0-0`;
      } else if (tpr) {
        to = `<=${tM}.${tm}.${tp}-${tpr}`;
      } else if (incPr) {
        to = `<${tM}.${tm}.${+tp + 1}-0`;
      } else {
        to = `<=${to}`;
      }
      return `${from} ${to}`.trim();
    };
    var testSet = (set, version, options) => {
      for (let i = 0; i < set.length; i++) {
        if (!set[i].test(version)) {
          return false;
        }
      }
      if (version.prerelease.length && !options.includePrerelease) {
        for (let i = 0; i < set.length; i++) {
          debug(set[i].semver);
          if (set[i].semver === Comparator.ANY) {
            continue;
          }
          if (set[i].semver.prerelease.length > 0) {
            const allowed = set[i].semver;
            if (allowed.major === version.major && allowed.minor === version.minor && allowed.patch === version.patch) {
              return true;
            }
          }
        }
        return false;
      }
      return true;
    };
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/comparator.js
var require_comparator = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/comparator.js"(exports, module) {
    "use strict";
    var ANY = /* @__PURE__ */ Symbol("SemVer ANY");
    var Comparator = class _Comparator {
      static get ANY() {
        return ANY;
      }
      constructor(comp, options) {
        options = parseOptions(options);
        if (comp instanceof _Comparator) {
          if (comp.loose === !!options.loose) {
            return comp;
          } else {
            comp = comp.value;
          }
        }
        comp = comp.trim().split(/\s+/).join(" ");
        debug("comparator", comp, options);
        this.options = options;
        this.loose = !!options.loose;
        this.parse(comp);
        if (this.semver === ANY) {
          this.value = "";
        } else {
          this.value = this.operator + this.semver.version;
        }
        debug("comp", this);
      }
      parse(comp) {
        const r = this.options.loose ? re[t.COMPARATORLOOSE] : re[t.COMPARATOR];
        const m = comp.match(r);
        if (!m) {
          throw new TypeError(`Invalid comparator: ${comp}`);
        }
        this.operator = m[1] !== void 0 ? m[1] : "";
        if (this.operator === "=") {
          this.operator = "";
        }
        if (!m[2]) {
          this.semver = ANY;
        } else {
          this.semver = new SemVer(m[2], this.options.loose);
        }
      }
      toString() {
        return this.value;
      }
      test(version) {
        debug("Comparator.test", version, this.options.loose);
        if (this.semver === ANY || version === ANY) {
          return true;
        }
        if (typeof version === "string") {
          try {
            version = new SemVer(version, this.options);
          } catch (er) {
            return false;
          }
        }
        return cmp(version, this.operator, this.semver, this.options);
      }
      intersects(comp, options) {
        if (!(comp instanceof _Comparator)) {
          throw new TypeError("a Comparator is required");
        }
        if (this.operator === "") {
          if (this.value === "") {
            return true;
          }
          return new Range(comp.value, options).test(this.value);
        } else if (comp.operator === "") {
          if (comp.value === "") {
            return true;
          }
          return new Range(this.value, options).test(comp.semver);
        }
        options = parseOptions(options);
        if (options.includePrerelease && (this.value === "<0.0.0-0" || comp.value === "<0.0.0-0")) {
          return false;
        }
        if (!options.includePrerelease && (this.value.startsWith("<0.0.0") || comp.value.startsWith("<0.0.0"))) {
          return false;
        }
        if (this.operator.startsWith(">") && comp.operator.startsWith(">")) {
          return true;
        }
        if (this.operator.startsWith("<") && comp.operator.startsWith("<")) {
          return true;
        }
        if (this.semver.version === comp.semver.version && this.operator.includes("=") && comp.operator.includes("=")) {
          return true;
        }
        if (cmp(this.semver, "<", comp.semver, options) && this.operator.startsWith(">") && comp.operator.startsWith("<")) {
          return true;
        }
        if (cmp(this.semver, ">", comp.semver, options) && this.operator.startsWith("<") && comp.operator.startsWith(">")) {
          return true;
        }
        return false;
      }
    };
    module.exports = Comparator;
    var parseOptions = require_parse_options();
    var { safeRe: re, t } = require_re();
    var cmp = require_cmp();
    var debug = require_debug();
    var SemVer = require_semver();
    var Range = require_range();
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/satisfies.js
var require_satisfies = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/satisfies.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var satisfies = (version, range, options) => {
      try {
        range = new Range(range, options);
      } catch (er) {
        return false;
      }
      return range.test(version);
    };
    module.exports = satisfies;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/to-comparators.js
var require_to_comparators = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/to-comparators.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var toComparators = (range, options) => new Range(range, options).set.map((comp) => comp.map((c) => c.value).join(" ").trim().split(" "));
    module.exports = toComparators;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/max-satisfying.js
var require_max_satisfying = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/max-satisfying.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var Range = require_range();
    var maxSatisfying = (versions, range, options) => {
      let max = null;
      let maxSV = null;
      let rangeObj = null;
      try {
        rangeObj = new Range(range, options);
      } catch (er) {
        return null;
      }
      versions.forEach((v) => {
        if (rangeObj.test(v)) {
          if (!max || maxSV.compare(v) === -1) {
            max = v;
            maxSV = new SemVer(max, options);
          }
        }
      });
      return max;
    };
    module.exports = maxSatisfying;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-satisfying.js
var require_min_satisfying = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-satisfying.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var Range = require_range();
    var minSatisfying = (versions, range, options) => {
      let min = null;
      let minSV = null;
      let rangeObj = null;
      try {
        rangeObj = new Range(range, options);
      } catch (er) {
        return null;
      }
      versions.forEach((v) => {
        if (rangeObj.test(v)) {
          if (!min || minSV.compare(v) === 1) {
            min = v;
            minSV = new SemVer(min, options);
          }
        }
      });
      return min;
    };
    module.exports = minSatisfying;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-version.js
var require_min_version = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-version.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var Range = require_range();
    var gt = require_gt();
    var minVersion = (range, loose) => {
      range = new Range(range, loose);
      let minver = new SemVer("0.0.0");
      if (range.test(minver)) {
        return minver;
      }
      minver = new SemVer("0.0.0-0");
      if (range.test(minver)) {
        return minver;
      }
      minver = null;
      for (let i = 0; i < range.set.length; ++i) {
        const comparators = range.set[i];
        let setMin = null;
        comparators.forEach((comparator) => {
          const compver = new SemVer(comparator.semver.version);
          switch (comparator.operator) {
            case ">":
              if (compver.prerelease.length === 0) {
                compver.patch++;
              } else {
                compver.prerelease.push(0);
              }
              compver.raw = compver.format();
            /* fallthrough */
            case "":
            case ">=":
              if (!setMin || gt(compver, setMin)) {
                setMin = compver;
              }
              break;
            case "<":
            case "<=":
              break;
            /* istanbul ignore next */
            default:
              throw new Error(`Unexpected operation: ${comparator.operator}`);
          }
        });
        if (setMin && (!minver || gt(minver, setMin))) {
          minver = setMin;
        }
      }
      if (minver && range.test(minver)) {
        return minver;
      }
      return null;
    };
    module.exports = minVersion;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/valid.js
var require_valid2 = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/valid.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var validRange = (range, options) => {
      try {
        return new Range(range, options).range || "*";
      } catch (er) {
        return null;
      }
    };
    module.exports = validRange;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/outside.js
var require_outside = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/outside.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var Comparator = require_comparator();
    var { ANY } = Comparator;
    var Range = require_range();
    var satisfies = require_satisfies();
    var gt = require_gt();
    var lt = require_lt();
    var lte = require_lte();
    var gte = require_gte();
    var outside = (version, range, hilo, options) => {
      version = new SemVer(version, options);
      range = new Range(range, options);
      let gtfn, ltefn, ltfn, comp, ecomp;
      switch (hilo) {
        case ">":
          gtfn = gt;
          ltefn = lte;
          ltfn = lt;
          comp = ">";
          ecomp = ">=";
          break;
        case "<":
          gtfn = lt;
          ltefn = gte;
          ltfn = gt;
          comp = "<";
          ecomp = "<=";
          break;
        default:
          throw new TypeError('Must provide a hilo val of "<" or ">"');
      }
      if (satisfies(version, range, options)) {
        return false;
      }
      for (let i = 0; i < range.set.length; ++i) {
        const comparators = range.set[i];
        let high = null;
        let low = null;
        comparators.forEach((comparator) => {
          if (comparator.semver === ANY) {
            comparator = new Comparator(">=0.0.0");
          }
          high = high || comparator;
          low = low || comparator;
          if (gtfn(comparator.semver, high.semver, options)) {
            high = comparator;
          } else if (ltfn(comparator.semver, low.semver, options)) {
            low = comparator;
          }
        });
        if (high.operator === comp || high.operator === ecomp) {
          return false;
        }
        if ((!low.operator || low.operator === comp) && ltefn(version, low.semver)) {
          return false;
        } else if (low.operator === ecomp && ltfn(version, low.semver)) {
          return false;
        }
      }
      return true;
    };
    module.exports = outside;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/gtr.js
var require_gtr = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/gtr.js"(exports, module) {
    "use strict";
    var outside = require_outside();
    var gtr = (version, range, options) => outside(version, range, ">", options);
    module.exports = gtr;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/ltr.js
var require_ltr = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/ltr.js"(exports, module) {
    "use strict";
    var outside = require_outside();
    var ltr = (version, range, options) => outside(version, range, "<", options);
    module.exports = ltr;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/intersects.js
var require_intersects = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/intersects.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var intersects = (r1, r2, options) => {
      r1 = new Range(r1, options);
      r2 = new Range(r2, options);
      return r1.intersects(r2, options);
    };
    module.exports = intersects;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/simplify.js
var require_simplify = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/simplify.js"(exports, module) {
    "use strict";
    var satisfies = require_satisfies();
    var compare2 = require_compare();
    module.exports = (versions, range, options) => {
      const set = [];
      let first = null;
      let prev = null;
      const v = versions.sort((a, b) => compare2(a, b, options));
      for (const version of v) {
        const included = satisfies(version, range, options);
        if (included) {
          prev = version;
          if (!first) {
            first = version;
          }
        } else {
          if (prev) {
            set.push([first, prev]);
          }
          prev = null;
          first = null;
        }
      }
      if (first) {
        set.push([first, null]);
      }
      const ranges = [];
      for (const [min, max] of set) {
        if (min === max) {
          ranges.push(min);
        } else if (!max && min === v[0]) {
          ranges.push("*");
        } else if (!max) {
          ranges.push(`>=${min}`);
        } else if (min === v[0]) {
          ranges.push(`<=${max}`);
        } else {
          ranges.push(`${min} - ${max}`);
        }
      }
      const simplified = ranges.join(" || ");
      const original = typeof range.raw === "string" ? range.raw : String(range);
      return simplified.length < original.length ? simplified : range;
    };
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/subset.js
var require_subset = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/subset.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var Comparator = require_comparator();
    var { ANY } = Comparator;
    var satisfies = require_satisfies();
    var compare2 = require_compare();
    var subset = (sub, dom, options = {}) => {
      if (sub === dom) {
        return true;
      }
      sub = new Range(sub, options);
      dom = new Range(dom, options);
      let sawNonNull = false;
      OUTER: for (const simpleSub of sub.set) {
        for (const simpleDom of dom.set) {
          const isSub = simpleSubset(simpleSub, simpleDom, options);
          sawNonNull = sawNonNull || isSub !== null;
          if (isSub) {
            continue OUTER;
          }
        }
        if (sawNonNull) {
          return false;
        }
      }
      return true;
    };
    var minimumVersionWithPreRelease = [new Comparator(">=0.0.0-0")];
    var minimumVersion = [new Comparator(">=0.0.0")];
    var simpleSubset = (sub, dom, options) => {
      if (sub === dom) {
        return true;
      }
      if (sub.length === 1 && sub[0].semver === ANY) {
        if (dom.length === 1 && dom[0].semver === ANY) {
          return true;
        } else if (options.includePrerelease) {
          sub = minimumVersionWithPreRelease;
        } else {
          sub = minimumVersion;
        }
      }
      if (dom.length === 1 && dom[0].semver === ANY) {
        if (options.includePrerelease) {
          return true;
        } else {
          dom = minimumVersion;
        }
      }
      const eqSet = /* @__PURE__ */ new Set();
      let gt, lt;
      for (const c of sub) {
        if (c.operator === ">" || c.operator === ">=") {
          gt = higherGT(gt, c, options);
        } else if (c.operator === "<" || c.operator === "<=") {
          lt = lowerLT(lt, c, options);
        } else {
          eqSet.add(c.semver);
        }
      }
      if (eqSet.size > 1) {
        return null;
      }
      let gtltComp;
      if (gt && lt) {
        gtltComp = compare2(gt.semver, lt.semver, options);
        if (gtltComp > 0) {
          return null;
        } else if (gtltComp === 0 && (gt.operator !== ">=" || lt.operator !== "<=")) {
          return null;
        }
      }
      for (const eq of eqSet) {
        if (gt && !satisfies(eq, String(gt), options)) {
          return null;
        }
        if (lt && !satisfies(eq, String(lt), options)) {
          return null;
        }
        for (const c of dom) {
          if (!satisfies(eq, String(c), options)) {
            return false;
          }
        }
        return true;
      }
      let higher, lower;
      let hasDomLT, hasDomGT;
      let needDomLTPre = lt && !options.includePrerelease && lt.semver.prerelease.length ? lt.semver : false;
      let needDomGTPre = gt && !options.includePrerelease && gt.semver.prerelease.length ? gt.semver : false;
      if (needDomLTPre && needDomLTPre.prerelease.length === 1 && lt.operator === "<" && needDomLTPre.prerelease[0] === 0) {
        needDomLTPre = false;
      }
      for (const c of dom) {
        hasDomGT = hasDomGT || c.operator === ">" || c.operator === ">=";
        hasDomLT = hasDomLT || c.operator === "<" || c.operator === "<=";
        if (gt) {
          if (needDomGTPre) {
            if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomGTPre.major && c.semver.minor === needDomGTPre.minor && c.semver.patch === needDomGTPre.patch) {
              needDomGTPre = false;
            }
          }
          if (c.operator === ">" || c.operator === ">=") {
            higher = higherGT(gt, c, options);
            if (higher === c && higher !== gt) {
              return false;
            }
          } else if (gt.operator === ">=" && !c.test(gt.semver)) {
            return false;
          }
        }
        if (lt) {
          if (needDomLTPre) {
            if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomLTPre.major && c.semver.minor === needDomLTPre.minor && c.semver.patch === needDomLTPre.patch) {
              needDomLTPre = false;
            }
          }
          if (c.operator === "<" || c.operator === "<=") {
            lower = lowerLT(lt, c, options);
            if (lower === c && lower !== lt) {
              return false;
            }
          } else if (lt.operator === "<=" && !c.test(lt.semver)) {
            return false;
          }
        }
        if (!c.operator && (lt || gt) && gtltComp !== 0) {
          return false;
        }
      }
      if (gt && hasDomLT && !lt && gtltComp !== 0) {
        return false;
      }
      if (lt && hasDomGT && !gt && gtltComp !== 0) {
        return false;
      }
      if (needDomGTPre || needDomLTPre) {
        return false;
      }
      return true;
    };
    var higherGT = (a, b, options) => {
      if (!a) {
        return b;
      }
      const comp = compare2(a.semver, b.semver, options);
      return comp > 0 ? a : comp < 0 ? b : b.operator === ">" && a.operator === ">=" ? b : a;
    };
    var lowerLT = (a, b, options) => {
      if (!a) {
        return b;
      }
      const comp = compare2(a.semver, b.semver, options);
      return comp < 0 ? a : comp > 0 ? b : b.operator === "<" && a.operator === "<=" ? b : a;
    };
    module.exports = subset;
  }
});

// ../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/index.js
var require_semver2 = __commonJS({
  "../../node_modules/.pnpm/semver@7.8.5/node_modules/semver/index.js"(exports, module) {
    "use strict";
    var internalRe = require_re();
    var constants = require_constants();
    var SemVer = require_semver();
    var identifiers = require_identifiers();
    var parse2 = require_parse();
    var valid = require_valid();
    var clean = require_clean();
    var inc = require_inc();
    var diff = require_diff();
    var major = require_major();
    var minor = require_minor();
    var patch = require_patch();
    var prerelease = require_prerelease();
    var compare2 = require_compare();
    var rcompare = require_rcompare();
    var compareLoose = require_compare_loose();
    var compareBuild = require_compare_build();
    var sort = require_sort();
    var rsort = require_rsort();
    var gt = require_gt();
    var lt = require_lt();
    var eq = require_eq();
    var neq = require_neq();
    var gte = require_gte();
    var lte = require_lte();
    var cmp = require_cmp();
    var coerce = require_coerce();
    var truncate = require_truncate();
    var Comparator = require_comparator();
    var Range = require_range();
    var satisfies = require_satisfies();
    var toComparators = require_to_comparators();
    var maxSatisfying = require_max_satisfying();
    var minSatisfying = require_min_satisfying();
    var minVersion = require_min_version();
    var validRange = require_valid2();
    var outside = require_outside();
    var gtr = require_gtr();
    var ltr = require_ltr();
    var intersects = require_intersects();
    var simplifyRange = require_simplify();
    var subset = require_subset();
    module.exports = {
      parse: parse2,
      valid,
      clean,
      inc,
      diff,
      major,
      minor,
      patch,
      prerelease,
      compare: compare2,
      rcompare,
      compareLoose,
      compareBuild,
      sort,
      rsort,
      gt,
      lt,
      eq,
      neq,
      gte,
      lte,
      cmp,
      coerce,
      truncate,
      Comparator,
      Range,
      satisfies,
      toComparators,
      maxSatisfying,
      minSatisfying,
      minVersion,
      validRange,
      outside,
      gtr,
      ltr,
      intersects,
      simplifyRange,
      subset,
      SemVer,
      re: internalRe.re,
      src: internalRe.src,
      tokens: internalRe.t,
      SEMVER_SPEC_VERSION: constants.SEMVER_SPEC_VERSION,
      RELEASE_TYPES: constants.RELEASE_TYPES,
      compareIdentifiers: identifiers.compareIdentifiers,
      rcompareIdentifiers: identifiers.rcompareIdentifiers
    };
  }
});

// ../../packages/capability-broker/src/index.ts
var import_ajv = __toESM(require_ajv(), 1);
var import_semver = __toESM(require_semver2(), 1);

// ../../packages/capability-protocol/src/types.ts
var TASK_STATUSES = [
  "queued",
  "running",
  "needs-input",
  "needs-approval",
  "completed",
  "failed",
  "cancelled",
  "unknown"
];
var ERROR_MESSAGES = Object.freeze({
  UNAUTHENTICATED: "Authentication is required.",
  FORBIDDEN: "The capability is not authorized.",
  INVALID_INPUT: "The request is invalid.",
  INVALID_OUTPUT: "The capability response is invalid.",
  INCOMPATIBLE: "The protocol or capability is incompatible.",
  CONFLICT: "The request conflicts with an existing request.",
  LIMIT_EXCEEDED: "The request exceeds a platform limit.",
  UNAVAILABLE: "The capability is unavailable.",
  RESULT_UNKNOWN: "The result is unknown. Query the original task.",
  CANCELLED: "Execution was cancelled.",
  INTERNAL_ERROR: "The capability could not complete the request."
});

// ../../packages/capability-protocol/src/schemas.ts
var UUID_PATTERN = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}(?![\\s\\S])";
var CAPABILITY_ID_PATTERN = "^[a-z][a-z0-9-]{0,62}/[a-z][a-z0-9.-]{0,126}(?![\\s\\S])";
var uuid = { type: "string", pattern: UUID_PATTERN, maxLength: 36 };
var capabilityId = { type: "string", pattern: CAPABILITY_ID_PATTERN, maxLength: 191 };
var object = (properties) => ({
  type: "object",
  properties,
  required: Object.keys(properties),
  additionalProperties: false
});
var requestSchema = object({
  protocolVersion: { const: 1 },
  requestId: uuid,
  capabilityId,
  input: {}
});
var taskReferenceSchema = object({
  taskId: {
    type: "string",
    pattern: "^[A-Za-z0-9][A-Za-z0-9._-]{0,127}(?![\\s\\S])",
    maxLength: 128
  },
  requestId: uuid,
  capabilityId,
  status: { enum: TASK_STATUSES }
});
var errorSchema = {
  anyOf: Object.entries(ERROR_MESSAGES).map(
    ([code, message]) => object({ code: { const: code }, message: { const: message } })
  )
};
var responseSchema = {
  anyOf: [
    object({
      protocolVersion: { const: 1 },
      requestId: uuid,
      status: { const: "success" },
      value: {}
    }),
    object({
      protocolVersion: { const: 1 },
      requestId: uuid,
      status: { const: "accepted" },
      task: taskReferenceSchema
    }),
    object({
      protocolVersion: { const: 1 },
      requestId: uuid,
      status: { const: "error" },
      error: errorSchema
    })
  ]
};
function freeze(schema) {
  if (schema.properties) {
    Object.values(schema.properties).forEach(freeze);
    Object.freeze(schema.properties);
  }
  schema.anyOf?.forEach(freeze);
  if (schema.anyOf) Object.freeze(schema.anyOf);
  if (schema.required) Object.freeze(schema.required);
  if (schema.enum) Object.freeze(schema.enum);
  return Object.freeze(schema);
}
[requestSchema, taskReferenceSchema, responseSchema].forEach(freeze);

// ../../packages/capability-protocol/src/index.ts
var PROTOCOL_LIMITS = Object.freeze({
  requestBytes: 64 * 1024,
  responseBytes: 128 * 1024,
  maxDepth: 32,
  maxNodes: 8192
});
function createCapabilityError(code) {
  const safeCode = Object.hasOwn(ERROR_MESSAGES, code) ? code : "INTERNAL_ERROR";
  return { code: safeCode, message: ERROR_MESSAGES[safeCode] };
}
function matches(value, schema) {
  if (Object.hasOwn(schema, "const") && value !== schema.const) return false;
  if (schema.enum && (typeof value !== "string" || !schema.enum.includes(value))) return false;
  if (schema.anyOf && !schema.anyOf.some((branch) => matches(value, branch))) return false;
  if (schema.type === "string") {
    if (typeof value !== "string") return false;
    if (schema.maxLength !== void 0 && value.length > schema.maxLength) return false;
    if (schema.pattern && !new RegExp(schema.pattern).test(value)) return false;
  }
  if (schema.type === "object") {
    if (value === null || typeof value !== "object" || Array.isArray(value)) return false;
    if (schema.required?.some((key) => !Object.hasOwn(value, key))) return false;
    for (const key of Object.keys(value)) {
      if (!Object.hasOwn(schema.properties ?? {}, key)) {
        if (schema.additionalProperties === false) return false;
      } else if (!matches(value[key], schema.properties[key])) return false;
    }
  }
  return true;
}
function jsonSnapshot(value, byteLimit) {
  let nodes = 0;
  let characters = 0;
  const ancestors = /* @__PURE__ */ new Set();
  function visit(item, depth) {
    if (++nodes > PROTOCOL_LIMITS.maxNodes || depth > PROTOCOL_LIMITS.maxDepth) throw new Error();
    if (typeof item === "string") {
      characters += item.length;
      if (characters > byteLimit) throw new Error();
      return;
    }
    if (item === null || typeof item === "boolean") return;
    if (typeof item === "number" && Number.isFinite(item)) return;
    if (typeof item !== "object" || ancestors.has(item)) throw new Error();
    const array = Array.isArray(item);
    const prototype = Object.getPrototypeOf(item);
    if (!array && prototype !== Object.prototype && prototype !== null) throw new Error();
    if (array && prototype !== Array.prototype) throw new Error();
    ancestors.add(item);
    const keys = Reflect.ownKeys(item);
    if (keys.length > PROTOCOL_LIMITS.maxNodes || array && keys.length !== item.length + 1)
      throw new Error();
    for (const key of keys) {
      if (array && key === "length") continue;
      const descriptor = Object.getOwnPropertyDescriptor(item, key);
      if (typeof key !== "string" || !descriptor?.enumerable || !Object.hasOwn(descriptor, "value"))
        throw new Error();
      if (!array) characters += key.length;
      if (characters > byteLimit) throw new Error();
      if (array && !/^(0|[1-9][0-9]*)$/.test(key)) throw new Error();
      visit(descriptor.value, depth + 1);
    }
    ancestors.delete(item);
  }
  visit(value, 0);
  const encoded = JSON.stringify(value);
  if (new TextEncoder().encode(encoded).byteLength > byteLimit) throw new Error();
  return JSON.parse(encoded);
}
function parse(value, schema, bytes, code) {
  try {
    const snapshot5 = jsonSnapshot(value, bytes);
    return matches(snapshot5, schema) ? { ok: true, value: snapshot5 } : { ok: false, error: createCapabilityError(code) };
  } catch {
    return { ok: false, error: createCapabilityError(code) };
  }
}
function parseCapabilityRequest(value) {
  const result = parse(
    value,
    requestSchema,
    PROTOCOL_LIMITS.requestBytes,
    "INVALID_INPUT"
  );
  if (!result.ok && value !== null && typeof value === "object") {
    try {
      const version = Object.getOwnPropertyDescriptor(value, "protocolVersion");
      if (version && Object.hasOwn(version, "value") && typeof version.value === "number" && Number.isInteger(version.value) && version.value !== 1)
        return { ok: false, error: createCapabilityError("INCOMPATIBLE") };
    } catch {
    }
  }
  return result;
}
function parseCapabilityResponse(value, expectedRequest) {
  const result = parse(
    value,
    responseSchema,
    PROTOCOL_LIMITS.responseBytes,
    "INVALID_OUTPUT"
  );
  if (!result.ok) return result;
  const response = result.value;
  if (expectedRequest && response.requestId !== expectedRequest.requestId || response.status === "accepted" && (response.task.requestId !== response.requestId || expectedRequest && response.task.capabilityId !== expectedRequest.capabilityId))
    return { ok: false, error: createCapabilityError("INVALID_OUTPUT") };
  return result;
}

// ../../packages/capability-broker/src/index.ts
var fixtureId = "019c7714-3b77-74d1-9866-e1f484aae2ab";
var entries = ["application", "conversation", "service"];
var environments = ["development", "test", "production"];
var failure = (code) => ({
  ok: false,
  error: createCapabilityError(code)
});
var CapabilityRegistrationError = class extends Error {
  code;
  constructor(code) {
    super(createCapabilityError(code).message);
    this.code = code;
  }
};
function reject(code = "INVALID_INPUT") {
  throw new CapabilityRegistrationError(code);
}
function snapshot(value) {
  const result = parseCapabilityRequest({
    protocolVersion: 1,
    requestId: fixtureId,
    capabilityId: "platform/validation",
    input: value
  });
  if (!result.ok) reject();
  return result.value.input;
}
function freeze2(value) {
  if (value && typeof value === "object") {
    Object.values(value).forEach(freeze2);
    Object.freeze(value);
  }
  return value;
}
function exact(value, keys) {
  return !!value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key));
}
function identifier(value) {
  return typeof value === "string" && parseCapabilityRequest({
    protocolVersion: 1,
    requestId: fixtureId,
    capabilityId: value,
    input: null
  }).ok;
}
function strings(value, check) {
  return Array.isArray(value) && value.length <= 64 && value.every((item) => typeof item === "string" && check(item)) && new Set(value).size === value.length;
}
var permission = (value) => value.length <= 128 && /^[a-z][a-z0-9.-]*(?::[a-z][a-z0-9.-]*)+(?![\s\S])/.test(value);
var scope = (value) => typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,191}(?![\s\S])/.test(value);
function binding(value) {
  return exact(value, ["capabilityId", "packageId", "version", "sha256"]) && identifier(value.capabilityId) && identifier(value.packageId) && value.capabilityId.split("/")[0] === value.packageId.split("/")[0] && typeof value.version === "string" && value.version.length <= 128 && import_semver.default.valid(value.version) === value.version && typeof value.sha256 === "string" && /^[a-f0-9]{64}(?![\s\S])/.test(value.sha256);
}
var bindingKey = (value) => JSON.stringify([value.capabilityId, value.packageId, value.version, value.sha256]);
function canonical(value) {
  if (!value || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}`;
}
function compile(schema) {
  if (typeof schema !== "boolean" && (!schema || typeof schema !== "object" || Array.isArray(schema)))
    reject();
  function check(value) {
    if (!value || typeof value !== "object") return;
    if (!Array.isArray(value)) {
      if (Object.hasOwn(value, "$async") || Object.hasOwn(value, "$id")) reject();
      if (Object.hasOwn(value, "$ref") && (typeof value.$ref !== "string" || !value.$ref.startsWith("#")))
        reject();
    }
    Object.values(value).forEach(check);
  }
  check(schema);
  try {
    return new import_ajv.Ajv({
      strict: true,
      allErrors: false,
      coerceTypes: false,
      useDefaults: false,
      removeAdditional: false
    }).compile(schema);
  } catch {
    return reject();
  }
}
var CapabilityBroker = class {
  #registry = /* @__PURE__ */ new Map();
  #packageDigests = /* @__PURE__ */ new Map();
  #sessions = /* @__PURE__ */ new WeakMap();
  #approvals = /* @__PURE__ */ new WeakMap();
  #diagnostic;
  constructor(options = {}) {
    this.#diagnostic = options.onDiagnostic;
  }
  register(raw, executor) {
    const declaration = snapshot(raw);
    if (!exact(declaration, [
      "binding",
      "interfaceVersion",
      "inputSchema",
      "outputSchema",
      "permissions",
      "allowedEntries",
      "delegates",
      "effects"
    ]) || !binding(declaration.binding) || declaration.interfaceVersion !== 1 || !strings(declaration.permissions, permission) || !strings(declaration.allowedEntries, (value) => entries.includes(value)) || !declaration.allowedEntries.length || !strings(declaration.delegates, identifier) || !exact(declaration.effects, ["billable", "externalWrite"]) || typeof declaration.effects.billable !== "boolean" || typeof declaration.effects.externalWrite !== "boolean" || typeof executor !== "function")
      reject();
    const key = bindingKey(declaration.binding);
    const packageKey = JSON.stringify([declaration.binding.packageId, declaration.binding.version]);
    const digest3 = this.#packageDigests.get(packageKey);
    if (this.#registry.has(key) || digest3 && digest3 !== declaration.binding.sha256)
      reject("CONFLICT");
    const input = compile(declaration.inputSchema);
    const output2 = compile(declaration.outputSchema);
    this.#registry.set(key, { declaration: freeze2(declaration), executor, input, output: output2 });
    this.#packageDigests.set(packageKey, declaration.binding.sha256);
  }
  createSession(raw) {
    const policy2 = snapshot(raw);
    if (!exact(policy2, [
      "tenantId",
      "environment",
      "installationId",
      "consumerAppId",
      "entry",
      "grants",
      "bindings"
    ]) || !scope(policy2.tenantId) || !scope(policy2.installationId) || !scope(policy2.consumerAppId) || !environments.includes(policy2.environment) || !entries.includes(policy2.entry) || !strings(policy2.grants, permission) || !Array.isArray(policy2.bindings) || policy2.bindings.length > 64 || !policy2.bindings.every(binding) || new Set(policy2.bindings.map((item) => item.capabilityId)).size !== policy2.bindings.length)
      reject();
    const session = Object.freeze({});
    this.#sessions.set(session, freeze2(policy2));
    return session;
  }
  revokeSession(session) {
    this.#sessions.delete(session);
  }
  /** Trusted host introspection; never expose the session policy to a guest. */
  getCaller(session) {
    const policy2 = this.#sessions.get(session);
    return policy2 ? { ok: true, value: policy2 } : failure("UNAUTHENTICATED");
  }
  /** Validate without executing. The task host can persist this exact binding first. */
  prepare(session, raw, options = {}) {
    const caller = this.getCaller(session);
    if (!caller.ok) return caller;
    const parsed = parseCapabilityRequest(raw);
    if (!parsed.ok) return parsed;
    const resolved = caller.value.bindings.find(
      (item) => item.capabilityId === parsed.value.capabilityId
    );
    if (!resolved) return failure("FORBIDDEN");
    const target = this.#registry.get(bindingKey(resolved));
    if (!target) return failure("UNAVAILABLE");
    const declaration = target.declaration;
    if (!declaration.allowedEntries.includes(caller.value.entry) || declaration.permissions.some((item) => !caller.value.grants.includes(item)) || !options.inspectEffects && (declaration.effects.billable || declaration.effects.externalWrite))
      return failure("FORBIDDEN");
    if (!target.input(parsed.value.input)) return failure("INVALID_INPUT");
    return {
      ok: true,
      value: freeze2({ request: parsed.value, binding: resolved, effects: declaration.effects })
    };
  }
  /** Called only after a trusted confirmation UI/action; does not authenticate a user itself. */
  issueApproval(session, raw, ttlMs = 3e4) {
    if (!Number.isInteger(ttlMs) || ttlMs < 1 || ttlMs > 3e5) return failure("INVALID_INPUT");
    const prepared = this.prepare(session, raw, { inspectEffects: true });
    if (!prepared.ok) return prepared;
    if (!prepared.value.effects.billable && !prepared.value.effects.externalWrite)
      return failure("CONFLICT");
    const approval = Object.freeze({});
    const expiresAt = Date.now() + ttlMs;
    this.#approvals.set(approval, {
      session,
      request: canonical(prepared.value.request),
      binding: bindingKey(prepared.value.binding),
      expiresAt
    });
    return { ok: true, value: { approval, expiresAt } };
  }
  /** Query results pass the same wire correlation and business output schema. */
  validateResult(session, raw, output2) {
    const prepared = this.prepare(session, raw, { inspectEffects: true });
    if (!prepared.ok) return prepared;
    const parsed = parseCapabilityResponse(output2, prepared.value.request);
    if (parsed.ok && parsed.value.status === "success" && !this.#registry.get(bindingKey(prepared.value.binding)).output(parsed.value.value))
      return failure("INVALID_OUTPUT");
    return parsed;
  }
  invoke(session, request, options = {}) {
    return this.#invoke(session, request, void 0, options);
  }
  async #invoke(session, raw, chain, options = {}) {
    const policy2 = this.#sessions.get(session);
    if (!policy2) return failure("UNAUTHENTICATED");
    if (options.signal?.aborted) return failure("CANCELLED");
    const parsed = parseCapabilityRequest(raw);
    if (!parsed.ok) return parsed;
    const request = freeze2(parsed.value);
    const started = Date.now();
    const resolved = policy2.bindings.find((item) => item.capabilityId === request.capabilityId);
    let result = failure("INTERNAL_ERROR");
    let effectDispatched = false;
    try {
      const target = resolved && this.#registry.get(bindingKey(resolved));
      if (chain && !chain.delegates.includes(request.capabilityId)) result = failure("FORBIDDEN");
      else if (!resolved) result = failure("FORBIDDEN");
      else if (!target) result = failure("UNAVAILABLE");
      else {
        const grants = chain?.grants ?? policy2.grants;
        const ancestors = chain?.ancestors ?? [];
        const declaration = target.declaration;
        if (ancestors.length >= 8) result = failure("LIMIT_EXCEEDED");
        else if (ancestors.includes(bindingKey(resolved))) result = failure("CONFLICT");
        else if (!declaration.allowedEntries.includes(policy2.entry) || declaration.permissions.some((item) => !grants.includes(item)))
          result = failure("FORBIDDEN");
        else if (!target.input(request.input)) result = failure("INVALID_INPUT");
        else if ((declaration.effects.billable || declaration.effects.externalWrite) && (chain || !this.#consumeApproval(options.approval, session, request, resolved)))
          result = failure("FORBIDDEN");
        else {
          const effective = grants.filter((item) => declaration.permissions.includes(item));
          const delegation = [
            ...chain?.delegation ?? [],
            { consumerAppId: policy2.consumerAppId, capabilityId: request.capabilityId }
          ];
          const context = freeze2({
            tenantId: policy2.tenantId,
            environment: policy2.environment,
            installationId: policy2.installationId,
            consumerAppId: policy2.consumerAppId,
            entry: policy2.entry,
            resolvedPackage: {
              packageId: resolved.packageId,
              version: resolved.version,
              sha256: resolved.sha256
            },
            grants: effective,
            delegation
          });
          let active = true;
          let output2;
          try {
            effectDispatched = declaration.effects.billable || declaration.effects.externalWrite;
            output2 = await target.executor(
              request,
              context,
              async (nested, nestedOptions = {}) => {
                if (!active) return failure("FORBIDDEN");
                const signal = options.signal && nestedOptions.signal ? AbortSignal.any([options.signal, nestedOptions.signal]) : options.signal ?? nestedOptions.signal;
                return this.#invoke(
                  session,
                  nested,
                  {
                    rootRequestId: chain?.rootRequestId ?? request.requestId,
                    parentRequestId: request.requestId,
                    grants: effective,
                    ancestors: [...ancestors, bindingKey(resolved)],
                    delegation,
                    delegates: declaration.delegates
                  },
                  { signal }
                );
              },
              options
            );
          } finally {
            active = false;
          }
          result = parseCapabilityResponse(output2, request);
          if (!result.ok && effectDispatched) result = failure("RESULT_UNKNOWN");
          if (result.ok && result.value.status === "success" && !target.output(result.value.value))
            result = failure(effectDispatched ? "RESULT_UNKNOWN" : "INVALID_OUTPUT");
        }
      }
    } catch {
      result = failure(effectDispatched ? "RESULT_UNKNOWN" : "INTERNAL_ERROR");
    }
    const diagnostic = freeze2({
      requestId: request.requestId,
      rootRequestId: chain?.rootRequestId ?? request.requestId,
      ...chain ? { parentRequestId: chain.parentRequestId } : {},
      capabilityId: request.capabilityId,
      tenantId: policy2.tenantId,
      environment: policy2.environment,
      installationId: policy2.installationId,
      consumerAppId: policy2.consumerAppId,
      ...resolved ? { binding: resolved } : {},
      depth: chain?.ancestors.length ?? 0,
      outcome: result.ok ? result.value.status : "error",
      ...!result.ok ? { code: result.error.code } : result.value.status === "error" ? { code: result.value.error.code } : {},
      durationMs: Math.max(0, Date.now() - started)
    });
    try {
      const logged = this.#diagnostic?.(diagnostic);
      if (logged) void logged.catch(() => {
      });
    } catch {
    }
    return result;
  }
  #consumeApproval(approval, session, request, binding2) {
    if (!approval) return false;
    const saved = this.#approvals.get(approval);
    this.#approvals.delete(approval);
    return !!saved && saved.session === session && saved.expiresAt > Date.now() && saved.binding === bindingKey(binding2) && saved.request === canonical(request);
  }
};

// ../../packages/capability-tasks/src/shared-quota.ts
import { randomUUID } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import path from "node:path";
var SharedTaskQuota = class {
  #db;
  #limits;
  identity;
  constructor(file, limits) {
    this.#limits = limits;
    this.#db = new DatabaseSync(path.toNamespacedPath(path.resolve(file)));
    try {
      this.#db.exec("PRAGMA busy_timeout=1000;");
      const tables = this.#db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all();
      if (tables.some((row) => !["quota_config", "reservations"].includes(String(row.name))))
        throw new Error("Not a shared quota database.");
      if (tables.length && tables.length !== 2)
        throw new Error("Incomplete shared quota database.");
      if (tables.length) {
        const prior = this.#db.prepare("SELECT version,limits,identity FROM quota_config WHERE id=1").get();
        if (!prior || prior.version !== 1 || prior.limits !== JSON.stringify(limits) || typeof prior.identity !== "string")
          throw new Error("Shared quota configuration mismatch.");
      }
      this.#db.exec("PRAGMA busy_timeout=1000; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;");
      this.#transaction(() => {
        this.#db.exec(
          "CREATE TABLE IF NOT EXISTS quota_config(id INTEGER PRIMARY KEY CHECK(id=1), version INTEGER NOT NULL, limits TEXT NOT NULL, last_tenant TEXT, identity TEXT NOT NULL);"
        );
        const prior = this.#db.prepare("SELECT version,limits,identity FROM quota_config WHERE id=1").get();
        const settings = JSON.stringify(limits);
        if (prior && (prior.version !== 1 || prior.limits !== settings))
          throw new Error("Shared quota configuration mismatch.");
        if (!prior)
          this.#db.prepare("INSERT INTO quota_config VALUES(1,1,?,NULL,?)").run(settings, randomUUID());
        this.#db.exec(
          "CREATE TABLE IF NOT EXISTS reservations(id TEXT PRIMARY KEY, tenant TEXT NOT NULL, account TEXT NOT NULL, scope TEXT NOT NULL, waiting INTEGER NOT NULL, active INTEGER NOT NULL, pid INTEGER NOT NULL);"
        );
      });
      this.identity = this.#db.prepare("SELECT identity FROM quota_config WHERE id=1").get().identity;
    } catch (error4) {
      this.#db.close();
      throw error4;
    }
  }
  #transaction(operation) {
    this.#db.exec("BEGIN IMMEDIATE");
    try {
      const result = operation();
      this.#db.exec("COMMIT");
      return result;
    } catch (error4) {
      this.#db.exec("ROLLBACK");
      throw error4;
    }
  }
  #rows() {
    return this.#db.prepare("SELECT * FROM reservations ORDER BY rowid").all();
  }
  #fits(identity, rows, pending) {
    const prefix = pending ? "maxPending" : "maxConcurrent";
    return [
      rows.length,
      rows.filter((r) => r.tenant === identity.tenant).length,
      rows.filter((r) => r.account === identity.account).length,
      rows.filter((r) => r.scope === identity.scope).length
    ].every(
      (count, index) => count < this.#limits[prefix + ["", "PerTenant", "PerAccount", "PerScope"][index]]
    );
  }
  #reap() {
    for (const row of this.#rows())
      if (row.active || row.waiting) {
        try {
          process.kill(row.pid, 0);
        } catch (error4) {
          if (error4.code === "ESRCH")
            this.#db.prepare("UPDATE reservations SET active=0,waiting=0 WHERE id=?").run(row.id);
        }
      }
  }
  reserve(id2, identity, waiting, requireExisting = false) {
    return this.#transaction(() => {
      const prior = this.#db.prepare("SELECT * FROM reservations WHERE id=?").get(id2);
      if (prior) {
        if (prior.tenant !== identity.tenant || prior.account !== identity.account || prior.scope !== identity.scope)
          throw new Error("Shared quota identity mismatch.");
        return true;
      }
      if (requireExisting) throw new Error("Missing original shared quota reservation.");
      if (!this.#fits(identity, this.#rows(), true)) return false;
      this.#db.prepare("INSERT INTO reservations VALUES(?,?,?,?,?,0,?)").run(id2, identity.tenant, identity.account, identity.scope, Number(waiting), process.pid);
      return true;
    });
  }
  observe(id2, waiting, terminal2) {
    this.#transaction(() => {
      this.#reap();
      const row = this.#db.prepare("SELECT active,pid FROM reservations WHERE id=?").get(id2);
      if (!row) {
        if (terminal2) return;
        throw new Error("Missing shared quota reservation.");
      }
      if (terminal2 && !row.active) this.#db.prepare("DELETE FROM reservations WHERE id=?").run(id2);
      else
        this.#db.prepare("UPDATE reservations SET waiting=? WHERE id=?").run(Number(waiting && !row.active), id2);
    });
  }
  acquire(id2) {
    return this.#transaction(() => {
      this.#reap();
      const rows = this.#rows(), running = rows.filter((r) => r.active);
      const candidates = rows.filter(
        (r) => r.waiting && !r.active && this.#fits(r, running, false)
      );
      const last = this.#db.prepare("SELECT last_tenant FROM quota_config WHERE id=1").get().last_tenant;
      const next = candidates.find((r) => r.tenant !== last) ?? candidates[0];
      if (next?.id !== id2) return false;
      this.#db.prepare("UPDATE reservations SET active=1,waiting=0,pid=? WHERE id=?").run(process.pid, id2);
      this.#db.prepare("UPDATE quota_config SET last_tenant=? WHERE id=1").run(next.tenant);
      return true;
    });
  }
  finished(id2, terminal2) {
    this.#transaction(() => {
      const row = this.#db.prepare("SELECT pid FROM reservations WHERE id=?").get(id2);
      if (!row) return;
      if (row.pid !== process.pid) throw new Error("Shared execution permit owner mismatch.");
      if (terminal2) this.#db.prepare("DELETE FROM reservations WHERE id=?").run(id2);
      else this.#db.prepare("UPDATE reservations SET active=0,waiting=0 WHERE id=?").run(id2);
    });
  }
  close() {
    this.#db.close();
  }
};

// ../../packages/capability-tasks/src/index.ts
import { createHash, randomUUID as randomUUID2 } from "node:crypto";
import { DatabaseSync as DatabaseSync3 } from "node:sqlite";
import path2 from "node:path";

// ../../packages/capability-tasks/src/views.ts
import { DatabaseSync as DatabaseSync2 } from "node:sqlite";

// ../../packages/capability-tasks/src/index.ts
var DEFAULT_TASK_SCHEDULING_LIMITS = Object.freeze({
  maxConcurrent: 8,
  maxConcurrentPerTenant: 2,
  maxConcurrentPerAccount: 2,
  maxConcurrentPerScope: 1,
  maxPending: 64,
  maxPendingPerTenant: 16,
  maxPendingPerAccount: 16,
  maxPendingPerScope: 8,
  executionMs: 3e4
});
var fail = (code) => ({
  ok: false,
  error: createCapabilityError(code)
});
var success = (value) => ({ ok: true, value });
var clone = (value) => structuredClone(value);
var scopeKey = (policy2) => JSON.stringify([
  policy2.tenantId,
  policy2.environment,
  policy2.installationId,
  policy2.consumerAppId
]);
function canonical2(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonical2).join(",")}]`;
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical2(value[key])}`).join(",")}}`;
}
var digest = (request, binding2) => createHash("sha256").update(
  canonical2({
    request,
    binding: binding2
  })
).digest("hex");
var terminal = (task) => ["completed", "failed", "cancelled"].includes(task.status);
var CapabilityTasks = class {
  broker;
  #db;
  #closed = false;
  #active = /* @__PURE__ */ new Map();
  #query;
  #maxTasks;
  #allowEffects;
  #packageLeases;
  #limits;
  #account;
  #pending = /* @__PURE__ */ new Map();
  #dispatching = /* @__PURE__ */ new Map();
  #lastTenant;
  #drainScheduled = false;
  #shared;
  #ledger;
  #poll;
  constructor(options) {
    this.broker = options.broker;
    this.#ledger = path2.resolve(options.path);
    const limits = { ...DEFAULT_TASK_SCHEDULING_LIMITS, ...options.scheduling };
    if (Object.keys(limits).some((key) => !Object.hasOwn(DEFAULT_TASK_SCHEDULING_LIMITS, key)) || Object.entries(limits).some(
      ([key, value]) => !Number.isSafeInteger(value) || value < 1 || value > (key === "executionMs" ? 3e4 : 1e4)
    ))
      throw new RangeError("Invalid task scheduling limits.");
    this.#limits = Object.freeze(limits);
    this.#account = options.accountKey ?? ((caller) => caller.installationId);
    this.#query = options.query;
    this.#maxTasks = options.maxTasks ?? 1e4;
    this.#allowEffects = options.allowEffects === true;
    this.#packageLeases = options.packageLeases;
    if (!Number.isSafeInteger(this.#maxTasks) || this.#maxTasks < 1 || this.#maxTasks > 1e6)
      throw new RangeError("Invalid task capacity.");
    this.#db = new DatabaseSync3(
      path2.isAbsolute(options.path) ? path2.toNamespacedPath(options.path) : options.path
    );
    try {
      this.#db.exec(
        "PRAGMA busy_timeout=100; PRAGMA locking_mode=EXCLUSIVE; PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; BEGIN EXCLUSIVE;"
      );
      this.#db.exec("CREATE TABLE IF NOT EXISTS metadata(version INTEGER NOT NULL);");
      const version = this.#db.prepare("SELECT version FROM metadata").get();
      if (version && version.version !== 1 && version.version !== 2)
        throw new Error("Unsupported task database version.");
      if (version?.version === 2 && !options.sharedQuotaPath)
        throw new Error("Task shared quota binding mismatch.");
      if (!version) this.#db.exec("INSERT INTO metadata VALUES (1)");
      this.#db.exec(
        "CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY, scope TEXT NOT NULL, request_id TEXT NOT NULL, data TEXT NOT NULL, UNIQUE(scope, request_id));"
      );
      const bindingTable = this.#db.prepare("SELECT name FROM sqlite_master WHERE name='task_quota_binding'").get();
      const priorBinding = bindingTable ? this.#db.prepare("SELECT path,identity FROM task_quota_binding").get() : void 0;
      const quotaPath = options.sharedQuotaPath ? path2.resolve(options.sharedQuotaPath) : void 0;
      if (priorBinding && priorBinding.path !== quotaPath)
        throw new Error("Task shared quota binding mismatch.");
      if (version?.version === 2 && !priorBinding)
        throw new Error("Missing task shared quota binding.");
      if (quotaPath) {
        const records = this.#db.prepare("SELECT data FROM tasks").all().map((row) => JSON.parse(row.data));
        if (records.some((record) => !terminal(record.task) && !record.quota))
          throw new Error("Legacy unresolved tasks require trusted quota mapping.");
        this.#shared = new SharedTaskQuota(quotaPath, limits);
        if (priorBinding && priorBinding.identity !== this.#shared.identity)
          throw new Error("Task shared quota instance mismatch.");
        if (!priorBinding) {
          this.#db.exec(
            "CREATE TABLE task_quota_binding(path TEXT NOT NULL, identity TEXT NOT NULL);"
          );
          this.#db.prepare("INSERT INTO task_quota_binding VALUES(?,?)").run(quotaPath, this.#shared.identity);
        }
        this.#db.exec("UPDATE metadata SET version=2");
        for (const record of records)
          if (!terminal(record.task)) {
            if (!this.#shared.reserve(
              this.#quotaId(record),
              { ...record.quota, scope: record.scope },
              false,
              !!priorBinding
            ))
              throw new Error("Shared quota cannot adopt unresolved task.");
          }
      }
      for (const row of this.#db.prepare("SELECT data FROM tasks").all()) {
        const record = JSON.parse(row.data);
        if (record.task.status === "queued" || record.task.status === "running") {
          this.#unknown(record);
          this.#write(record);
        }
      }
      this.#db.exec("COMMIT");
      for (const row of this.#db.prepare("SELECT data FROM tasks").all()) {
        const record = JSON.parse(row.data);
        this.#shared?.observe(this.#quotaId(record), false, terminal(record.task));
        this.#release(record);
      }
    } catch (error4) {
      this.#db.close();
      this.#shared?.close();
      throw error4;
    }
  }
  #quotaId(record) {
    return JSON.stringify([this.#ledger, record.task.taskId]);
  }
  #write(record) {
    this.#db.prepare("UPDATE tasks SET data=? WHERE id=?").run(JSON.stringify(record), record.task.taskId);
    this.#shared?.observe(
      this.#quotaId(record),
      record.task.status === "queued" && !record.task.upstreamTask,
      terminal(record.task)
    );
    this.#release(record);
  }
  #release(record) {
    if (!terminal(record.task)) return;
    try {
      this.#packageLeases?.release(clone(record.task), record.scope);
    } catch {
    }
  }
  #acquire(record, session) {
    if (!this.#packageLeases) return success(null);
    const caller = this.broker.getCaller(session);
    if (!caller.ok) return caller;
    try {
      return this.#packageLeases.acquire(clone(record.task), caller.value);
    } catch {
      return fail("UNAVAILABLE");
    }
  }
  #unknown(record) {
    record.task.status = "unknown";
    record.task.revision++;
    record.task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    record.task.result = {
      protocolVersion: 1,
      requestId: record.request.requestId,
      status: "error",
      error: createCapabilityError("RESULT_UNKNOWN")
    };
  }
  #owner(session) {
    if (this.#closed) return fail("UNAVAILABLE");
    const caller = this.broker.getCaller(session);
    return caller.ok ? success(scopeKey(caller.value)) : caller;
  }
  #read(session, id2) {
    const owner3 = this.#owner(session);
    if (!owner3.ok) return owner3;
    if (typeof id2 !== "string" || id2.length > 128) return fail("INVALID_INPUT");
    const row = this.#db.prepare("SELECT data FROM tasks WHERE id=? AND scope=?").get(id2, owner3.value);
    return row ? success(JSON.parse(row.data)) : fail("FORBIDDEN");
  }
  get(session, id2) {
    const found = this.#read(session, id2);
    return found.ok ? success(clone(found.value.task)) : found;
  }
  list(session, options = {}) {
    const owner3 = this.#owner(session);
    if (!owner3.ok) return owner3;
    const limit = options.limit ?? 50;
    const offset = options.offset ?? 0;
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100 || !Number.isSafeInteger(offset) || offset < 0)
      return fail("INVALID_INPUT");
    return success(
      this.#db.prepare("SELECT data FROM tasks WHERE scope=? ORDER BY rowid DESC LIMIT ? OFFSET ?").all(owner3.value, limit, offset).map((row) => JSON.parse(row.data).task)
    );
  }
  #quota(caller) {
    const account = this.#account(caller);
    if (typeof account !== "string" || account.length < 1 || account.length > 256)
      throw new Error("Invalid trusted account mapping.");
    return {
      tenant: JSON.stringify([caller.environment, caller.tenantId]),
      account: JSON.stringify([caller.environment, caller.tenantId, account])
    };
  }
  #fits(record, records, pending) {
    const prefix = pending ? "maxPending" : "maxConcurrent";
    const counts = [
      records.length,
      records.filter(
        (item) => (item.quota?.tenant ?? JSON.stringify(JSON.parse(item.scope).slice(0, 2).reverse())) === record.quota?.tenant
      ).length,
      records.filter(
        (item) => item.quota?.account === record.quota?.account || !item.quota && JSON.stringify(JSON.parse(item.scope).slice(0, 2).reverse()) === record.quota?.tenant
      ).length,
      records.filter((item) => item.scope === record.scope).length
    ];
    return counts.every(
      (count, index) => count < this.#limits[prefix + ["", "PerTenant", "PerAccount", "PerScope"][index]]
    );
  }
  #schedule() {
    if (this.#closed || this.#drainScheduled) return;
    this.#drainScheduled = true;
    queueMicrotask(() => {
      this.#drainScheduled = false;
      if (this.#closed) return;
      try {
        while (this.#pending.size) {
          const candidates = [];
          for (const id3 of this.#pending.keys()) {
            const row = this.#db.prepare("SELECT data FROM tasks WHERE id=?").get(id3);
            const record2 = row ? JSON.parse(row.data) : void 0;
            if (!record2 || record2.task.status !== "queued") {
              this.#pending.delete(id3);
              continue;
            }
            if (this.#fits(record2, [...this.#dispatching.values()], false)) candidates.push(record2);
          }
          let record = candidates.find((item) => item.quota?.tenant !== this.#lastTenant) ?? candidates[0];
          if (!record) break;
          if (this.#shared && !this.#shared.acquire(this.#quotaId(record))) {
            const another = candidates.find(
              (item) => item !== record && this.#shared.acquire(this.#quotaId(item))
            );
            if (!another) break;
            record = another;
          }
          const id2 = record.task.taskId;
          const entry = this.#pending.get(id2);
          this.#pending.delete(id2);
          this.#dispatching.set(id2, record);
          this.#lastTenant = record.quota?.tenant;
          void this.#run(entry.session, id2, entry.approval).catch(() => {
          }).finally(() => {
            this.#dispatching.delete(id2);
            if (!this.#closed) {
              try {
                const row = this.#db.prepare("SELECT data FROM tasks WHERE id=?").get(id2);
                const latest = row ? JSON.parse(row.data) : void 0;
                this.#shared?.finished(this.#quotaId(record), !!latest && terminal(latest.task));
              } catch {
              }
            }
            if (this.#closed) {
              try {
                this.#shared?.finished(this.#quotaId(record), false);
              } catch {
              }
              if (!this.#dispatching.size) this.#shared?.close();
            }
            this.#schedule();
          });
        }
      } catch {
      }
      if (this.#shared && this.#pending.size && !this.#poll) {
        this.#poll = setTimeout(() => {
          this.#poll = void 0;
          this.#schedule();
        }, 50);
        this.#poll.unref();
      }
    });
  }
  submit(session, raw) {
    const owner3 = this.#owner(session);
    if (!owner3.ok) return owner3;
    const parsed = parseCapabilityRequest(raw);
    if (!parsed.ok) return parsed;
    const previous = this.#db.prepare("SELECT data FROM tasks WHERE scope=? AND request_id=?").get(owner3.value, parsed.value.requestId);
    if (previous) {
      const record2 = JSON.parse(previous.data);
      const caller2 = this.broker.getCaller(session);
      if (!caller2.ok) return caller2;
      const binding2 = caller2.value.bindings.find(
        (item) => item.capabilityId === parsed.value.capabilityId
      );
      if (canonical2(parsed.value) !== canonical2(record2.request) || binding2 && digest(parsed.value, binding2) !== record2.fingerprint)
        return fail("CONFLICT");
      return success(clone(record2.task));
    }
    const prepared = this.broker.prepare(session, parsed.value, {
      inspectEffects: this.#allowEffects
    });
    if (!prepared.ok) return prepared;
    const count = this.#db.prepare("SELECT COUNT(*) AS total FROM tasks").get();
    if (count.total >= this.#maxTasks) return fail("LIMIT_EXCEEDED");
    const caller = this.broker.getCaller(session);
    if (!caller.ok) return caller;
    let quota;
    try {
      quota = this.#quota(caller.value);
    } catch {
      return fail("UNAVAILABLE");
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const record = {
      quota,
      scope: owner3.value,
      fingerprint: digest(prepared.value.request, prepared.value.binding),
      request: prepared.value.request,
      task: {
        taskId: randomUUID2(),
        requestId: parsed.value.requestId,
        capabilityId: parsed.value.capabilityId,
        binding: prepared.value.binding,
        status: prepared.value.effects.billable || prepared.value.effects.externalWrite ? "needs-approval" : "queued",
        revision: 1,
        createdAt: now,
        updatedAt: now
      }
    };
    const outstanding = this.#db.prepare("SELECT data FROM tasks").all().map((row) => JSON.parse(row.data)).filter((item) => !terminal(item.task));
    if (!this.#fits(record, outstanding, true)) return fail("LIMIT_EXCEEDED");
    if (this.#shared && !this.#shared.reserve(this.#quotaId(record), { ...quota, scope: record.scope }, false))
      return fail("LIMIT_EXCEEDED");
    const pinned = this.#acquire(record, session);
    if (!pinned.ok) return pinned;
    this.#db.prepare("INSERT INTO tasks VALUES (?,?,?,?)").run(record.task.taskId, owner3.value, parsed.value.requestId, JSON.stringify(record));
    this.#shared?.observe(this.#quotaId(record), record.task.status === "queued", false);
    if (record.task.status === "queued") {
      this.#pending.set(record.task.taskId, { session });
      this.#schedule();
    }
    return success(clone(record.task));
  }
  /** Trusted confirmation only. Callers/Guest must not receive this management action. */
  getConfirmation(session, id2) {
    const found = this.#read(session, id2);
    if (!found.ok) return found;
    if (found.value.task.status !== "needs-approval" || found.value.task.upstreamTask)
      return fail("CONFLICT");
    return success(
      clone({
        taskId: id2,
        revision: found.value.task.revision,
        request: found.value.request,
        binding: found.value.task.binding
      })
    );
  }
  approve(session, id2, revision2) {
    const found = this.#read(session, id2);
    if (!found.ok) return found;
    const record = found.value;
    if (!this.#allowEffects || record.task.upstreamTask || record.task.status !== "needs-approval" || record.task.revision !== revision2)
      return fail("CONFLICT");
    const prepared = this.broker.prepare(session, record.request, { inspectEffects: true });
    if (!prepared.ok) return prepared;
    if (digest(record.request, prepared.value.binding) !== record.fingerprint)
      return fail("CONFLICT");
    const issued = this.broker.issueApproval(session, record.request);
    if (!issued.ok) return issued;
    record.task.status = "queued";
    record.task.revision++;
    record.task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    this.#write(record);
    this.#pending.set(id2, { session, approval: issued.value.approval });
    this.#schedule();
    return success(clone(record.task));
  }
  async #run(session, id2, approval) {
    const found = this.#read(session, id2);
    const row = this.#db.prepare("SELECT data FROM tasks WHERE id=?").get(id2);
    if (!row) return;
    const record = JSON.parse(row.data);
    if (record.task.status !== "queued") return;
    if (!found.ok) {
      this.#finish(record, {
        protocolVersion: 1,
        requestId: record.request.requestId,
        status: "error",
        error: found.error
      });
      return;
    }
    const pinned = this.#acquire(record, session);
    if (!pinned.ok) {
      this.#finish(record, {
        protocolVersion: 1,
        requestId: record.request.requestId,
        status: "error",
        error: pinned.error
      });
      return;
    }
    const controller = new AbortController();
    this.#active.set(id2, controller);
    record.task.status = "running";
    record.task.revision++;
    record.task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    const timer = setTimeout(() => {
      if (this.#closed || controller.signal.aborted) return;
      try {
        const row2 = this.#db.prepare("SELECT data FROM tasks WHERE id=?").get(id2);
        if (row2) {
          const latest = JSON.parse(row2.data);
          this.#unknown(latest);
          this.#write(latest);
        }
      } catch {
      } finally {
        controller.abort();
      }
    }, this.#limits.executionMs);
    try {
      this.#write(record);
      const response = await this.broker.invoke(session, record.request, {
        signal: controller.signal,
        approval
      });
      if (this.#closed || controller.signal.aborted) return;
      const current = this.#db.prepare("SELECT data FROM tasks WHERE id=?").get(id2);
      if (!current) return;
      const latest = JSON.parse(current.data);
      this.#finish(
        latest,
        response.ok ? response.value : {
          protocolVersion: 1,
          requestId: record.request.requestId,
          status: "error",
          error: response.error
        }
      );
    } catch {
    } finally {
      clearTimeout(timer);
      this.#active.delete(id2);
    }
  }
  #finish(record, response) {
    record.task.result = response;
    if (response.status === "success") record.task.status = "completed";
    else if (response.status === "accepted") {
      record.task.upstreamTask = response.task;
      record.task.status = ["queued", "running", "needs-input", "needs-approval"].includes(
        response.task.status
      ) ? response.task.status : "unknown";
    } else
      record.task.status = response.error.code === "RESULT_UNKNOWN" ? "unknown" : response.error.code === "CANCELLED" ? "cancelled" : "failed";
    record.task.revision++;
    record.task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    this.#write(record);
  }
  cancel(session, id2) {
    const found = this.#read(session, id2);
    if (!found.ok) return found;
    const record = found.value;
    if (terminal(record.task)) return success(record.task);
    if ((record.task.status === "queued" || record.task.status === "needs-approval") && !record.task.upstreamTask) {
      this.#finish(record, {
        protocolVersion: 1,
        requestId: record.request.requestId,
        status: "error",
        error: createCapabilityError("CANCELLED")
      });
    } else {
      this.#unknown(record);
      this.#write(record);
    }
    this.#pending.delete(id2);
    this.#active.get(id2)?.abort();
    this.#schedule();
    return success(clone(record.task));
  }
  async reconcile(session, id2) {
    const found = this.#read(session, id2);
    if (!found.ok) return found;
    const record = found.value;
    if (terminal(record.task)) return success(record.task);
    if (this.#active.has(id2)) return fail("CONFLICT");
    if (!this.#query) return fail("UNAVAILABLE");
    if (record.task.status === "needs-approval" && !record.task.upstreamTask)
      return fail("CONFLICT");
    const prepared = this.broker.prepare(session, record.request, { inspectEffects: true });
    if (!prepared.ok) return prepared;
    if (digest(record.request, prepared.value.binding) !== record.fingerprint)
      return fail("CONFLICT");
    const caller = this.broker.getCaller(session);
    if (!caller.ok) return caller;
    const controller = new AbortController();
    this.#active.set(id2, controller);
    const timer = setTimeout(() => controller.abort(), 1500);
    try {
      const aborted = new Promise(
        (_, reject2) => controller.signal.addEventListener("abort", () => reject2(new Error("Query stopped.")), {
          once: true
        })
      );
      const output2 = await Promise.race([
        this.#query(clone(record.task), controller.signal, {
          request: clone(record.request),
          caller: caller.value
        }),
        aborted
      ]);
      const current = this.#read(session, id2);
      if (!current.ok) return current;
      if (current.value.task.revision !== record.task.revision) return fail("CONFLICT");
      const checked = this.broker.validateResult(session, record.request, output2);
      if (!checked.ok) return checked;
      this.#finish(record, checked.value);
      return success(clone(record.task));
    } catch {
      return fail("RESULT_UNKNOWN");
    } finally {
      clearTimeout(timer);
      this.#active.delete(id2);
    }
  }
  close() {
    if (this.#closed) return;
    let failure3;
    try {
      for (const row of this.#db.prepare("SELECT data FROM tasks").all()) {
        const record = JSON.parse(row.data);
        if (record.task.status === "queued" || record.task.status === "running") {
          this.#unknown(record);
          try {
            this.#write(record);
          } catch (error4) {
            failure3 ??= error4;
          }
        }
      }
    } catch (error4) {
      failure3 ??= error4;
    } finally {
      this.#closed = true;
      this.#pending.clear();
      if (this.#poll) clearTimeout(this.#poll);
      for (const controller of this.#active.values()) controller.abort();
      this.#db.close();
      if (!this.#dispatching.size) this.#shared?.close();
    }
    if (failure3) throw failure3;
  }
};

// ../../packages/capability-references/src/index.ts
import { randomUUID as randomUUID3 } from "node:crypto";

// ../../packages/capability-references/src/store.ts
import { DatabaseSync as DatabaseSync4 } from "node:sqlite";
import path3 from "node:path";
var referenceUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}(?![\s\S])/;
var identifier2 = /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,191}(?![\s\S])/;
function referenceOwner(scope3) {
  if (!scope3 || !["development", "test", "production"].includes(scope3.environment) || [scope3.tenantId, scope3.installationId, scope3.consumerAppId].some(
    (value) => typeof value !== "string" || !identifier2.test(value)
  ))
    throw Error("Invalid reference scope.");
  return JSON.stringify([
    scope3.tenantId,
    scope3.environment,
    scope3.installationId,
    scope3.consumerAppId
  ]);
}
function validate(payload2) {
  if (!payload2 || typeof payload2 !== "object" || Array.isArray(payload2))
    throw Error("Invalid reference content.");
  const keys = Object.keys(payload2).sort().join(",");
  if (payload2.kind === "text" && keys === "kind,text" && typeof payload2.text === "string" && Buffer.byteLength(payload2.text) <= 32768)
    return;
  if (payload2.kind === "model" && keys === "kind,providerId,providerRevision" && typeof payload2.providerId === "string" && identifier2.test(payload2.providerId) && Number.isSafeInteger(payload2.providerRevision) && payload2.providerRevision > 0)
    return;
  throw Error("Invalid reference content.");
}
var CapabilityReferenceStore = class {
  #database;
  constructor(filename) {
    const database = new DatabaseSync4(
      path3.isAbsolute(filename) ? path3.toNamespacedPath(filename) : filename
    );
    this.#database = database;
    try {
      database.exec("PRAGMA busy_timeout=1000");
      const version = database.prepare("PRAGMA user_version").get().user_version;
      if (version !== 0 && version !== 1) throw Error("Unsupported reference store.");
      const tables = database.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all();
      if (version === 0 && tables.length || version === 1 && (tables.length !== 1 || tables[0].name !== "capability_references"))
        throw Error("Unsupported reference store.");
      database.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;
        BEGIN IMMEDIATE;
        CREATE TABLE IF NOT EXISTS capability_references (
          id TEXT PRIMARY KEY, owner TEXT NOT NULL, payload TEXT NOT NULL CHECK(json_valid(payload)),
          revision INTEGER NOT NULL CHECK(revision IN (1,2)), revoked INTEGER NOT NULL CHECK(revoked IN (0,1)),
          CHECK(revision=revoked+1)
        ) STRICT;
        CREATE TRIGGER IF NOT EXISTS immutable_reference BEFORE UPDATE ON capability_references
          WHEN NEW.id!=OLD.id OR NEW.owner!=OLD.owner OR NEW.payload!=OLD.payload OR OLD.revoked!=0 OR NEW.revoked!=1 OR NEW.revision!=2
          BEGIN SELECT RAISE(ABORT,'immutable reference'); END;
        CREATE TRIGGER IF NOT EXISTS preserve_reference BEFORE DELETE ON capability_references
          BEGIN SELECT RAISE(ABORT,'preserve reference'); END;
        PRAGMA user_version=1;
        COMMIT;`);
    } catch (error4) {
      database.close();
      throw error4;
    }
  }
  has(referenceId) {
    return !!this.#database.prepare("SELECT id FROM capability_references WHERE id=?").get(referenceId);
  }
  issue(scope3, referenceId, payload2) {
    const owner3 = referenceOwner(scope3);
    if (typeof referenceId !== "string" || !referenceUuid.test(referenceId))
      throw Error("Invalid reference identity.");
    validate(payload2);
    const snapshot5 = JSON.stringify(
      payload2.kind === "text" ? { kind: "text", text: payload2.text } : {
        kind: "model",
        providerId: payload2.providerId,
        providerRevision: payload2.providerRevision
      }
    );
    validate(JSON.parse(snapshot5));
    this.#database.exec("BEGIN IMMEDIATE");
    try {
      if (Number(
        this.#database.prepare("SELECT count(*) AS total FROM capability_references").get().total
      ) >= 1024)
        throw Error();
      this.#database.prepare("INSERT INTO capability_references VALUES(?,?,?,1,0)").run(referenceId, owner3, snapshot5);
      this.#database.exec("COMMIT");
      return referenceId;
    } catch {
      this.#database.exec("ROLLBACK");
      throw Error("Invalid or conflicting reference.");
    }
  }
  read(scope3, referenceId) {
    const row = this.#database.prepare("SELECT * FROM capability_references WHERE id=? AND owner=?").get(referenceId, referenceOwner(scope3));
    if (!row) return;
    const payload2 = JSON.parse(String(row.payload));
    validate(payload2);
    if (row.revoked !== 0 && row.revoked !== 1 || row.revision !== Number(row.revoked) + 1)
      throw Error("Invalid reference record.");
    return Object.freeze({
      ...payload2,
      referenceId,
      revision: Number(row.revision),
      revoked: row.revoked === 1
    });
  }
  /** Trusted owner enumeration for explicit provider rebuilding; never exposed to Guest/HTTP. */
  list(scope3) {
    const rows = this.#database.prepare("SELECT id FROM capability_references WHERE owner=? ORDER BY id LIMIT 1025").all(referenceOwner(scope3));
    if (rows.length > 1024) throw Error("Invalid reference store.");
    return Object.freeze(rows.map((row) => this.read(scope3, String(row.id))));
  }
  revoke(scope3, referenceId) {
    if (!this.read(scope3, referenceId)) throw Error("Reference unavailable.");
    this.#database.prepare(
      "UPDATE capability_references SET revoked=1,revision=2 WHERE id=? AND owner=? AND revoked=0"
    ).run(referenceId, referenceOwner(scope3));
  }
  close() {
    this.#database.close();
  }
};

// ../../packages/capability-references/src/index.ts
var CapabilityReferences = class {
  #items = /* @__PURE__ */ new Map();
  #issued = /* @__PURE__ */ new Set();
  #providers = /* @__PURE__ */ new Map();
  #store;
  constructor(options = {}) {
    this.#store = options.store;
  }
  issuePersistentText(scope3, text, referenceId = randomUUID3()) {
    return this.#persist(scope3, referenceId, { kind: "text", text });
  }
  issuePersistentModel(scope3, providerId, providerRevision, referenceId = randomUUID3()) {
    return this.#persist(scope3, referenceId, { kind: "model", providerId, providerRevision });
  }
  #persist(scope3, id2, payload2) {
    if (!this.#store || this.#issued.has(id2)) throw Error("Invalid or conflicting reference.");
    return this.#store.issue(scope3, id2, payload2);
  }
  bindPersistentModelProvider(scope3, referenceId, providerId, providerRevision, provider) {
    const row = this.#store?.read(scope3, referenceId);
    if (!row || row.revoked || row.kind !== "model" || row.providerId !== providerId || row.providerRevision !== providerRevision || this.#providers.has(referenceId) || !provider || typeof provider.infer !== "function" || provider.query !== void 0 && typeof provider.query !== "function")
      throw Error("Model reference unavailable.");
    this.#providers.set(
      referenceId,
      Object.freeze({ infer: provider.infer, query: provider.query })
    );
  }
  revokePersistent(scope3, referenceId) {
    if (!this.#store) throw Error("Reference store unavailable.");
    this.#store.revoke(scope3, referenceId);
    this.#providers.delete(referenceId);
  }
  #find(scope3, id2) {
    const reference = this.#items.get(id2);
    if (reference) return reference;
    const row = this.#store?.read(scope3, id2);
    if (!row || row.revoked) return;
    if (row.kind === "text") return { scope: referenceOwner(scope3), kind: "text", text: row.text };
    const provider = this.#providers.get(id2);
    return provider ? { scope: referenceOwner(scope3), kind: "model", provider } : void 0;
  }
  issueText(scope3, text, referenceId = randomUUID3()) {
    if (typeof text !== "string" || Buffer.byteLength(text) > 32768)
      throw new Error("Invalid reference content.");
    return this.#issue(referenceId, { scope: referenceOwner(scope3), kind: "text", text });
  }
  issueModel(scope3, infer, referenceId = randomUUID3()) {
    return this.issueModelProvider(scope3, { infer }, referenceId);
  }
  issueModelProvider(scope3, provider, referenceId = randomUUID3()) {
    if (!provider || typeof provider.infer !== "function" || provider.query !== void 0 && typeof provider.query !== "function")
      throw new Error("Invalid model provider.");
    return this.#issue(referenceId, {
      scope: referenceOwner(scope3),
      kind: "model",
      provider: Object.freeze({ infer: provider.infer, query: provider.query })
    });
  }
  /** Trusted task-query port. Missing/revoked references and query failures throw safely. */
  async queryModel(scope3, request, signal) {
    try {
      const parsed = parseCapabilityRequest(request);
      if (!parsed.ok || parsed.value.capabilityId !== "platform/infer") throw new Error();
      const input = parsed.value.input;
      if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).length !== 2 || typeof input.referenceId !== "string" || !referenceUuid.test(input.referenceId) || typeof input.prompt !== "string" || [...input.prompt].length > 2e3)
        throw new Error();
      const ref = this.#find(scope3, input.referenceId);
      if (!ref || ref.kind !== "model" || ref.scope !== referenceOwner(scope3) || !ref.provider.query || signal?.aborted)
        throw new Error();
      const snapshot5 = Object.freeze({
        tenantId: scope3.tenantId,
        environment: scope3.environment,
        installationId: scope3.installationId,
        consumerAppId: scope3.consumerAppId
      });
      const value = await ref.provider.query(
        input.prompt,
        snapshot5,
        parsed.value.requestId,
        signal
      );
      const current = this.#find(scope3, input.referenceId);
      if (signal?.aborted || !current || current.kind !== "model" || current.provider !== ref.provider)
        throw new Error();
      return value;
    } catch {
      throw new Error("Original model result unavailable.");
    }
  }
  #issue(id2, value) {
    if (!referenceUuid.test(id2) || this.#issued.has(id2) || this.#store?.has(id2) || this.#issued.size >= 1024)
      throw new Error("Invalid or conflicting reference.");
    this.#issued.add(id2);
    this.#items.set(id2, Object.freeze(value));
    return id2;
  }
  revoke(referenceId) {
    this.#items.delete(referenceId);
  }
  registerCapabilities(broker, bindings) {
    for (const capability of this.createCapabilities(bindings))
      broker.register(capability.declaration, capability.execute);
  }
  /** Trusted registration descriptors; callers still need Broker authorization and approval. */
  createCapabilities(bindings) {
    const capabilities = [];
    const register = (declaration, execute) => capabilities.push({ declaration, execute });
    if (bindings.text.capabilityId !== "platform/read-text" || bindings.model.capabilityId !== "platform/infer")
      throw new Error("Invalid reference capability bindings.");
    const schema = {
      type: "object",
      properties: { referenceId: { type: "string", pattern: referenceUuid.source } },
      required: ["referenceId"],
      additionalProperties: false
    };
    register(
      {
        binding: bindings.text,
        interfaceVersion: 1,
        inputSchema: schema,
        outputSchema: { type: "string" },
        permissions: ["resource:read"],
        allowedEntries: ["application", "conversation", "service"],
        delegates: [],
        effects: { billable: false, externalWrite: false }
      },
      (request, context) => {
        const ref = this.#find(context, request.input.referenceId);
        return !ref || ref.kind !== "text" || ref.scope !== referenceOwner(context) ? this.#failure(request, "FORBIDDEN") : {
          protocolVersion: 1,
          requestId: request.requestId,
          status: "success",
          value: ref.text
        };
      }
    );
    register(
      {
        binding: bindings.model,
        interfaceVersion: 1,
        inputSchema: {
          ...schema,
          properties: { ...schema.properties, prompt: { type: "string", maxLength: 2e3 } },
          required: ["referenceId", "prompt"]
        },
        outputSchema: true,
        permissions: ["model:infer"],
        allowedEntries: ["application", "conversation", "service"],
        delegates: [],
        effects: { billable: true, externalWrite: false }
      },
      async (request, context, _invoke, options) => {
        const input = request.input;
        const ref = this.#find(context, input.referenceId);
        if (!ref || ref.kind !== "model" || ref.scope !== referenceOwner(context))
          return this.#failure(request, "FORBIDDEN");
        if (options?.signal?.aborted) return this.#failure(request, "CANCELLED");
        try {
          const value = await ref.provider.infer(
            input.prompt,
            context,
            request.requestId,
            options?.signal
          );
          const current = this.#find(context, input.referenceId);
          return options?.signal?.aborted || !current || current.kind !== "model" || current.provider !== ref.provider ? this.#failure(request, "RESULT_UNKNOWN") : { protocolVersion: 1, requestId: request.requestId, status: "success", value };
        } catch {
          return this.#failure(request, "RESULT_UNKNOWN");
        }
      }
    );
    return capabilities;
  }
  #failure(request, code) {
    return {
      protocolVersion: 1,
      requestId: request.requestId,
      status: "error",
      error: createCapabilityError(code)
    };
  }
};

// ../../packages/capability-dev-host/src/model-ledger.ts
import { DatabaseSync as DatabaseSync5 } from "node:sqlite";
import path4 from "node:path";
import { createHash as createHash2, randomUUID as randomUUID4 } from "node:crypto";
import { isDeepStrictEqual } from "node:util";
var owner = (scope3) => JSON.stringify([scope3.tenantId, scope3.environment, scope3.installationId, scope3.consumerAppId]);
function snapshot2(value) {
  const parsed = parseCapabilityRequest({
    protocolVersion: 1,
    requestId: value.requestId,
    capabilityId: value.binding.capabilityId,
    input: { referenceId: value.referenceId, prompt: value.prompt }
  });
  if (!parsed.ok || ![
    "platform/infer",
    "platform/generate-image",
    "platform/text-request",
    "platform/image-request"
  ].includes(value.binding.capabilityId) || typeof value.referenceId !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(
    value.referenceId
  ) || typeof value.prompt !== "string" || [...value.prompt].length > (["platform/text-request", "platform/image-request"].includes(value.binding.capabilityId) ? 32768 : 2e3) || typeof value.providerId !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._:/-]{0,191}$/.test(value.providerId) || !Number.isSafeInteger(value.providerRevision) || value.providerRevision <= 0)
    throw Error("Invalid model request.");
  new CapabilityBroker().createSession({
    ...value.scope,
    entry: value.entry,
    bindings: [value.binding],
    grants: []
  });
  return {
    scope: {
      tenantId: value.scope.tenantId,
      environment: value.scope.environment,
      installationId: value.scope.installationId,
      consumerAppId: value.scope.consumerAppId
    },
    entry: value.entry,
    binding: {
      capabilityId: value.binding.capabilityId,
      packageId: value.binding.packageId,
      version: value.binding.version,
      sha256: value.binding.sha256
    },
    referenceId: value.referenceId,
    providerId: value.providerId,
    providerRevision: value.providerRevision,
    requestId: parsed.value.requestId,
    prompt: value.prompt
  };
}
function output(requestId, result) {
  const checked = parseCapabilityResponse({
    protocolVersion: 1,
    requestId,
    status: "success",
    value: result
  });
  if (!checked.ok || checked.value.status !== "success")
    throw Error("Original model result unavailable.");
  return checked.value.value;
}
function frozen(record) {
  const copy = JSON.parse(JSON.stringify(record));
  Object.freeze(copy.scope);
  Object.freeze(copy.binding);
  return Object.freeze(copy);
}
var ModelRequestLedger = class {
  #database;
  constructor(filename) {
    this.#database = new DatabaseSync5(
      path4.isAbsolute(filename) ? path4.toNamespacedPath(filename) : filename
    );
    try {
      this.#database.exec("PRAGMA busy_timeout=1000");
      const version = this.#database.prepare("PRAGMA user_version").get().user_version;
      const tables = this.#database.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all();
      if (version !== 0 && version !== 1 || version === 0 && tables.length || version === 1 && (tables.length !== 1 || tables[0].name !== "model_requests"))
        throw Error("Unsupported model ledger.");
      this.#database.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;
        BEGIN IMMEDIATE;
        CREATE TABLE IF NOT EXISTS model_requests (
          owner TEXT NOT NULL, request_id TEXT NOT NULL, identity TEXT NOT NULL CHECK(json_valid(identity)),
          input_sha256 TEXT NOT NULL, upstream_id TEXT NOT NULL UNIQUE,
          result TEXT CHECK(result IS NULL OR json_valid(result)), PRIMARY KEY(owner,request_id)
        ) STRICT;
        CREATE TRIGGER IF NOT EXISTS immutable_model_request BEFORE UPDATE ON model_requests
          WHEN NEW.owner!=OLD.owner OR NEW.request_id!=OLD.request_id OR NEW.identity!=OLD.identity OR NEW.input_sha256!=OLD.input_sha256 OR NEW.upstream_id!=OLD.upstream_id OR OLD.result IS NOT NULL OR NEW.result IS NULL
          BEGIN SELECT RAISE(ABORT,'immutable model request'); END;
        CREATE TRIGGER IF NOT EXISTS preserve_model_request BEFORE DELETE ON model_requests
          BEGIN SELECT RAISE(ABORT,'preserve model request'); END;
        PRAGMA user_version=1; COMMIT;`);
    } catch (error4) {
      this.#database.close();
      throw error4;
    }
  }
  read(scope3, requestId) {
    new CapabilityBroker().createSession({ ...scope3, entry: "service", bindings: [], grants: [] });
    const row = this.#database.prepare("SELECT * FROM model_requests WHERE owner=? AND request_id=?").get(owner(scope3), requestId);
    if (!row) return;
    const identity = snapshot2(JSON.parse(String(row.identity)));
    const inputSha256 = createHash2("sha256").update(JSON.stringify({ referenceId: identity.referenceId, prompt: identity.prompt })).digest("hex");
    if (owner(identity.scope) !== owner(scope3) || identity.requestId !== requestId || row.input_sha256 !== inputSha256 || typeof row.upstream_id !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(row.upstream_id))
      throw Error("Invalid model ledger record.");
    return frozen({
      ...identity,
      inputSha256,
      upstreamRequestId: row.upstream_id,
      status: row.result === null ? "dispatched" : "completed",
      ...row.result === null ? {} : { result: output(requestId, JSON.parse(String(row.result))) }
    });
  }
  reserve(identity) {
    const value = snapshot2(identity), encoded = JSON.stringify(value);
    this.#database.exec("BEGIN IMMEDIATE");
    try {
      const existing = this.read(value.scope, value.requestId);
      if (existing) {
        if (!isDeepStrictEqual(snapshot2(existing), value))
          throw Error("Conflicting model request.");
        this.#database.exec("COMMIT");
        return { created: false, record: existing };
      }
      if (Number(
        this.#database.prepare("SELECT count(*) AS total FROM model_requests").get().total
      ) >= 4096)
        throw Error("Model ledger full.");
      const inputSha256 = createHash2("sha256").update(JSON.stringify({ referenceId: value.referenceId, prompt: value.prompt })).digest("hex");
      this.#database.prepare("INSERT INTO model_requests VALUES(?,?,?,?,?,NULL)").run(owner(value.scope), value.requestId, encoded, inputSha256, randomUUID4());
      const record = this.read(value.scope, value.requestId);
      this.#database.exec("COMMIT");
      return { created: true, record };
    } catch (error4) {
      this.#database.exec("ROLLBACK");
      throw error4;
    }
  }
  complete(identity, result) {
    const value = snapshot2(identity), normalized = output(value.requestId, result);
    const current = this.read(value.scope, value.requestId);
    if (!current || !isDeepStrictEqual(snapshot2(current), value))
      throw Error("Conflicting model request.");
    if (current.status === "completed") {
      if (!isDeepStrictEqual(current.result, normalized)) throw Error("Conflicting model result.");
      return current.result;
    }
    this.#database.prepare(
      "UPDATE model_requests SET result=? WHERE owner=? AND request_id=? AND result IS NULL"
    ).run(JSON.stringify(normalized), owner(value.scope), value.requestId);
    const completed = this.read(value.scope, value.requestId);
    if (!isDeepStrictEqual(completed.result, normalized)) throw Error("Conflicting model result.");
    return completed.result;
  }
  close() {
    this.#database.close();
  }
};
function createDurableModelProvider(options) {
  const { ledger, references, referenceId } = options;
  const scope3 = Object.freeze({ ...options.scope }), binding2 = Object.freeze({ ...options.binding });
  const infer = options.upstream.infer, query = options.upstream.query;
  const initial = references.read(scope3, referenceId);
  if (!initial || initial.revoked || initial.kind !== "model" || typeof infer !== "function" || typeof query !== "function")
    throw Error("Model reference unavailable.");
  const check = () => {
    const row = references.read(scope3, referenceId);
    if (!row || row.revoked || row.kind !== "model" || row.providerId !== initial.providerId || row.providerRevision !== initial.providerRevision)
      throw Error("Model reference unavailable.");
  };
  const identity = (prompt, requestId, entry) => snapshot2({
    scope: scope3,
    binding: binding2,
    referenceId,
    providerId: initial.providerId,
    providerRevision: initial.providerRevision,
    prompt,
    requestId,
    entry
  });
  const provider = {
    infer: async (prompt, context, requestId, signal) => {
      check();
      if (signal?.aborted || owner(context) !== owner(scope3) || !isDeepStrictEqual(context.resolvedPackage, {
        packageId: binding2.packageId,
        version: binding2.version,
        sha256: binding2.sha256
      }))
        throw Error("Original model result unavailable.");
      const claimed = ledger.reserve(identity(prompt, requestId, context.entry));
      if (!claimed.created) {
        if (claimed.record.status === "completed") return claimed.record.result;
        throw Error("Original dispatch unresolved.");
      }
      const result = await infer(claimed.record, signal);
      check();
      if (signal?.aborted) throw Error("Original model result unavailable.");
      return ledger.complete(claimed.record, result);
    },
    query: async (prompt, caller, requestId, signal) => {
      check();
      if (signal?.aborted || owner(caller) !== owner(scope3))
        throw Error("Original model result unavailable.");
      const record = ledger.read(scope3, requestId);
      if (!record || !isDeepStrictEqual(snapshot2(record), identity(prompt, requestId, record.entry)))
        throw Error("Original model result unavailable.");
      if (record.status === "completed") return record.result;
      const result = await query(record, signal);
      check();
      if (signal?.aborted) throw Error("Original model result unavailable.");
      return ledger.complete(record, result);
    }
  };
  return Object.freeze(provider);
}

// ../../packages/capability-dev-host/src/image-services.ts
function createImageService(options) {
  const binding2 = Object.freeze({ ...options.binding });
  const { store, ledger } = options;
  const upstream = Object.freeze({ ...options.upstream });
  if (binding2.capabilityId !== "platform/generate-image") throw Error("Invalid image binding.");
  const provider = (scope3, request) => {
    const input = request.input;
    const row = store.read(scope3, input.referenceId);
    if (!row || row.revoked || row.kind !== "model" || !/^image\/[a-f0-9]{64}$/.test(row.providerId))
      throw Error("Image reference unavailable.");
    return createDurableModelProvider({
      ledger,
      references: store,
      scope: {
        tenantId: scope3.tenantId,
        environment: scope3.environment,
        installationId: scope3.installationId,
        consumerAppId: scope3.consumerAppId
      },
      referenceId: row.referenceId,
      binding: binding2,
      upstream
    });
  };
  const declaration = imageCapabilityDeclaration(binding2);
  const execute = async (request, context, _invoke, execution) => {
    let originalProvider;
    try {
      originalProvider = provider(context, request);
    } catch {
      return {
        protocolVersion: 1,
        requestId: request.requestId,
        status: "error",
        error: createCapabilityError("FORBIDDEN")
      };
    }
    if (execution?.signal?.aborted)
      return {
        protocolVersion: 1,
        requestId: request.requestId,
        status: "error",
        error: createCapabilityError("CANCELLED")
      };
    try {
      const value = await originalProvider.infer(
        request.input.prompt,
        context,
        request.requestId,
        execution?.signal
      );
      return { protocolVersion: 1, requestId: request.requestId, status: "success", value };
    } catch {
      return {
        protocolVersion: 1,
        requestId: request.requestId,
        status: "error",
        error: createCapabilityError("RESULT_UNKNOWN")
      };
    }
  };
  const query = async (task, signal, { request, caller }) => {
    if (task.capabilityId !== binding2.capabilityId || request.requestId !== task.requestId || JSON.stringify(task.binding) !== JSON.stringify(binding2))
      throw Error("Original image task unavailable.");
    const port = provider(caller, request);
    const value = await port.query(
      request.input.prompt,
      caller,
      request.requestId,
      signal
    );
    return { protocolVersion: 1, requestId: task.requestId, status: "success", value };
  };
  return { declaration, execute, query };
}
function imageCapabilityDeclaration(binding2) {
  if (binding2.capabilityId !== "platform/generate-image") throw Error("Invalid image binding.");
  return {
    binding: binding2,
    interfaceVersion: 1,
    inputSchema: {
      type: "object",
      properties: {
        referenceId: { type: "string", pattern: "^[a-f0-9-]{36}$" },
        prompt: { type: "string", minLength: 1, maxLength: 2e3 }
      },
      required: ["referenceId", "prompt"],
      additionalProperties: false
    },
    outputSchema: {
      type: "object",
      properties: {
        imageTaskId: { type: "string", pattern: "^[a-f0-9-]{36}$" },
        artifactId: { type: "string", maxLength: 64 }
      },
      required: ["imageTaskId", "artifactId"],
      additionalProperties: false
    },
    permissions: ["model:infer", "resource:read"],
    allowedEntries: ["application", "conversation", "service"],
    delegates: [],
    effects: { billable: true, externalWrite: false }
  };
}

// ../../packages/capability-dev-host/src/request-services.ts
var attachment = {
  type: "object",
  additionalProperties: false,
  required: ["id", "description"],
  properties: {
    id: { type: "string", pattern: "^[a-f0-9-]{36}$" },
    description: { type: "string", maxLength: 500 }
  }
};
function requestCapabilityDeclaration(binding2) {
  const image = binding2.capabilityId === "platform/image-request";
  if (!image && binding2.capabilityId !== "platform/text-request")
    throw Error("Invalid request service.");
  const parameters = image ? {
    prompt: { type: "string", minLength: 1, maxLength: 8e3 },
    aspectRatio: { type: "string", minLength: 1, maxLength: 20 },
    resolution: { type: "string", enum: ["1K", "2K", "4K"] },
    attachments: { type: "array", maxItems: 8, items: attachment },
    references: {
      type: "array",
      maxItems: 8,
      items: { type: "string", maxLength: 2048, pattern: "^https://" }
    },
    resourcePackId: { type: "string", maxLength: 128 }
  } : {
    prompt: { type: "string", minLength: 1, maxLength: 8e3 },
    instructions: { type: "string", maxLength: 8e3 },
    maxTokens: { type: "integer", minimum: 128, maximum: 32768 },
    attachments: { type: "array", maxItems: 8, items: attachment },
    responseSchema: { type: "object" }
  };
  return {
    binding: binding2,
    interfaceVersion: 1,
    inputSchema: {
      type: "object",
      additionalProperties: false,
      required: ["referenceId", "parameters"],
      properties: {
        referenceId: { type: "string", pattern: "^[a-f0-9-]{36}$" },
        parameters: {
          type: "object",
          additionalProperties: false,
          required: ["prompt"],
          properties: parameters
        }
      }
    },
    outputSchema: {
      type: "object",
      additionalProperties: false,
      required: ["taskId"],
      properties: { taskId: { type: "string", pattern: "^[a-f0-9-]{36}$" } }
    },
    permissions: ["model:infer", "resource:read"],
    allowedEntries: ["application", "conversation", "service"],
    delegates: [],
    effects: { billable: true, externalWrite: false }
  };
}
function createRequestService(options) {
  const binding2 = Object.freeze({ ...options.binding });
  const { store, ledger } = options;
  const upstream = Object.freeze({ ...options.upstream });
  const declaration = requestCapabilityDeclaration(binding2);
  const image = binding2.capabilityId === "platform/image-request";
  const provider = (scope3, request) => {
    const { referenceId, parameters } = request.input;
    const ref = store.read(scope3, referenceId);
    if (!ref || ref.revoked || ref.kind !== "model" || !(image ? /^image\/[a-f0-9]{64}$/ : /^newapi\/[A-Za-z0-9._:/-]{1,100}$/).test(ref.providerId))
      throw Error("Original provider reference unavailable.");
    return {
      prompt: JSON.stringify(parameters),
      port: createDurableModelProvider({
        ledger,
        references: store,
        binding: binding2,
        referenceId,
        upstream,
        scope: {
          tenantId: scope3.tenantId,
          environment: scope3.environment,
          installationId: scope3.installationId,
          consumerAppId: scope3.consumerAppId
        }
      })
    };
  };
  const execute = async (request, caller, _invoke, execution) => {
    const failure3 = (code) => ({
      protocolVersion: 1,
      requestId: request.requestId,
      status: "error",
      error: createCapabilityError(code)
    });
    let original;
    try {
      original = provider(caller, request);
    } catch {
      return failure3("FORBIDDEN");
    }
    if (execution?.signal?.aborted) return failure3("CANCELLED");
    try {
      const value = await original.port.infer(
        original.prompt,
        caller,
        request.requestId,
        execution?.signal
      );
      return { protocolVersion: 1, requestId: request.requestId, status: "success", value };
    } catch {
      return failure3("RESULT_UNKNOWN");
    }
  };
  const query = async (task, signal, { request, caller }) => {
    if (task.capabilityId !== binding2.capabilityId || request.requestId !== task.requestId || JSON.stringify(task.binding) !== JSON.stringify(binding2))
      throw Error("Original request unavailable.");
    const original = provider(caller, request);
    const value = await original.port.query(original.prompt, caller, request.requestId, signal);
    return { protocolVersion: 1, requestId: task.requestId, status: "success", value };
  };
  return { declaration, execute, query };
}

// ../../packages/capability-runtime/src/index.ts
import { Worker } from "node:worker_threads";
import { createHash as createHash3 } from "node:crypto";
var DEFAULT_RUNTIME_LIMITS = Object.freeze({
  wallMs: 5e3,
  cpuMs: 250,
  memoryBytes: 8 * 1024 * 1024,
  bridgeMs: 1500,
  maxCalls: 16,
  maxPending: 4,
  maxConcurrent: 8
});
var fail2 = (code) => ({
  ok: false,
  error: createCapabilityError(code)
});
var errorResponse = (request, code) => ({
  protocolVersion: 1,
  requestId: request.requestId,
  status: "error",
  error: createCapabilityError(code)
});
var CapabilityRuntime = class {
  #active = 0;
  #limits;
  #event;
  constructor(options = {}) {
    const limits = { ...DEFAULT_RUNTIME_LIMITS, ...options.limits };
    const bounds = {
      wallMs: [1, 3e4],
      cpuMs: [1, 1e3],
      memoryBytes: [1024 * 1024, 16 * 1024 * 1024],
      bridgeMs: [1, 3e4],
      maxCalls: [1, 64],
      maxPending: [1, 16],
      maxConcurrent: [1, 16]
    };
    if (Object.keys(limits).some((key) => !Object.hasOwn(bounds, key)) || Object.entries(bounds).some(([key, [min, max]]) => {
      const value = limits[key];
      return !Number.isInteger(value) || value < min || value > max;
    }))
      throw new RangeError("Invalid runtime limits.");
    this.#limits = Object.freeze(limits);
    this.#event = options.onState;
  }
  get activeRuns() {
    return this.#active;
  }
  /** Compile the exact execution wrapper in QuickJS without evaluating guest code. */
  async checkSource({ source, sourceSha256 }, options = {}) {
    if (typeof source !== "string" || Buffer.byteLength(source) > 64 * 1024 || createHash3("sha256").update(source).digest("hex") !== sourceSha256)
      return fail2("INVALID_INPUT");
    if (options.signal?.aborted) return fail2("CANCELLED");
    if (this.#active >= this.#limits.maxConcurrent) return fail2("LIMIT_EXCEEDED");
    this.#active++;
    try {
      return await new Promise((resolve3) => {
        let worker;
        try {
          worker = new Worker(new URL("./worker.mjs", import.meta.url), {
            workerData: { source, inputJson: "null", limits: this.#limits, checkOnly: true },
            env: {},
            execArgv: [],
            resourceLimits: {
              maxOldGenerationSizeMb: 32,
              maxYoungGenerationSizeMb: 8,
              stackSizeMb: 2
            }
          });
        } catch {
          resolve3(fail2("UNAVAILABLE"));
          return;
        }
        let done = false;
        const finish = (result) => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          options.signal?.removeEventListener("abort", cancel);
          void worker.terminate().then(
            () => resolve3(result),
            () => resolve3(result)
          );
        };
        const cancel = () => finish(fail2("CANCELLED"));
        const timer = setTimeout(() => finish(fail2("LIMIT_EXCEEDED")), this.#limits.wallMs);
        options.signal?.addEventListener("abort", cancel, { once: true });
        if (options.signal?.aborted) cancel();
        worker.on("message", (message) => {
          if (message.type === "result" && message.json === "null")
            finish({ ok: true, value: null });
          else if (message.type === "error")
            finish(fail2(message.code === "LIMIT_EXCEEDED" ? "LIMIT_EXCEEDED" : "INVALID_INPUT"));
          else if (message.type !== "ready") finish(fail2("INVALID_INPUT"));
        });
        worker.on("error", () => finish(fail2("UNAVAILABLE")));
        worker.on("exit", () => {
          if (!done) finish(fail2("UNAVAILABLE"));
        });
      });
    } finally {
      this.#active--;
    }
  }
  createExecutor({
    source,
    sourceSha256
  }) {
    if (typeof source !== "string" || Buffer.byteLength(source) > 64 * 1024 || createHash3("sha256").update(source).digest("hex") !== sourceSha256)
      throw new Error("Invalid capability source or digest.");
    return async (request, _context, invoke, options = {}) => {
      const parsed = parseCapabilityRequest(request);
      if (!parsed.ok) return errorResponse(request, "INVALID_INPUT");
      request = parsed.value;
      if (options.signal?.aborted) return errorResponse(request, "CANCELLED");
      if (this.#active >= this.#limits.maxConcurrent)
        return errorResponse(request, "LIMIT_EXCEEDED");
      this.#active++;
      const emit = (state, code) => {
        try {
          const observed = this.#event?.(
            Object.freeze({
              requestId: request.requestId,
              capabilityId: request.capabilityId,
              state,
              activeRuns: this.#active,
              ...code ? { code } : {}
            })
          );
          if (observed) void observed.catch(() => {
          });
        } catch {
        }
      };
      emit("starting");
      try {
        return await new Promise((resolve3) => {
          let worker;
          try {
            worker = new Worker(new URL("./worker.mjs", import.meta.url), {
              workerData: {
                source,
                inputJson: JSON.stringify(request.input),
                limits: this.#limits
              },
              env: {},
              execArgv: [],
              resourceLimits: {
                maxOldGenerationSizeMb: 32,
                maxYoungGenerationSizeMb: 8,
                stackSizeMb: 2
              }
            });
          } catch {
            emit("failed", "UNAVAILABLE");
            resolve3(errorResponse(request, "UNAVAILABLE"));
            return;
          }
          let done = false;
          let calls = 0;
          const pending = /* @__PURE__ */ new Map();
          const finish = (response) => {
            if (done) return;
            done = true;
            clearTimeout(wall);
            options.signal?.removeEventListener("abort", cancel);
            for (const entry of pending.values()) {
              clearTimeout(entry.timer);
              entry.controller.abort();
            }
            pending.clear();
            const state = response.status === "success" ? "completed" : response.status === "error" && response.error.code === "CANCELLED" ? "cancelled" : "failed";
            emit(state, response.status === "error" ? response.error.code : void 0);
            void worker.terminate().then(
              () => resolve3(response),
              () => resolve3(response)
            );
          };
          const cancel = () => finish(errorResponse(request, "CANCELLED"));
          const wall = setTimeout(
            () => finish(errorResponse(request, pending.size ? "RESULT_UNKNOWN" : "LIMIT_EXCEEDED")),
            this.#limits.wallMs
          );
          options.signal?.addEventListener("abort", cancel, { once: true });
          if (options.signal?.aborted) cancel();
          worker.on("message", (message) => {
            if (done) return;
            if (message.type === "ready") {
              emit("running");
              return;
            }
            if (message.type === "error") {
              const code = ["LIMIT_EXCEEDED", "INVALID_OUTPUT"].includes(message.code) ? message.code : "INTERNAL_ERROR";
              finish(errorResponse(request, pending.size ? "RESULT_UNKNOWN" : code));
              return;
            }
            if (message.type === "result") {
              if (pending.size) {
                finish(errorResponse(request, "RESULT_UNKNOWN"));
                return;
              }
              if (typeof message.json !== "string" || Buffer.byteLength(message.json) > 128 * 1024) {
                finish(errorResponse(request, "INVALID_OUTPUT"));
                return;
              }
              try {
                const result = parseCapabilityResponse(
                  {
                    protocolVersion: 1,
                    requestId: request.requestId,
                    status: "success",
                    value: JSON.parse(message.json)
                  },
                  request
                );
                finish(result.ok ? result.value : errorResponse(request, "INVALID_OUTPUT"));
              } catch {
                finish(errorResponse(request, "INVALID_OUTPUT"));
              }
              return;
            }
            if (message.type !== "invoke" || !Number.isInteger(message.id) || typeof message.json !== "string") {
              finish(errorResponse(request, "INTERNAL_ERROR"));
              return;
            }
            const id2 = message.id;
            const send2 = (reply) => {
              if (!done) worker.postMessage({ type: "reply", id: id2, json: JSON.stringify(reply) });
            };
            if (++calls > this.#limits.maxCalls || pending.size >= this.#limits.maxPending || pending.has(id2)) {
              send2(fail2("LIMIT_EXCEEDED"));
              return;
            }
            let nested;
            try {
              nested = Buffer.byteLength(message.json) <= 64 * 1024 ? parseCapabilityRequest(JSON.parse(message.json)) : fail2("INVALID_INPUT");
            } catch {
              nested = fail2("INVALID_INPUT");
            }
            if (!nested.ok) {
              send2(nested);
              return;
            }
            const controller = new AbortController();
            const timer = setTimeout(() => {
              pending.delete(id2);
              controller.abort();
              send2(fail2("RESULT_UNKNOWN"));
            }, this.#limits.bridgeMs);
            pending.set(id2, { controller, timer });
            const complete = (reply) => {
              const entry = pending.get(id2);
              if (!entry || done) return;
              clearTimeout(entry.timer);
              pending.delete(id2);
              send2(reply);
            };
            void Promise.resolve().then(
              () => done || controller.signal.aborted ? fail2("CANCELLED") : invoke(nested.value, { signal: controller.signal })
            ).then(
              (reply) => {
                if (!reply.ok) complete(fail2(reply.error.code));
                else {
                  const valid = parseCapabilityResponse(reply.value, nested.value);
                  complete(valid);
                }
              },
              () => complete(fail2("INTERNAL_ERROR"))
            ).catch(() => complete(fail2("INTERNAL_ERROR")));
          });
          worker.on(
            "error",
            () => finish(errorResponse(request, pending.size ? "RESULT_UNKNOWN" : "INTERNAL_ERROR"))
          );
          worker.on("exit", () => {
            if (!done) finish(errorResponse(request, "INTERNAL_ERROR"));
          });
        });
      } finally {
        this.#active--;
      }
    };
  }
};

// ../../packages/capability-dev-host/src/installed.ts
import { openSync, readSync, closeSync, fstatSync } from "node:fs";
import { realpath } from "node:fs/promises";
import { resolve, relative, isAbsolute } from "node:path";
import { createHash as createHash6 } from "node:crypto";
import { isDeepStrictEqual as isDeepStrictEqual2 } from "node:util";

// ../../packages/capability-packages/src/index.ts
import { createHash as createHash5 } from "node:crypto";
var import_semver2 = __toESM(require_semver2(), 1);

// ../../packages/capability-packages/src/internal.ts
var verifiedPackages = /* @__PURE__ */ new WeakSet();

// ../../packages/capability-packages/src/migrations.ts
import { DatabaseSync as DatabaseSync8 } from "node:sqlite";

// ../../packages/capability-packages/src/installations.ts
import { DatabaseSync as DatabaseSync7 } from "node:sqlite";

// ../../packages/capability-packages/src/releases.ts
import { DatabaseSync as DatabaseSync6 } from "node:sqlite";

// ../../packages/capability-packages/src/signatures.ts
import { createPublicKey, sign, verify, KeyObject } from "node:crypto";
var SIGNATURE_LIMITS = Object.freeze({
  keys: 32,
  attestationBytes: 4096,
  maxValidityMs: 7 * 24 * 60 * 60 * 1e3
});
var keyId = /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}(?![\s\S])/;
var namespace = /^[a-z][a-z0-9.-]{0,63}(?![\s\S])/;
var environments2 = ["development", "test", "production"];
var SignatureError = class extends Error {
  code;
  constructor(code) {
    super(createCapabilityError(code).message);
    this.code = code;
  }
};
function fail3(code) {
  throw new SignatureError(code);
}
function exact2(value, fields) {
  return !!value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === fields.length && fields.every((key) => Object.hasOwn(value, key));
}
function snapshot3(raw) {
  const result = parseCapabilityRequest({
    protocolVersion: 1,
    requestId: "019c7714-3b77-74d1-9866-e1f484aae2ab",
    capabilityId: "platform/signature-validation",
    input: raw
  });
  if (!result.ok) fail3("INVALID_INPUT");
  return result.value.input;
}
function metadata(raw) {
  const data = snapshot3(raw);
  if (!exact2(data, ["keyId", "environment", "issuedAt", "expiresAt"]) || typeof data.keyId !== "string" || !keyId.test(data.keyId) || !environments2.includes(data.environment) || !Number.isSafeInteger(data.issuedAt) || !Number.isSafeInteger(data.expiresAt) || data.issuedAt < 0 || data.expiresAt <= data.issuedAt || data.expiresAt - data.issuedAt > SIGNATURE_LIMITS.maxValidityMs)
    fail3("INVALID_INPUT");
  return data;
}
function payload(value) {
  return Buffer.from(
    JSON.stringify([
      "sitoo-capability-release-attestation-v1",
      value.formatVersion,
      value.keyId,
      value.environment,
      value.packageId,
      value.version,
      value.sha256,
      value.issuedAt,
      value.expiresAt
    ])
  );
}
function validation(work) {
  try {
    return { ok: true, value: work() };
  } catch (error4) {
    return {
      ok: false,
      error: createCapabilityError(error4 instanceof SignatureError ? error4.code : "INVALID_INPUT")
    };
  }
}
function signCapabilityPackage(pkg, privateKey, options) {
  return validation(() => {
    if (!verifiedPackages.has(pkg) || !(privateKey instanceof KeyObject) || privateKey.type !== "private" || privateKey.asymmetricKeyType !== "ed25519")
      fail3("INVALID_INPUT");
    const claims = {
      formatVersion: 1,
      ...metadata(options),
      packageId: pkg.manifest.packageId,
      version: pkg.manifest.version,
      sha256: pkg.sha256
    };
    return Object.freeze({
      ...claims,
      signature: sign(null, payload(claims), privateKey).toString("base64")
    });
  });
}
var CapabilityPackageTrust = class {
  #keys = /* @__PURE__ */ new Map();
  constructor(raw) {
    const data = snapshot3(raw);
    if (!Array.isArray(data) || !data.length || data.length > SIGNATURE_LIMITS.keys)
      fail3("INVALID_INPUT");
    for (const entry of data) {
      if (!exact2(entry, [
        "keyId",
        "namespace",
        "environments",
        "publicKeyPem",
        "notBefore",
        "notAfter",
        "revoked"
      ]) || typeof entry.keyId !== "string" || !keyId.test(entry.keyId) || this.#keys.has(entry.keyId) || typeof entry.namespace !== "string" || !namespace.test(entry.namespace) || !Array.isArray(entry.environments) || !entry.environments.length || entry.environments.length > 3 || new Set(entry.environments).size !== entry.environments.length || !entry.environments.every((value) => environments2.includes(value)) || typeof entry.publicKeyPem !== "string" || entry.publicKeyPem.length > 4096 || !entry.publicKeyPem.startsWith("-----BEGIN PUBLIC KEY-----") || !Number.isSafeInteger(entry.notBefore) || !Number.isSafeInteger(entry.notAfter) || entry.notBefore < 0 || entry.notAfter <= entry.notBefore || typeof entry.revoked !== "boolean")
        fail3("INVALID_INPUT");
      let key;
      try {
        key = createPublicKey(entry.publicKeyPem);
      } catch {
        fail3("INVALID_INPUT");
      }
      if (key.asymmetricKeyType !== "ed25519") fail3("INVALID_INPUT");
      const policy2 = entry;
      Object.freeze(policy2.environments);
      Object.freeze(policy2);
      this.#keys.set(policy2.keyId, { policy: policy2, key });
    }
  }
  verify(pkg, raw, now = Date.now()) {
    return validation(() => {
      if (!verifiedPackages.has(pkg) || !Number.isSafeInteger(now) || now < 0)
        fail3("INVALID_INPUT");
      const data = snapshot3(raw);
      if (!exact2(data, [
        "formatVersion",
        "keyId",
        "environment",
        "packageId",
        "version",
        "sha256",
        "issuedAt",
        "expiresAt",
        "signature"
      ]) || data.formatVersion !== 1 || typeof data.signature !== "string" || Buffer.byteLength(JSON.stringify(data)) > SIGNATURE_LIMITS.attestationBytes)
        fail3("INVALID_INPUT");
      const options = metadata({
        keyId: data.keyId,
        environment: data.environment,
        issuedAt: data.issuedAt,
        expiresAt: data.expiresAt
      });
      const key = this.#keys.get(options.keyId);
      if (!key || key.policy.revoked || pkg.manifest.packageId.split("/")[0] !== key.policy.namespace || !key.policy.environments.includes(options.environment) || now < key.policy.notBefore || now >= key.policy.notAfter || options.issuedAt < key.policy.notBefore || options.expiresAt > key.policy.notAfter || now < options.issuedAt || now >= options.expiresAt || data.packageId !== pkg.manifest.packageId || data.version !== pkg.manifest.version || data.sha256 !== pkg.sha256)
        fail3("FORBIDDEN");
      const signature = Buffer.from(data.signature, "base64");
      if (signature.length !== 64 || signature.toString("base64") !== data.signature)
        fail3("INVALID_INPUT");
      const attestation = data;
      if (!verify(null, payload(attestation), key.key, signature)) fail3("FORBIDDEN");
      return Object.freeze({ package: pkg, attestation: Object.freeze(attestation) });
    });
  }
};

// ../../packages/capability-packages/src/releases.ts
var error = (code) => ({
  ok: false,
  error: createCapabilityError(code)
});
var CapabilityReleaseStore = class {
  #db;
  #closed = false;
  #readOnly = false;
  constructor(path5, options = {}) {
    this.#readOnly = options.readOnly === true;
    try {
      this.#db = new DatabaseSync6(path5, { readOnly: this.#readOnly });
      const version = this.#db.prepare("PRAGMA user_version").get()?.user_version;
      const application = this.#db.prepare("PRAGMA application_id").get()?.application_id;
      const tables = this.#db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
      if (!(version === 0 && application === 0 && !tables.length || version === 1 && application === 1396920402))
        throw new Error("Unsupported release store schema.");
      if (this.#readOnly) {
        if (version !== 1 || application !== 1396920402) throw new Error();
        this.#db.exec("PRAGMA busy_timeout=100;");
        return;
      }
      this.#db.exec(
        "PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; PRAGMA busy_timeout=100; BEGIN IMMEDIATE; CREATE TABLE IF NOT EXISTS releases(environment TEXT NOT NULL,package_id TEXT NOT NULL,version TEXT NOT NULL,sha256 TEXT NOT NULL,manifest TEXT NOT NULL,sources TEXT NOT NULL,PRIMARY KEY(environment,package_id,version)); CREATE TABLE IF NOT EXISTS attestations(environment TEXT NOT NULL,package_id TEXT NOT NULL,version TEXT NOT NULL,signature TEXT NOT NULL,envelope TEXT NOT NULL,PRIMARY KEY(environment,package_id,version,signature)); PRAGMA user_version=1; PRAGMA application_id=0x53435052; COMMIT;"
      );
    } catch {
      try {
        this.#db?.close();
      } catch {
      }
      throw new Error("Release store unavailable.");
    }
  }
  publish(pkg, attestation, trust, now = Date.now()) {
    if (this.#closed) return error("UNAVAILABLE");
    if (this.#readOnly) return error("FORBIDDEN");
    const checked = trust.verify(pkg, attestation, now);
    if (!checked.ok) return checked;
    const envelope = checked.value.attestation;
    let transaction = false;
    try {
      this.#db.exec("BEGIN IMMEDIATE");
      transaction = true;
      const old = this.#db.prepare("SELECT sha256 FROM releases WHERE environment=? AND package_id=? AND version=?").get(envelope.environment, envelope.packageId, envelope.version);
      if (old && old.sha256 !== pkg.sha256) {
        this.#db.exec("ROLLBACK");
        transaction = false;
        return error("CONFLICT");
      }
      const existing = this.#db.prepare(
        "SELECT signature FROM attestations WHERE environment=? AND package_id=? AND version=? AND signature=?"
      ).get(envelope.environment, envelope.packageId, envelope.version, envelope.signature);
      if (!old && Number(this.#db.prepare("SELECT COUNT(*) AS count FROM releases").get().count) >= 128 || !existing && Number(this.#db.prepare("SELECT COUNT(*) AS count FROM attestations").get().count) >= 512) {
        this.#db.exec("ROLLBACK");
        transaction = false;
        return error("LIMIT_EXCEEDED");
      }
      if (!old)
        this.#db.prepare("INSERT INTO releases VALUES (?,?,?,?,?,?)").run(
          envelope.environment,
          envelope.packageId,
          envelope.version,
          pkg.sha256,
          JSON.stringify(pkg.manifest),
          JSON.stringify(pkg.sources)
        );
      if (!existing)
        this.#db.prepare("INSERT INTO attestations VALUES (?,?,?,?,?)").run(
          envelope.environment,
          envelope.packageId,
          envelope.version,
          envelope.signature,
          JSON.stringify(envelope)
        );
      this.#db.exec("COMMIT");
      transaction = false;
      return {
        ok: true,
        value: Object.freeze({
          packageId: envelope.packageId,
          version: envelope.version,
          sha256: pkg.sha256,
          environment: envelope.environment
        })
      };
    } catch {
      if (transaction)
        try {
          this.#db.exec("ROLLBACK");
        } catch {
        }
      return error("UNAVAILABLE");
    }
  }
  get(reference, trust, now = Date.now()) {
    if (this.#closed) return error("UNAVAILABLE");
    try {
      if (!reference || !Number.isSafeInteger(now) || now < 0 || Object.keys(reference).length !== 4 || typeof reference.packageId !== "string" || typeof reference.version !== "string" || !/^[a-f0-9]{64}(?![\s\S])/.test(reference.sha256) || !["development", "test", "production"].includes(reference.environment))
        return error("INVALID_INPUT");
      const row = this.#db.prepare(
        "SELECT * FROM releases WHERE environment=? AND package_id=? AND version=? AND sha256=?"
      ).get(reference.environment, reference.packageId, reference.version, reference.sha256);
      if (!row) return error("FORBIDDEN");
      const sources = JSON.parse(row.sources);
      const files = new Map(
        Object.entries(sources).map(([path5, source]) => [path5, Buffer.from(source, "utf8")])
      );
      const pkg = verifyCapabilityPackage(row.manifest, files);
      if (!pkg.ok || pkg.value.sha256 !== reference.sha256) return error("INVALID_INPUT");
      for (const record of this.#db.prepare(
        "SELECT envelope FROM attestations WHERE environment=? AND package_id=? AND version=? ORDER BY rowid DESC"
      ).all(reference.environment, reference.packageId, reference.version)) {
        const result = trust.verify(pkg.value, JSON.parse(record.envelope), now);
        if (result.ok && result.value.attestation.environment === reference.environment)
          return result;
      }
      return error("FORBIDDEN");
    } catch {
      return error("UNAVAILABLE");
    }
  }
  close() {
    if (!this.#closed) {
      this.#closed = true;
      this.#db.close();
    }
  }
};

// ../../packages/capability-packages/src/installations.ts
import { createHash as createHash4 } from "node:crypto";
var INSTALLATION_LIMITS = Object.freeze({ roots: 128, packages: 128, transactions: 512 });
var LEASE_LIMITS = Object.freeze({ records: 1024 });
var error2 = (code) => ({
  ok: false,
  error: createCapabilityError(code)
});
var InstallationError = class extends Error {
  code;
  constructor(code) {
    super(createCapabilityError(code).message);
    this.code = code;
  }
};
function fail4(code) {
  throw new InstallationError(code);
}
function unwrap(result) {
  if (!result.ok) fail4(result.error.code);
  return result.value;
}
function freeze3(value) {
  if (value && typeof value === "object") {
    Object.values(value).forEach(freeze3);
    Object.freeze(value);
  }
  return value;
}
function snapshot4(raw) {
  return unwrap(
    parseCapabilityRequest({
      protocolVersion: 1,
      requestId: "019c7714-3b77-74d1-9866-e1f484aae2ab",
      capabilityId: "platform/installation-validation",
      input: raw
    })
  ).input;
}
var identifier3 = (value) => typeof value === "string" && /^[a-zA-Z0-9][a-zA-Z0-9._/-]{0,127}(?![\s\S])/.test(value);
function rootKey(raw) {
  const root = snapshot4(raw);
  if (!root || Object.keys(root).length !== 4 || !identifier3(root.tenantId) || !identifier3(root.accountId) || !identifier3(root.applicationId) || !["development", "test", "production"].includes(root.environment))
    fail4("INVALID_INPUT");
  return JSON.stringify([root.tenantId, root.accountId, root.applicationId, root.environment]);
}
function checkedPlan(roots, raw, environment, releases, trust, now, applicationId) {
  const references = snapshot4(raw);
  if (!Array.isArray(references) || !references.length || references.length > INSTALLATION_LIMITS.packages)
    fail4("INVALID_INPUT");
  const packages = references.map((reference) => {
    if (!reference || reference.environment !== environment) fail4("FORBIDDEN");
    const item = unwrap(releases.get(reference, trust, now));
    if (item.attestation.environment !== environment) fail4("FORBIDDEN");
    return item;
  });
  const plan = unwrap(
    resolveCapabilityDependencies(
      roots,
      packages.map((item) => item.package)
    )
  );
  if (plan.packages.length !== packages.length || plan.packages.some(
    (item) => !references.some(
      (ref) => ref.packageId === item.packageId && ref.version === item.version && ref.sha256 === item.sha256
    )
  ))
    fail4("CONFLICT");
  checkApplicationRoot(plan, packages, applicationId);
  return { plan, packages };
}
function checkApplicationRoot(plan, packages, applicationId) {
  const applications = packages.filter(
    (item) => item.package.manifest.execution === "static-application-v1"
  );
  if (!applications.length) return;
  const manifest = applications[0].package.manifest;
  if (manifest.execution !== "static-application-v1" || applications.length !== 1 || plan.roots.length !== 1 || plan.roots[0].packageId !== manifest.packageId || manifest.application.applicationId !== applicationId)
    fail4("FORBIDDEN");
}
var CapabilityInstallationStore = class {
  #db;
  #closed = false;
  #readOnly = false;
  #scope;
  #environment;
  #applicationId;
  constructor(path5, root, options = {}) {
    this.#readOnly = options.readOnly === true;
    try {
      this.#scope = rootKey(root);
      this.#environment = JSON.parse(this.#scope)[3];
      this.#applicationId = JSON.parse(this.#scope)[2];
      this.#db = new DatabaseSync7(path5, { readOnly: options.readOnly === true });
      const version = this.#db.prepare("PRAGMA user_version").get()?.user_version;
      const application = this.#db.prepare("PRAGMA application_id").get()?.application_id;
      const tables = this.#db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
      if (!(version === 0 && application === 0 && !tables.length || (version === 1 || version === 2 || version === 3) && application === 1396918606))
        throw new Error();
      if (options.readOnly === true) {
        if (version !== 3 || application !== 1396918606) throw new Error();
        this.#db.exec("PRAGMA busy_timeout=100;");
        return;
      }
      this.#db.exec(`PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; PRAGMA busy_timeout=100;
        BEGIN IMMEDIATE;
        CREATE TABLE IF NOT EXISTS installation_transactions(scope TEXT NOT NULL,request_id TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('prepared','committed','aborted')),plan TEXT NOT NULL,PRIMARY KEY(scope,request_id));
        CREATE TABLE IF NOT EXISTS installation_roots(scope TEXT PRIMARY KEY,plan TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS installed_packages(environment TEXT NOT NULL,package_id TEXT NOT NULL,version TEXT NOT NULL,sha256 TEXT NOT NULL,manifest TEXT NOT NULL,sources TEXT NOT NULL,attestation TEXT NOT NULL,PRIMARY KEY(environment,package_id,version));
        CREATE TABLE IF NOT EXISTS installation_references(scope TEXT NOT NULL,environment TEXT NOT NULL,package_id TEXT NOT NULL,version TEXT NOT NULL,sha256 TEXT NOT NULL,PRIMARY KEY(scope,package_id));
        CREATE TABLE IF NOT EXISTS package_leases(scope TEXT NOT NULL,task_id TEXT NOT NULL,request_id TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('active','released')),plan TEXT NOT NULL,PRIMARY KEY(scope,task_id));
        CREATE TABLE IF NOT EXISTS installation_generations(scope TEXT PRIMARY KEY,generation INTEGER NOT NULL);
        INSERT OR IGNORE INTO installation_generations SELECT scope,1 FROM installation_roots;
        CREATE TABLE IF NOT EXISTS installation_operations(scope TEXT NOT NULL,request_id TEXT NOT NULL,operation TEXT NOT NULL CHECK(operation IN ('update','uninstall')),generation INTEGER NOT NULL,PRIMARY KEY(scope,request_id));
        PRAGMA user_version=3; PRAGMA application_id=0x5343494e; COMMIT;`);
    } catch {
      try {
        this.#db?.close();
      } catch {
      }
      throw new Error("Installation store unavailable.");
    }
  }
  #work(work, write = false) {
    if (this.#closed) return error2("UNAVAILABLE");
    if (write && this.#readOnly) return { ok: false, error: createCapabilityError("FORBIDDEN") };
    let transaction = false;
    try {
      this.#db.exec(write ? "BEGIN IMMEDIATE" : "BEGIN");
      transaction = true;
      const value = work();
      this.#db.exec("COMMIT");
      transaction = false;
      return { ok: true, value: freeze3(value) };
    } catch (cause) {
      if (transaction)
        try {
          this.#db.exec("ROLLBACK");
        } catch {
        }
      return error2(cause instanceof InstallationError ? cause.code : "UNAVAILABLE");
    }
  }
  #transaction(requestId) {
    if (!identifier3(requestId)) fail4("INVALID_INPUT");
    const row = this.#db.prepare("SELECT status,plan FROM installation_transactions WHERE scope=? AND request_id=?").get(this.#scope, requestId);
    if (!row) fail4("FORBIDDEN");
    return {
      requestId,
      status: row.status,
      plan: JSON.parse(row.plan)
    };
  }
  prepare(requestId, roots, references, releases, trust, now = Date.now()) {
    return this.#prepare(requestId, roots, references, releases, trust, now, false);
  }
  prepareUpdate(requestId, roots, references, releases, trust, now = Date.now()) {
    return this.#prepare(requestId, roots, references, releases, trust, now, true);
  }
  #generation() {
    return Number(
      this.#db.prepare("SELECT generation FROM installation_generations WHERE scope=?").get(this.#scope)?.generation ?? 0
    );
  }
  #operation(requestId) {
    return this.#db.prepare(
      "SELECT operation,generation FROM installation_operations WHERE scope=? AND request_id=?"
    ).get(this.#scope, requestId);
  }
  #capacity() {
    if (Number(
      this.#db.prepare("SELECT COUNT(*) AS count FROM installation_transactions").get().count
    ) >= INSTALLATION_LIMITS.transactions)
      fail4("LIMIT_EXCEEDED");
  }
  #idle() {
    if (this.#db.prepare("SELECT task_id FROM package_leases WHERE scope=? AND status='active' LIMIT 1").get(this.#scope))
      fail4("CONFLICT");
  }
  #prepare(requestId, roots, references, releases, trust, now, update) {
    return this.#work(() => {
      if (!identifier3(requestId)) fail4("INVALID_INPUT");
      const { plan, packages } = checkedPlan(
        roots,
        references,
        this.#environment,
        releases,
        trust,
        now,
        this.#applicationId
      );
      const serialized = JSON.stringify(plan);
      const old = this.#db.prepare("SELECT plan FROM installation_transactions WHERE scope=? AND request_id=?").get(this.#scope, requestId);
      if (old) {
        if (old.plan !== serialized || (this.#operation(requestId)?.operation ?? "install") !== (update ? "update" : "install"))
          fail4("CONFLICT");
        return this.#transaction(requestId);
      }
      const installed = this.#db.prepare("SELECT scope FROM installation_roots WHERE scope=?").get(this.#scope);
      if (update ? !installed : installed) fail4("CONFLICT");
      if (update) {
        const previous = this.#db.prepare(
          "SELECT p.* FROM installed_packages p JOIN installation_references r ON p.environment=r.environment AND p.package_id=r.package_id AND p.version=r.version AND p.sha256=r.sha256 WHERE r.scope=?"
        ).all(this.#scope);
        const wasApplication = previous.some(
          (row) => this.#content(row).manifest.execution === "static-application-v1"
        );
        if (wasApplication && !packages.some((item) => item.package.manifest.execution === "static-application-v1"))
          fail4("FORBIDDEN");
      }
      this.#capacity();
      this.#db.prepare("INSERT INTO installation_transactions VALUES (?,?,'prepared',?)").run(this.#scope, requestId, serialized);
      if (update)
        this.#db.prepare("INSERT INTO installation_operations VALUES (?,?,'update',?)").run(this.#scope, requestId, this.#generation());
      return this.#transaction(requestId);
    }, true);
  }
  prepareUninstall(requestId) {
    return this.#work(() => {
      if (!identifier3(requestId)) fail4("INVALID_INPUT");
      const old = this.#db.prepare("SELECT request_id FROM installation_transactions WHERE scope=? AND request_id=?").get(this.#scope, requestId);
      if (old) {
        if (this.#operation(requestId)?.operation !== "uninstall") fail4("CONFLICT");
        return this.#transaction(requestId);
      }
      const root = this.#db.prepare("SELECT plan FROM installation_roots WHERE scope=?").get(this.#scope);
      if (!root) fail4("FORBIDDEN");
      this.#capacity();
      this.#db.prepare("INSERT INTO installation_transactions VALUES (?,?,'prepared',?)").run(this.#scope, requestId, root.plan);
      this.#db.prepare("INSERT INTO installation_operations VALUES (?,?,'uninstall',?)").run(this.#scope, requestId, this.#generation());
      return this.#transaction(requestId);
    }, true);
  }
  #removeRoot() {
    this.#db.prepare("DELETE FROM installation_references WHERE scope=?").run(this.#scope);
    this.#db.prepare("DELETE FROM installation_roots WHERE scope=?").run(this.#scope);
  }
  #advance() {
    this.#db.prepare(
      "INSERT INTO installation_generations VALUES (?,1) ON CONFLICT(scope) DO UPDATE SET generation=generation+1"
    ).run(this.#scope);
  }
  commitUninstall(requestId) {
    return this.#work(() => {
      const transaction = this.#transaction(requestId);
      const operation = this.#operation(requestId);
      if (operation?.operation !== "uninstall") fail4("CONFLICT");
      if (transaction.status === "committed") return transaction;
      if (transaction.status !== "prepared" || operation.generation !== this.#generation())
        fail4("CONFLICT");
      this.#idle();
      if (!this.#db.prepare("SELECT scope FROM installation_roots WHERE scope=?").get(this.#scope))
        fail4("CONFLICT");
      this.#removeRoot();
      this.#advance();
      this.#db.prepare(
        "UPDATE installation_transactions SET status='committed' WHERE scope=? AND request_id=?"
      ).run(this.#scope, requestId);
      return this.#transaction(requestId);
    }, true);
  }
  commit(requestId, releases, trust, now = Date.now()) {
    return this.#commit(requestId, releases, trust, now);
  }
  reviewUpdate(requestId, policy2, releases, trust, now = Date.now()) {
    return this.#work(() => this.#reviewUpdate(requestId, policy2, releases, trust, now));
  }
  #reviewUpdate(requestId, raw, releases, trust, now) {
    const policy2 = snapshot4(raw);
    if (!policy2 || Object.keys(policy2).length !== 2 || !Object.hasOwn(policy2, "entry") || !Object.hasOwn(policy2, "grants"))
      fail4("INVALID_INPUT");
    try {
      const broker = new CapabilityBroker();
      const session = broker.createSession({
        tenantId: "review",
        environment: this.#environment,
        installationId: "review",
        consumerAppId: "review",
        entry: policy2.entry,
        grants: policy2.grants,
        bindings: []
      });
      broker.revokeSession(session);
    } catch {
      fail4("INVALID_INPUT");
    }
    const transaction = this.#transaction(requestId);
    const operation = this.#operation(requestId);
    if (transaction.status !== "prepared" || operation?.operation !== "update" || operation.generation !== this.#generation())
      fail4("CONFLICT");
    const current = this.#loadInstalled(trust, now);
    const target = checkedPlan(
      transaction.plan.roots,
      transaction.plan.packages.map((item) => ({ ...item, environment: this.#environment })),
      this.#environment,
      releases,
      trust,
      now,
      this.#applicationId
    );
    if (JSON.stringify(target.plan) !== JSON.stringify(transaction.plan)) fail4("CONFLICT");
    const declarations = target.packages.flatMap((item) => item.package.manifest.capabilities);
    const required = [...new Set(declarations.flatMap((item) => item.permissions))].sort();
    const previous = new Set(
      current.packages.flatMap(
        (item) => item.package.manifest.capabilities.flatMap((cap) => cap.permissions)
      )
    );
    const review = {
      requestId,
      generation: this.#generation(),
      plan: target.plan,
      policy: { entry: policy2.entry, grants: [...policy2.grants].sort() },
      required,
      added: required.filter((item) => !previous.has(item)),
      removed: [...previous].filter((item) => !required.includes(item)).sort(),
      missing: required.filter((item) => !policy2.grants.includes(item)),
      unsupportedEntries: declarations.filter((item) => !item.allowedEntries.includes(policy2.entry)).map((item) => item.capabilityId).sort()
    };
    return {
      ...review,
      reviewSha256: createHash4("sha256").update(JSON.stringify(review)).digest("hex")
    };
  }
  /** Trusted host supplies reviewed grants; this does not mint or persist execution authorization. */
  commitAuthorizedUpdate(requestId, policy2, reviewSha256, releases, trust, now = Date.now()) {
    return this.#commit(requestId, releases, trust, now, { policy: policy2, reviewSha256 });
  }
  #commit(requestId, releases, trust, now, authorization) {
    return this.#work(() => {
      const transaction = this.#transaction(requestId);
      const operation = this.#operation(requestId);
      if (authorization && operation?.operation !== "update") fail4("CONFLICT");
      if (operation?.operation === "uninstall") fail4("CONFLICT");
      if (transaction.status === "committed") return transaction;
      if (transaction.status === "aborted") fail4("CONFLICT");
      if (authorization) {
        const review = this.#reviewUpdate(requestId, authorization.policy, releases, trust, now);
        if (review.reviewSha256 !== authorization.reviewSha256) fail4("CONFLICT");
        if (review.missing.length || review.unsupportedEntries.length) fail4("FORBIDDEN");
      }
      const installed = this.#db.prepare("SELECT scope FROM installation_roots WHERE scope=?").get(this.#scope);
      if (operation?.operation === "update") {
        if (!installed || operation.generation !== this.#generation()) fail4("CONFLICT");
        this.#idle();
      } else if (installed) fail4("CONFLICT");
      const references = transaction.plan.packages.map((item) => ({
        ...item,
        environment: this.#environment
      }));
      const checked = checkedPlan(
        transaction.plan.roots,
        references,
        this.#environment,
        releases,
        trust,
        now,
        this.#applicationId
      );
      if (JSON.stringify(checked.plan) !== JSON.stringify(transaction.plan)) fail4("CONFLICT");
      if (!installed && Number(this.#db.prepare("SELECT COUNT(*) AS count FROM installation_roots").get().count) >= INSTALLATION_LIMITS.roots)
        fail4("LIMIT_EXCEEDED");
      const count = Number(
        this.#db.prepare("SELECT COUNT(*) AS count FROM installed_packages").get().count
      );
      const missing = checked.packages.filter(
        (item) => !this.#db.prepare(
          "SELECT sha256 FROM installed_packages WHERE environment=? AND package_id=? AND version=?"
        ).get(this.#environment, item.package.manifest.packageId, item.package.manifest.version)
      );
      if (count + missing.length > INSTALLATION_LIMITS.packages) fail4("LIMIT_EXCEEDED");
      if (installed) this.#removeRoot();
      for (const item of checked.packages) {
        const pkg = item.package;
        const row = this.#db.prepare(
          "SELECT * FROM installed_packages WHERE environment=? AND package_id=? AND version=?"
        ).get(this.#environment, pkg.manifest.packageId, pkg.manifest.version);
        if (row) {
          if (row.sha256 !== pkg.sha256) fail4("CONFLICT");
          const cached = this.#content(row);
          if (cached.sha256 !== pkg.sha256) fail4("INVALID_INPUT");
          this.#db.prepare(
            "UPDATE installed_packages SET attestation=? WHERE environment=? AND package_id=? AND version=?"
          ).run(
            JSON.stringify(item.attestation),
            this.#environment,
            pkg.manifest.packageId,
            pkg.manifest.version
          );
        } else
          this.#db.prepare("INSERT INTO installed_packages VALUES (?,?,?,?,?,?,?)").run(
            this.#environment,
            pkg.manifest.packageId,
            pkg.manifest.version,
            pkg.sha256,
            JSON.stringify(pkg.manifest),
            JSON.stringify(pkg.sources),
            JSON.stringify(item.attestation)
          );
        this.#db.prepare("INSERT INTO installation_references VALUES (?,?,?,?,?)").run(
          this.#scope,
          this.#environment,
          pkg.manifest.packageId,
          pkg.manifest.version,
          pkg.sha256
        );
      }
      this.#db.prepare("INSERT INTO installation_roots VALUES (?,?)").run(this.#scope, JSON.stringify(checked.plan));
      this.#advance();
      this.#db.prepare(
        "UPDATE installation_transactions SET status='committed' WHERE scope=? AND request_id=?"
      ).run(this.#scope, requestId);
      return this.#transaction(requestId);
    }, true);
  }
  #content(row) {
    const sources = JSON.parse(row.sources);
    const pkg = unwrap(
      verifyCapabilityPackage(
        row.manifest,
        new Map(
          Object.entries(sources).map(([path5, source]) => [path5, Buffer.from(source, "utf8")])
        )
      )
    );
    if (pkg.sha256 !== row.sha256 || pkg.manifest.packageId !== row.package_id || pkg.manifest.version !== row.version)
      fail4("INVALID_INPUT");
    return pkg;
  }
  status(requestId) {
    return this.#work(() => this.#transaction(requestId));
  }
  abort(requestId) {
    return this.#work(() => {
      const transaction = this.#transaction(requestId);
      if (transaction.status === "committed") fail4("CONFLICT");
      this.#db.prepare(
        "UPDATE installation_transactions SET status='aborted' WHERE scope=? AND request_id=?"
      ).run(this.#scope, requestId);
      return this.#transaction(requestId);
    }, true);
  }
  pending() {
    return this.#work(
      () => this.#db.prepare(
        "SELECT request_id FROM installation_transactions WHERE scope=? AND status='prepared' ORDER BY request_id"
      ).all(this.#scope).map((row) => this.#transaction(row.request_id))
    );
  }
  load(trust, now = Date.now()) {
    return this.#work(() => this.#loadInstalled(trust, now));
  }
  #loadInstalled(trust, now) {
    const root = this.#db.prepare("SELECT plan FROM installation_roots WHERE scope=?").get(this.#scope);
    if (!root) fail4("FORBIDDEN");
    const plan = JSON.parse(root.plan);
    const refs = this.#db.prepare("SELECT * FROM installation_references WHERE scope=?").all(this.#scope);
    if (refs.length !== plan.packages.length) fail4("INVALID_INPUT");
    for (const item of plan.packages) {
      if (!refs.some(
        (ref) => ref.environment === this.#environment && ref.package_id === item.packageId && ref.version === item.version && ref.sha256 === item.sha256
      ))
        fail4("INVALID_INPUT");
    }
    return this.#hydratePlan(plan, trust, now);
  }
  #hydratePlan(plan, trust, now) {
    const packages = plan.packages.map((item) => {
      const row = this.#db.prepare(
        "SELECT * FROM installed_packages WHERE environment=? AND package_id=? AND version=? AND sha256=?"
      ).get(this.#environment, item.packageId, item.version, item.sha256);
      if (!row) fail4("INVALID_INPUT");
      const trusted = unwrap(
        trust.verify(this.#content(row), JSON.parse(row.attestation), now)
      );
      if (trusted.attestation.environment !== this.#environment) fail4("FORBIDDEN");
      return trusted;
    });
    const checked = unwrap(
      resolveCapabilityDependencies(
        plan.roots,
        packages.map((item) => item.package)
      )
    );
    if (JSON.stringify(checked) !== JSON.stringify(plan)) fail4("INVALID_INPUT");
    checkApplicationRoot(checked, packages, this.#applicationId);
    return { plan: checked, packages };
  }
  #lease(taskId) {
    if (!identifier3(taskId)) fail4("INVALID_INPUT");
    const row = this.#db.prepare("SELECT * FROM package_leases WHERE scope=? AND task_id=?").get(this.#scope, taskId);
    if (!row) fail4("FORBIDDEN");
    if (!["active", "released"].includes(row.status)) fail4("INVALID_INPUT");
    return {
      taskId,
      requestId: row.request_id,
      status: row.status,
      plan: JSON.parse(row.plan)
    };
  }
  acquireLease(taskId, requestId, bindings, trust, now = Date.now()) {
    return this.#work(() => {
      if (!identifier3(taskId) || !identifier3(requestId)) fail4("INVALID_INPUT");
      const { plan } = this.#loadInstalled(trust, now);
      const requested = snapshot4(bindings);
      if (!Array.isArray(requested) || requested.length !== plan.bindings.length || requested.some(
        (item) => !item || Object.keys(item).length !== 4 || !plan.bindings.some(
          (binding2) => binding2.capabilityId === item.capabilityId && binding2.packageId === item.packageId && binding2.version === item.version && binding2.sha256 === item.sha256
        )
      ))
        fail4("CONFLICT");
      if (new Set(requested.map((item) => item.capabilityId)).size !== requested.length)
        fail4("CONFLICT");
      const old = this.#db.prepare("SELECT task_id FROM package_leases WHERE scope=? AND task_id=?").get(this.#scope, taskId);
      if (old) {
        const lease = this.#lease(taskId);
        if (lease.requestId !== requestId || lease.status !== "active" || JSON.stringify(lease.plan) !== JSON.stringify(plan))
          fail4("CONFLICT");
        return lease;
      }
      if (Number(this.#db.prepare("SELECT COUNT(*) AS count FROM package_leases").get().count) >= LEASE_LIMITS.records)
        fail4("LIMIT_EXCEEDED");
      this.#db.prepare("INSERT INTO package_leases VALUES (?,?,?,'active',?)").run(this.#scope, taskId, requestId, JSON.stringify(plan));
      return this.#lease(taskId);
    }, true);
  }
  getLease(taskId) {
    return this.#work(() => this.#lease(taskId));
  }
  activeLeases() {
    return this.#work(
      () => this.#db.prepare(
        "SELECT task_id FROM package_leases WHERE scope=? AND status='active' ORDER BY task_id"
      ).all(this.#scope).map((row) => this.#lease(row.task_id))
    );
  }
  releaseLease(taskId) {
    return this.#work(() => {
      const lease = this.#lease(taskId);
      if (lease.status === "released") return lease;
      this.#db.prepare("UPDATE package_leases SET status='released' WHERE scope=? AND task_id=?").run(this.#scope, taskId);
      return this.#lease(taskId);
    }, true);
  }
  loadLease(taskId, trust, now = Date.now()) {
    return this.#work(() => {
      const lease = this.#lease(taskId);
      if (lease.status !== "active") fail4("FORBIDDEN");
      return this.#hydratePlan(lease.plan, trust, now);
    });
  }
  leaseInventory() {
    return this.#work(() => {
      const active = this.#db.prepare("SELECT plan FROM package_leases WHERE status='active'").all();
      return {
        records: Number(
          this.#db.prepare("SELECT COUNT(*) AS count FROM package_leases").get().count
        ),
        active: active.length,
        references: active.reduce(
          (count, row) => count + JSON.parse(row.plan).packages.length,
          0
        )
      };
    });
  }
  /** Explicit global maintenance; preserve every root, active pin and prepared transaction. */
  collectUnused() {
    return this.#work(() => {
      const protectedPackages = /* @__PURE__ */ new Set();
      for (const row of this.#db.prepare("SELECT environment,package_id,version,sha256 FROM installation_references").all())
        protectedPackages.add(
          JSON.stringify([row.environment, row.package_id, row.version, row.sha256])
        );
      for (const row of this.#db.prepare(
        "SELECT scope,plan FROM installation_roots UNION ALL SELECT scope,plan FROM package_leases WHERE status='active' UNION ALL SELECT scope,plan FROM installation_transactions WHERE status='prepared'"
      ).all()) {
        const environment = JSON.parse(row.scope)[3];
        const plan = JSON.parse(row.plan);
        for (const item of plan.packages)
          protectedPackages.add(
            JSON.stringify([environment, item.packageId, item.version, item.sha256])
          );
      }
      const rows = this.#db.prepare("SELECT environment,package_id,version,sha256 FROM installed_packages").all();
      let removed = 0;
      for (const row of rows) {
        if (protectedPackages.has(
          JSON.stringify([row.environment, row.package_id, row.version, row.sha256])
        ))
          continue;
        this.#db.prepare(
          "DELETE FROM installed_packages WHERE environment=? AND package_id=? AND version=? AND sha256=?"
        ).run(
          row.environment,
          row.package_id,
          row.version,
          row.sha256
        );
        removed++;
      }
      return { removed, retained: rows.length - removed };
    }, true);
  }
  /** Administrative aggregate only; this class must not be exposed directly to applications. */
  inventory() {
    return this.#work(() => ({
      packages: Number(
        this.#db.prepare("SELECT COUNT(*) AS count FROM installed_packages").get().count
      ),
      roots: Number(
        this.#db.prepare("SELECT COUNT(*) AS count FROM installation_roots").get().count
      ),
      references: Number(
        this.#db.prepare("SELECT COUNT(*) AS count FROM installation_references").get().count
      ),
      transactions: Number(
        this.#db.prepare("SELECT COUNT(*) AS count FROM installation_transactions").get().count
      )
    }));
  }
  close() {
    if (!this.#closed) {
      this.#closed = true;
      this.#db.close();
    }
  }
};

// ../../packages/capability-packages/src/migrations.ts
var DATA_MIGRATION_LIMITS = Object.freeze({
  roots: 128,
  records: 512,
  version: 2147483647,
  revision: 2147483647
});

// ../../packages/capability-packages/src/authorizations.ts
import { DatabaseSync as DatabaseSync9 } from "node:sqlite";
var AUTHORIZATION_LIMITS = Object.freeze({
  scopes: 384,
  records: 1024,
  revision: 2147483647
});
var AuthorizationError = class extends Error {
  code;
  constructor(code) {
    super(code);
    this.code = code;
  }
};
function fail5(code) {
  throw new AuthorizationError(code);
}
function policy(raw) {
  if (!raw || Object.keys(raw).length !== 3 || !["entry", "grants", "bindings"].every((key) => Object.hasOwn(raw, key)))
    fail5("INVALID_INPUT");
  const broker = new CapabilityBroker();
  try {
    const session = broker.createSession({
      tenantId: "authorization",
      environment: "test",
      installationId: "authorization",
      consumerAppId: "authorization",
      ...raw
    });
    const caller = broker.getCaller(session);
    broker.revokeSession(session);
    if (!caller.ok) return fail5("INVALID_INPUT");
    return {
      entry: caller.value.entry,
      grants: [...caller.value.grants].sort(),
      bindings: caller.value.bindings.map((item) => ({
        capabilityId: item.capabilityId,
        packageId: item.packageId,
        version: item.version,
        sha256: item.sha256
      })).sort((a, b) => a.capabilityId.localeCompare(b.capabilityId))
    };
  } catch {
    return fail5("INVALID_INPUT");
  }
}
function freeze4(value) {
  if (value && typeof value === "object") {
    Object.values(value).forEach(freeze4);
    Object.freeze(value);
  }
  return value;
}
function revision(value) {
  return Number.isInteger(value) && value >= 0 && value <= AUTHORIZATION_LIMITS.revision;
}
var CapabilityAuthorizationStore = class {
  #db;
  #scope;
  #closed = false;
  #readOnly = false;
  constructor(path5, root, entry, options = {}) {
    this.#readOnly = options.readOnly === true;
    this.#scope = JSON.stringify([
      rootKey(root),
      policy({ entry, grants: [], bindings: [] }).entry
    ]);
    try {
      this.#db = new DatabaseSync9(path5, { readOnly: options.readOnly === true });
      const version = this.#db.prepare("PRAGMA user_version").get()?.user_version;
      const application = this.#db.prepare("PRAGMA application_id").get()?.application_id;
      const tables = this.#db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
      if (!(version === 0 && application === 0 && !tables.length || version === 1 && application === 1396916565))
        throw new Error();
      if (options.readOnly === true) {
        if (version !== 1 || application !== 1396916565) throw new Error();
        this.#db.exec("PRAGMA busy_timeout=100;");
        return;
      }
      this.#db.exec(`PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; PRAGMA busy_timeout=100;
        BEGIN IMMEDIATE;
        CREATE TABLE IF NOT EXISTS authorizations(scope TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS authorization_receipts(scope TEXT NOT NULL,request_id TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(scope,request_id));
        PRAGMA user_version=1; PRAGMA application_id=0x53434155; COMMIT;`);
    } catch {
      try {
        this.#db?.close();
      } catch {
      }
      throw new Error("Authorization store unavailable.");
    }
  }
  #work(work, write = false) {
    if (this.#closed) return { ok: false, error: createCapabilityError("UNAVAILABLE") };
    if (write && this.#readOnly) return { ok: false, error: createCapabilityError("FORBIDDEN") };
    let transaction = false;
    try {
      this.#db.exec(write ? "BEGIN IMMEDIATE" : "BEGIN");
      transaction = true;
      const value = work();
      this.#db.exec("COMMIT");
      transaction = false;
      return { ok: true, value: freeze4(value) };
    } catch (cause) {
      if (transaction)
        try {
          this.#db.exec("ROLLBACK");
        } catch {
        }
      return {
        ok: false,
        error: createCapabilityError(
          cause instanceof AuthorizationError ? cause.code : "UNAVAILABLE"
        )
      };
    }
  }
  #checked(raw) {
    if (!raw || Object.keys(raw).length !== 3 || !revision(raw.revision) || raw.revision === 0 || !["active", "revoked"].includes(raw.status))
      fail5("INVALID_INPUT");
    const checked = policy(raw.policy);
    if (JSON.stringify([JSON.parse(this.#scope)[0], checked.entry]) !== this.#scope || raw.status === "revoked" && checked.grants.length)
      fail5("INVALID_INPUT");
    return { revision: raw.revision, status: raw.status, policy: checked };
  }
  #read() {
    const row = this.#db.prepare("SELECT value FROM authorizations WHERE scope=?").get(this.#scope);
    return row ? this.#checked(JSON.parse(row.value)) : null;
  }
  #receipt(id2) {
    if (typeof id2 !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9._/-]{0,127}(?![\s\S])/.test(id2))
      fail5("INVALID_INPUT");
    const row = this.#db.prepare("SELECT value FROM authorization_receipts WHERE scope=? AND request_id=?").get(this.#scope, id2);
    if (!row) return null;
    const raw = JSON.parse(row.value);
    if (Object.keys(raw).length !== 3 || raw.requestId !== id2 || !revision(raw.expectedRevision) || raw.authorization.revision !== raw.expectedRevision + 1)
      fail5("INVALID_INPUT");
    return {
      requestId: id2,
      expectedRevision: raw.expectedRevision,
      authorization: this.#checked(raw.authorization)
    };
  }
  read() {
    return this.#work(() => this.#read());
  }
  status(requestId) {
    return this.#work(() => this.#receipt(requestId));
  }
  set(requestId, expectedRevision, raw, status = "active") {
    return this.#work(() => {
      const checked = policy(raw);
      if (!revision(expectedRevision) || !["active", "revoked"].includes(status) || status === "revoked" && checked.grants.length)
        fail5("INVALID_INPUT");
      if (JSON.stringify([JSON.parse(this.#scope)[0], checked.entry]) !== this.#scope)
        fail5("INVALID_INPUT");
      const old = this.#receipt(requestId);
      if (old) {
        if (old.expectedRevision !== expectedRevision || old.authorization.status !== status || JSON.stringify(old.authorization.policy) !== JSON.stringify(checked))
          fail5("CONFLICT");
        return old;
      }
      const current = this.#read();
      if ((current?.revision ?? 0) !== expectedRevision) fail5("CONFLICT");
      if (expectedRevision === AUTHORIZATION_LIMITS.revision || Number(
        this.#db.prepare("SELECT COUNT(*) AS count FROM authorization_receipts").get().count
      ) >= AUTHORIZATION_LIMITS.records || !current && Number(this.#db.prepare("SELECT COUNT(*) AS count FROM authorizations").get().count) >= AUTHORIZATION_LIMITS.scopes)
        fail5("LIMIT_EXCEEDED");
      const authorization = this.#checked({
        revision: expectedRevision + 1,
        status,
        policy: checked
      });
      const receipt = { requestId, expectedRevision, authorization };
      this.#db.prepare(
        "INSERT INTO authorizations VALUES (?,?) ON CONFLICT(scope) DO UPDATE SET value=excluded.value"
      ).run(this.#scope, JSON.stringify(authorization));
      this.#db.prepare("INSERT INTO authorization_receipts VALUES (?,?,?)").run(this.#scope, requestId, JSON.stringify(receipt));
      return receipt;
    }, true);
  }
  close() {
    if (!this.#closed) {
      this.#closed = true;
      this.#db.close();
    }
  }
};

// ../../packages/capability-packages/src/index.ts
var PACKAGE_LIMITS = Object.freeze({
  manifestBytes: 65536,
  files: 16,
  sourceBytes: 65536,
  packageBytes: 1048576,
  dependencies: 32,
  capabilities: 16,
  catalog: 128,
  searchStates: 2048
});
var id = /^[a-z][a-z0-9.-]{0,63}\/[a-z][a-z0-9.-]{0,63}(?![\s\S])/;
var hash = /^[a-f0-9]{64}(?![\s\S])/;
function fail6(code) {
  throw new PackageError(code);
}
var PackageError = class extends Error {
  code;
  constructor(code) {
    super(createCapabilityError(code).message);
    this.code = code;
  }
};
var digest2 = (bytes) => createHash5("sha256").update(bytes).digest("hex");
var compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
function freeze5(value) {
  if (value && typeof value === "object") {
    Object.values(value).forEach(freeze5);
    Object.freeze(value);
  }
  return value;
}
function exact3(value, keys) {
  return !!value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === keys.length && keys.every((key) => Object.hasOwn(value, key));
}
function canonical3(value) {
  if (Array.isArray(value)) return "[" + value.map(canonical3).join(",") + "]";
  if (value && typeof value === "object")
    return "{" + Object.keys(value).sort().map(
      (key) => JSON.stringify(key) + ":" + canonical3(value[key])
    ).join(",") + "}";
  return JSON.stringify(value);
}
function pathValid(value, application = false) {
  return typeof value === "string" && value.length <= 192 && (application ? /\.(html|css|js|json)$/.test(value) : value.endsWith(".guest")) && value.split("/").every(
    (part) => /^[a-zA-Z0-9_-][a-zA-Z0-9_.-]*(?![\s\S])/.test(part) && !/[.]$/.test(part) && !/^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(part)
  );
}
function requirements(raw) {
  const snapshot5 = parseCapabilityRequest({
    protocolVersion: 1,
    requestId: "019c7714-3b77-74d1-9866-e1f484aae2ab",
    capabilityId: "platform/package-validation",
    input: raw
  });
  if (!snapshot5.ok || !Array.isArray(snapshot5.value.input) || snapshot5.value.input.length > PACKAGE_LIMITS.dependencies)
    fail6("INVALID_INPUT");
  const result = snapshot5.value.input;
  const seen = /* @__PURE__ */ new Set();
  for (const item of result) {
    if (!exact3(item, ["packageId", "range"]) || typeof item.packageId !== "string" || !id.test(item.packageId) || typeof item.range !== "string" || !item.range.trim() || item.range.length > 192 || !import_semver2.default.validRange(item.range) || seen.has(item.packageId))
      fail6("INVALID_INPUT");
    seen.add(item.packageId);
  }
  return result;
}
function validation2(work) {
  try {
    return { ok: true, value: work() };
  } catch (error4) {
    return {
      ok: false,
      error: createCapabilityError(error4 instanceof PackageError ? error4.code : "INVALID_INPUT")
    };
  }
}
function verifyCapabilityPackage(manifestJson, files) {
  return validation2(() => {
    if (typeof manifestJson !== "string" || Buffer.byteLength(manifestJson) > PACKAGE_LIMITS.manifestBytes)
      fail6("INVALID_INPUT");
    const snapshot5 = parseCapabilityRequest({
      protocolVersion: 1,
      requestId: "019c7714-3b77-74d1-9866-e1f484aae2ab",
      capabilityId: "platform/package-validation",
      input: JSON.parse(manifestJson)
    });
    if (!snapshot5.ok) fail6("INVALID_INPUT");
    const raw = snapshot5.value.input;
    const application = raw !== null && typeof raw === "object" && !Array.isArray(raw) && raw.execution === "static-application-v1";
    const service = raw !== null && typeof raw === "object" && !Array.isArray(raw) && raw.execution === "host-service-v1";
    if (!exact3(raw, [
      "formatVersion",
      "execution",
      "packageId",
      "version",
      "dependencies",
      "capabilities",
      "files",
      ...application ? ["application"] : []
    ]) || raw.formatVersion !== 1 || !application && !service && raw.execution !== "quickjs-function-v1" || typeof raw.packageId !== "string" || !id.test(raw.packageId) || typeof raw.version !== "string" || import_semver2.default.valid(raw.version) !== raw.version)
      fail6("INVALID_INPUT");
    const manifest = raw;
    if (manifest.execution === "static-application-v1" && (!exact3(manifest.application, ["applicationId", "entry"]) || typeof manifest.application.applicationId !== "string" || manifest.application.applicationId.length > 128 || !/^[a-z][a-z0-9.-]+(?![\s\S])/.test(manifest.application.applicationId) || !manifest.application.applicationId.startsWith(manifest.packageId.split("/")[0] + ".") || !pathValid(manifest.application.entry, true) || !manifest.application.entry.endsWith(".html")))
      fail6("INVALID_INPUT");
    requirements(manifest.dependencies);
    if (manifest.dependencies.some((dep) => dep.packageId === manifest.packageId)) fail6("CONFLICT");
    if (!Array.isArray(manifest.files) || (service ? manifest.files.length !== 0 : !manifest.files.length) || manifest.files.length > PACKAGE_LIMITS.files || !(files instanceof Map) || files.size !== manifest.files.length || !Array.isArray(manifest.capabilities) || (application ? manifest.capabilities.length !== 0 : !manifest.capabilities.length) || manifest.capabilities.length > PACKAGE_LIMITS.capabilities)
      fail6("INVALID_INPUT");
    const paths = /* @__PURE__ */ new Set();
    const folded = /* @__PURE__ */ new Set();
    const sources = /* @__PURE__ */ Object.create(null);
    let bytes = 0;
    for (const file of manifest.files) {
      if (!exact3(file, ["path", "bytes", "sha256"]) || !pathValid(file.path, application) || file.path === "capability-package.json" || !Number.isSafeInteger(file.bytes) || file.bytes < 1 || file.bytes > PACKAGE_LIMITS.sourceBytes || !hash.test(file.sha256) || folded.has(file.path.toLowerCase()))
        fail6("INVALID_INPUT");
      const contents = files.get(file.path);
      if (!(contents instanceof Uint8Array) || contents.byteLength !== file.bytes || digest2(contents) !== file.sha256)
        fail6("INVALID_INPUT");
      bytes += contents.byteLength;
      if (bytes > PACKAGE_LIMITS.packageBytes) fail6("LIMIT_EXCEEDED");
      sources[file.path] = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(
        contents
      );
      paths.add(file.path);
      folded.add(file.path.toLowerCase());
    }
    if (manifest.execution === "static-application-v1" && !paths.has(manifest.application.entry))
      fail6("INVALID_INPUT");
    const sha256 = digest2(canonical3(manifest));
    const broker = new CapabilityBroker();
    const bindings = [];
    const used = /* @__PURE__ */ new Set();
    for (const capability of manifest.capabilities) {
      if (!exact3(capability, [
        "capabilityId",
        ...service ? [] : ["source"],
        "interfaceVersion",
        "inputSchema",
        "outputSchema",
        "permissions",
        "allowedEntries",
        "delegates",
        "effects"
      ]) || typeof capability.capabilityId !== "string" || !id.test(capability.capabilityId) || !service && (!("source" in capability) || typeof capability.source !== "string" || !paths.has(capability.source)))
        fail6("INVALID_INPUT");
      const { capabilityId: capabilityId2, ...contract } = capability;
      const { source, ...declaration } = { source: void 0, ...contract };
      const binding2 = {
        capabilityId: capabilityId2,
        packageId: manifest.packageId,
        version: manifest.version,
        sha256
      };
      broker.register({ ...declaration, binding: binding2 }, () => null);
      bindings.push(binding2);
      if (source) used.add(source);
    }
    if (!application && used.size !== paths.size) fail6("INVALID_INPUT");
    const result = freeze5({ manifest, sha256, sources, bindings });
    verifiedPackages.add(result);
    return result;
  });
}
function resolveCapabilityDependencies(roots, catalog) {
  return validation2(() => {
    const requested = requirements(roots);
    if (!requested.length || !Array.isArray(catalog) || catalog.length > PACKAGE_LIMITS.catalog)
      fail6("INVALID_INPUT");
    const versions = /* @__PURE__ */ new Map();
    for (const item of catalog) {
      if (!item || !verifiedPackages.has(item)) fail6("INVALID_INPUT");
      const list = versions.get(item.manifest.packageId) ?? [];
      const same = list.find((p) => p.manifest.version === item.manifest.version);
      if (same) {
        if (same.sha256 !== item.sha256) fail6("CONFLICT");
        continue;
      }
      list.push(item);
      versions.set(item.manifest.packageId, list);
    }
    for (const list of versions.values())
      list.sort(
        (a, b) => import_semver2.default.rcompare(a.manifest.version, b.manifest.version) || compare(a.manifest.version, b.manifest.version)
      );
    let states = 0;
    function order(selected) {
      const visiting = /* @__PURE__ */ new Set();
      const visited = /* @__PURE__ */ new Set();
      const sorted = [];
      function visit(packageId) {
        if (visiting.has(packageId)) return false;
        if (visited.has(packageId)) return true;
        visiting.add(packageId);
        const item = selected.get(packageId);
        for (const dep of [...item.manifest.dependencies].sort(
          (a, b) => compare(a.packageId, b.packageId)
        ))
          if (selected.get(dep.packageId).manifest.execution === "static-application-v1" || !visit(dep.packageId))
            return false;
        visiting.delete(packageId);
        visited.add(packageId);
        sorted.push(item);
        return true;
      }
      for (const name of [...selected.keys()].sort()) if (!visit(name)) return void 0;
      const ids = /* @__PURE__ */ new Set();
      for (const item of sorted)
        for (const binding2 of item.bindings) {
          if (ids.has(binding2.capabilityId)) return void 0;
          ids.add(binding2.capabilityId);
        }
      for (const item of sorted) {
        const allowed = /* @__PURE__ */ new Set();
        const seen = /* @__PURE__ */ new Set();
        const collect = (p) => {
          if (seen.has(p.manifest.packageId)) return;
          seen.add(p.manifest.packageId);
          p.bindings.forEach((b) => allowed.add(b.capabilityId));
          p.manifest.dependencies.forEach((d) => collect(selected.get(d.packageId)));
        };
        collect(item);
        if (item.manifest.capabilities.some((c) => c.delegates.some((d) => !allowed.has(d))))
          return void 0;
      }
      return sorted;
    }
    function search(selected, constraints) {
      if (++states > PACKAGE_LIMITS.searchStates) fail6("LIMIT_EXCEEDED");
      for (const [name2, item] of selected)
        if (!constraints.get(name2).every((range) => import_semver2.default.satisfies(item.manifest.version, range)))
          return void 0;
      const name = [...constraints.keys()].filter((key) => !selected.has(key)).sort()[0];
      if (!name) return order(selected);
      for (const item of versions.get(name) ?? []) {
        if (!constraints.get(name).every((range) => import_semver2.default.satisfies(item.manifest.version, range)))
          continue;
        const next = new Map(selected);
        next.set(name, item);
        const requirements2 = new Map([...constraints].map(([key, ranges]) => [key, [...ranges]]));
        for (const dep of item.manifest.dependencies)
          requirements2.set(dep.packageId, [...requirements2.get(dep.packageId) ?? [], dep.range]);
        const result = search(next, requirements2);
        if (result) return result;
      }
      return void 0;
    }
    const resolved = search(
      /* @__PURE__ */ new Map(),
      new Map(requested.map((root) => [root.packageId, [root.range]]))
    );
    if (!resolved) fail6("CONFLICT");
    return freeze5({
      formatVersion: 1,
      roots: requested,
      packages: resolved.map((item) => ({
        packageId: item.manifest.packageId,
        version: item.manifest.version,
        sha256: item.sha256
      })),
      bindings: resolved.flatMap((item) => item.bindings)
    });
  });
}

// ../../packages/capability-dev-host/src/installed.ts
var scope2 = (caller) => JSON.stringify([
  caller.tenantId,
  caller.environment,
  caller.installationId,
  caller.consumerAppId
]);
var failure2 = () => ({ ok: false, error: createCapabilityError("FORBIDDEN") });
var bindingsKey = (bindings) => JSON.stringify(
  bindings.map((item) => JSON.stringify([item.capabilityId, item.packageId, item.version, item.sha256])).sort()
);
function trustFile(path5) {
  const fd = openSync(path5, "r");
  try {
    const stat = fstatSync(fd);
    if (!stat.isFile() || stat.size > 65536) throw new Error();
    const bytes = Buffer.alloc(65537);
    let size = 0;
    while (size < bytes.length) {
      const count = readSync(fd, bytes, size, bytes.length - size, null);
      if (!count) break;
      size += count;
    }
    if (size > 65536) throw new Error();
    return new CapabilityPackageTrust(
      JSON.parse(
        new TextDecoder("utf-8", { fatal: true }).decode(bytes.subarray(0, size))
      )
    );
  } finally {
    closeSync(fd);
  }
}
async function prepareInstalledHost(rootDirectory, raw, broker, runtime, services = []) {
  const stores = [];
  const authorizations = [];
  try {
    if (!Array.isArray(services) || services.length > 32 || services.length && raw.version !== 3)
      throw new Error();
    const serviceRegistry = /* @__PURE__ */ new Map();
    for (const service of services) {
      if (!service || typeof service.execute !== "function") throw new Error();
      const declaration = JSON.parse(JSON.stringify(service.declaration));
      const key = JSON.stringify([
        declaration.binding.capabilityId,
        declaration.binding.packageId,
        declaration.binding.version,
        declaration.binding.sha256
      ]);
      if (serviceRegistry.has(key)) throw new Error();
      serviceRegistry.set(key, { declaration, execute: service.execute });
    }
    const selectedServices = /* @__PURE__ */ new Set();
    if (Object.keys(raw).length !== (raw.version === 3 ? 5 : 4) || ![2, 3].includes(raw.version) || typeof raw.installationPath !== "string" || typeof raw.trustPath !== "string" || !Array.isArray(raw.consumers) || !raw.consumers.length || raw.consumers.length > 32)
      throw new Error();
    const boundedPath = async (path5) => {
      const full = await realpath(resolve(rootDirectory, path5));
      const local = relative(rootDirectory, full);
      if (local.startsWith("..") || isAbsolute(local)) throw new Error();
      return full;
    };
    const installationPath = await boundedPath(raw.installationPath);
    const trustPath = await boundedPath(raw.trustPath);
    const authorizationPath = raw.version === 3 ? await boundedPath(raw.authorizationPath) : void 0;
    const checks = /* @__PURE__ */ new Map();
    const byToken = /* @__PURE__ */ new Map();
    const conversations = /* @__PURE__ */ new Map();
    const applications = /* @__PURE__ */ new Map();
    const currentTrust = () => trustFile(trustPath);
    const registered = /* @__PURE__ */ new Set(), checked = /* @__PURE__ */ new Set();
    const byScope = /* @__PURE__ */ new Map();
    const accounts = /* @__PURE__ */ new Map();
    const tokens = /* @__PURE__ */ new Set();
    const consumers = [];
    for (const consumer of raw.consumers) {
      if (!consumer || Object.keys(consumer).length !== (raw.version === 3 ? 3 : 4) || !Object.hasOwn(consumer, "token") || !Object.hasOwn(consumer, "root") || !Object.hasOwn(consumer, "entry") || raw.version === 2 && !Object.hasOwn(consumer, "grants") || // test只开放已签名、持久授权的v3路径；旧源码/显式grants与production保持原边界。
      !(consumer.root.environment === "development" || raw.version === 3 && consumer.root.environment === "test"))
        throw new Error();
      if (typeof consumer.token !== "string" || !/^[a-f0-9]{64}$/.test(consumer.token) || tokens.has(consumer.token))
        throw new Error();
      tokens.add(consumer.token);
      const store = new CapabilityInstallationStore(installationPath, consumer.root);
      stores.push(store);
      const loaded = store.load(currentTrust());
      if (!loaded.ok) throw new Error();
      const installationId = createHash6("sha256").update(
        JSON.stringify([
          consumer.root.tenantId,
          consumer.root.accountId,
          consumer.root.applicationId,
          consumer.root.environment
        ])
      ).digest("hex");
      const policy2 = {
        tenantId: consumer.root.tenantId,
        environment: consumer.root.environment,
        installationId,
        consumerAppId: consumer.root.applicationId,
        entry: consumer.entry,
        grants: "grants" in consumer ? consumer.grants : [],
        bindings: loaded.value.plan.bindings
      };
      accounts.set(scope2(policy2), String(consumer.root.accountId));
      const checkKey = scope2(policy2) + ":" + consumer.entry;
      if (raw.version === 3 && checks.has(checkKey)) throw new Error();
      let currentAuthorization = () => true;
      if (authorizationPath) {
        const authorization = new CapabilityAuthorizationStore(
          authorizationPath,
          consumer.root,
          consumer.entry
        );
        authorizations.push(authorization);
        const snapshot5 = authorization.read();
        if (!snapshot5.ok || !snapshot5.value || snapshot5.value.status !== "active" || bindingsKey(snapshot5.value.policy.bindings) !== bindingsKey(policy2.bindings))
          throw new Error();
        policy2.grants = snapshot5.value.policy.grants;
        const expected = JSON.stringify(snapshot5.value);
        currentAuthorization = () => {
          const current = authorization.read();
          return current.ok && JSON.stringify(current.value) === expected;
        };
      }
      checks.set(checkKey, currentAuthorization);
      byToken.set(consumer.token, currentAuthorization);
      const expectedPlan = JSON.stringify(loaded.value.plan);
      conversations.set(consumer.token, () => {
        if (raw.version !== 3 || consumer.entry !== "conversation" || !currentAuthorization())
          return failure2();
        const current = store.load(currentTrust());
        if (!current.ok || JSON.stringify(current.value.plan) !== expectedPlan) return failure2();
        const tools = [];
        for (const item of current.value.packages)
          for (const capability of item.package.manifest.capabilities) {
            const { capabilityId: capabilityId2, ...contract } = capability;
            const { source: _source, ...declaration } = {
              source: void 0,
              ...contract
            };
            void _source;
            const binding2 = policy2.bindings.find((item2) => item2.capabilityId === capabilityId2);
            if (binding2 && declaration.allowedEntries.includes("conversation") && declaration.permissions.every((permission2) => policy2.grants.includes(permission2)) && (!declaration.effects.billable && !declaration.effects.externalWrite || item.package.manifest.execution === "host-service-v1"))
              tools.push({ ...declaration, binding: binding2 });
          }
        return {
          ok: true,
          value: {
            planSha256: createHash6("sha256").update(expectedPlan).digest("hex"),
            tools
          }
        };
      });
      applications.set(consumer.token, () => {
        if (raw.version !== 3 || consumer.entry !== "application" || !currentAuthorization())
          return failure2();
        const current = store.load(currentTrust());
        if (!current.ok || JSON.stringify(current.value.plan) !== expectedPlan) return failure2();
        const application = current.value.packages.find(
          (item) => item.package.manifest.execution === "static-application-v1"
        );
        if (!application || application.package.manifest.execution !== "static-application-v1")
          return failure2();
        const manifest = application.package.manifest;
        return {
          ok: true,
          value: {
            applicationId: manifest.application.applicationId,
            packageId: manifest.packageId,
            version: manifest.version,
            sha256: application.package.sha256,
            entry: manifest.application.entry,
            files: manifest.files.map((file) => ({
              ...file,
              source: application.package.sources[file.path]
            }))
          }
        };
      });
      const probe = broker.createSession(policy2);
      broker.revokeSession(probe);
      byScope.set(scope2(policy2), store);
      consumers.push({ token: consumer.token, policy: policy2 });
      for (const item of loaded.value.packages)
        for (const capability of item.package.manifest.capabilities) {
          const { capabilityId: capabilityId2, ...contract } = capability;
          const { source, ...declaration } = {
            source: void 0,
            ...contract
          };
          const binding2 = item.package.bindings.find(
            (binding3) => binding3.capabilityId === capabilityId2
          );
          const key = JSON.stringify(binding2);
          if (registered.has(key)) continue;
          let executor;
          if (item.package.manifest.execution === "host-service-v1") {
            const serviceKey = JSON.stringify([
              binding2.capabilityId,
              binding2.packageId,
              binding2.version,
              binding2.sha256
            ]);
            const service = serviceRegistry.get(serviceKey);
            if (!service || !isDeepStrictEqual2(service.declaration, { ...declaration, binding: binding2 }))
              throw new Error();
            executor = service.execute;
            selectedServices.add(serviceKey);
          } else {
            if (!source) throw new Error();
            const file = item.package.manifest.files.find((file2) => file2.path === source);
            const sourceCode = item.package.sources[source];
            if (!checked.has(file.sha256)) {
              const health = await runtime.checkSource({
                source: sourceCode,
                sourceSha256: file.sha256
              });
              if (!health.ok) throw new Error();
              checked.add(file.sha256);
            }
            executor = runtime.createExecutor({ source: sourceCode, sourceSha256: file.sha256 });
          }
          broker.register({ ...declaration, binding: binding2 }, (request, context, invoke, options) => {
            const root = byScope.get(
              JSON.stringify([
                context.tenantId,
                context.environment,
                context.installationId,
                context.consumerAppId
              ])
            );
            try {
              if (!root || !checks.get(
                scope2({ ...context, grants: [], bindings: [] }) + ":" + context.entry
              )?.())
                return {
                  protocolVersion: 1,
                  requestId: request.requestId,
                  status: "error",
                  error: createCapabilityError("FORBIDDEN")
                };
              const current = root.load(currentTrust());
              if (!current.ok || !current.value.plan.bindings.some((item2) => JSON.stringify(item2) === key))
                return {
                  protocolVersion: 1,
                  requestId: request.requestId,
                  status: "error",
                  error: createCapabilityError("FORBIDDEN")
                };
              return executor(request, context, invoke, options);
            } catch {
              return {
                protocolVersion: 1,
                requestId: request.requestId,
                status: "error",
                error: createCapabilityError("UNAVAILABLE")
              };
            }
          });
          registered.add(key);
        }
    }
    if (selectedServices.size !== serviceRegistry.size) throw new Error();
    const leases = {
      acquire(task, caller) {
        const store = byScope.get(scope2(caller));
        if (!store || !checks.get(scope2(caller) + ":" + caller.entry)?.()) return failure2();
        if (!caller.bindings.some(
          (binding2) => JSON.stringify(binding2) === JSON.stringify(task.binding)
        ))
          return failure2();
        const result = store.acquireLease(
          task.taskId,
          task.requestId,
          caller.bindings,
          currentTrust()
        );
        return result.ok ? { ok: true, value: null } : result;
      },
      release(task, owner3) {
        const store = byScope.get(owner3);
        if (!store) return failure2();
        const lease = store.getLease(task.taskId);
        if (!lease.ok) return lease;
        if (lease.value.requestId !== task.requestId || !lease.value.plan.bindings.some(
          (binding2) => JSON.stringify(binding2) === JSON.stringify(task.binding)
        ))
          return failure2();
        const result = store.releaseLease(task.taskId);
        return result.ok ? { ok: true, value: null } : result;
      }
    };
    return {
      consumers,
      leases,
      authorized: (token) => byToken.get(token)?.() ?? false,
      application: (token) => applications.get(token)?.() ?? failure2(),
      conversation: (token) => conversations.get(token)?.() ?? failure2(),
      accountKey: (caller) => {
        const account = accounts.get(scope2(caller));
        if (!account) throw new Error("Unknown trusted installation account.");
        return account;
      },
      validateCaller: (caller) => {
        try {
          if (!checks.get(scope2(caller) + ":" + caller.entry)?.()) return false;
          const current = byScope.get(scope2(caller))?.load(currentTrust());
          return !!current?.ok && bindingsKey(current.value.plan.bindings) === bindingsKey(caller.bindings);
        } catch {
          return false;
        }
      },
      close: () => {
        stores.forEach((store) => store.close());
        authorizations.forEach((store) => store.close());
      }
    };
  } catch {
    stores.forEach((store) => store.close());
    authorizations.forEach((store) => store.close());
    throw new Error("Installed development configuration unavailable.");
  }
}

// ../../packages/capability-dev-host/src/index.ts
import { createServer } from "node:http";
import { readFile, realpath as realpath2, mkdir, appendFile } from "node:fs/promises";
import { dirname, resolve as resolve2, relative as relative2, isAbsolute as isAbsolute2, join as join2 } from "node:path";
import { createHash as createHash8, timingSafeEqual, randomBytes } from "node:crypto";
import { fileURLToPath } from "node:url";

// ../../packages/capability-dev-host/src/fixtures.ts
import { DatabaseSync as DatabaseSync10 } from "node:sqlite";
import { join } from "node:path";
import { createHash as createHash7 } from "node:crypto";
var fixtureBindings = {
  text: {
    capabilityId: "platform/read-text",
    packageId: "platform/reference-fixtures",
    version: "0.1.0",
    sha256: createHash7("sha256").update("local-reference-fixture-v1").digest("hex")
  },
  model: {
    capabilityId: "platform/infer",
    packageId: "platform/reference-fixtures",
    version: "0.1.0",
    sha256: createHash7("sha256").update("local-reference-fixture-v1").digest("hex")
  }
};
var owner2 = (scope3) => JSON.stringify([scope3.tenantId, scope3.environment, scope3.installationId, scope3.consumerAppId]);
function createReferenceFixtures(broker, consumers, dataDirectory) {
  const references = new CapabilityReferences();
  const ledger = new DatabaseSync10(join(dataDirectory, "fixture-charges.sqlite"));
  try {
    ledger.exec(
      "PRAGMA synchronous=FULL; CREATE TABLE IF NOT EXISTS charges(scope TEXT, request_id TEXT, prompt TEXT, reference_id TEXT, result TEXT, PRIMARY KEY(scope,request_id));"
    );
    references.registerCapabilities(broker, fixtureBindings);
    for (const consumer of consumers) {
      const ref = consumer.references;
      if (!ref) throw new Error("Missing fixture references.");
      references.issueText(consumer.policy, ref.text, ref.textId);
      references.issueModelProvider(
        consumer.policy,
        {
          infer: async (prompt, context, requestId) => {
            const key = owner2(context);
            const previous = ledger.prepare("SELECT * FROM charges WHERE scope=? AND request_id=?").get(key, requestId);
            const result = { model: "local-fixture", text: prompt.toUpperCase() };
            if (previous && (previous.prompt !== prompt || previous.reference_id !== ref.modelId))
              throw new Error("Mock request conflict.");
            if (!previous)
              ledger.prepare("INSERT INTO charges VALUES (?,?,?,?,?)").run(key, requestId, prompt, ref.modelId, JSON.stringify(result));
            if (prompt === "__unknown__") throw new Error("Mock response lost after charge.");
            return result;
          },
          query: async (prompt, context, requestId) => {
            const row = ledger.prepare("SELECT * FROM charges WHERE scope=? AND request_id=?").get(owner2(context), requestId);
            if (!row || row.reference_id !== ref.modelId || row.prompt !== prompt)
              throw new Error("No original fixture request.");
            return JSON.parse(row.result);
          }
        },
        ref.modelId
      );
    }
  } catch (error4) {
    ledger.close();
    throw error4;
  }
  return {
    close: () => ledger.close(),
    query: createModelTaskQuery(references)
  };
}

// ../../packages/capability-dev-host/src/browser.ts
var DEVELOPMENT_PAGE = `<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Sitoo \u5E94\u7528\u5F00\u53D1\u9884\u89C8</title>
<meta name="development-script-nonce" content="__SCRIPT_NONCE__">
<style>body{font:16px system-ui;margin:24px;color:#18202b;background:#f6f7f9}main{max-width:1100px;margin:auto}form{display:flex;gap:12px;flex-wrap:wrap}input{flex:1;min-width:240px;padding:10px}button{padding:10px 18px}iframe{width:100%;height:540px;border:1px solid #ccd2dc;background:white}#status{min-height:24px}</style>
<main><h1>\u5E94\u7528\u5F00\u53D1\u9884\u89C8</h1><p>\u8F93\u5165\u672C\u673A\u5E94\u7528\u5F00\u53D1\u4EE4\u724C\uFF0C\u6253\u5F00\u5DF2\u5B89\u88C5\u7684\u7B7E\u540D\u9875\u9762\u3002\u4EE4\u724C\u4EC5\u4FDD\u7559\u5728\u6B64\u9884\u89C8\u7A97\u53E3\u3002</p>
<form id="open"><label for="token">\u5F00\u53D1\u4EE4\u724C</label><input id="token" type="password" autocomplete="off" required maxlength="64"><button>\u6253\u5F00\u5E94\u7528</button><button type="button" id="close">\u5173\u95ED\u9875\u9762</button></form>
<p id="status" role="status">\u7B49\u5F85\u6253\u5F00\u5E94\u7528</p><div id="container"></div><p><a href="/development/operator">\u6253\u5F00\u4EFB\u52A1\u786E\u8BA4\u4E0E\u6838\u5BF9</a> \xB7 <a href="/development/conversation">\u6253\u5F00\u5F00\u53D1\u5BF9\u8BDD</a></p></main>
<script type="module" src="/development/client.mjs"></script></html>`;
var DEVELOPMENT_CSP = "default-src 'none'; script-src 'self' 'nonce-__SCRIPT_NONCE__'; style-src 'unsafe-inline'; img-src data:; connect-src 'self'; frame-src 'self'; base-uri 'none'; form-action 'none'; object-src 'none'; frame-ancestors 'none'";
var CONVERSATION_PAGE = `<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Sitoo \u5F00\u53D1\u5BF9\u8BDD</title>
<style>body{font:16px system-ui;margin:24px;color:#18202b;background:#f6f7f9}main{max-width:960px;margin:auto}section{padding:20px;margin:16px 0;background:white;border:1px solid #ccd2dc;border-radius:8px}form{display:flex;gap:12px;flex-wrap:wrap}input,textarea{padding:10px;box-sizing:border-box}input{flex:1;min-width:240px}textarea{width:100%;min-height:100px}button{padding:10px 18px;cursor:pointer}button:disabled{cursor:default}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f0f2f5;padding:12px}#status{min-height:24px}li{margin:8px 0}</style>
<main><h1>\u5F00\u53D1\u5BF9\u8BDD</h1><p>\u8FDE\u63A5\u672C\u673A\u5BF9\u8BDD\u8EAB\u4EFD\uFF0C\u67E5\u770B\u8C03\u7528\u63D0\u6848\u540E\u63D0\u4EA4\u3002\u5173\u95ED\u7A97\u53E3\u540E\uFF0C\u53EF\u91CD\u65B0\u8FDE\u63A5\u67E5\u8BE2\u539F\u4EFB\u52A1\u3002</p>
<section><form id="connect"><label for="token">\u5BF9\u8BDD\u5F00\u53D1\u4EE4\u724C</label><input id="token" type="password" autocomplete="off" maxlength="64" required><button>\u8FDE\u63A5\u5BF9\u8BDD</button><button type="button" id="disconnect">\u65AD\u5F00\u8FDE\u63A5</button></form><p id="status" role="status">\u7B49\u5F85\u8FDE\u63A5</p><h2>\u53EF\u7528\u5DE5\u5177</h2><ul id="tools"></ul></section>
<section><h2>\u9700\u6C42\u4E0E\u63D0\u6848</h2><label for="prompt">\u8F93\u5165\u9700\u6C42</label><textarea id="prompt" maxlength="8192" disabled placeholder="\u672C\u5730\u6D4B\u8BD5\u5939\u5177\u793A\u4F8B\uFF1A\u8BF7\u8C03\u7528 bob/prepare \u5904\u7406\uFF1A hello "></textarea><p><button id="plan" disabled>\u751F\u6210\u63D0\u6848</button> <button id="submit" disabled>\u63D0\u4EA4\u63D0\u6848</button></p><pre id="proposal">\u7B49\u5F85\u751F\u6210\u63D0\u6848</pre></section>
<section><h2>\u624B\u52A8\u586B\u5199\u5DE5\u5177\u53C2\u6570</h2><p>\u6A21\u578B\u4E0D\u53EF\u7528\u65F6\uFF0C\u9009\u62E9\u5DF2\u6388\u6743\u5DE5\u5177\u5E76\u6309\u4E0B\u65B9\u7ED3\u6784\u586B\u5199 JSON\u3002\u6821\u9A8C\u53EA\u751F\u6210\u63D0\u6848\uFF0C\u786E\u8BA4\u540E\u518D\u63D0\u4EA4\u3002</p><label>\u5DE5\u5177<select id="capability" disabled></select></label><pre id="schema"></pre><label>\u53C2\u6570<textarea id="arguments" maxlength="65536" disabled>{}</textarea></label><button id="prepare" disabled>\u6821\u9A8C\u786E\u5B9A\u6027\u63D0\u6848</button></section><section><h2>\u539F\u4EFB\u52A1\u7ED3\u679C</h2><p><button id="query" disabled>\u67E5\u8BE2\u539F\u4EFB\u52A1</button> <button id="history" disabled>\u5237\u65B0\u4EFB\u52A1\u5217\u8868</button> <button id="artifact" disabled>\u8BFB\u53D6\u539F\u4EFB\u52A1\u56FE\u7247</button></p><pre id="result">\u5C1A\u672A\u63D0\u4EA4\u4EFB\u52A1</pre><img id="artifact-image" alt="\u539F\u4EFB\u52A1\u56FE\u7247" hidden><ul id="tasks"></ul></section>
<p><a href="/development/operator">\u6253\u5F00\u4EFB\u52A1\u786E\u8BA4\u4E0E\u6838\u5BF9</a> \xB7 <a href="/development">\u8FD4\u56DE\u5E94\u7528\u5F00\u53D1\u9884\u89C8</a></p></main><script type="module" src="/development/conversation.mjs"></script></html>`;
var OPERATOR_PAGE = `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>\u5F00\u53D1\u4EFB\u52A1\u786E\u8BA4\u4E0E\u6838\u5BF9</title><style>body{font:16px system-ui;margin:24px}form{display:flex;gap:12px;flex-wrap:wrap}input,button{padding:10px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f0f2f5;padding:12px}</style><main><h1>\u5F00\u53D1\u4EFB\u52A1\u786E\u8BA4\u4E0E\u6838\u5BF9</h1><p>\u4EC5\u4F9B\u53EF\u4FE1\u5F00\u53D1\u64CD\u4F5C\u8005\u3002\u6D88\u8D39\u4EE4\u724C\u9650\u5B9A\u4EFB\u52A1\u8EAB\u4EFD\uFF1B\u72EC\u7ACB\u5BC6\u94A5\u7528\u4E8E\u786E\u8BA4\u3002\u5BC6\u94A5\u53EA\u4FDD\u7559\u5728\u6B64\u7A97\u53E3\u5185\u5B58\u3002\u6838\u5BF9\u53EA\u67E5\u8BE2\u539F\u7ED3\u679C\uFF0C\u4E0A\u6E38\u4E0D\u53EF\u67E5\u8BE2\u65F6\u4FDD\u7559\u672A\u77E5\u72B6\u6001\u3002</p><form id="connect"><label>\u6D88\u8D39\u4EE4\u724C<input id="token" type="password" autocomplete="off" maxlength="64" required></label><label>\u64CD\u4F5C\u8005\u5BC6\u94A5<input id="operator" type="password" autocomplete="off" maxlength="64" required></label><button>\u8FDE\u63A5\u4EFB\u52A1</button><button id="disconnect" type="button">\u65AD\u5F00\u8FDE\u63A5</button></form><p id="status" role="status">\u7B49\u5F85\u8FDE\u63A5</p><button id="history" disabled>\u5237\u65B0\u539F\u4EFB\u52A1</button><ul id="tasks"></ul><h2>\u539F\u4EFB\u52A1</h2><pre id="result"></pre><h2>\u5F85\u786E\u8BA4\u8C03\u7528</h2><p>\u6838\u5BF9\u7ED1\u5B9A\u3001\u53C2\u6570\u548C\u4FEE\u8BA2\u540E\uFF0C\u660E\u786E\u5141\u8BB8\u6B64\u8C03\u7528\u6267\u884C\u3002</p><pre id="confirmation"></pre><button id="approve" disabled>\u786E\u8BA4\u672C\u6B21\u8C03\u7528</button><button id="reconcile" disabled>\u6838\u5BF9\u539F\u7ED3\u679C</button><p><a href="/development">\u8FD4\u56DE\u5E94\u7528\u5F00\u53D1\u9884\u89C8</a> \xB7 <a href="/development/conversation">\u6253\u5F00\u5F00\u53D1\u5BF9\u8BDD</a></p></main><script type="module" src="/development/operator.mjs"></script></html>`;

// ../../packages/capability-dev-host/src/health.ts
var HEALTH_CHECK_LIMITS = Object.freeze({
  cases: 8,
  caseWaitMs: 1e4,
  fileBytes: PROTOCOL_LIMITS.requestBytes
});

// ../../packages/capability-dev-host/src/index.ts
var error3 = (code) => ({ ok: false, error: createCapabilityError(code) });
var InvalidRequest = class extends Error {
};
async function boundedFile(path5, limit = PROTOCOL_LIMITS.requestBytes) {
  const contents = await readFile(path5);
  if (contents.length > limit) throw new Error("Input exceeds development limit.");
  return contents.toString("utf8");
}
async function body(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > PROTOCOL_LIMITS.requestBytes) throw new InvalidRequest();
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new InvalidRequest();
  }
}
function send(res, status, value) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff"
  });
  res.end(JSON.stringify(value));
}
async function startDevelopmentHost(options) {
  const configPath = await realpath2(options.configPath);
  const planningTimeout = options.conversationPlanningTimeoutMs ?? 5e3;
  if (!Number.isSafeInteger(planningTimeout) || planningTimeout < 5e3 || planningTimeout > 3e4)
    throw new Error("Invalid planning timeout.");
  const browserClient = await boundedFile(
    fileURLToPath(new URL("./browser-client.mjs", import.meta.url))
  );
  const conversationBrowser = await boundedFile(
    fileURLToPath(new URL("./conversation-browser.mjs", import.meta.url))
  );
  const root = dirname(configPath);
  const operatorBrowser = await boundedFile(
    fileURLToPath(new URL("./operator-browser.mjs", import.meta.url))
  );
  const rawConfig = JSON.parse(await boundedFile(configPath));
  if ((options.installedServices || options.taskQuery || options.taskArtifact || options.confirmationToken) && (rawConfig.version !== 3 || !options.installedServices?.length || !options.confirmationToken))
    throw new Error("Trusted installed service configuration unavailable.");
  if (options.taskQuery !== void 0 && typeof options.taskQuery !== "function")
    throw new Error("Invalid trusted query port.");
  if (options.confirmationToken && (!/^[a-f0-9]{64}$/.test(options.confirmationToken) || rawConfig.consumers.some((consumer) => consumer.token === options.confirmationToken)))
    throw new Error("Invalid confirmation key.");
  let config = rawConfig;
  if (rawConfig.version !== 2 && rawConfig.version !== 3 && (config.version !== 1 || !Array.isArray(config.capabilities) || !Array.isArray(config.consumers) || config.capabilities.length < 1 || config.capabilities.length > 32 || config.consumers.length < 1 || config.consumers.length > 32))
    throw new Error("Invalid development host configuration.");
  const data = resolve2(options.dataDirectory);
  await mkdir(data, { recursive: true });
  const broker = new CapabilityBroker({
    onDiagnostic: (diagnostic) => appendFile(join2(data, "diagnostics.jsonl"), JSON.stringify(diagnostic) + "\n", {
      mode: 384
    })
  });
  const runtime = new CapabilityRuntime();
  const installed = rawConfig.version === 2 || rawConfig.version === 3 ? await prepareInstalledHost(root, rawConfig, broker, runtime, options.installedServices) : void 0;
  if (installed) config = { version: 1, capabilities: [], consumers: installed.consumers };
  for (const capability of config.capabilities) {
    const sourcePath = await realpath2(resolve2(root, capability.source));
    const local = relative2(root, sourcePath);
    if (local.startsWith("..") || isAbsolute2(local))
      throw new Error("Source must be inside the development project.");
    const source = await boundedFile(sourcePath);
    broker.register(
      capability.declaration,
      runtime.createExecutor({ source, sourceSha256: capability.sourceSha256 })
    );
  }
  const seen = /* @__PURE__ */ new Set();
  const consumers = config.consumers.map(({ token, policy: policy2 }) => {
    if (typeof token !== "string" || !/^[a-f0-9]{64}$/.test(token) || seen.has(token) || !(policy2.environment === "development" || installed && rawConfig.version === 3 && policy2.environment === "test"))
      throw new Error("Invalid development consumer.");
    seen.add(token);
    return {
      digest: createHash8("sha256").update(token).digest(),
      session: broker.createSession(policy2),
      entry: policy2.entry,
      // A startup page snapshot identifies the original read-only task consumer.
      applicationSha256: (() => {
        const application = installed?.application(token);
        return application?.ok ? application.value.sha256 : void 0;
      })()
    };
  });
  const confirmationToken = options.confirmationToken ?? config.fixtureConfirmationToken;
  if (confirmationToken && (!/^[a-f0-9]{64}$/.test(confirmationToken) || seen.has(confirmationToken)))
    throw new Error("Invalid fixture confirmation key.");
  const confirmation = confirmationToken ? createHash8("sha256").update(confirmationToken).digest() : void 0;
  const taskQuery = options.taskQuery;
  const fixtures = config.fixtureConfirmationToken ? createReferenceFixtures(broker, config.consumers, data) : void 0;
  let tasks;
  try {
    tasks = new CapabilityTasks({
      path: join2(data, "tasks.sqlite"),
      broker,
      allowEffects: !!confirmation,
      query: fixtures?.query ?? (taskQuery ? async (task, signal, context) => {
        if (!installed?.validateCaller(context.caller))
          throw new Error("Original service result unavailable.");
        const result = await taskQuery(task, signal, context);
        if (!installed.validateCaller(context.caller))
          throw new Error("Original service result unavailable.");
        return result;
      } : void 0),
      packageLeases: installed?.leases,
      accountKey: installed?.accountKey,
      sharedQuotaPath: options.sharedQuotaPath
    });
  } catch (error4) {
    fixtures?.close();
    installed?.close();
    throw error4;
  }
  let origin = "";
  const scriptNonce = randomBytes(16).toString("hex");
  const server = createServer(async (req, res) => {
    try {
      const url = new URL(req.url ?? "/", origin);
      const browserTask = url.pathname === "/v1/tasks" || url.pathname.startsWith("/v1/tasks/");
      const browserOrigin = rawConfig.version === 3 && req.headers.origin === origin && (url.pathname === "/v1/application" || browserTask || url.pathname.startsWith("/v1/confirmations/") || ["/v1/conversation/tools", "/v1/conversation/plan", "/v1/conversation/prepare"].includes(
        url.pathname
      ));
      const shellRoutes = [
        "/development",
        "/development/client.mjs",
        "/development/conversation",
        "/development/conversation.mjs",
        "/development/operator",
        "/development/operator.mjs"
      ];
      const shellOrigin = req.headers.origin === origin && req.method === "GET" && shellRoutes.includes(url.pathname);
      if (req.headers.origin && !browserOrigin && !shellOrigin || req.headers.host !== origin.slice("http://".length)) {
        send(res, 403, error3("FORBIDDEN"));
        return;
      }
      if (req.method === "GET" && !url.search && shellRoutes.includes(url.pathname)) {
        res.writeHead(200, {
          "content-type": !url.pathname.endsWith(".mjs") ? "text/html; charset=utf-8" : "text/javascript; charset=utf-8",
          "content-security-policy": DEVELOPMENT_CSP.replaceAll("__SCRIPT_NONCE__", scriptNonce),
          "cache-control": "no-store",
          "x-content-type-options": "nosniff",
          "referrer-policy": "no-referrer",
          "permissions-policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=()"
        });
        res.end(
          url.pathname === "/development" ? DEVELOPMENT_PAGE.replaceAll("__SCRIPT_NONCE__", scriptNonce) : url.pathname === "/development/client.mjs" ? browserClient : url.pathname === "/development/conversation" ? CONVERSATION_PAGE : url.pathname === "/development/conversation.mjs" ? conversationBrowser : url.pathname === "/development/operator" ? OPERATOR_PAGE : operatorBrowser
        );
        return;
      }
      const authorization = req.headers.authorization;
      if (!authorization || !/^Bearer [a-f0-9]{64}$/.test(authorization)) {
        send(res, 401, error3("UNAUTHENTICATED"));
        return;
      }
      const digest3 = createHash8("sha256").update(authorization.slice(7)).digest();
      const consumer = consumers.find((candidate) => timingSafeEqual(candidate.digest, digest3));
      if (!consumer) {
        send(res, 401, error3("UNAUTHENTICATED"));
        return;
      }
      const pagePin = req.headers["x-sitoo-application"];
      const conversationPin = req.headers["x-sitoo-conversation"];
      const conversationAuthorized = () => {
        const catalog = installed?.conversation(authorization.slice(7));
        return typeof conversationPin === "string" && catalog?.ok && catalog.value.planSha256 === conversationPin;
      };
      if (browserTask && conversationPin !== void 0 && !conversationAuthorized()) {
        send(res, 403, error3("FORBIDDEN"));
        return;
      }
      const pageAuthorized = () => {
        const page = installed?.application(authorization.slice(7));
        return typeof pagePin === "string" && /^[a-f0-9]{64}$/.test(pagePin) && page?.ok && page.value.sha256 === pagePin;
      };
      const pageRequest = pagePin !== void 0 || browserOrigin && consumer.entry === "application";
      const originalTaskRead = req.method === "GET" && (url.pathname === "/v1/tasks" || /^\/v1\/tasks\/[a-f0-9-]{36}$/.test(url.pathname));
      const pageAllowed = originalTaskRead ? typeof pagePin === "string" && pagePin === consumer.applicationSha256 : pageAuthorized();
      if (browserTask && pageRequest && !pageAllowed) {
        send(res, 403, error3("FORBIDDEN"));
        return;
      }
      if (browserTask && browserOrigin && (consumer.entry === "service" || consumer.entry === "conversation" && req.method === "POST" && url.pathname === "/v1/tasks" && !conversationAuthorized())) {
        send(res, 403, error3("FORBIDDEN"));
        return;
      }
      if (req.method === "GET" && url.pathname === "/v1/application" && !url.search) {
        const result = installed?.application(authorization.slice(7)) ?? error3("FORBIDDEN");
        send(res, result.ok ? 200 : 403, result);
        return;
      }
      if (!url.search && url.pathname === "/v1/conversation/tools" && req.method === "GET") {
        const catalog = installed?.conversation(authorization.slice(7)) ?? error3("FORBIDDEN");
        send(res, catalog.ok ? 200 : 403, catalog);
        return;
      }
      if (!url.search && url.pathname === "/v1/conversation/prepare" && req.method === "POST") {
        const input = await body(req);
        const catalog = installed?.conversation(authorization.slice(7));
        if (!catalog?.ok) {
          send(res, 403, error3("FORBIDDEN"));
          return;
        }
        const prepared = broker.prepare(consumer.session, input, {
          inspectEffects: !!confirmation
        });
        send(
          res,
          prepared.ok ? 200 : 400,
          prepared.ok ? {
            ok: true,
            value: {
              request: prepared.value.request,
              binding: prepared.value.binding,
              planSha256: catalog.value.planSha256
            }
          } : prepared
        );
        return;
      }
      if (!url.search && url.pathname === "/v1/conversation/plan" && req.method === "POST") {
        const catalog = installed?.conversation(authorization.slice(7));
        if (!catalog?.ok) {
          send(res, 403, error3("FORBIDDEN"));
          return;
        }
        const input = await body(req);
        if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).length !== 2 || !("requestId" in input) || !("text" in input) || typeof input.requestId !== "string" || !/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(
          input.requestId
        ) || typeof input.text !== "string" || !input.text.length || input.text.length > 8192) {
          send(res, 400, error3("INVALID_INPUT"));
          return;
        }
        if (!options.conversationPlanner) {
          send(res, 503, error3("UNAVAILABLE"));
          return;
        }
        const beforePlanning = installed?.conversation(authorization.slice(7));
        if (!beforePlanning?.ok || beforePlanning.value.planSha256 !== catalog.value.planSha256) {
          send(res, 403, error3("FORBIDDEN"));
          return;
        }
        const controller = new AbortController();
        let timer;
        let proposal;
        try {
          proposal = await Promise.race([
            options.conversationPlanner({
              text: input.text,
              requestId: input.requestId,
              tools: structuredClone(catalog.value.tools),
              signal: controller.signal
            }),
            new Promise((_, reject2) => {
              timer = setTimeout(() => {
                controller.abort();
                reject2(new Error());
              }, planningTimeout);
            })
          ]);
        } finally {
          clearTimeout(timer);
          controller.abort();
        }
        const current = installed?.conversation(authorization.slice(7));
        if (!current?.ok || current.value.planSha256 !== catalog.value.planSha256) {
          send(res, 403, error3("FORBIDDEN"));
          return;
        }
        if (!proposal || typeof proposal !== "object" || Array.isArray(proposal) || Object.keys(proposal).length !== 2 || !("capabilityId" in proposal) || !("input" in proposal) || !catalog.value.tools.some((tool) => tool.binding.capabilityId === proposal.capabilityId)) {
          send(res, 400, error3("INVALID_INPUT"));
          return;
        }
        const request = {
          protocolVersion: 1,
          requestId: input.requestId,
          capabilityId: proposal.capabilityId,
          input: proposal.input
        };
        const prepared = broker.prepare(consumer.session, request, {
          inspectEffects: !!confirmation
        });
        send(
          res,
          prepared.ok ? 200 : 400,
          prepared.ok ? {
            ok: true,
            value: {
              request: prepared.value.request,
              binding: prepared.value.binding,
              planSha256: catalog.value.planSha256
            }
          } : prepared
        );
        return;
      }
      const confirmationRoute = /^\/v1\/confirmations\/([a-f0-9-]{36})$/.exec(url.pathname);
      if (confirmationRoute && !url.search && (req.method === "GET" || req.method === "POST")) {
        const token = req.headers["x-fixture-confirmation"];
        if (!confirmation || typeof token !== "string" || !/^[a-f0-9]{64}$/.test(token) || !timingSafeEqual(confirmation, createHash8("sha256").update(token).digest())) {
          send(res, 403, error3("FORBIDDEN"));
          return;
        }
        const input = req.method === "POST" ? await body(req) : void 0;
        if (req.method === "POST" && (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).length !== 1 || !("revision" in input) || !Number.isSafeInteger(input.revision))) {
          send(res, 400, error3("INVALID_INPUT"));
          return;
        }
        const result = req.method === "GET" ? tasks.getConfirmation(consumer.session, confirmationRoute[1]) : tasks.approve(
          consumer.session,
          confirmationRoute[1],
          input.revision
        );
        send(res, result.ok ? 200 : 400, result);
        return;
      }
      const artifactRoute = /^\/v1\/tasks\/([a-f0-9-]{36})\/artifact$/.exec(url.pathname);
      if (artifactRoute && !url.search && req.method === "GET") {
        const caller = broker.getCaller(consumer.session);
        const original = tasks.get(consumer.session, artifactRoute[1]);
        const allowed = () => caller.ok && caller.value.grants.includes("resource:read") && installed?.validateCaller(caller.value) && (!pageRequest || pageAuthorized()) && (conversationPin === void 0 || conversationAuthorized());
        if (!options.taskArtifact || !caller.ok || !original.ok || original.value.status !== "completed" || !["platform/generate-image", "platform/image-request"].includes(
          original.value.capabilityId
        ) || !allowed()) {
          send(res, 403, error3("FORBIDDEN"));
          return;
        }
        const artifact = await options.taskArtifact(
          Object.freeze(structuredClone(original.value)),
          Object.freeze({
            tenantId: caller.value.tenantId,
            environment: caller.value.environment,
            installationId: caller.value.installationId,
            consumerAppId: caller.value.consumerAppId
          })
        );
        if (!allowed() || artifact.mimeType !== "image/png" || typeof artifact.dataUrl !== "string" || artifact.dataUrl.length > Math.ceil(16 * 1024 * 1024 / 3) * 4 + 32 || !/^data:image\/png;base64,[A-Za-z0-9+/]+={0,2}$/.test(artifact.dataUrl)) {
          send(res, 403, error3("FORBIDDEN"));
          return;
        }
        send(res, 200, { ok: true, value: artifact });
        return;
      }
      const queryRoute = /^\/v1\/tasks\/([a-f0-9-]{36})\/reconcile$/.exec(url.pathname);
      if (queryRoute && !url.search && req.method === "POST") {
        const result = await tasks.reconcile(consumer.session, queryRoute[1]);
        send(res, result.ok ? 200 : 400, result);
        return;
      }
      if (req.method === "POST" && url.pathname === "/v1/tasks" && !url.search) {
        if (installed && !installed.authorized(authorization.slice(7))) {
          send(res, 403, error3("FORBIDDEN"));
          return;
        }
        const input = await body(req);
        if (pageRequest && !pageAuthorized()) {
          send(res, 403, error3("FORBIDDEN"));
          return;
        }
        if (conversationPin !== void 0 && !conversationAuthorized()) {
          send(res, 403, error3("FORBIDDEN"));
          return;
        }
        const submitted = tasks.submit(consumer.session, input);
        send(res, submitted.ok ? 202 : 400, submitted);
        return;
      }
      if (req.method === "GET" && url.pathname === "/v1/tasks") {
        if ([...url.searchParams.keys()].some((key) => !["limit", "offset"].includes(key))) {
          send(res, 400, error3("INVALID_INPUT"));
          return;
        }
        const listed = tasks.list(consumer.session, {
          limit: url.searchParams.has("limit") ? Number(url.searchParams.get("limit")) : void 0,
          offset: url.searchParams.has("offset") ? Number(url.searchParams.get("offset")) : void 0
        });
        send(res, listed.ok ? 200 : 400, listed);
        return;
      }
      const match = /^\/v1\/tasks\/([a-f0-9-]{36})(\/cancel)?$/.exec(url.pathname);
      if (match && !url.search && (req.method === "GET" && !match[2] || req.method === "POST" && match[2])) {
        const result = match[2] ? tasks.cancel(consumer.session, match[1]) : tasks.get(consumer.session, match[1]);
        send(res, result.ok ? 200 : result.error.code === "FORBIDDEN" ? 403 : 400, result);
        return;
      }
      send(res, 404, error3("UNAVAILABLE"));
    } catch (cause) {
      if (!res.headersSent)
        send(
          res,
          cause instanceof InvalidRequest ? 400 : 503,
          error3(cause instanceof InvalidRequest ? "INVALID_INPUT" : "UNAVAILABLE")
        );
      else res.end();
    }
  });
  server.requestTimeout = 5e3;
  server.headersTimeout = 5e3;
  server.maxConnections = 32;
  try {
    await new Promise((resolve3, reject2) => {
      server.once("error", reject2);
      server.listen(0, "127.0.0.1", () => {
        server.off("error", reject2);
        resolve3();
      });
    });
  } catch (error4) {
    tasks.close();
    fixtures?.close();
    installed?.close();
    throw error4;
  }
  const address = server.address();
  if (!address || typeof address === "string") {
    tasks.close();
    fixtures?.close();
    installed?.close();
    throw new Error("Invalid development address.");
  }
  origin = `http://127.0.0.1:${address.port}`;
  let closed = false;
  return {
    url: origin,
    async close() {
      if (closed) return;
      closed = true;
      for (const consumer of consumers) broker.revokeSession(consumer.session);
      tasks.close();
      installed?.close();
      fixtures?.close();
      server.closeAllConnections();
      await new Promise((resolve3) => server.close(() => resolve3()));
    }
  };
}

// ../../packages/capability-dev-host/src/service-host.ts
function createModelTaskQuery(references) {
  return async (task, signal, { request, caller }) => {
    if (task.capabilityId !== "platform/infer" || request.capabilityId !== task.capabilityId || request.requestId !== task.requestId || !caller.bindings.some((binding2) => JSON.stringify(binding2) === JSON.stringify(task.binding)))
      throw new Error("Original model task unavailable.");
    const value = await references.queryModel(caller, request, signal);
    return { protocolVersion: 1, requestId: task.requestId, status: "success", value };
  };
}
export {
  CapabilityAuthorizationStore,
  CapabilityBroker,
  CapabilityInstallationStore,
  CapabilityPackageTrust,
  CapabilityReferenceStore,
  CapabilityReferences,
  CapabilityReleaseStore,
  CapabilityRuntime,
  CapabilityTasks,
  ModelRequestLedger,
  createDurableModelProvider,
  createImageService,
  createModelTaskQuery,
  createRequestService,
  imageCapabilityDeclaration,
  prepareInstalledHost,
  requestCapabilityDeclaration,
  signCapabilityPackage,
  startDevelopmentHost,
  verifyCapabilityPackage
};
