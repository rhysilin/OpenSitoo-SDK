// Trusted Node adapter acceptance using only the public, copied distribution.
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import {
  CapabilityReferenceStore,
  ModelRequestLedger,
  createRequestService,
} from './service-host.mjs';

const directory = await mkdtemp(join(tmpdir(), 'sitoo-structured-contract-'));
let executed = 0;
try {
  for (const kind of ['text', 'image']) {
    const store = new CapabilityReferenceStore(join(directory, kind + '-references.sqlite'));
    let ledger = new ModelRequestLedger(join(directory, kind + '-ledger.sqlite'));
    const scope = {
      tenantId: 'external',
      environment: 'development',
      installationId: 'install',
      consumerAppId: 'consumer.app',
    };
    const binding = {
      capabilityId: 'platform/' + kind + '-request',
      packageId: 'platform/requests',
      version: '1.0.0',
      sha256: 'a'.repeat(64),
    };
    const referenceId = randomUUID();
    store.issue(scope, referenceId, {
      kind: 'model',
      providerId: kind === 'image' ? 'image/' + 'b'.repeat(64) : 'newapi/local-fixture',
      providerRevision: 1,
    });
    const parameters =
      kind === 'text'
        ? {
            prompt: 'x'.repeat(6000),
            instructions: 'preserve instructions',
            maxTokens: 8192,
            responseSchema: { type: 'object', properties: { title: { type: 'string' } } },
          }
        : {
            prompt: 'original image',
            aspectRatio: '2:3',
            resolution: '1K',
            attachments: [{ id: randomUUID(), description: 'original logo' }],
          };
    const request = {
      protocolVersion: 1,
      requestId: randomUUID(),
      capabilityId: binding.capabilityId,
      input: { referenceId, parameters },
    };
    const caller = {
      ...scope,
      entry: 'application',
      resolvedPackage: {
        packageId: binding.packageId,
        version: binding.version,
        sha256: binding.sha256,
      },
      grants: ['model:infer', 'resource:read'],
      delegation: [],
    };
    let calls = 0,
      queries = 0,
      originalId,
      available = false;
    const upstream = {
      async infer(record) {
        calls++;
        executed++;
        originalId = record.upstreamRequestId;
        assert.deepEqual(JSON.parse(record.prompt), parameters);
        throw Error('lost reply');
      },
      async query(record) {
        queries++;
        assert.equal(record.upstreamRequestId, originalId);
        assert.deepEqual(JSON.parse(record.prompt), parameters);
        if (!available) throw Error('unavailable');
        return { taskId: originalId };
      },
    };
    const create = () => createRequestService({ binding, store, ledger, upstream });
    let service = create();
    const execute = () =>
      service.execute(request, caller, async () => {
        throw Error('No delegation');
      });
    try {
      assert.equal((await execute()).status, 'error');
      assert.equal(calls, 1);
      ledger.close();
      ledger = new ModelRequestLedger(join(directory, kind + '-ledger.sqlite'));
      service = create();
      assert.equal((await execute()).status, 'error');
      const task = { capabilityId: binding.capabilityId, requestId: request.requestId, binding };
      const context = {
        request,
        caller: { ...scope, entry: 'application', bindings: [binding], grants: caller.grants },
      };
      await assert.rejects(service.query(task, new AbortController().signal, context));
      available = true;
      assert.deepEqual((await service.query(task, new AbortController().signal, context)).value, {
        taskId: originalId,
      });
      assert.equal(calls, 1);
      assert.equal(queries, 2);
      assert.equal(
        (
          await service.execute(
            { ...request, requestId: randomUUID() },
            { ...caller, consumerAppId: 'other.app' },
            async () => {},
          )
        ).status,
        'error',
      );
      store.revoke(scope, referenceId);
      assert.equal((await execute()).status, 'error');
      assert.equal(calls, 1);
    } finally {
      ledger.close();
      store.close();
    }
  }
  console.log(
    JSON.stringify({
      passed: true,
      structuredContracts: 2,
      upstreamCalls: executed,
      paidRequests: 0,
      recovery: 'same-process ledger reopen; query-only',
    }),
  );
} finally {
  await rm(directory, { recursive: true, force: true });
}
