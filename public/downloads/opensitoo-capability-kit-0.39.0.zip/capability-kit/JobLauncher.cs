using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
// 可信Windows启动器：进程创建时加入Job，不能先运行Guest再补资源限制。
class JobLauncher {
 [StructLayout(LayoutKind.Sequential)] struct BasicLimits { public long ProcessTime, JobTime; public uint Flags; public UIntPtr MinWorking,MaxWorking; public uint ActiveProcessLimit; public UIntPtr Affinity; public uint Priority,Scheduling; }
 [StructLayout(LayoutKind.Sequential)] struct IoCounters { public ulong ReadOperations,WriteOperations,OtherOperations,ReadBytes,WriteBytes,OtherBytes; }
 [StructLayout(LayoutKind.Sequential)] struct ExtendedLimits { public BasicLimits Basic; public IoCounters Io; public UIntPtr ProcessMemory,JobMemory,PeakProcessMemory,PeakJobMemory; }
 [StructLayout(LayoutKind.Sequential)] struct CpuLimits { public uint Flags,Rate; }
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct StartupInfo { public uint Size; public string Reserved,Desktop,Title; public uint X,Y,XSize,YSize,XCount,YCount,Fill,Flags; public short Show,ReservedBytes; public IntPtr ReservedPointer,Input,Output,Error; }
 [StructLayout(LayoutKind.Sequential)] struct StartupInfoEx { public StartupInfo Startup; public IntPtr Attributes; }
 [StructLayout(LayoutKind.Sequential)] struct ProcessInfo { public IntPtr Process,Thread; public uint ProcessId,ThreadId; }
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr CreateJobObject(IntPtr attributes,string name);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool QueryInformationJobObject(IntPtr job,int kind,IntPtr data,uint size,IntPtr returned);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetInformationJobObject(IntPtr job,int kind,IntPtr data,uint size);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool InitializeProcThreadAttributeList(IntPtr list,int count,uint flags,ref IntPtr size);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool UpdateProcThreadAttribute(IntPtr list,uint flags,IntPtr attribute,IntPtr value,IntPtr size,IntPtr previous,IntPtr returned);
 [DllImport("kernel32.dll")] static extern void DeleteProcThreadAttributeList(IntPtr list);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CreateProcess(string app,StringBuilder command,IntPtr processAttributes,IntPtr threadAttributes,bool inherit,uint flags,IntPtr environment,string directory,ref StartupInfoEx startup,out ProcessInfo process);
 [DllImport("kernel32.dll")] static extern IntPtr GetStdHandle(int kind);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetHandleInformation(IntPtr handle,uint mask,uint flags);
 [DllImport("kernel32.dll")] static extern uint WaitForSingleObject(IntPtr handle,uint milliseconds);
 [DllImport("kernel32.dll")] static extern bool GetExitCodeProcess(IntPtr process,out uint code);
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,uint pid);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool TerminateJobObject(IntPtr job,uint code);
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
 static void Check(bool value) { if(!value) throw new Win32Exception(Marshal.GetLastWin32Error()); }
 static void Set<T>(IntPtr job,int kind,T value) { var size=Marshal.SizeOf(typeof(T));var pointer=Marshal.AllocHGlobal(size);try{Marshal.StructureToPtr(value,pointer,false);Check(SetInformationJobObject(job,kind,pointer,(uint)size));}finally{Marshal.FreeHGlobal(pointer);} }
 static T Get<T>(IntPtr job,int kind) { var size=Marshal.SizeOf(typeof(T));var pointer=Marshal.AllocHGlobal(size);try{Check(QueryInformationJobObject(job,kind,pointer,(uint)size,IntPtr.Zero));return (T)Marshal.PtrToStructure(pointer,typeof(T));}finally{Marshal.FreeHGlobal(pointer);} }
 // Windows命令行逐参数转义，保留空格/引号/反斜杠，不经第二层shell解释。
 static string Quote(string value) { var text=new StringBuilder("\"");int slashes=0;foreach(char c in value){if(c=='\\'){slashes++;continue;}if(c=='"'){text.Append('\\',slashes*2+1);text.Append(c);}else{text.Append('\\',slashes);text.Append(c);}slashes=0;}text.Append('\\',slashes*2);text.Append('"');return text.ToString(); }
 static int Main(string[] args) {
  IntPtr job=IntPtr.Zero,list=IntPtr.Zero,jobValue=IntPtr.Zero,owner=IntPtr.Zero;ProcessInfo child=new ProcessInfo();bool initialized=false;
  try {
   int memory,cpu;
   if(args.Length<3||!int.TryParse(args[0],out memory)||memory<64||memory>2048||!int.TryParse(args[1],out cpu)||cpu<1||cpu>50) return 64;
   int executableIndex=2;
   if(args[2]=="--owner"){uint pid;if(args.Length<5||!uint.TryParse(args[3],out pid))return 64;owner=OpenProcess(0x100000,false,pid);if(owner==IntPtr.Zero||WaitForSingleObject(owner,0)!=0x102)throw new Exception();executableIndex=4;}
   job=CreateJobObject(IntPtr.Zero,null);if(job==IntPtr.Zero)throw new Win32Exception();
   var limits=new ExtendedLimits();limits.Basic.Flags=0x2000|0x100|0x200|0x8;limits.Basic.ActiveProcessLimit=1;limits.ProcessMemory=new UIntPtr((ulong)memory*1024*1024);limits.JobMemory=limits.ProcessMemory;
   Set(job,9,limits);Set(job,15,new CpuLimits{Flags=1|4,Rate=(uint)cpu*100});
   var verified=Get<ExtendedLimits>(job,9);var verifiedCpu=Get<CpuLimits>(job,15);if(verified.Basic.Flags!=limits.Basic.Flags||verified.Basic.ActiveProcessLimit!=1||verified.JobMemory!=limits.JobMemory||verifiedCpu.Rate!=(uint)cpu*100||verifiedCpu.Flags!=5)throw new Exception();
   IntPtr size=IntPtr.Zero;InitializeProcThreadAttributeList(IntPtr.Zero,1,0,ref size);list=Marshal.AllocHGlobal(size);Check(InitializeProcThreadAttributeList(list,1,0,ref size));initialized=true;
   jobValue=Marshal.AllocHGlobal(IntPtr.Size);Marshal.WriteIntPtr(jobValue,job);
   // JOB_LIST在CreateProcess内生效，启动器在创建途中崩溃也不会留下未受限的运行进程。
   Check(UpdateProcThreadAttribute(list,0,new IntPtr(0x2000D),jobValue,new IntPtr(IntPtr.Size),IntPtr.Zero,IntPtr.Zero));
   var startup=new StartupInfoEx();startup.Attributes=list;startup.Startup.Size=(uint)Marshal.SizeOf(typeof(StartupInfoEx));startup.Startup.Flags=0x100;
   startup.Startup.Input=GetStdHandle(-10);startup.Startup.Output=GetStdHandle(-11);startup.Startup.Error=GetStdHandle(-12);
   foreach(var handle in new[]{startup.Startup.Input,startup.Startup.Output,startup.Startup.Error})Check(SetHandleInformation(handle,1,1));
   var command=new StringBuilder();for(int i=executableIndex;i<args.Length;i++){if(i>executableIndex)command.Append(' ');command.Append(Quote(args[i]));}
   Check(CreateProcess(args[executableIndex],command,IntPtr.Zero,IntPtr.Zero,true,0x80000|0x8000000,IntPtr.Zero,null,ref startup,out child));
   // 可信所有者强退也终止Job；不能只依赖可被强退绕开的JS退出回调。
   if(owner!=IntPtr.Zero){var watcher=new Thread(()=>{WaitForSingleObject(owner,0xFFFFFFFF);TerminateJobObject(job,71);});watcher.IsBackground=true;watcher.Start();}
   Console.Error.WriteLine("{\"type\":\"sitoo-job\",\"pid\":"+child.ProcessId+",\"memoryMiB\":"+memory+",\"cpuPercent\":"+cpu+",\"activeProcessLimit\":1}");
   WaitForSingleObject(child.Process,0xFFFFFFFF);var peak=Get<ExtendedLimits>(job,9);Console.Error.WriteLine("{\"type\":\"sitoo-job-exit\",\"peakCommitBytes\":"+peak.PeakJobMemory.ToUInt64()+"}");uint code;GetExitCodeProcess(child.Process,out code);return unchecked((int)code);
  }catch(Exception){Console.Error.WriteLine("SITOO_PROCESS_ISOLATION_UNAVAILABLE");return 70;}
  finally{if(child.Thread!=IntPtr.Zero)CloseHandle(child.Thread);if(child.Process!=IntPtr.Zero)CloseHandle(child.Process);if(list!=IntPtr.Zero){if(initialized)DeleteProcThreadAttributeList(list);Marshal.FreeHGlobal(list);}if(jobValue!=IntPtr.Zero)Marshal.FreeHGlobal(jobValue);if(job!=IntPtr.Zero)CloseHandle(job);if(owner!=IntPtr.Zero)CloseHandle(owner);}
 }
}
