import { readdir, readFile, mkdir } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const [selected, ...extra] = process.argv.slice(2);
if (extra.length || (selected && !/^(apps|capabilities)\/[a-z][a-z0-9-]*$/.test(selected)))
  throw Error('Usage: node tooling/build.mjs [apps/name|capabilities/name]');
const projects = [];
for (const category of ['capabilities', 'apps'])
  for (const entry of await readdir(join(root, category), { withFileTypes: true }))
    if (entry.isDirectory()) projects.push(category + '/' + entry.name);
if (selected && !projects.includes(selected)) throw Error('Unknown project');
const env = { ...process.env };
for (const name of ['NODE_PATH', 'NODE_OPTIONS', 'ELECTRON_RUN_AS_NODE']) delete env[name];
const run = (file, args) =>
  execFileSync(process.execPath, [file, ...args], {
    cwd: root,
    env,
    windowsHide: true,
    stdio: 'pipe',
    timeout: 30000,
  });
const built = [];
const outputRoot = join(root, 'dist', Date.now() + '-' + process.pid);
await mkdir(outputRoot, { recursive: true });
for (const project of selected ? [selected] : projects) {
  const manifest = JSON.parse(await readFile(join(root, project, 'manifest.json'), 'utf8'));
  const output = join(outputRoot, project.replace('/', '-') + '-' + manifest.version);
  run(join(root, project, 'build.mjs'), [output]);
  const result = JSON.parse(
    run(join(root, 'vendor/sitoo/capability-packages/capability-packages.mjs'), [
      'inspect',
      output,
    ]),
  );
  if (!result.ok) throw Error('Public inspect failed: ' + result.error.code);
  built.push({ project, version: manifest.version, output });
}
console.log(JSON.stringify({ passed: true, built, published: false, installed: false }));
