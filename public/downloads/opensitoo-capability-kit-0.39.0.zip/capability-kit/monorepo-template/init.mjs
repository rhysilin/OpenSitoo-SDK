import { cp, mkdir, readdir, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { execFileSync } from 'node:child_process';

const [target, kitArgument, packagesArgument, ...extra] = process.argv.slice(2);
if (!target || !kitArgument || !packagesArgument || extra.length)
  throw Error('Usage: node init.mjs <existing-directory> <capability-kit> <capability-packages>');
const root = resolve(target),
  kit = resolve(kitArgument),
  packages = resolve(packagesArgument);
const existing = await readdir(root);
for (const name of [
  'apps',
  'capabilities',
  'tooling',
  'docs',
  '.ci',
  '.local',
  'vendor',
  'dist',
  'README.md',
  '.gitignore',
  '.gitattributes',
  'package.json',
])
  if (existing.includes(name)) throw Error('Refusing to overwrite: ' + name);
// Only public distributions are consumed; no package resolver or platform source imports.
await mkdir(join(root, '.local'));
await mkdir(join(root, 'vendor/sitoo'), { recursive: true });
await cp(kit, join(root, 'vendor/sitoo/capability-kit'), { recursive: true });
await cp(packages, join(root, 'vendor/sitoo/capability-packages'), { recursive: true });
const bootstrap = join(root, '.local/bootstrap');
execFileSync(process.execPath, [join(kit, 'sitoo-project.mjs'), 'create', bootstrap], {
  cwd: root,
  windowsHide: true,
  stdio: 'pipe',
});
await mkdir(join(root, 'apps'));
await mkdir(join(root, 'capabilities'));
await cp(join(bootstrap, 'app-a'), join(root, 'apps/text-normalizer-a'), { recursive: true });
await cp(join(bootstrap, 'app-b'), join(root, 'apps/text-normalizer-b'), { recursive: true });
await cp(join(bootstrap, 'core'), join(root, 'capabilities/text-normalizer'), { recursive: true });
await cp(new URL('./tooling/', import.meta.url), join(root, 'tooling'), { recursive: true });
await mkdir(join(root, 'docs'));
await cp(new URL('./ci/', import.meta.url), join(root, '.ci'), { recursive: true });
await writeFile(join(root, '.ci/verify.ps1'), 'node .ci/verify.mjs\nexit $LASTEXITCODE\n', {
  flag: 'wx',
});
await writeFile(
  join(root, '.gitignore'),
  '.local/\ndist/\nnode_modules/\napp-test-1/sitoo-*/\n*.pem\n*.key\n*.sqlite*\n.env*\n',
  { flag: 'wx' },
);
await writeFile(join(root, '.gitattributes'), '* text=auto eol=lf\nvendor/** -text\n', {
  flag: 'wx',
});
await writeFile(
  join(root, 'package.json'),
  JSON.stringify(
    {
      name: 'opensitoo-ecosystem-acceptance',
      private: true,
      type: 'module',
      engines: { node: '>=24' },
      scripts: { build: 'node tooling/build.mjs', verify: 'node .ci/verify.mjs' },
    },
    null,
    2,
  ),
  { flag: 'wx' },
);
await cp(new URL('./README.md', import.meta.url), join(root, 'README.md'));
console.log(
  JSON.stringify({ created: root, applications: 2, sharedCapabilities: 1, productionTrust: false }),
);
