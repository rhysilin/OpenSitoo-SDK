import { mkdir, mkdtemp, readFile, writeFile, readdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFileSync, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join, resolve } from 'node:path';
const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
if (Number(process.versions.node.split('.')[0]) < 24) throw Error('Node 24 or newer required');
await mkdir(join(root, '.local/ci'), { recursive: true });
const output = await mkdtemp(join(root, '.local/ci/run-'));
const env = { ...process.env };
for (const name of ['NODE_PATH', 'NODE_OPTIONS', 'ELECTRON_RUN_AS_NODE']) delete env[name];
const git = spawnSync('git', ['rev-parse', 'HEAD'], {
  cwd: root,
  encoding: 'utf8',
  windowsHide: true,
});
const dirty = spawnSync('git', ['status', '--porcelain'], {
  cwd: root,
  encoding: 'utf8',
  windowsHide: true,
});
const report = {
  status: 'running',
  startedAt: new Date().toISOString(),
  node: process.version,
  platform: process.platform,
  commit: git.status === 0 ? git.stdout.trim() : null,
  worktreeDirty: dirty.status === 0 ? Boolean(dirty.stdout.trim()) : null,
  execution: 'local-or-runner-unverified',
  inputs: {},
  steps: [],
  paidRequests: 0,
  remaining: [
    'fixed Desktop acceptance is separate',
    'hosted status requires independent run URL and logs',
  ],
};
const manifest = JSON.parse(
  await readFile(join(root, 'vendor/sitoo/capability-kit/kit-manifest.json')),
);
for (const [path, expected] of Object.entries(manifest.artifacts)) {
  const actual = createHash('sha256')
    .update(await readFile(join(root, 'vendor/sitoo/capability-kit', path)))
    .digest('hex');
  if (actual !== expected) throw Error('Public artifact digest mismatch: ' + path);
}
for (const path of [
  'tooling/build.mjs',
  '.ci/verify.mjs',
  'vendor/sitoo/capability-kit/kit-manifest.json',
  'vendor/sitoo/capability-packages/capability-packages.mjs',
])
  report.inputs[path] = createHash('sha256')
    .update(await readFile(join(root, path)))
    .digest('hex');
async function snapshot(path) {
  for (const entry of await readdir(join(root, path), { withFileTypes: true })) {
    const child = path + '/' + entry.name;
    if (entry.isDirectory()) await snapshot(child);
    else if (entry.isFile())
      report.inputs[child] = createHash('sha256')
        .update(await readFile(join(root, child)))
        .digest('hex');
    else throw Error('Ordinary project files required');
  }
}
await snapshot('apps');
await snapshot('capabilities');
for (const [name, path] of [
  ['build-applications', 'tooling/build.mjs'],
  ['persistent-references', 'vendor/sitoo/capability-kit/verify-persistent-references.mjs'],
  ['model-ledger', 'vendor/sitoo/capability-kit/verify-model-ledger.mjs'],
  ['image-services', 'vendor/sitoo/capability-kit/verify-image-services.mjs'],
  ['structured-requests', 'vendor/sitoo/capability-kit/verify-request-services.mjs'],
]) {
  let status = 'passed';
  try {
    const log = execFileSync(process.execPath, [join(root, path)], {
      cwd: root,
      env,
      windowsHide: true,
      timeout: 120000,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    await writeFile(join(output, name + '.log'), log);
  } catch (error) {
    status = 'failed';
    await writeFile(
      join(output, name + '.log'),
      Buffer.concat([error.stdout ?? Buffer.alloc(0), error.stderr ?? Buffer.alloc(0)]),
    );
  }
  report.steps.push({ name, status });
  report.status = status === 'failed' ? 'failed' : 'running';
  await writeFile(join(output, 'report.json'), JSON.stringify(report, null, 2));
  if (status === 'failed') break;
}
if (report.status === 'running') report.status = 'passed';
report.finishedAt = new Date().toISOString();
await writeFile(join(output, 'report.json'), JSON.stringify(report, null, 2));
console.log(
  JSON.stringify({
    status: report.status,
    report: join(output, 'report.json'),
    steps: report.steps.length,
  }),
);
if (report.status !== 'passed') process.exitCode = 1;
