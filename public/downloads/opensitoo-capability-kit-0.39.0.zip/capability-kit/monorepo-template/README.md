# 多应用开发测试仓库

Node 24，无平台源码、私有导入或 workspace 依赖。应用与共享能力独立声明和版本；仓库根目录统一组织，不把它们合并为一个安装包。

| 路径                                           | 职责                                                      |
| ---------------------------------------------- | --------------------------------------------------------- |
| apps/text-normalizer-a、apps/text-normalizer-b | 两个独立消费应用，分别调用公开能力 SDK                    |
| capabilities/text-normalizer                   | 唯一共享业务实现                                          |
| tooling                                        | 构建与公开 CLI 检查入口                                   |
| docs                                           | 开发流程及脱敏验收记录                                    |
| .ci                                            | CI 命令，不代表托管执行通过                               |
| vendor/sitoo                                   | 固定版本的公开 SDK/CLI/宿主分发和许可证，允许干净克隆构建 |
| .local                                         | 测试私钥、令牌和数据库，不提交                            |
| dist                                           | 不可覆盖的本机构建产物，不提交                            |

```powershell
node tooling/build.mjs
node tooling/build.mjs apps/text-normalizer-a
pwsh -NoProfile -File .ci/verify.ps1
```

构建按各 manifest 的真实版本生成新目录并执行公开 inspect；不签名、不发布、不安装、不自动授权。发布沿用 capability-packages.mjs sign/verify-signed/publish，私钥和开发信任由可信操作者提供，须放在 .local 中。更新增加权限必须重新授权；未知结果只查询原任务。

`.gitattributes` 将项目文本固定为 LF，vendor 禁止 Git 自动换行转换，保持发布物摘要。不得重新格式化 vendor 中的生成文件。CI 会逐项核对 kit-manifest 中的原始字节；干净 Git 克隆在 Windows core.autocrlf=true 下也必须通过。

初始化仅使用维护者交付的 capability-kit 与 capability-packages：`node init.mjs <已存在目录> <capability-kit目录> <capability-packages目录>`。目标中的同名项目或文件会被拒绝；无关目录保留。初始化生成的 starter 命名空间是测试身份，正式接入需更改 manifest、页面与 client 的 ID，并由平台登记开发信任。

公开工具更新时由维护者提供完整、核对摘要的同版分发目录，再更新 vendor/sitoo 并单独审查提交；应用和能力代码、密钥与任务数据各自保留。开发测试签名不等于生产发布或自助上线。远端按项目所有者指定，不能使用其他业务仓库。
