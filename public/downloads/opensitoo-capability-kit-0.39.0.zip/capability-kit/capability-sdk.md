# 能力 SDK 与 Desktop 开发验收

E3-R04图片服务及原任务产物交付。

E3-R03产品宿主服务交付。

E3-R02原请求账本交付。

E3-R01持久引用交付。

第二十四批固定开发客户端确认与核对。

第二十三批签名宿主服务 · 服务适配。

第二十二批公共服务端口 · 可信服务适配。已安装服务声明与精确可信实现已接入，生产服务仍待后续。

第二十一批独立项目创建与E3收口 · 从零开发手册。优先补生态通用服务契约，现有应用用于兼容回归。

第二十批设计方案共享校验：独立业务示例复用原应用源码；旧应用收费推理/生图仍待迁移。

返回总目录 · 当前状态 · SDK 手册 · API 参考 · 本批证据

维护日期：2026-10-09。SDK 0.0.10、Desktop 0.0.30、工具包 0.33.0、独立宿主 0.18.0。状态：开发窗口、产品账户管理、隔离业务页面与对话工具；Pi 共享工具已接入；精确版本切换/卸载、prepared 恢复与仓库外固定客户端业务门禁已通过；原任务历史只读恢复已接入；原任务unknown与Pi候选兼容门禁已有本地证据，生产上游、正式版本推广和生产身份待后续。

## SDK 客户端

新增浏览器子入口 `@sitoo/sdk/capabilities`，导出 `createCapabilityClient(transport)`、AppCapabilityTransport、AppCapabilityTask、CapabilityRequest/Response、ProtocolValidation。没有 Node、Pi、Electron、HTTP 地址、bearer 或 caller 参数。transport 是可信宿主已限定身份的四方法桥：submit/get/cancel/list，不能让应用提供宿主执行器或授权。

```ts
import { createCapabilityClient, type AppCapabilityTransport } from '@sitoo/sdk/capabilities';
declare global {
  interface Window {
    sitooDevelopmentTasks: AppCapabilityTransport;
  }
}
// 开发容器提供的受限桥；没有开发令牌。
const client = createCapabilityClient(window.sitooDevelopmentTasks);
const request = {
  protocolVersion: 1 as const,
  requestId: crypto.randomUUID(),
  capabilityId: 'bob/prepare',
  input: { text: ' hello ', childRequestId: crypto.randomUUID() },
};
const submitted = await client.submit(request);
if (submitted.ok) {
  const original = await client.get(submitted.value.taskId);
  // 展示 original，不自动重建请求或重跑 unknown。
}
client.dispose();
```

调用者负责创建并保留原 requestId；客户端不生成 ID、不持久化任务、不自动重试、轮询、确认或 reconcile。submit 使用原协议解析器对标准请求作 JSON 快照，非法参数或身份注入在发送前拒绝；实际业务 schema、权限、安装与去重仍由原宿主校验。get/cancel 只接受小写 UUID taskId，list 对应当前桥列表（开发宿主最近 100 条）。返回原 `{ok,value}` / `{ok:false,error}` 契约；task 含原 binding、revision、时间、result/upstreamTask，不另建 SDK 任务。

最多 32 个未完成调用，每个等待 10 秒。超限 LIMIT_EXCEEDED；传输异常/超时或在途 submit 被 dispose 后返回 RESULT_UNKNOWN，表示可能已接受，保留原请求并查询原任务。查询/取消传输未确认返回 UNAVAILABLE，原取消仍可能生效。dispose 立即结束本客户端等待并拒绝后续操作，不取消宿主任务，迟到结果不覆盖已结束 Promise。错误消息按原协议安全码重建，不显示传输异常正文。

升级时核对产品 manifest.sdkRange 是否包含 0.0.10；现有仓库应用范围已兼容，不自动改写或重签第三方旧包。

原 `/ui` 的 createAppClient、sitoo-app-v1 与 static-platform/spkg 不变；该客户端没有自动挂到原 `/ui` 或平台 capabilities.features 中，旧宿主也不会因 SDK 升级新增任务服务。使用前需要明确已提供四方法 transport。

## 独立构建与分发

`node scripts/capability-kit.mjs` 生成零外部运行依赖的 capability-sdk.mjs（ESM）及 capability-sdk.js（经典脚本，全局 SitooCapabilitySdk），manifest 记录 SDK 版本与摘要。把 SDK 发布物加入应用文件清单并签名，使用经典脚本的 static-application-v1 页面先加载 SDK 再加载业务脚本。SDK 不能从 CDN 下载；独立项目不需要平台源码。

Bob/Carol 构建命令 `node application.mjs <version> <new-output> <capability-sdk.js>`，显式复制工具包 SDK。业务页通过 createCapabilityClient 调用原受限任务桥；保留桥供已有应用兼容。工具包版本与 SDK/宿主版本独立，不能把工具包 0.11.0 写成宿主 0.11.0。

`node scripts/app-toolkit.mjs` 的 npm 目录包增加 `/capabilities` JavaScript 和声明，内联原协议实现，复制类型声明；对外包不带 workspace 依赖。现有 `/ui` 客户端与发布工具继续交付。尚未发布公共 npm。

## Desktop 开发入口

构建 `apps/desktop/build.mjs` 后，使用项目实际 Electron 运行目录启动 Desktop：`electron apps/desktop --capability-development-url=http://127.0.0.1:<port> --user-data-dir=<dedicated-development-profile>`。窗口打开当前独立宿主 /development，手工输入已签发应用令牌；通过底部链接进入 /development/conversation，输入单独对话令牌。不要把令牌或模型密钥放入 URL/命令参数。

入口仅允许未打包 Desktop、单个 http/127.0.0.1/显式端口根 URL，无用户名、密码、query 或 hash。正式安装包拒绝该参数；普通启动流程不变。开发模式提前进入独立窗口，不启动产品账户、Pi 或工作台 IPC，不将开发 bearer 当作生产登录。独立非持久 session、sandbox/contextIsolation 开启、Node 与子帧 Node 关闭，无 preload；拒绝权限、下载、webview、窗口弹出和越界导航。只允许当前宿主两个开发页面以及子帧 about:blank/srcdoc；没有关闭 webSecurity 或沙箱。

宿主重启更换端口后，用新端口重启同一 Desktop 构建并重新连接；不重建 Desktop，不迁移/丢弃原任务。应用更新需原宿主完整计划与独立入口授权刷新；开发窗口不会自动批准安装或付费能力。

本机模型选项及费用见对话手册。本批默认验收使用无费用规划夹具；沿用用户已授权 gemini-3.8-flash 配置的预览只有点击生成提案才可能收费。

## 验证与限制

`node scripts/verify-shared-capabilities.mjs --desktop --conversation --keep` 验证仓库外签名应用、实际 Electron、SDK 外部声明与原任务/共享能力。固定 Desktop main 摘要在更新/回退/卸载前后相同；宿主重启导致开发窗口重连，不属于 Desktop 重新构建。真实收费模型与整个 E3 产品门禁以各自证据为准。

第六批交付记录结果与下一步。Electron 配置参考[官方安全指南](https://www.electronjs.org/docs/latest/tutorial/security)与[导航事件](https://www.electronjs.org/docs/latest/api/web-contents)。

## 产品账户安装状态（Desktop 0.0.10）

第七批证据。普通产品窗口新增私有 piMarket.sharedApplications.inspect()；仅可信主 frame 使用，不是 App SDK 或对外 HTTP 接口。它从 DesktopAuth 决定账户，不接受身份、路径或应用根参数。返回 development 环境中签名复核后的静态应用、精确依赖摘要和两个入口的授权状态；不执行任务或自动安装/授予权限。

可信账户目录 `userData/shared-installations/<scope>` 包含 installations.sqlite（schema 3）、authorizations.sqlite（schema 1）、trust.json。tenantId=SHA256(new URL(NewAPI站点).origin)，accountId=String(正整数账户ID)，scope=SHA256(tenantId + NUL + accountId)。只读打开现有数据库，缺账户返回空，部分配置、签名/内容/计划异常返回 SHARED_INSTALLATIONS_UNAVAILABLE；旧库不自动迁移，文件须在本账户目录内。信任应由宿主操作者配置，应用不能从包内自签发公钥。原独立夹具根不自动迁移成产品账户。

授权 status 为 active/revoked/missing/stale，revision 仅有记录时返回；active 表示持久授权 bindings 匹配当前安装计划，不表示产品执行入口已开放。切换账户立即撤销，包含 A→B→A 的旧异步读取。产品安装 UI、任务与对话桥继续待后续门禁；SDK 与第六批显式开发窗口契约不变。

此新增私有 preload 方法返回原 AuthReply 数据：成功 {ok:true,value:SharedInstallationState}，失败 {ok:false,error:{code,message}}。不跨 contextBridge 抛出附带 code 的 Error，以免错误码被 Electron 序列化丢弃；消费页面应检查 ok。原有 IPC 方法不变。

普通产品窗口的可重复检查：设置已有 SITOO_TEST_PLAYWRIGHT_MODULE，构建 Desktop 后运行 `node scripts/verify-desktop-shared-installations.mjs`；加 `--keep` 保留窗口。使用新的专用临时 profile，默认只关闭脚本自己的窗口，不读取真实用户凭据或自动登录；真实账户与市场闭环仍待后续。

`--keep` 的可交互产品预览会先调用原 `scripts/dev-up.ps1`，幂等启动/检查本地 IdP(:9000) 和 New API(:3000)；任一服务不可用则停止启动。显式 `--login-smoke` 使用本地内置演示账户在临时 profile 验证登录、登录态读取和退出，不调用模型，不自动登录现有窗口。仅支持本机默认开发认证配置，不能用于生产账号。登录页无法打开时先核对 IdP discovery；本批漏启 IdP 的恢复与真实登录证据见第七批记录。

## 产品市场首次安装与入口授权（Desktop 0.0.11）

第八批证据。普通产品市场新增共享应用开发预览，读取本账户可信部署的签名 releases.sqlite；连同前述 trust/installation/authorization 四文件预配置。账户目录无此配置时显示尚未配置，不从下载包导入公钥或自动继承旧 .spkg 权限。原 CLI 发布本机 development 签名版本后即可显示兼容静态应用；目录和预览真正只读。

先检查精确应用版本与完整依赖，明确确认首次安装；再分别确认应用页面或对话入口的权限。授权按完整精确 bindings/CAS 写原持久账本，取消无持久效果，撤销不影响另一个入口。收费或外部写入 Guest 权限本批不开放。管理入口只在未打包 Desktop 的可信主 frame，已安装版本更新和业务任务/页面加载仍待后续；安装/授权成功不代表已提供产品执行桥。

私有 piMarket.sharedApplications 增加 catalog、prepareInstall(packageId,version,sha256)、prepareAuthorization(applicationId,entry,revoke)、confirm(token)、discard(token)、abort(applicationId,requestId)、status(applicationId,requestId,entry?)。均返回 AuthReply；错误按 ok/error.code 读取。确认令牌账户绑定，最多 32 个、5 分钟，切换账户或信任/安装/授权改变需重新预览；confirm 不接受身份、路径、grants 或 bindings。持久原收据查询不依赖预览令牌，不自动恢复、批准或更换原请求。显式失败重试必须用同一确认与 requestId，历史收据不恢复后来撤销的权限。

验收 `node scripts/verify-desktop-shared-installations.mjs --market`：显式本地演示账户、新临时 profile 与签名发布夹具，实际产品市场点击安装/授权/撤销并切换账户，无模型请求。`--keep` 先启动/检查本地登录服务；如加 --market 会在专用验收 profile 配置夹具，最终退出演示登录，不操作用户现有 profile。生产可信分发、运行隔离与整个 E3 待后续门禁。

确认失败后可显式放弃原安装：abort 只把原 prepared 收据转为 aborted，不能删除 committed 根；没有自动回收代码、卸载或更换请求。初次预览取消没有持久写入；已经确认过的未决操作关闭弹窗不会自动撤回，应先查询原收据或明确放弃。跨进程 pending 列表和继续确认 UI 保持待实现。

## 产品共享业务页面（Desktop 0.0.12）

第九批交付与证据。在开发客户端市场为本账户已安装应用明确授权 application 后，点击“打开业务页面”。产品使用原独立宿主 v3 复核签名/完整依赖/持久授权；页面复用本手册浏览器 SDK 的 submit/get/list/cancel，不依赖产品 IPC、Pi 或额外业务特判。普通产品只增加私有 piMarket.sharedApplications.open(applicationId)，AuthReply 返回 {opened:true}，不返回路径、URL、bearer 或业务源码；正式安装包拒绝。无 application 授权时不能用 conversation 授权代替。

每账户/应用一个独立原任务宿主；关闭业务窗口不停止任务，重开按原 taskId 查询，不自动重提请求。账户退出/切换关闭所属窗口与子进程，原任务/unknown 和 pin 保留。撤权后现有页面的新调用拒绝、原查询仍可用，另一应用独立。授权 revision 或安装版本变化后再次打开重启该应用宿主；不能自动恢复 unknown 或处理 prepared。配置由可信主进程生成并读取后删除，凭据不进业务 iframe。

`node scripts/verify-desktop-shared-installations.mjs --pages` 使用独立本机演示 profile，实际市场安装授权、打开两个签名 SDK 页面、QuickJS 结果、页面重开原任务、跨应用拒绝、撤权与账户退出验证；可加 --keep 留下最新产品窗口。签名夹具和 Node 服务层故障回归与独立开发者/生产总门禁分别记录。

## 产品对话工具（Desktop 0.0.13）

第十批交付与证据。当前账户明确授权 conversation 后，市场“打开对话工具”发现真实工具与参数 schema，填写 JSON、预览提案，再明确提交；预览不执行任务。关闭重开可查询原任务。自然语言模型规划尚未接入本产品入口。

同一账户/应用的页面与对话共用原宿主和任务存储，使用不同 bearer 与独立入口授权；撤销任一入口拒绝其新执行，原身份仍可只读原任务，另一入口不因此失去授权。账户退出关闭两个入口及所属宿主。授权集合/修订或安装变化后显式重开会重启该应用宿主及窗口；原 unknown/pin 按原规则保留。私有 openConversation(applicationId) 不返回路径、令牌或 URL，签名业务 frame 不获得此桥。SDK 0.0.9 公共接口不变。

## Pi 自然语言共享工具（Desktop 0.0.14）

第十一批交付与证据。在市场安装并明确授权 conversation 后，工作台使用当前选定模型，通过 sitoo_shared 发现授权应用及工具 schema，提出业务参数。原宿主校验后展示桌面确认框；取消不提交，确认后真实执行，原 taskId 与结果作为 Pi 工具结果回送，沿用工作台工具卡片与 Pi 会话持久化。模型规划使用既有模型通道并可能计费；共享执行的 billable/写入门禁没有放宽。

工具操作 applications/tools/execute/tasks/get 不接受账户、grants、路径或宿主 URL。execute 的请求编号由原 Pi session/toolCallId 稳定派生；一次性提案绑定账户/应用/计划摘要，120 秒到期，确认后只消费一次，实际提交仍复核当前授权。重复消费拒绝；新工具调用是新请求，必须再次明确确认。丢响应或 unknown 不自动重试，使用原 requestId/taskId 经 tasks/get 查询。查询/停止会话不等于取消已提交业务。

签名页面、确定性对话工具窗口与工作台同应用共用原宿主/任务。工具发现/预览在需要时启动开发宿主；授权修订或有效入口集合变化时复用原显式重启规则，会关闭该应用既有窗口，原任务/pin 保留。进程重启后无授权时不能新建查询宿主；完整原任务恢复界面仍待后续。正式包不注册该开发桥。Pi 是唯一推理/会话来源，没有另建 agent loop、模型规划器或 SDK 业务特判。

## 产品市场生命周期（Desktop 0.0.15）

第十二批交付与证据 · 原安装事务手册。开发市场按 applicationId 汇总当前可信目录的版本；先预览精确应用/完整依赖闭包，再明确确认切换版本或卸载。切换包括回退，不重建客户端、不重新实现安装器、不授予新权限。旧的精确授权通常变为失配，application/conversation 分别授权后才能新执行；账本保留，切回完全相同的旧闭包可能再次匹配已有有效授权，不能将回退描述为一律撤权。

卸载只删除当前账户应用安装根，保留业务数据、授权账本、原任务与事务收据、其他应用根以及共享缓存；不触发 GC。原租约/unknown pin 继续阻止更新和卸载。预览记录原安装代数和完整计划，确认前复核，防止卸载再安装同一版本后错误接受旧预览。操作仍受当前签名目录、信任与 development 身份限制；失效信任的管理处置不在本批产品入口范围。

确认后写入失败可能留下 prepared；市场“待处理的原操作”只读列出当前账户原 requestId，用户检查后继续原事务或明确放弃。关闭确认框、刷新页面或重启管理服务不提交、不放弃原事务；恢复不生成新 requestId，不自动清理 pin。原操作查询/放弃复用既有接口。新开业务入口仍检查当前安装/授权；已有窗口可查询原任务，卸载后没有新的执行授权。产品 unknown 的解决与进程重启后撤权历史查询界面仍待后续。

## 固定客户端仓库外开发验收

从零接入手册 · 第十三批证据。复制后的三发布者项目只使用 Node 内置模块、公开便携 CLI 与浏览器 SDK，先构建/签名/发布1.0.0，再在客户端真实执行后追加1.1.0；原 Desktop 0.0.15 的主进程/preload/renderer/宿主产物全程固定摘要。可信操作者初始化专用 development 目录，客户端明确安装/授权/更新，页面和对话共享实际 V2 代码。没有新增公共导入 API，没有自助获取信任或生产上线。unknown 界面与 Pi 升级/不可用门禁仍待后续。

## 原任务历史查询（Desktop 0.0.16）

开发版主窗口“应用市场”提供“原任务历史查询”：填原应用编号，可选原任务编号，明确查询；留空任务编号按每页20条翻页。无需重新授予执行权限或安装旧应用。登录所有者从可信账户派生；撤权/卸载/宿主退出后仍查原 scope，其他账户和应用不共享历史。

只有可信主窗口 preload 暴露 `piMarket.sharedApplications.history(applicationId, taskId?, offset=0)`，返回 AuthReply，成功 value 为 `{source:'live'|'stored',tasks:DurableTask[]}`。严格私有 IPC 与错误见API 参考。业务 frame、浏览器 SDK、模型工具不接受这个原库入口；不接收路径、账户、身份或 bearer。

活宿主走原 GET；宿主退出后只读原库，不启动执行宿主。界面保留原 taskId/requestId/精确绑定和结果，标明记录来源；原 queued/running 显示“最后记录未完成，结果待确认”，unknown 显示“结果未知”。换账户、编辑查询范围或失败会清空展示；禁止将历史当成可重新执行的提案。查询不解锁更新/卸载，不取消、不释放 pin，也不查询原收费服务；原上游结果核对还需下一批对应适配和证据。

原因：撤权或卸载后不应为了读取历史恢复执行授权。兼容：新增可信只读方法，无 SDK/schema/HTTP 改动。验证和边界见第十四批交付。

## Pi 兼容验收与不可用路径（Desktop 0.0.17）

工作台遇到 Pi 目录缺失/无法加载或进程退出时进入 error，显示重新打开及“应用市场→业务页面/对话工具/原任务查询”入口指引。不会自动将自然语言请求改为确定性执行，也不会自动重提未知任务。用户明确打开业务入口、检查原任务或重新打开工作台；业务仍由原共享宿主执行，原taskId/requestId、授权、租约与unknown保护规则不变。

可信 Runtime Adapter 同时指定 conversationInstructions 和 sharedTool 时，受限应用会话只加载原 sitoo_shared 扩展，官方 CLI 精确限定 `--tools sitoo_shared`；不启用内置文件/命令、通用审批扩展、MCP或另一套planner。没有 sharedTool 的原应用 Agent 仍为无工具会话；普通工作台继续原完整审批兼容门禁。共享执行仍调用原prepare/确认/submit/get与主进程原账户授权；显式桥不是业务应用可注入的参数。

产品仍为Pi1.0.0。第十五批时1.1.0仅受限会话通过、完整审批拒绝；第十六批已补齐固定扩展的完整审批和升级回退验收。仍未开放自动更新或通过生产降级门禁。真实进程、模拟模型与剩余范围见第十五批证据。

## 精确审批兼容登记（Desktop0.0.18）

审批发行物保留version原字段，新增compatiblePiVersions精确列表 `["1.0.0","1.1.0"]`，固定pi-permission-classifier0.5.2和@gotgenes/pi-permission-system39.0.3。构建及加载均复核已验组合：未来Pi版本、扩展版本变更、缺失/重复扩展或列表改变拒绝，不能按semver推断兼容。旧单版本manifest保留相同版本的原行为，未登记Pi仍拒绝。

本机无费用模型夹具下，完整1.1.0审批（人工/自动/全授权及受保护文件）、官方RPC和1.0.0→1.1.0→1.0.0同一Pi会话/业务任务通过。完整审批不授予共享业务权限；其原显式确认与主进程授权仍有效。产品随包Pi仍1.0.0，无用户数据迁移或在线更新入口；证据/范围见第十六批交付。

## 整个客户端重启验收（Desktop0.0.19）

运行 `node scripts/verify-desktop-shared-installations.mjs --restart`，包含原 --history 链路，在专用测试 profile 强退脚本自己连接的实际 Electron 进程，并使用相同 profile 启动新进程。认证走正常登录，不注入账户、不重置限流；第十七批已落盘unknown的验证见当批，当前 --restart 先中断真实running，按只读保留与原宿主显式恢复路径查询原记录和 active pin。无新任务派发，也没有上游自动核对按钮。仅无费用本地演示业务；真实结果见第十七批交付。

本次 Electron 强退时另一个测试应用宿主仍存活，验收脚本只清理强退前已核对父PID和专用profile的自身子宿主，保留数据；这不是产品自动收口。unknown 在强退前已持久化且原宿主已停止。本批未证明正在执行的任务随父进程退出自动收口，也未实现认证自动恢复：新进程为登出，经过正常重新登录读取同账户原记录。当时此门禁待补齐；后续第十八批已加入父管道与实际在途恢复验收。

## 客户端异常退出的宿主生命期（Desktop0.0.20）

Desktop保留自己的stdin管道并显式开启宿主 --parent-pipe，管道断开触发原close并退出；实际强退也可能使宿主未完成写回，原只读记录保留running，显式重开原宿主后由原恢复逻辑转为unknown。更新 --restart 门禁：先确认任务真实running，再强退实际Electron；等待原两个宿主自行退出，不以验收脚本kill代替；同profile正常重新登录查询同taskId/requestId的unknown和原completed，active pin保留。无认证自动恢复或新业务重提。第十七批手动清理只是历史条件，当前证据见第十八批交付。

## 能力CI入口（Desktop0.0.21）

新增独立能力CI编排，不改共享业务、SDK或产品Pi版本。Windows Node24门禁从源码重建可搬运工具，再运行原仓库外验收与原生SQLite容量故障；实际Electron/登录/Pi升级与真实USB容量继续独立验收。无远端仓库时只有本机证据，不能宣布托管通过。运行与报告见CI手册、第十九批交付。

## 固定开发客户端的任务确认与核对（0.15.0）

打开本机开发宿主的 /development/operator，或在未打包Desktop的能力开发窗口点击“打开任务确认与核对”。输入对应入口的消费令牌与独立操作者密钥，两者不得相同；连接后输入框清空，凭据只保留在模块内存，断开会中止窗口请求、清除任务与确认显示。该页面不加载应用代码，不提供生产管理桥或业务执行器。

选择原任务后，needs-approval显示原capability/package/version/hash、请求参数与revision；操作者逐次点击“确认本次调用”，复用GET/POST /v1/confirmations/:taskId和历史X-Fixture-Confirmation头。原任务unknown才开放“核对原结果”，复用POST /v1/tasks/:taskId/reconcile。查询失败保留unknown及租约，不调用infer；确认响应丢失时刷新原任务，不能重复提交新请求。结果均用textContent渲染，不执行参数或结果内的HTML。两入口分别读取当前应用摘要或对话计划摘要，原身份/安装/授权检查保持。

这是可信开发操作者界面；消费令牌没有自我确认能力，操作者密钥不传到应用iframe或SDK。这是第二十四批当时边界；普通产品现由R03/R04接入原生Provider。生产登录、计费额度、不可变引用持久映射和原生实现来源仍需后续接入。SDK0.0.9、Tasks0.4.0、wire/schema保持，无旧数据迁移。

仓库外真实服务验收：node scripts/verify-installed-services.mjs --client，需要已有SITOO_TEST_PLAYWRIGHT_MODULE和已构建Desktop；驱动仅用于验收，样例通过可信测试环境变量加载，不接受包/HTTP配置。无费用Provider账本仍在内存，宿主重建仍同进程，不能当成生产恢复证明。见第二十四批证据。

## R02历史侧车与产品边界（当批Desktop0.0.28）

本版本同步宿主0.17.0及工具包0.32.0，加入可信Node原请求账本及实际服务进程中断门禁；SDK0.0.9、Pi1.0.0与普通产品Provider保持。独立服务从原确认/reconcile路线恢复结果，详见服务手册及R02证据。当批普通产品宿主服务尚未接入；现已由上方R03接入，不把侧车存在当成产品可调用证明。

## 原任务图片读取（SDK0.0.10）

createCapabilityClient新增`artifact(taskId):Promise<ProtocolValidation<AppCapabilityArtifact>>`，AppCapabilityArtifact为{mimeType:image/png,dataUrl:string}，AppCapabilityTransport.artifact可选。旧四方法transport继续工作，缺少artifact返回UNAVAILABLE；无URL/Bearer/身份或生成参数，不自动重试。按原taskId读取，非法UUID/URL/非PNG/超16MiB响应拒绝，继承32并发/10秒/dispose规则。图片通过data:显示，不开放iframe外网。独立对话预览新增“读取原任务图片”，同一原任务可在页面/对话读取。

2026-10-11：Desktop0.0.32增加显式test目录通用适配，默认development保持；OS加密只读凭据、精确签名安装、撤回前确认复核与离线原任务保留见目录手册和R03验收。

Desktop0.0.33等待原图片缓存保存完成再交付共享任务结果，不重新生成；原任务/SDK/schema保持。R04记录。

[返回工具包说明](./README.md)
