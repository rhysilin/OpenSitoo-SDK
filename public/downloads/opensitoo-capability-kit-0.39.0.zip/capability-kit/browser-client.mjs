const form = document.querySelector('#open');
const input = document.querySelector('#token');
const status = document.querySelector('#status');
const container = document.querySelector('#container');
let current;
let generation = 0;
const limit = 32;
const scriptNonce = document.querySelector('meta[name="development-script-nonce"]').content;
const invalid = () => ({
  ok: false,
  error: { code: 'FORBIDDEN', message: 'The capability is not authorized.' },
});

function disconnect() {
  generation++;
  if (current) {
    current.port?.close();
    current.abort.abort();
    current = undefined;
  }
  container.replaceChildren();
}
document.querySelector('#close').addEventListener('click', () => {
  disconnect();
  input.value = '';
  status.textContent = '页面已关闭；已提交任务仍由宿主持久保存';
});

// Runs inside the opaque application frame. No bearer, config or Host API.
function bridge(channel) {
  let port;
  const pending = new Map();
  const ready = new Promise((resolve) => {
    const receive = (event) => {
      if (event.source !== parent || event.data?.channel !== channel || !event.ports[0]) return;
      window.removeEventListener('message', receive);
      port = event.ports[0];
      port.onmessage = ({ data }) => {
        const waiter = pending.get(data?.id);
        if (!waiter) return;
        pending.delete(data.id);
        clearTimeout(waiter.timer);
        waiter.resolve(data.result);
      };
      resolve();
    };
    window.addEventListener('message', receive);
  });
  const request = async (method, input) => {
    if (pending.size >= 32) throw new Error('Development bridge busy.');
    const id = crypto.randomUUID();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new Error('Development bridge timeout; query the original task.'));
      }, 10000);
      pending.set(id, { resolve, timer });
      void ready.then(() => {
        if (pending.has(id)) port.postMessage({ id, method, input });
      });
    });
  };
  Object.defineProperty(window, 'sitooDevelopmentTasks', {
    value: Object.freeze({
      submit: (input) => request('submit', input),
      get: (taskId) => request('get', taskId),
      cancel: (taskId) => request('cancel', taskId),
      list: () => request('list', null),
      artifact: (taskId) => request('artifact', taskId),
    }),
    writable: false,
    configurable: false,
  });
  parent.postMessage({ kind: 'sitoo-development-ready', channel }, '*');
}

function render(application, state) {
  const sources = new Map(application.files.map((file) => [file.path, file.source]));
  const html = sources.get(application.entry);
  if (typeof html !== 'string') throw new Error();
  const doc = new DOMParser().parseFromString(html, 'text/html');
  const asset = (path, extension) => {
    if (typeof path !== 'string' || /^(?:[a-z][a-z0-9+.-]*:|\/)/i.test(path)) throw new Error();
    const base = new URL(application.entry, 'https://application.invalid/');
    const url = new URL(path, base);
    if (url.origin !== base.origin || url.search || url.hash) throw new Error();
    const name = decodeURIComponent(url.pathname.slice(1));
    if (!name.endsWith(extension) || !sources.has(name)) throw new Error();
    return sources.get(name);
  };
  doc
    .querySelectorAll('base,meta[http-equiv],iframe,frame,object,embed')
    .forEach((node) => node.remove());
  for (const script of doc.querySelectorAll('script')) {
    if (
      (script.type && !['text/javascript', 'application/javascript'].includes(script.type)) ||
      script.hasAttribute('async') ||
      script.hasAttribute('defer')
    )
      throw new Error();
    const source = script.hasAttribute('src')
      ? asset(script.getAttribute('src'), '.js')
      : script.textContent;
    // Only signed classic scripts receive the shell nonce. Event handlers remain blocked.
    script.removeAttribute('integrity');
    script.removeAttribute('src');
    script.removeAttribute('nonce');
    script.setAttribute('data-sitoo-development-script', '');
    script.textContent = source.replace(/<\/script/gi, '<\\/script');
  }
  for (const link of doc.querySelectorAll('link')) {
    if (link.rel !== 'stylesheet') {
      link.remove();
      continue;
    }
    const style = doc.createElement('style');
    style.media = link.media;
    style.textContent = asset(link.getAttribute('href'), '.css').replace(/<\/style/gi, '<\\/style');
    link.replaceWith(style);
  }
  const policy = doc.createElement('meta');
  policy.httpEquiv = 'Content-Security-Policy';
  // Parent nonce admits only rewritten signed scripts. Child policy additionally
  // denies every external script, even one that reuses a visible script nonce.
  policy.content =
    "default-src 'none'; script-src 'none'; script-src-elem 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; frame-src 'none'; worker-src 'none'; base-uri 'none'; form-action 'none'; object-src 'none'";
  const bootstrap = doc.createElement('script');
  bootstrap.setAttribute('data-sitoo-development-script', '');
  bootstrap.textContent = '(' + bridge.toString() + ')(' + JSON.stringify(state.channel) + ');';
  doc.head.prepend(policy, bootstrap);
  const frame = document.createElement('iframe');
  frame.title = application.applicationId;
  frame.setAttribute('sandbox', 'allow-scripts allow-forms');
  frame.setAttribute('referrerpolicy', 'no-referrer');
  state.frame = frame;
  // DOM serialization hides nonce attributes; insert them only after serialization.
  frame.srcdoc =
    '<!doctype html>' +
    doc.documentElement.outerHTML.replaceAll(
      'data-sitoo-development-script=""',
      'nonce="' + scriptNonce + '"',
    );
  return frame;
}

window.addEventListener('message', (event) => {
  const state = current;
  if (
    !state ||
    state.port ||
    event.source !== state.frame?.contentWindow ||
    event.origin !== 'null' ||
    event.data?.kind !== 'sitoo-development-ready' ||
    event.data.channel !== state.channel
  )
    return;
  const pair = new MessageChannel();
  state.port = pair.port1;
  state.frame.contentWindow.postMessage({ channel: state.channel }, '*', [pair.port2]);
  let active = 0;
  const seen = new Set();
  pair.port1.onmessage = async ({ data }) => {
    if (
      current !== state ||
      !data ||
      typeof data.id !== 'string' ||
      !/^[a-f0-9-]{36}$/.test(data.id) ||
      seen.has(data.id)
    )
      return;
    if (active >= limit || seen.size >= 1024) {
      pair.port1.postMessage({ id: data.id, result: invalid() });
      return;
    }
    seen.add(data.id);
    active++;
    try {
      if (
        JSON.stringify(data).length > 65536 ||
        Object.keys(data).sort().join(',') !== 'id,input,method'
      )
        throw new Error();
      let path,
        method = 'GET',
        body;
      if (data.method === 'submit') {
        path = '/v1/tasks';
        method = 'POST';
        body = JSON.stringify(data.input);
      } else if (data.method === 'list' && data.input === null) path = '/v1/tasks';
      else if (
        ['get', 'cancel', 'artifact'].includes(data.method) &&
        typeof data.input === 'string' &&
        /^[a-f0-9-]{36}$/.test(data.input)
      ) {
        path =
          '/v1/tasks/' +
          data.input +
          (data.method === 'cancel' ? '/cancel' : data.method === 'artifact' ? '/artifact' : '');
        if (data.method === 'cancel') method = 'POST';
      } else throw new Error();
      const response = await fetch(path, {
        method,
        ...(body ? { body } : {}),
        signal: state.abort.signal,
        headers: {
          authorization: 'Bearer ' + state.token,
          'x-sitoo-application': state.sha256,
          ...(body ? { 'content-type': 'application/json' } : {}),
        },
      });
      const result = await response.json();
      if (current === state) pair.port1.postMessage({ id: data.id, result });
    } catch {
      if (current === state)
        pair.port1.postMessage({
          id: data.id,
          result: {
            ok: false,
            error: { code: 'UNAVAILABLE', message: 'The capability is unavailable.' },
          },
        });
    } finally {
      active--;
    }
  };
});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const token = input.value.trim();
  input.value = '';
  disconnect();
  const attempt = generation;
  status.textContent = '正在验证应用…';
  try {
    if (!/^[a-f0-9]{64}$/.test(token)) throw new Error();
    const response = await fetch('/v1/application', {
      headers: { authorization: 'Bearer ' + token },
    });
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error();
    if (attempt !== generation) return;
    const state = {
      token,
      sha256: result.value.sha256,
      abort: new AbortController(),
      channel: crypto.randomUUID(),
    };
    current = state;
    container.replaceChildren(render(result.value, state));
    status.textContent = result.value.applicationId + ' · ' + result.value.version;
  } catch {
    if (attempt === generation) {
      disconnect();
      status.textContent = '无法打开应用，请检查安装、授权与开发令牌';
    }
  }
});
window.addEventListener('pagehide', disconnect);
