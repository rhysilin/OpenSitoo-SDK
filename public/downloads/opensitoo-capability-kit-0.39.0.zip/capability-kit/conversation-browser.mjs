const element = (id) => document.getElementById(id);
const status = element('status');
let current;

function controls(state, busy = false) {
  for (const id of ['capability', 'arguments', 'prepare'])
    element(id).disabled = !state?.catalog || busy;
  element('prompt').disabled = !state?.catalog || busy;
  element('plan').disabled = !state?.catalog || busy;
  element('submit').disabled = !state?.proposal || !!state?.submitted || busy;
  element('query').disabled = !state?.taskId || busy;
  element('history').disabled = !state?.connected || busy;
  element('artifact').disabled = !state?.taskId || busy;
}
function disconnect() {
  element('artifact-image').removeAttribute('src');
  element('artifact-image').hidden = true;
  current?.abort.abort();
  current = undefined;
  element('token').value = '';
  element('prompt').value = '';
  element('tools').replaceChildren();
  element('capability').replaceChildren();
  element('arguments').value = '{}';
  element('schema').textContent = '';
  element('tasks').replaceChildren();
  element('proposal').textContent = '等待生成提案';
  element('result').textContent = '尚未提交任务';
  element('result').removeAttribute('data-task-id');
  element('result').removeAttribute('data-status');
  controls();
}
async function call(state, path, input, pin) {
  const response = await fetch(path, {
    method: input === undefined ? 'GET' : 'POST',
    headers: {
      authorization: 'Bearer ' + state.token,
      'content-type': 'application/json',
      ...(pin ? { 'x-sitoo-conversation': pin } : {}),
    },
    body: input === undefined ? undefined : JSON.stringify(input),
    signal: AbortSignal.any([
      state.abort.signal,
      AbortSignal.timeout(path === '/v1/conversation/plan' ? 35000 : 10000),
    ]),
  });
  const result = await response.json();
  if (current !== state) throw new Error('DISCONNECTED');
  if (!result.ok) throw new Error(result.error?.code === 'FORBIDDEN' ? 'FORBIDDEN' : 'UNAVAILABLE');
  return result.value;
}
async function action(work) {
  const state = current;
  if (!state || state.busy) return;
  state.busy = true;
  controls(state, true);
  try {
    await work(state);
  } catch (error) {
    if (current === state)
      status.textContent =
        error.message === 'FORBIDDEN'
          ? '当前授权或安装已变化，请重新连接；原任务仍可查询'
          : '请求未完成；提交结果未确认时请重试同一提案，或查询原任务';
  } finally {
    state.busy = false;
    if (current === state) controls(state);
  }
}
function display(task) {
  const result = element('result');
  result.dataset.taskId = task.taskId;
  result.dataset.status = task.status;
  result.textContent = JSON.stringify(task, null, 2);
  status.textContent =
    task.status === 'unknown'
      ? '原任务结果未知，保留原请求；不会自动重跑'
      : '原任务状态：' + task.status;
}
async function query(state) {
  display(await call(state, '/v1/tasks/' + encodeURIComponent(state.taskId)));
}
element('disconnect').addEventListener('click', () => {
  disconnect();
  status.textContent = '已断开；已提交任务仍由宿主持久保存';
});
element('connect').addEventListener('submit', async (event) => {
  event.preventDefault();
  const token = element('token').value.trim();
  disconnect();
  if (!/^[a-f0-9]{64}$/.test(token)) {
    status.textContent = '请输入有效对话开发令牌';
    return;
  }
  const state = { token, abort: new AbortController() };
  current = state;
  await action(async () => {
    let catalog;
    try {
      catalog = await call(state, '/v1/conversation/tools');
    } catch (error) {
      if (error.message !== 'FORBIDDEN') throw error;
      await call(state, '/v1/tasks?limit=1');
      state.connected = true;
      status.textContent = '工具发现被拒绝；可查询原任务，不开放新执行';
      return;
    }
    state.connected = true;
    state.catalog = catalog;
    for (const tool of catalog.tools) {
      const item = document.createElement('li');
      item.textContent = tool.binding.capabilityId + ' · ' + tool.binding.version;
      element('tools').append(item);
      const option = document.createElement('option');
      option.value = tool.binding.capabilityId;
      option.textContent = tool.binding.capabilityId;
      element('capability').append(option);
    }
    showSchema();
    status.textContent = '已连接；生成提案后查看参数，再提交任务';
  });
});
element('prompt').addEventListener('input', () => {
  if (!current || current.busy) return;
  current.proposal = undefined;
  element('proposal').textContent = '需求已修改，请重新生成提案';
  controls(current);
});
element('plan').addEventListener(
  'click',
  () =>
    void action(async (state) => {
      const text = element('prompt').value;
      if (!text.trim()) {
        status.textContent = '请输入需求';
        return;
      }
      state.proposal = undefined;
      const proposal = await call(state, '/v1/conversation/plan', {
        requestId: crypto.randomUUID(),
        text,
      });
      setProposal(state, proposal);
    }),
);
function setProposal(state, proposal) {
  state.proposal = proposal;
  state.taskId = undefined;
  state.submitted = false;
  element('result').textContent = '提案尚未提交';
  element('result').removeAttribute('data-task-id');
  element('result').removeAttribute('data-status');
  element('proposal').textContent = JSON.stringify(proposal, null, 2);
  status.textContent = '提案已生成，尚未执行业务；确认参数后提交';
}
function showSchema() {
  const tool = current?.catalog?.tools.find(
    (tool) => tool.binding.capabilityId === element('capability').value,
  );
  element('schema').textContent = tool ? JSON.stringify(tool.inputSchema, null, 2) : '';
}
function invalidate() {
  if (!current || current.busy) return;
  current.proposal = undefined;
  element('proposal').textContent = '参数已修改，请重新校验提案';
  controls(current);
}
element('capability').addEventListener('change', () => {
  showSchema();
  invalidate();
});
element('arguments').addEventListener('input', invalidate);
element('prepare').addEventListener(
  'click',
  () =>
    void action(async (state) => {
      state.proposal = undefined;
      const input = JSON.parse(element('arguments').value);
      setProposal(
        state,
        await call(state, '/v1/conversation/prepare', {
          protocolVersion: 1,
          requestId: crypto.randomUUID(),
          capabilityId: element('capability').value,
          input,
        }),
      );
    }),
);
element('submit').addEventListener(
  'click',
  () =>
    void action(async (state) => {
      const task = await call(
        state,
        '/v1/tasks',
        state.proposal.request,
        state.proposal.planSha256,
      );
      state.taskId = task.taskId;
      state.submitted = true;
      display(task);
      // Only queries the original task; never retries planning or execution automatically.
      for (let i = 0; i < 100; i++) {
        const original = await call(state, '/v1/tasks/' + encodeURIComponent(state.taskId));
        display(original);
        if (['completed', 'failed', 'cancelled', 'unknown'].includes(original.status)) break;
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
    }),
);
element('query').addEventListener('click', () => void action(query));
element('artifact').addEventListener(
  'click',
  () =>
    void action(async (state) => {
      const value = await call(
        state,
        '/v1/tasks/' + encodeURIComponent(state.taskId) + '/artifact',
        undefined,
        state.catalog?.planSha256,
      );
      if (
        value.mimeType !== 'image/png' ||
        typeof value.dataUrl !== 'string' ||
        value.dataUrl.length > Math.ceil((16 * 1024 * 1024) / 3) * 4 + 32 ||
        !/^data:image\/png;base64,[A-Za-z0-9+/]+={0,2}$/.test(value.dataUrl)
      )
        throw Error('Invalid artifact.');
      element('artifact-image').src = value.dataUrl;
      element('artifact-image').hidden = false;
    }),
);
element('history').addEventListener(
  'click',
  () =>
    void action(async (state) => {
      const tasks = await call(state, '/v1/tasks?limit=100');
      element('tasks').replaceChildren();
      for (const task of tasks) {
        const item = document.createElement('li');
        const button = document.createElement('button');
        button.textContent = task.taskId + ' · ' + task.status;
        button.addEventListener(
          'click',
          () =>
            void action(async (active) => {
              active.taskId = task.taskId;
              await query(active);
            }),
        );
        item.append(button);
        element('tasks').append(item);
      }
      status.textContent = '已读取原任务列表';
    }),
);
