"use strict";
var SitooCapabilitySdk = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // ../../packages/app-sdk/src/capabilities.ts
  var capabilities_exports = {};
  __export(capabilities_exports, {
    createCapabilityClient: () => createCapabilityClient
  });

  // ../../packages/capability-protocol/src/types.ts
  var TASK_STATUSES = [
    "queued",
    "running",
    "needs-input",
    "needs-approval",
    "completed",
    "failed",
    "cancelled",
    "unknown"
  ];
  var ERROR_MESSAGES = Object.freeze({
    UNAUTHENTICATED: "Authentication is required.",
    FORBIDDEN: "The capability is not authorized.",
    INVALID_INPUT: "The request is invalid.",
    INVALID_OUTPUT: "The capability response is invalid.",
    INCOMPATIBLE: "The protocol or capability is incompatible.",
    CONFLICT: "The request conflicts with an existing request.",
    LIMIT_EXCEEDED: "The request exceeds a platform limit.",
    UNAVAILABLE: "The capability is unavailable.",
    RESULT_UNKNOWN: "The result is unknown. Query the original task.",
    CANCELLED: "Execution was cancelled.",
    INTERNAL_ERROR: "The capability could not complete the request."
  });

  // ../../packages/capability-protocol/src/schemas.ts
  var UUID_PATTERN = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}(?![\\s\\S])";
  var CAPABILITY_ID_PATTERN = "^[a-z][a-z0-9-]{0,62}/[a-z][a-z0-9.-]{0,126}(?![\\s\\S])";
  var uuid = { type: "string", pattern: UUID_PATTERN, maxLength: 36 };
  var capabilityId = { type: "string", pattern: CAPABILITY_ID_PATTERN, maxLength: 191 };
  var object = (properties) => ({
    type: "object",
    properties,
    required: Object.keys(properties),
    additionalProperties: false
  });
  var requestSchema = object({
    protocolVersion: { const: 1 },
    requestId: uuid,
    capabilityId,
    input: {}
  });
  var taskReferenceSchema = object({
    taskId: {
      type: "string",
      pattern: "^[A-Za-z0-9][A-Za-z0-9._-]{0,127}(?![\\s\\S])",
      maxLength: 128
    },
    requestId: uuid,
    capabilityId,
    status: { enum: TASK_STATUSES }
  });
  var errorSchema = {
    anyOf: Object.entries(ERROR_MESSAGES).map(
      ([code, message]) => object({ code: { const: code }, message: { const: message } })
    )
  };
  var responseSchema = {
    anyOf: [
      object({
        protocolVersion: { const: 1 },
        requestId: uuid,
        status: { const: "success" },
        value: {}
      }),
      object({
        protocolVersion: { const: 1 },
        requestId: uuid,
        status: { const: "accepted" },
        task: taskReferenceSchema
      }),
      object({
        protocolVersion: { const: 1 },
        requestId: uuid,
        status: { const: "error" },
        error: errorSchema
      })
    ]
  };
  function freeze(schema) {
    if (schema.properties) {
      Object.values(schema.properties).forEach(freeze);
      Object.freeze(schema.properties);
    }
    schema.anyOf?.forEach(freeze);
    if (schema.anyOf) Object.freeze(schema.anyOf);
    if (schema.required) Object.freeze(schema.required);
    if (schema.enum) Object.freeze(schema.enum);
    return Object.freeze(schema);
  }
  [requestSchema, taskReferenceSchema, responseSchema].forEach(freeze);

  // ../../packages/capability-protocol/src/index.ts
  var PROTOCOL_LIMITS = Object.freeze({
    requestBytes: 64 * 1024,
    responseBytes: 128 * 1024,
    maxDepth: 32,
    maxNodes: 8192
  });
  function createCapabilityError(code) {
    const safeCode = Object.hasOwn(ERROR_MESSAGES, code) ? code : "INTERNAL_ERROR";
    return { code: safeCode, message: ERROR_MESSAGES[safeCode] };
  }
  function matches(value, schema) {
    if (Object.hasOwn(schema, "const") && value !== schema.const) return false;
    if (schema.enum && (typeof value !== "string" || !schema.enum.includes(value))) return false;
    if (schema.anyOf && !schema.anyOf.some((branch) => matches(value, branch))) return false;
    if (schema.type === "string") {
      if (typeof value !== "string") return false;
      if (schema.maxLength !== void 0 && value.length > schema.maxLength) return false;
      if (schema.pattern && !new RegExp(schema.pattern).test(value)) return false;
    }
    if (schema.type === "object") {
      if (value === null || typeof value !== "object" || Array.isArray(value)) return false;
      if (schema.required?.some((key) => !Object.hasOwn(value, key))) return false;
      for (const key of Object.keys(value)) {
        if (!Object.hasOwn(schema.properties ?? {}, key)) {
          if (schema.additionalProperties === false) return false;
        } else if (!matches(value[key], schema.properties[key])) return false;
      }
    }
    return true;
  }
  function jsonSnapshot(value, byteLimit) {
    let nodes = 0;
    let characters = 0;
    const ancestors = /* @__PURE__ */ new Set();
    function visit(item, depth) {
      if (++nodes > PROTOCOL_LIMITS.maxNodes || depth > PROTOCOL_LIMITS.maxDepth) throw new Error();
      if (typeof item === "string") {
        characters += item.length;
        if (characters > byteLimit) throw new Error();
        return;
      }
      if (item === null || typeof item === "boolean") return;
      if (typeof item === "number" && Number.isFinite(item)) return;
      if (typeof item !== "object" || ancestors.has(item)) throw new Error();
      const array = Array.isArray(item);
      const prototype = Object.getPrototypeOf(item);
      if (!array && prototype !== Object.prototype && prototype !== null) throw new Error();
      if (array && prototype !== Array.prototype) throw new Error();
      ancestors.add(item);
      const keys = Reflect.ownKeys(item);
      if (keys.length > PROTOCOL_LIMITS.maxNodes || array && keys.length !== item.length + 1)
        throw new Error();
      for (const key of keys) {
        if (array && key === "length") continue;
        const descriptor = Object.getOwnPropertyDescriptor(item, key);
        if (typeof key !== "string" || !descriptor?.enumerable || !Object.hasOwn(descriptor, "value"))
          throw new Error();
        if (!array) characters += key.length;
        if (characters > byteLimit) throw new Error();
        if (array && !/^(0|[1-9][0-9]*)$/.test(key)) throw new Error();
        visit(descriptor.value, depth + 1);
      }
      ancestors.delete(item);
    }
    visit(value, 0);
    const encoded = JSON.stringify(value);
    if (new TextEncoder().encode(encoded).byteLength > byteLimit) throw new Error();
    return JSON.parse(encoded);
  }
  function parse(value, schema, bytes, code) {
    try {
      const snapshot = jsonSnapshot(value, bytes);
      return matches(snapshot, schema) ? { ok: true, value: snapshot } : { ok: false, error: createCapabilityError(code) };
    } catch {
      return { ok: false, error: createCapabilityError(code) };
    }
  }
  function parseCapabilityRequest(value) {
    const result = parse(
      value,
      requestSchema,
      PROTOCOL_LIMITS.requestBytes,
      "INVALID_INPUT"
    );
    if (!result.ok && value !== null && typeof value === "object") {
      try {
        const version = Object.getOwnPropertyDescriptor(value, "protocolVersion");
        if (version && Object.hasOwn(version, "value") && typeof version.value === "number" && Number.isInteger(version.value) && version.value !== 1)
          return { ok: false, error: createCapabilityError("INCOMPATIBLE") };
      } catch {
      }
    }
    return result;
  }

  // ../../packages/app-sdk/src/capabilities.ts
  function createCapabilityClient(transport) {
    let disposed = false;
    const pending = /* @__PURE__ */ new Set();
    const fail = (code) => ({
      ok: false,
      error: createCapabilityError(code)
    });
    async function call(work, submission = false) {
      if (disposed) return fail("UNAVAILABLE");
      if (pending.size >= 32) return fail("LIMIT_EXCEEDED");
      return new Promise((resolve) => {
        let settled = false;
        const finish = (value) => {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          pending.delete(cancel);
          resolve(value);
        };
        const cancel = () => finish(fail(submission ? "RESULT_UNKNOWN" : "UNAVAILABLE"));
        const timer = setTimeout(cancel, 1e4);
        pending.add(cancel);
        try {
          void work().then((result) => {
            if (result?.ok === true) finish(result);
            else finish(fail(result?.ok === false ? result.error?.code : "INVALID_OUTPUT"));
          }).catch(cancel);
        } catch {
          cancel();
        }
      });
    }
    const task = (method, taskId) => typeof taskId !== "string" || !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(taskId) ? Promise.resolve(fail("INVALID_INPUT")) : call(() => transport[method](taskId));
    return Object.freeze({
      submit(request) {
        const parsed = parseCapabilityRequest(request);
        return parsed.ok ? call(() => transport.submit(parsed.value), true) : Promise.resolve(parsed);
      },
      get: (taskId) => task("get", taskId),
      cancel: (taskId) => task("cancel", taskId),
      list: () => call(() => transport.list()),
      artifact: (taskId) => {
        if (typeof taskId !== "string" || !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(taskId))
          return Promise.resolve(fail("INVALID_INPUT"));
        if (!transport.artifact) return Promise.resolve(fail("UNAVAILABLE"));
        return call(async () => {
          const reply = await transport.artifact(taskId);
          if (!reply.ok) return reply;
          const artifact = reply.value;
          return artifact && Object.keys(artifact).sort().join(",") === "dataUrl,mimeType" && artifact.mimeType === "image/png" && typeof artifact.dataUrl === "string" && artifact.dataUrl.length <= Math.ceil(16 * 1024 * 1024 / 3) * 4 + 32 && /^data:image\/png;base64,[A-Za-z0-9+/]+={0,2}$/.test(artifact.dataUrl) ? reply : fail("INVALID_OUTPUT");
        });
      },
      dispose() {
        disposed = true;
        for (const cancel of pending) cancel();
      }
    });
  }
  return __toCommonJS(capabilities_exports);
})();
