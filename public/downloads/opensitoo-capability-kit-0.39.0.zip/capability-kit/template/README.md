# 无 UI 能力参考项目

normalize 是确定性无 UI 能力，compose 使用受限异步桥委托 normalize；应用 A/B 各自使用公开协议与参考任务传输。源码是 `.guest` 异步函数体，不应当作 Node 模块运行。

本目录为模板，host.json 中 GENERATED 不能直接启动。请使用独立能力工具包（参见工具包 README.md）的 init 创建仓库外项目，它会复制协议分发与调用脚本、生成各自凭据和精确摘要。不要在平台仓库模板写入真实 token 或业务数据。
