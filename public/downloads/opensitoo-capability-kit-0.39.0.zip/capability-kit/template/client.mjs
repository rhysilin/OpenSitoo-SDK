import { readFile } from 'node:fs/promises';
import { randomUUID, createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseCapabilityRequest } from '@sitoo/capability-protocol';
const directory = dirname(fileURLToPath(import.meta.url));
const [url, command, argument = 'hello', requestId = randomUUID()] = process.argv.slice(2);
const origin = new URL(url);
if (
  origin.protocol !== 'http:' ||
  origin.hostname !== '127.0.0.1' ||
  origin.pathname !== '/' ||
  origin.username ||
  origin.password ||
  origin.search ||
  origin.hash
)
  throw new Error('Use the development loopback host URL.');
const token = (await readFile(join(directory, 'token.txt'), 'utf8')).trim();
const childBytes = createHash('sha256')
  .update(requestId + '/demo/normalize')
  .digest()
  .subarray(0, 16);
childBytes[6] = (childBytes[6] & 15) | 64;
childBytes[8] = (childBytes[8] & 63) | 128;
const childHex = childBytes.toString('hex');
const childRequestId = [
  childHex.slice(0, 8),
  childHex.slice(8, 12),
  childHex.slice(12, 16),
  childHex.slice(16, 20),
  childHex.slice(20),
].join('-');
let path = '/v1/tasks';
let method = 'GET';
let body;
if (command === 'submit' || command === 'model' || command === 'reference') {
  method = 'POST';
  const app = JSON.parse(await readFile(join(directory, 'package.json'), 'utf8'));
  let request = {
    protocolVersion: 1,
    requestId,
    capabilityId: app.capabilityId,
    input:
      app.capabilityId === 'demo/compose'
        ? { text: argument, caption: 'app B', childRequestId }
        : { text: argument },
  };
  if (command === 'model' || command === 'reference') {
    const refs = JSON.parse(await readFile(join(directory, 'references.json'), 'utf8'));
    request = {
      protocolVersion: 1,
      requestId,
      capabilityId: command === 'model' ? 'platform/infer' : 'demo/read-reference',
      input:
        command === 'model'
          ? { referenceId: refs.modelId, prompt: argument }
          : { referenceId: refs.textId, childRequestId },
    };
  }
  const checked = parseCapabilityRequest(request);
  if (!checked.ok) throw new Error(checked.error.code);
  body = JSON.stringify(checked.value);
} else if (command === 'get' || command === 'cancel' || command === 'reconcile') {
  if (!/^[a-f0-9-]{36}$/.test(argument)) throw new Error('Expected a task ID');
  path +=
    '/' +
    argument +
    (command === 'cancel' ? '/cancel' : command === 'reconcile' ? '/reconcile' : '');
  method = command === 'cancel' || command === 'reconcile' ? 'POST' : 'GET';
} else if (command !== 'list') throw new Error('Expected submit/get/list/cancel');
const result = await fetch(new URL(path, origin), {
  method,
  headers: { authorization: 'Bearer ' + token, 'content-type': 'application/json' },
  body,
  signal: AbortSignal.timeout(5000),
});
const response = await result.json();
console.log(JSON.stringify(response));
if (!result.ok) process.exitCode = 1;
