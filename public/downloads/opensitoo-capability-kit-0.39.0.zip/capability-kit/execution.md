# 已安装能力运行、版本绑定与任务租约

维护日期：2026-10-08。E2-04 开发参考：capability-packages 0.8.0、capability-runtime 0.2.0、capability-tasks 0.3.0、capability-dev-host/工具包 0.5.0。可信 Node 24 辅助接口，不是浏览器 SDK、生产 REST 或 Desktop IPC。沿用安装根与原子事务、署名与分发，没有 Pi/Electron/应用业务依赖。

## 决策、兼容与范围

原任务仅记录入口 binding，不能保护嵌套调用的整个依赖闭包。本批在安装库持久保存租约快照，任务先取得租约再写任务记录，并在执行前再次复核。未知结果不按超时自动释放。任务库和安装库分别维护：跨库中断允许留下保守的孤立租约，不允许先执行后补 pin。它不是跨库恰好一次事务；后续 GC 必须同时检查安装根和活动租约。

E2-04 首次引入安装库 schema 1→2 的租约迁移；当前 0.5.0 已迁移至 schema 3，兼容条件见生命周期手册。schema 1→2 的历史行为为，application_id 保持 `0x5343494e`；只新增 package_leases 表，旧根、代码、原请求和引用不重建、不覆盖。迁移失败回滚，未知 schema 拒绝。新版需要旧版本之外的新增表；迁移后旧 0.3.0 安装工具拒绝打开 schema 2，回退需兼容工具或经过验证的备份，不能手改 user_version。任务库 schema 1 不变；packageLeases 默认为未设置，原宿主/API/模板兼容，但不自动获得租约保护。

不同根可以分别绑定同一能力的 v1/v2；共享内容按 environment/packageId/version/sha256，Broker 使用精确能力绑定分别注册。没有 latest 回退，任务记录和租约保留原版本。原 prepare 仍禁止替换已安装根；0.5.0 新增独立更新/卸载事务并在 active 租约存在时拒绝提交。已有权限预检和独立 JSON 数据迁移；自动授权、产品数据迁移与运行中热切换未实现。静态应用、SDK 0.0.8、Desktop 0.0.8 与用户原任务不改变。

## 安装库租约接口

新增 `CapabilityPackageLease = {taskId,requestId,status:'active'|'released',plan:CapabilityDependencyPlan}` 和 `LEASE_LIMITS = {records:1024}`。标识沿用安装器 1–128 字符规则，根由构造时可信身份决定。plan 是整个已安装精确闭包的深冻结快照，不是执行授权。

| 方法                                                   | 同步 ProtocolValidation 返回与规则                                                                                                                                                         |
| ------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| acquireLease(taskId, requestId, bindings, trust, now?) | 当前根必须已安装，重新验签/检查环境、完整引用与依赖；bindings 必须与整个安装计划一致，不能缺少嵌套依赖、多余或重复能力。绑定对象 key 顺序和数组顺序不影响校验。返回 CapabilityPackageLease |
| getLease(taskId)                                       | 查询当前根的原租约，不执行、不验签，不泄漏其他根                                                                                                                                           |
| activeLeases()                                         | 当前根 active 租约，按 taskId 排序                                                                                                                                                         |
| releaseLease(taskId)                                   | 可信管理操作 active→released，幂等；不会删除代码或根                                                                                                                                       |
| loadLease(taskId, trust, now?)                         | active 租约的原计划对应精确源码，重验内容/当前信任/环境和依赖，返回 `{plan,packages:TrustedCapabilityPackage[]}`；不需要当前根仍指向该计划，不按新根重解释旧任务                           |
| leaseInventory()                                       | 可信管理员整库 `{records,active,references}`；references 为 active 计划中的包引用总数，原 inventory 四字段不变                                                                             |

同 taskId + 原 requestId + 原计划幂等；不同请求/计划冲突。released taskId 不可复用或重新 acquire。1024 条是整库生命周期预算，released 记录也计入，不自动删除去重墓碑；满额保留已有活动 pin、查询与重复 active acquire。原安装预算、包格式和发布库 schema 不变。

租约没有 TTL。署名过期/撤销拒绝新 acquire/loadLease，但不删除旧 pin；未知副作用尚未核实时必须保留代码。releaseLease 是宿主已确认终态后的管理端口，不能让应用凭自己声称“完成”直接释放。没有后台 GC、管理员自动认领孤立 pin、自动重新执行或收费重试。

错误沿用 INVALID_INPUT、FORBIDDEN、CONFLICT、LIMIT_EXCEEDED、UNAVAILABLE。源码/信任/根/绑定失败发生在任务创建前；存储或提交响应未知先查原任务和原租约。release 失败保留 pin，不能推测成功。

## 持久任务端口

`new CapabilityTasks({...原选项, packageLeases?:TaskPackageLeases})`。新可信端口：

```ts
interface TaskPackageLeases {
  acquire(
    task: Readonly<DurableTask>,
    caller: Readonly<CapabilityCallerPolicy>,
  ): ProtocolValidation<null>;
  release(task: Readonly<DurableTask>, scope: string): ProtocolValidation<null>;
}
```

scope 是内部原任务 owner 键：`JSON.stringify([tenantId,environment,installationId,consumerAppId])`，由任务服务生成；不是 wire 字段、身份认证凭据或应用可以选择的账户。端口接收宿主快照，不把公开 JSON 当作可信会话。

新请求先 acquire，再任务落盘，再调度。needs-approval 也先 pin，批准不换版本。执行前再次 acquire；失败不执行，写安全失败终态。终态 completed/failed/cancelled 先持久化，再 release。needs-input/needs-approval/上游 accepted/unknown 保留，已分派取消转 unknown 同样保留；queued 未分派取消可释放。query-only 确认原任务终态后才释放，不执行能力。

任务重开只恢复 queued/running 为 unknown，不重跑；终态记录在重开时补尝试 release，修复“任务已完成而释放响应失败”窗口。端口异常使 acquire 为 UNAVAILABLE；release 异常/拒绝不改任务已持久化的终态，pin 保守保留，下次重开可补偿。所有旧收费确认、去重和原版本查询规则仍成立。没有注入端口的任务仍沿用旧行为，不能假定已保护安装代码。

## QuickJS 健康门禁

新增 `CapabilityRuntime.checkSource({source,sourceSha256},{signal?}={}):Promise<ProtocolValidation<null>>`。校验原摘要/64 KiB 源码，在真实隔离 Worker/QuickJS 中编译与执行相同的程序包装；使用 [quickjs-wasi 的 compile API](https://github.com/vercel-labs/quickjs-wasi/blob/main/README.md)，不评估 bytecode，不调用业务或 Host 桥。每次新 VM，无源码/bytecode持久授权缓存。

与业务执行共用 Runtime 并发、CPU/allocator/wall/Worker 预算；清理终止完成后释放名额。摘要/语法失败为 INVALID_INPUT，限额为 LIMIT_EXCEEDED，取消 CANCELLED，Worker 创建/异常 UNAVAILABLE；不返回源码、堆栈或路径。编译通过不证明业务输出正确、无副作用或生产安全。未知 Host 结果、RSS/OS 隔离和业务健康探针保持原生产门禁。安装器本身仍只存储，不自动调用 Runtime；下面已安装宿主在开放服务前执行编译门禁。

## 独立开发宿主配置版本 2

`startDevelopmentHost({configPath,dataDirectory})` 和 serve 命令保持。新增 `InstalledDevelopmentHostConfig`，host.json 精确四字段：

```json
{
  "version": 2,
  "installationPath": "installation.sqlite",
  "trustPath": "trust.json",
  "consumers": [
    {
      "token": "替换为唯一64位小写十六进制随机凭据",
      "root": {
        "tenantId": "tenant",
        "accountId": "account",
        "applicationId": "app-a",
        "environment": "development"
      },
      "entry": "application",
      "grants": []
    }
  ]
}
```

两个文件须已存在，并经 realpath 确保在配置目录内，不能越界；trust 最多 64 KiB，每次读取重新构造可信配置。consumers 1–32，每项精确 token/root/entry/grants，token 唯一，root.environment 固定 development，entry 和 grants 沿用 Broker 校验。只能由可信管理员选择身份和权限。

宿主从安装根加载精确计划，为每个原源码摘要先通过真实编译，之后注册 exact binding；相同 binding 只注册一次，不同版本并存。consumerAppId=root.applicationId；installationId 为根四项 JSON 数组 SHA-256，账户切换产生不同任务 scope；租户/环境保留。bindings 只能来自已安装计划，配置不能伪造。

每次取得任务 pin 和执行/嵌套调用时重新读取当前 trust/根，防止启动快照绕过后来撤销。不自动升级、新权限不静默授予。参考 HTTP 路由及 loopback/Origin/Host/token 防护不变；v2 没有 fixtureConfirmationToken，不启用真实收费或模拟收费审批。v1 源码模板仍兼容，但不是签名安装的路径。

库/信任/配置或编译失败不开放监听服务，固定错误不返回原源码。构造可能迁移安装库至 schema 3，因此只有可信本地宿主可运行；本机开发 bearer 不是生产认证。没有 Desktop/网页接入或生产供应链开放。

## 独立命令与验证

包工具 0.4.0 首次引入、0.5.0 保留：

```text
node capability-packages.mjs lease-acquire installation.sqlite root.json lease.json trust.json
node capability-packages.mjs lease-status installation.sqlite root.json task-id
node capability-packages.mjs lease-list installation.sqlite root.json
node capability-packages.mjs lease-load installation.sqlite root.json task-id trust.json
node capability-packages.mjs lease-release installation.sqlite root.json task-id
node capability-packages.mjs lease-inventory installation.sqlite root.json
```

lease.json 精确 `{taskId,requestId,bindings}`，bindings 为安装读取返回的完整能力闭包。CLI 为可信管理工具，只有查询到实际原任务已终结才能手动 release；不是消费应用的 HTTP 接口。lease-load 输出源码/署名，反序列化结果不是授权或可信证明。旧安装/签名/规划命令兼容。

`node scripts/verify-installed-capabilities.mjs` 实际复制两工具至仓库外，不借用平台模块，12 项真实 WASM、v1/v2、持久 pin、强制进程结束、原请求 unknown/去重、动态撤销、编译失败和 CLI/离线生命周期验收。旧独立工具验收继续执行，历史 7 项证据见E2-04 交付，新增生命周期场景见E2-05 第一批。

返回文档总目录 · 当前状态 · API 参考

更新、卸载与代码回收：安装库当前 schema 3；维护流程、活动任务限制及迁移兼容性见此页。

[持久授权与运行门禁](./authorizations.md)（包工具 0.8.0、开发宿主 0.5.0；可信管理与 opt-in v3）。

[显式业务健康检查](./health.md)（开发宿主/工具包 0.5.0，真实任务与预期结果比较；不是自动升级批准）。

三发布者共享运行参考将独立署名业务包、嵌套委托、在途租约、升级与卸载串联验证；应用发布物安装仍未接入。

[返回工具包说明](./README.md)
