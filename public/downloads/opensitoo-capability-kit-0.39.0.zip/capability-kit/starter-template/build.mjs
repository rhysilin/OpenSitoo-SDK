import { readFile, readdir, mkdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const [argument, ...extra] = process.argv.slice(2);
if (!argument || extra.length) throw new Error('Usage: node build.mjs <new-output-directory>');
const project = fileURLToPath(new URL('.', import.meta.url));
const manifest = JSON.parse(await readFile(join(project, 'manifest.json'), 'utf8'));
const files = [];
for (const entry of await readdir(join(project, 'src'), { withFileTypes: true })) {
  // This small template uses flat sources; links and nested directories are not followed.
  if (!entry.isFile()) throw new Error('Source must contain ordinary files only.');
  const bytes = await readFile(join(project, 'src', entry.name));
  files.push({ path: entry.name, bytes });
}
const output = resolve(argument);
await mkdir(output); // Never overwrite another build or a user directory.
for (const file of files) await writeFile(join(output, file.path), file.bytes, { flag: 'wx' });
await writeFile(
  join(output, 'capability-package.json'),
  JSON.stringify(
    {
      ...manifest,
      files: files.map(({ path, bytes }) => ({
        path,
        bytes: bytes.length,
        sha256: createHash('sha256').update(bytes).digest('hex'),
      })),
    },
    null,
    2,
  ),
  { flag: 'wx' },
);
console.log(
  JSON.stringify({ built: output, packageId: manifest.packageId, version: manifest.version }),
);
