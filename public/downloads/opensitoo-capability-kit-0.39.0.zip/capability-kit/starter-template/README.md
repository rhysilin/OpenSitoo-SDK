# 两应用共享能力：从零项目模板

使用可搬运工具包，不需要平台源码、Pi、Electron或npm依赖。运行环境为Node24。starter-*是开发示例命名空间，实际接入前更改manifest、页面和client中的ID，并由可信运营者登记发布者与信任。

```powershell
node C:\Sitoo\capability-kit\sitoo-project.mjs create C:\Temp\my-ecosystem
node C:\Temp\my-ecosystem\core\build.mjs C:\Temp\core-1.0.0
node C:\Temp\my-ecosystem\app-a\build.mjs C:\Temp\app-a-1.0.0
node C:\Temp\my-ecosystem\app-b\build.mjs C:\Temp\app-b-1.0.0
node C:\Sitoo\capability-packages\capability-packages.mjs inspect C:\Temp\core-1.0.0
```

create与build均要求目录不存在，拒绝覆盖已有项目/发布物。三个子项目都有独立manifest.json、src和build.mjs，可单独移出父目录构建；两个应用携带公开SDK，页面调用starter-core/normalize，共享实现只在core/src/main.guest。build生成摘要清单，inspect才是现有公开包契约校验；构建不签名、安装或授权。

修改src与manifest.json后使用新版本和新输出目录。core能力接口为{text:string}→{text:string}，输入text最多2000字符，输出text最多8000字符、无额外字段；无费用与外部写入。应用声明^1.0.0依赖，安装仍锁定精确版本和摘要；不会因为发布新版本自动换绑定。

签名与发布由可信操作者提供私钥路径、signing.json和trust.json，不把密钥复制到src或发布物中。每个发布者分别执行：

```powershell
node C:\Sitoo\capability-packages\capability-packages.mjs sign C:\Temp\core-1.0.0 C:\Private\core.pem C:\Private\signing.json C:\Private\core.attestation.json
node C:\Sitoo\capability-packages\capability-packages.mjs verify-signed C:\Temp\core-1.0.0 C:\Private\core.attestation.json C:\Private\trust.json
node C:\Sitoo\capability-packages\capability-packages.mjs publish C:\Temp\core-1.0.0 C:\Private\core.attestation.json C:\Private\trust.json C:\Private\releases.sqlite
```

元数据keyId/environment/issuedAt/expiresAt与可信公钥登记一致。publish返回的精确引用交给可信宿主管理者，按原安装事务和分入口授权接入开发环境。项目创建没有生成信任、账户、授权、令牌或安装；开发者不能自行授予生产信任。

宿主管理者提供loopback URL与本应用入口令牌后，可打开/development，或运行独立SDK客户端：

```powershell
$env:SITOO_CAPABILITY_TOKEN='<可信操作者提供的开发令牌>'
node C:\Temp\my-ecosystem\app-a\client.mjs http://127.0.0.1:12345 ' hello ' '<保留的requestId>'
```

application/conversation令牌分别授予text:read和精确绑定。客户端只提交业务参数，查询原任务；超时、失败或unknown不自动换requestId重试。文本标准化通过无模型SDK调用；自然语言规划与生产认证另行验收。

仓库文档：从零接入手册 · E3收口清单 · 总目录。随包说明剥除仓库链接。
