import { createCapabilityClient } from './capability-sdk.mjs';
import { randomUUID } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';

const [url, text, requestId = randomUUID(), ...extra] = process.argv.slice(2);
const token = process.env.SITOO_CAPABILITY_TOKEN;
if (!url || text === undefined || extra.length || !/^[a-f0-9]{64}$/.test(token ?? ''))
  throw new Error(
    'Usage: SITOO_CAPABILITY_TOKEN=<operator-issued token> node client.mjs <loopback-url> <text> [original-requestId]',
  );
const endpoint = new URL(url);
if (
  endpoint.protocol !== 'http:' ||
  endpoint.hostname !== '127.0.0.1' ||
  endpoint.username ||
  endpoint.password ||
  endpoint.pathname !== '/' ||
  endpoint.search ||
  endpoint.hash
)
  throw new Error('Use the trusted local development host URL.');
const request = async (path, body) =>
  (
    await fetch(endpoint.origin + path, {
      method: body === undefined ? 'GET' : 'POST',
      headers: { authorization: 'Bearer ' + token, 'content-type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(5000),
    })
  ).json();
const client = createCapabilityClient({
  submit: (body) => request('/v1/tasks', body),
  get: (id) => request('/v1/tasks/' + id),
  list: () => request('/v1/tasks'),
  cancel: (id) => request('/v1/tasks/' + id + '/cancel', {}),
});
try {
  let reply = await client.submit({
    protocolVersion: 1,
    requestId,
    capabilityId: 'starter-core/normalize',
    input: { text },
  });
  if (reply.ok) {
    const taskId = reply.value.taskId;
    for (let i = 0; i < 100; i++) {
      reply = await client.get(taskId);
      if (!reply.ok || ['completed', 'failed', 'unknown', 'cancelled'].includes(reply.value.status))
        break;
      await delay(100);
    }
  }
  console.log(JSON.stringify(reply));
  if (!reply.ok || reply.value.status !== 'completed') process.exitCode = 1;
} finally {
  client.dispose();
}
