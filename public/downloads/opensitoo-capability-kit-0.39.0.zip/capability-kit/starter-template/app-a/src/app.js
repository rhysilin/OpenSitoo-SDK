const client = SitooCapabilitySdk.createCapabilityClient(window.sitooDevelopmentTasks);
const output = document.querySelector('#result');
document.querySelector('#run').onclick = async () => {
  window.lastReply = await client.submit({
    protocolVersion: 1,
    requestId: crypto.randomUUID(),
    capabilityId: 'starter-core/normalize',
    input: { text: document.querySelector('#text').value },
  });
  if (window.lastReply.ok) {
    const taskId = window.lastReply.value.taskId;
    for (let i = 0; i < 100; i++) {
      window.lastReply = await client.get(taskId);
      if (
        !window.lastReply.ok ||
        ['completed', 'failed', 'unknown', 'cancelled'].includes(window.lastReply.value.status)
      )
        break;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
  }
  output.textContent = JSON.stringify(window.lastReply, null, 2);
};
document.querySelector('#history').onclick = async () => {
  window.historyReply = await client.list();
  output.textContent = JSON.stringify(window.historyReply, null, 2);
};
