# 持久能力任务（可信宿主）

E3-R04图片服务及原任务产物交付。

E3-R03产品宿主服务交付。

E3-R02原请求账本交付。

维护日期：2026-10-11。`@sitoo/capability-tasks@0.6.1` 为工作区 private Node 24 模块，非浏览器 SDK、REST、IPC 或已发布 npm。与 协议、代理、执行器 分开版本化。无 Pi/Electron/Desktop 依赖；SDK 旧结构只作类型引用。

## 构造与宿主职责

`new CapabilityTasks({path, broker, query?, maxTasks?, allowEffects?, packageLeases?, scheduling?, accountKey?, sharedQuotaPath?})` 接宿主自选的 SQLite 文件和已注册的 CapabilityBroker。目录须已存在，路径、账户、session、查询端口仅由可信宿主设置。`broker` 属性返回同一实例；不是让应用设置身份或注册执行器的入口。

Node 原生 SQLite 使用 EXCLUSIVE 单连接所有权、DELETE journal、FULL 同步和 100ms busy timeout。第二个宿主打开同库失败，不能把仍在运行的任务当成崩溃任务恢复。初始化在独占事务中完成，数据库 schema version 为 1，不支持未知版本。构造/存储错误可抛出，宿主应停止受理并报告存储故障，不自动换数据库或重试业务。使用本机持久磁盘；网络文件系统、复制库双写、磁盘损坏、备份恢复和生产容量待专项验收。

默认最多 10000 条记录，可配置 1–1000000 的整数。满额拒绝新请求，原请求仍可查询/去重，不自动淘汰记录。请求/结果为本地业务数据，库不加密；宿主须按租户保护目录、权限与备份。诊断不输出原文、凭据或数据库内容。

## 方法

| 方法                                 | 返回与语义                                                                                                                  |
| ------------------------------------ | --------------------------------------------------------------------------------------------------------------------------- |
| `submit(session, request)`           | 同步 `ProtocolValidation<DurableTask>`；纯能力先落盘 queued，随后 microtask 经代理异步执行。结果尚未完成也可立即查 taskId。 |
| `get(session, taskId)`               | 同步任务快照；不存在或不属于调用者均 FORBIDDEN，避免泄漏其他人的 ID。                                                       |
| `list(session, {limit?,offset?}={})` | 同步任务数组；当前 scope，按创建顺序倒序。limit 默认 50，范围 1–100；offset 非负整数。                                      |
| `cancel(session, taskId)`            | 未分派 queued 可 cancelled；已分派/上游任务转 unknown 并取消本地信号。不会承诺上游撤销或退款。终态保持。                    |
| `reconcile(session, taskId)`         | 异步快照；已完成/失败/取消直接返回。其他状态仅调用构造时注入的 query-only 端口，不执行能力。                                |
| `close()`                            | 同步、幂等；queued/running 先记录 unknown，再中止活动信号并关闭库。之后返回 UNAVAILABLE。                                   |

scope 为 `(tenantId, environment, installationId, consumerAppId)`，由代理 session 获取，调用参数不能覆盖。application/conversation 入口共享相同 scope 的任务；安装身份变化不会继承旧数据，后续 E2 须显式迁移映射。读快照不要求旧版本仍安装，但宿主仍须签发有效的同 scope 会话。

`DurableTask` 包含协议 taskId/requestId/capabilityId/status，加 binding（packageId/version/sha256 等）、revision、createdAt/updatedAt ISO 时间，及可选 result（完整 CapabilityResponse）、upstreamTask（原上游 task reference）。快照可在客户端修改，不能回写状态；不返回内部原请求、scope 或凭据。

同 scope + requestId 唯一。JSON 对象 key 顺序不影响去重；数组顺序和实际值影响。相同 ID 但不同输入、能力或当前精确版本返回 CONFLICT。相同请求重提返回原任务，即使结果 unknown，也绝不再次执行。旧绑定已移除时仍返回原记录；新请求必须通过 prepare 的全部授权与输入校验。allowEffects 默认 false，仍拒绝 billable/externalWrite。可信宿主显式启用时，先落盘 needs-approval，不排执行队列；使用 getConfirmation(session, taskId) 读取原请求/绑定/revision，approve(session, taskId, revision) 验证后排队并消费短期凭证。原上游待确认任务不可借此再次执行。完整方法、一次确认与恢复语义见确认与引用参考。

## 状态和恢复

queued → running → completed/failed/unknown/cancelled；Provider accepted 时保存 upstreamTask，允许 queued/running/needs-input/needs-approval，其他引用状态映射 unknown。单凭 accepted 内的 completed 不表示已拿到真实结果。

启动遇到旧 queued/running 一律 unknown，不自动重新调执行器；其他持久状态保留。RESULT_UNKNOWN 错误保留原 requestId/taskId 和上游身份。业务级 error 转 failed，CANCELLED 转 cancelled。已经开始执行的 cancel 转 unknown，并拒绝迟到回调覆盖；这是保守策略，可能连纯计算取消也显示 unknown。

`TaskQuery(task: Readonly<DurableTask>, signal: AbortSignal, context: {request:CapabilityRequest;caller:CapabilityCallerPolicy}): Promise<unknown>` 是可信宿主只查原任务的端口。第三参数提供原请求副本与冻结调用政策，仅限可信查询器；旧两参数回调兼容。尚未确认的本地任务禁止 reconcile；不能用查询绕过确认。必须根据绑定和 taskId/upstreamTask 查询原服务，不能调用 generate、换请求 ID 或推测成功。没有端口返回 UNAVAILABLE。单次上限 1500ms，超时/异常返回 RESULT_UNKNOWN，保留记录，无自动轮询。相同任务正在执行/查询返回 CONFLICT。响应须通过代理的 wire 关联及业务 output schema 校验；查询期间会话撤销、版本变更或 revision 变化不能写入结果。恢复 old binding 需保留同版本的声明与可信绑定，不能借新版本解释旧结果。

## 旧文本/生图视图

`new LegacyTaskViews({broker, readers, map})`；readers 仅 `text?:Pick<AppTextProvider,'getTask'|'listTasks'>` 和 `image?:Pick<AppImageProvider,'getTask'|'listTasks'>`。map 是可信宿主显式 scope → `{textAppId?,imageCaller?}` 映射，未映射 FORBIDDEN，不能从用户输入构造 caller。

`get(session, source, id)` 返回异步 `ProtocolValidation<LegacyTaskView>`；`list(session, source)` 返回数组。source 仅 legacy-text/legacy-image；沿用旧 Provider list 的容量约束，无新分页接口。返回 source/taskId/status/createdAt/updatedAt，可选 text/value、gatewayTaskId、artifacts。submitting 规范为 running，unknown 保留。检查返回 appId/caller 和原 ID，异步查询后重新检查会话。异常使用固定 UNAVAILABLE，原错误、prompt、配置不回传。

此视图不复制旧数据库、不提交生图、不更换原 ID，也不提供 generate。旧 Provider 仍为状态真实来源，其 getTask 可以执行原有查询/规范化逻辑。尚未接入 Desktop 产品路由；可信宿主须按租户/环境建立映射，不能把同 appId 当作跨租户共享授权。

## 验证与后续

证据见 E1-04。本地去重保证不能替代上游幂等或收费对账，也不覆盖绕过服务直接 invoke 的调用；可信宿主应统一通过本服务受理任务。事务日志/快照/备份恢复后的重放策略、生产审批与预算、生产收费核对及 E2 安装生命周期仍需后续门禁。

返回文档总目录 · 当前状态 · 对应交付记录

0.3.0 新增可选可信 TaskPackageLeases acquire/release 端口，任务落盘/执行前保护整个依赖闭包，终态先持久化再释放，unknown 保留，重开补偿终态释放失败。没有端口时原行为兼容；具体类型、scope、顺序、失败与预算见执行与租约参考。

## 既有任务库只读视图（0.4.0）

`new CapabilityTaskViews({path, scope})` 仅供可信 Node 所有者读取既有 schema 1 库；scope 严格为 `{tenantId, environment, installationId, consumerAppId}`，沿用原代理校验，不含入口、grants、执行器或凭据。构造只读打开，不创建目录/数据库，不迁移、不恢复运行状态；缺库、未知 schema、原 EXCLUSIVE 宿主占用时构造失败，100ms busy timeout。

`get(taskId): ProtocolValidation<DurableTask>` 按原 scope/ID 查询；不存在或其他 scope 返回 FORBIDDEN。`list({limit=50,offset=0}={}): ProtocolValidation<DurableTask[]>` 按原 rowid 倒序，limit 为 1–100 整数，offset 为非负安全整数。非法参数 INVALID_INPUT，损坏记录/存储错误/已关闭返回 UNAVAILABLE；`close()` 同步幂等。原记录最大 256 KiB，复核 scope、请求关联、绑定、结果和状态；快照不返回内部 request 输入、fingerprint 或 scope。

此视图不调用执行/上游查询，不回写任务，不释放租约。unknown 保留；进程强退后未经原 CapabilityTasks 恢复的 running/queued 也原样返回，不能把记录状态当作仍在执行或最终失败。原宿主仍在运行时使用它的既有 GET 查询；不要另开执行宿主规避独占锁。执行授权撤销不替代原账户历史隔离。

产品适配、验收证据与剩余上游核对见第十四批交付和SDK/Desktop 手册。

## 原上游查询失败与恢复门禁

可信 query-only 原接口不变。仓库外宿主暂查不到原模拟请求时保留 unknown 和原快照；恢复后核对同一 requestId/taskId，完成结果跨宿主重启与重复查询保持一致，未再执行模型。此为本地模拟上游，非生产收费验证；见第十七批交付。

## 父进程退出的原任务收口

任务模块0.4.0与schema不变。开发宿主显式父管道断开时调用原close：正常close将queued/running落盘为unknown；强退未写回时只读记录仍为running/queued，原宿主启动后恢复unknown。已完成不变，原租约/pin不清理。产品重开读取同一原记录，不能把退出当作撤销副作用。流程与门禁见第十八批交付。

R02可信持久模型账本复用原query-only路径，实际宿主SIGKILL后恢复原unknown及完整pin；查询失败/撤权保留，显式恢复后只接受原结果。原Tasks0.4.0与旧schema保持。账本与上游职责见服务手册，真实本地进程与无费用夹具证据见R02交付。

2026-10-11：Tasks0.4.1修复Windows深层SQLite路径写入与只读打开；文件位置、schema1与原任务身份保持。见目录验收。


## 有界调度与超时

0.5.0可信构造选项 `scheduling?: Partial<TaskSchedulingLimits>` 和 `accountKey?: (caller) => string` 不进入消费请求/wire。`DEFAULT_TASK_SCHEDULING_LIMITS` 导出默认配置；未知字段、非整数、零或超过10000（executionMs超过30000）拒绝构造。

| 限制 | 默认值 |
| --- | --- |
| maxConcurrent / PerTenant / PerAccount / PerScope | 8 / 2 / 2 / 1 |
| maxPending / PerTenant / PerAccount / PerScope | 64 / 16 / 16 / 8 |
| executionMs | 30000ms |

表中 PerTenant 等完整键名是 `maxConcurrentPerTenant`、`maxPendingPerAccount` 等。默认值是保守工程初值，尚未完成容量基准，不是生产吞吐承诺。全局只指当前任务账本。租户计数绑定(environment,tenantId)，账户绑定(environment,tenantId,可信账户键)，scope沿用四维归属。v2/v3已安装开发宿主从可信安装根accountId映射；独立Tasks构造缺省使用installationId，不代表同账户多安装总配额。旧记录没有quota字段时，对账户待处理计数保守计入同租户，旧记录不会重发或改写原身份。

待处理预算包含queued、running、needs-approval及unknown等全部非终态；相同requestId先返回原任务，不被满额挡住。新请求满额返回LIMIT_EXCEEDED，拒绝发生在pin与任务插入之前，不驱逐去重记录。等待执行仍是持久queued；取消未分派任务写入cancelled后释放pin和预算。空位按租户轮转，同租户内保持可执行任务的提交顺序；限额阻挡的scope不堵塞其他可执行scope。

执行期限从分派开始计算。超时先持久unknown再中止信号，保留原ID/版本pin及待处理预算，不把已发生副作用声明为回滚。忽略中止的执行器仍占实际并发槽直到返回，迟到结果丢弃，不靠超时释放槽启动更多失控任务。磁盘故障保留最后持久running，重启仅恢复unknown；原请求查询不重新生成。原有reconcile查询期限1500ms独立保持。

SQLite独占锁只防止同库多宿主，不同账本仍可各自计数；本机全局协调、真实容量基准和OS资源隔离未通过，production执行继续关闭。Worker/QuickJS内存限制不等于全进程RSS硬上限。

调度实现与验证记录 · 返回文档总目录 · 当前状态


## 同机共享配额文件

0.6.0可信构造选项`sharedQuotaPath?: string`指定本机共同SQLite文件，目录须存在；不同任务账本共用它才受同一总量限制。独立宿主`startDevelopmentHost({configPath,dataDirectory,sharedQuotaPath?})`转交该路径，serve CLI通过可信进程环境`SITOO_TASK_QUOTA_PATH`配置。不是消费HTTP参数、SDK调用或公网服务。Desktop每个环境/资料根的页面子宿主和原生服务宿主都使用平台根`task-quota.sqlite`；不同资料根/机器没有自动共享。

```ts
const tasks = new CapabilityTasks({
  path: trustedTaskDatabase,
  broker,
  sharedQuotaPath: trustedSharedQuotaFile,
  accountKey: caller => trustedAccountMap.get(caller.installationId)!,
});
```

示例变量均由可信宿主创建。所有连接必须使用相同完整scheduling设置，后来的连接不能提高限额；消费应用没有配置入口。协调库schema1、WAL、FULL、1000ms busy timeout和BEGIN IMMEDIATE确保占位/获取许可/回收是原子操作。陌生数据库或不兼容配置拒绝，不回退到局部计数。轮转在共享事务内选择下一个租户，等待宿主每50ms重新核对；不是实时吞吐承诺。

新任务先保守占位，再取得版本pin、写入原任务，最后进入可执行队列；跨库中断可能留下占位，既不丢原任务也不自动删除来腾容量。执行终态落盘与实际执行器退出分开：执行器没有返回时并发槽继续占用。只有原持有者正常返回或`process.kill(pid,0)`明确报告ESRCH时才回收执行槽。存活但卡住、权限错误、PID复用均保守保留；不靠心跳超时认定已停止，不会因此多开执行。退出仅回收本机执行槽，unknown和孤立占位仍占待处理预算；未知上游是否继续运行仍须查询原任务，不能声称已取消/退款。

显式启用后任务库升至schema2并固定配额文件路径。0.5.0及更早执行器拒绝schema2；当前构造不能禁用/替换它或用不兼容限额打开。普通局部任务库仍schema1。旧非终态没有可信quota字段时拒绝升级，原库保持，使用只读历史查询；不能猜测账户或重发任务迁移。`CapabilityTaskViews`只读支持合法schema1/2，不打开配额库、不修改业务状态。代码回退不能等同于schema降级，不提供自动降级/占位删除入口。

同机可信进程协调不提供OS沙盒、全机所有任意进程计数或多机共识；任意本地可信操作者仍可修改文件。production业务执行继续关闭，资源容量基准与目标宿主隔离须另验。

共享配额实现与验证 · 返回文档总目录 · 当前状态

共享模式同时固定协调库随机实例标识；删除/重建或换成不同实例拒绝。已绑定任务库的非终态原占位缺失也拒绝，不根据单库残留自动重建全局计数；恢复须保留整组一致性，后续备份轮次另验。

## 存储故障时关闭

close仍同步且幂等；即使unknown落盘失败，也中止本地活动并关闭连接，随后抛出原存储错误。不能把错误当成上游未执行或允许重试。重启从最后持久running/queued保守恢复原任务unknown，schema与去重保持。共享协调库缺表拒绝重建，不换库继续接单。

本机隔离与可靠性交付 · 容量和边界决策。

[返回工具包说明](./README.md)
