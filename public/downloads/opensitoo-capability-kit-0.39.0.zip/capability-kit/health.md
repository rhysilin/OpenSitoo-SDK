# 已安装能力业务健康检查

维护日期：2026-10-08。维护中，适用独立开发宿主/工具包 0.5.0、能力包模块/工具 0.8.0。可信 Node 24 显式开发辅助，不是浏览器 SDK、生产健康接口或自动升级批准。证据见E2-05 第五批。

## 检查范围与兼容

签名、依赖和编译通过，不保证给定输入得到正确业务结果。本接口使用操作者提供的测试向量，通过现有 Broker、真实 QuickJS-WASM、持久任务与完整闭包租约运行，然后比较预期 JSON。沿用[已安装执行](./execution.md)与[持久授权](./authorizations.md)门禁，不注册模型、网络或其他原生 Provider。

只支持已有已安装配置 v2/v3，v1 源码 fixture 不在本检查路径。v3 每项检查接收前和结果判定前复核启动时授权快照，任务租约和执行器继续复核当前信任与授权；旧 passing 报告不能替代这些门禁。配置字段、安装/任务/数据/授权 schema 不变；不影响 serve、旧模板、SDK、Desktop 或现有用户数据。不会自动安装、迁移、回滚或更改 grants。

收费/外部写入声明由现有无副作用执行门禁拒绝，没有消费自批、确认或真实付费服务接线；嵌套调用也沿用 Broker 的委托和副作用限制。使用独立测试数据，不能把业务生产操作当成健康向量。

## 管理接口与命令

```ts
checkInstalledCapabilities({ configPath, casesPath, dataDirectory });
```

异步返回 `ProtocolValidation<CapabilityHealthReport>`。成功读取并完成判定为 ok=true，报告 passed=false 仍为正常检查结果；输入文件/向量无效返回 INVALID_INPUT，安装、当前信任/授权、存储等不可用返回安全 UNAVAILABLE。每项业务失败保留原协议安全错误，不输出路径、SQL、原异常或堆栈。

可搬运工具复制完整目录后执行：

```text
node sitoo-capability.mjs health <host.json> <cases.json> <health-data-directory>
```

退出码 0 仅用于 ok=true 且全部检查 passed；其他结果为 1。它不会启动 HTTP 服务或消费 serve 的任务库；health-data-directory 使用独立 health-tasks.sqlite，并保存 health-RUN_ID.json。任务库记录真实测试请求与结果，按现有任务身份隔离和单宿主锁保护；JSON 报告不含输入、预期值、输出或 bearer。管理目录与测试数据不得交给消费应用。

## 测试向量

```json
{
  "formatVersion": 1,
  "cases": [
    {
      "consumerIndex": 0,
      "request": {
        "protocolVersion": 1,
        "requestId": "019c7714-3b77-74d1-9866-e1f484aae2ab",
        "capabilityId": "alice/run",
        "input": "fixture"
      },
      "expected": "v1:fixture"
    }
  ]
}
```

顶层严格两个字段，case 严格 consumerIndex/request/expected 三字段；consumerIndex 为当前配置 consumers 的有效零起始索引，不是请求自选账户。身份、权限和 bindings 全由可信配置与账本构造；request 不得注入 tenant、bindings、grants 等 authority。request 使用真实协议及业务 schema，expected 是合法 JSON。整个配置/向量文件最多 64 KiB；HEALTH_CHECK_LIMITS 为 cases=8、caseWaitMs=10000、fileBytes=65536。全部向量先做结构校验，再进入执行；一批 requestId 必须唯一。

逐项执行，每项仍受运行器默认 CPU/内存/桥/5 秒总时限预算；悬挂 Guest 因运行预算失败，当前墙钟预算错误码是 LIMIT_EXCEEDED。检查最多观察 queued/running 10 秒，超额或 unknown/needs-input/其他非终态标为 unresolved；不会根据观察超时假设任务成功或释放保护租约。

## 结果、恢复与限制

报告为 `{formatVersion:1,runId,passed,checks}`。每项包含 consumerIndex/requestId/status，可含 taskId、原精确 binding、observedTaskStatus 和安全 error。status 为 passed（完成且 JSON 等于预期）、mismatch（完成但不等于预期）、failed（接收/执行失败）、unresolved（非确定终态）。对象键顺序不影响 JSON 比较，数组顺序有意义；通过 Broker 输出 schema 后才比较，不做字符串模糊匹配。

报告仅说明列出的向量及精确任务结果，不证明未测输入、整个业务的正确性、生产安全或安装原子成功。expected 由操作者维护；改动预期值可能使结果变化，不是发布者认证。报告新建使用唯一 runId 与排他写入，不覆盖历史报告；报告文件和任务库不是跨库原子提交，也未验证断电耐久性。保存失败返回错误，查询原任务而不更换请求 ID。

同一健康目录和原 requestId 重试遵循原任务去重：已完成任务只查询，不再次执行；输入/能力/精确 binding 变化冲突。只修改 expected 可重新比较原结果。若需对同一纯测试场景做新的实际执行，在确认旧任务终态后显式提供新 requestId；不能据此重提 unknown 请求。

真实进程退出后任务恢复为 unknown，重跑原健康命令输出 unresolved，保留原 taskId、旧版本 pin，不自动执行或释放。终态由任务服务先落盘，再释放租约；释放失败保守保留 pin，passing 报告不证明 pin 已释放。关闭观察器也先保存不确定状态。原任务/收据与租约沿用现有生命周期预算，不自动清理去重记录；报告保留和目录维护由可信操作者负责，不删除未知任务目录来绕开更新保护。

业务健康探针已提供；将其作为更新前置批准、跨库维护协调以及 E2 共享总验收尚待后续，不因一次 CLI 成功标记阶段完成。

[执行与租约](./execution.md) · [持久授权](./authorizations.md) · [工具包](./README.md) · API 参考 · 第五批记录

返回文档总目录 · 当前状态

[返回工具包说明](./README.md)
