# 固定客户端的仓库外开发与发布

R07 Alpha总验收记录：仅核对开发/测试支持范围，不改变公共契约。

E3-R06独立多应用开发与CI。

[返回总目录](./README.md) · 当前状态 · [SDK/Desktop 手册](./capability-sdk.md) · [独立工具包](./README.md) · 独立发布示例 · 第十三批交付

维护日期：2026-10-09。Desktop 0.0.15、SDK 0.0.9、开发工具包 0.18.0、便携包 CLI 0.9.0、原安装模块/宿主 0.11.0。状态：开发接入流程；不等于自助上线或生产市场。

## 准备公开分发工具

平台维护者运行 `node scripts/capability-packages.mjs` 和 `node scripts/capability-kit.mjs`，向开发者提供完整 release/capability-packages 与 release/capability-kit。开发者只需要 Node 24、分发文件与 product-reference 示例，不需要平台仓库、Pi/Electron 或 npm 安装。SDK 分发文件仅作为签名页面的浏览器任务客户端。

将两个工具目录放在仓库外，例如 C:/dev/capability-packages 与 C:/dev/capability-kit；复制 product-reference/publisher.mjs 到 C:/dev/example。运行：

```powershell
node C:/dev/example/publisher.mjs init C:/dev/product-example C:/dev/capability-packages C:/dev/capability-kit/capability-sdk.js
node C:/dev/example/publisher.mjs publish C:/dev/product-example 1.0.0 C:/dev/product-example/releases.sqlite
```

init 生成仅用于 development 的三名演示发布者密钥/信任；publish 独立构建三份发布物，使用原 sign/publish CLI 校验并发布。应用包 bob/application 与 carol/application 分别声明 bob.product/carol.product，精确依赖 alice/shared。能力只有 text:read，没有收费和外部写入。签名元数据与 attestation 不放进包目录；目录内文件须完整声明并校验摘要。旧构建目录和原签名文件不会被覆盖，开发者需使用新版本。

## 可信操作者接入客户端

当前没有公开的产品目录导入 API 或自助审核服务。可信操作者负责账号 development 目录、发布库、独立安装/授权库与经过确认的 trust.json，路径和账户身份不交给应用。现有目录布局和管理接口见[SDK/Desktop 手册](./capability-sdk.md)与安装事务手册。开发者的自签名不能自行取得平台信任。

专用自动验收由 scripts/desktop-external-project.mjs 初始化全新的测试账户目录：只通过公开 CLI prepare 后 abort 一个非业务 bootstrap 根，初始化安装库；为同一 bootstrap 根记录 revoked、空 grants 的策略初始化授权库。没有预装 bob/carol，也没有授予它们执行权限。此步骤属于测试操作者，不是应用 SDK 的职责，不应用于覆盖真实账户现有库。已经存在的业务数据、任务、授权和目录须保留。

用户在应用市场分别预览并确认两个应用安装，再分别授权 application/conversation。签名页面通过公开 SDK submit/get/list 查询原任务；对话窗口或 Pi 工具仍使用同一原宿主，开发者不实现另一份业务或 agent loop。

## 固定客户端上的独立修复

在客户端已安装并执行 1.0.0 后，开发者运行：

```powershell
node C:/dev/example/publisher.mjs publish C:/dev/product-example 1.1.0 <可信操作者提供的开发发布库路径>
```

该命令追加签名新发布物，不替换整个现有库，不提交安装或修改授权。刷新市场后，用户明确确认精确版本切换；复核并授权两个入口，页面与对话均获得 V2 实际能力结果。回退继续调用原安装器，旧版本结果恢复。共享代码缓存和两个消费应用的任务/数据各自保持原隔离。

更新/回退不授予新权限；精确闭包变化通常使旧授权失配，回到相同旧闭包可能匹配保留的有效账本。卸载保留任务/数据/其他根；unknown pin 阻止更新和卸载。prepared 可以沿原 requestId 明确继续或放弃，unknown 的产品解决界面仍待后续，不自动重跑或释放 pin。

## 自动验证与限制

```powershell
# 使用已有本机 Playwright 模块路径，不安装新版本：
$env:SITOO_TEST_PLAYWRIGHT_MODULE='<playwright-core/index.mjs 的绝对路径>'
node scripts/verify-desktop-shared-installations.mjs --external
```

测试先固定客户端 package.json/main/preload/renderer 和五个原宿主 sidecar 的 SHA-256，仓库外构建与发布新版本后再次核对，完整流程结束再核对。它不是在每次发布后重建客户端；改变任一已记录产物会拒绝验收。实际能力由 QuickJS/WASM 执行，页面与对话必须比较结果，不能只凭签名或 HTTP 200 判定成功。使用专用临时 profile、真实演示登录和本机服务，无模型请求；重复登录可能触发 1200 秒限流，应等待，不自动重置服务。

本流程的本机自动脚本不等于托管 CI 已上线。外部开发者固定客户端业务门禁、Pi 升级/不可用、unknown 显式恢复、设计工作室迁移各自记录证据；生产身份/联网审核与 E4 自助发布尚未通过。
