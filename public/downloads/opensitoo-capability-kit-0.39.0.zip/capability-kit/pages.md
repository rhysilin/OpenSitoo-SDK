# 独立应用页面与开发任务桥

维护日期：2026-10-09。状态：维护中。开发宿主 0.11.0 / 工具包 0.16.0，Node 24 / Windows 本机浏览器开发参考。使用 static-application-v1、持久授权 v3 与现有任务/QuickJS 链路；任务桥已有浏览器 SDK 与产品 Desktop 接入；HTTP 开发宿主不是产品公开 API。

## 打开页面

启动已安装开发宿主后，在其 loopback URL 打开 `/development`。输入可信操作者已在 host.json 配置的应用开发令牌，点击“打开应用”。页面容器读取 [GET /v1/application](./applications.md)，只打开该消费者的当前签名安装根。令牌只保留在外层容器内存，输入框随后清空，不进入应用 HTML、消息或本地存储。

`GET /development` 与 `GET /development/client.mjs` 无令牌、无查询参数；返回固定容器与可信脚本，不返回配置或用户数据。均 no-store、nosniff，容器带 CSP、no-referrer、设备权限关闭及 frame-ancestors none。应用资源仍需 bearer 与 application 入口的持久授权。

应用运行在 `sandbox="allow-scripts allow-forms"` 的不透明 iframe，没有 allow-same-origin、弹窗、顶层导航或设备权限。allow-forms 仅使应用表单事件可处理，CSP form-action none 阻止实际表单提交。应用不能访问父窗口 DOM、同源存储或直接联网；connect-src、frame-src、worker-src、object-src 均为 none。签名经典脚本通过 nonce 执行，内联事件属性未开放。

父窗口 nonce 策略与子页面仅内联 script-src-elem 策略共同约束脚本；即使应用读取自己的 script nonce，也不能据此加载外部脚本。真实 Chromium 验证报告记录 CSP 阻断而非仅依靠 HTTP 拒绝。

当前支持入口 HTML、相对路径引用的已签名 `.js` 同步经典脚本和 `.css` 样式，以及 HTML 内经典 script/style。容器从签名资源中取内容，不请求未安装资源；拒绝外部脚本/样式、带 query/hash 的引用、缺失资源及 module/async/defer script。移除 base、应用 CSP/refresh meta 和嵌套容器。图片、字体、动态 import、fetch、Worker 与 JSON 文件读取没有开放。此受限开发容器不能替代生产浏览器安全或完整 Web 应用托管。

## 任务桥契约

应用只调用实验性 `window.sitooDevelopmentTasks`。方法返回 `Promise<ProtocolValidation<...>>`，复用 持久任务 与 协议 的真实输入和结果：

| 方法            | 参数                                                            | 成功 value                         |
| --------------- | --------------------------------------------------------------- | ---------------------------------- |
| submit(request) | CapabilityRequest，protocolVersion/requestId/capabilityId/input | DurableTask                        |
| get(taskId)     | 原任务 ID                                                       | DurableTask                        |
| cancel(taskId)  | 原任务 ID                                                       | DurableTask                        |
| list()          | 无                                                              | 当前消费身份的默认分页任务快照数组 |

没有注册、授权、消费者切换、配置、密钥、收费批准、reconcile 或管理方法。宿主继续检查 schema、入口、精确绑定、grants、任务所有权和租约；页面不得通过 input 提供 session 或更换 scope。业务代码仅由原 QuickJS 能力执行，不在容器复制。

外层容器以已打开应用的清单摘要发送 `X-Sitoo-Application`，服务器每次复核完整应用计划、签名和原授权快照。携带该头但格式/摘要/应用状态不符为 403 FORBIDDEN。v3 任务路由允许精确宿主 Origin；有 Origin 的任务请求必须有有效摘要。null、外部 Origin、外部 Host 仍拒绝；v1/v2 不开放浏览器任务调用，原无 Origin CLI 保持兼容。提交体读取后再复核一次，避免读体期间更新沿用旧页面状态。

消息通道只接受当前 iframe 的 null Origin 与随机 channel；完成握手后使用专有 MessagePort。旧页面关闭/替换即关闭端口、移除 iframe、终止容器的 HTTP 等待，不取消或释放已提交持久任务。更新、撤权、信任失效和卸载后已打开页面不能继续经桥调用；需要可信操作者更新授权并重启宿主，再重新打开页面。原任务及 unknown pin 按原任务服务保留。

每页最多 32 个待答桥请求、单消息最多 65536 个序列化字符；服务器继续限制 HTTP 体为 64 KiB。每页通道最多处理 1024 个不同消息 ID，超过后拒绝，重新打开才建立新通道。桥等待 10 秒超时抛出 Error，不自动重发；父容器传输失败返回 UNAVAILABLE。请保留 requestId/taskId，查询原任务；超时或关闭不代表业务回滚。

## 示例与验证

bob/carol 参考项目分别构建自己的签名 HTML/CSS/JS，页面只调用各自 `prepare` 能力，并经同一 alice 能力处理文本。carol 更新到 v2 后页面得到大写结果；宿主没有 appId 特判。

```powershell
node scripts/capability-packages.mjs
node scripts/capability-kit.mjs
# 指向本机已安装的验收工具，不增加应用或宿主依赖。
$env:SITOO_TEST_PLAYWRIGHT_MODULE = 'C:/本机工具/playwright-core/index.mjs'
$env:SITOO_TEST_CHROMIUM = 'C:/本机工具/chrome.exe'
node scripts/verify-shared-capabilities.mjs --browser-pages --keep
```

浏览器工具仅由验证器加载；复制到仓库外的宿主与示例不导入 Playwright、Pi、Electron、平台源码或 node_modules。报告与不含令牌的截图保存于 `.cache/e3-02-browser`，独立夹具 acceptance.json 记录共享全链路检查。`--keep` 保留含开发令牌的夹具，签名有效期一小时，不用于发布。原 `--application-reads` 14 项与 CLI 入口保持兼容。

浏览器模式与 `--faults`/容量/卷故障模式分别执行，不能合用；浏览器进程或报告失败后仍清理自己启动的宿主。

[开发工具包](./README.md) · API 参考 · 本批验证记录 · 当前状态 · 返回总目录

页面之外的同契约规划入口见对话手册。

## 原任务查询（宿主 0.11.0）

GET /v1/tasks 与 GET /v1/tasks/:taskId 在启动时精确应用摘要及原消费身份内只读；撤权或页面更新后现有页面可查询原任务，不恢复执行权限。摘要错误、跨应用、错误 bearer 或不合法 Origin 拒绝。提交、取消与页面读取仍复核当前完整计划/授权。宿主重启使用新的启动摘要，旧 frame 必须重新连接，不能用历史摘要接入新会话。产品实际验收与兼容决定见第九批。

[返回工具包说明](./README.md)
