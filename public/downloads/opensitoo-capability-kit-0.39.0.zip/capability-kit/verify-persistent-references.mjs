// Trusted zero-fee sample. No task ledger or product integration is implemented here.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, relative, isAbsolute } from 'node:path';
import {
  CapabilityReferenceStore,
  CapabilityReferences,
  CapabilityBroker,
} from './service-host.mjs';
const scope = {
  tenantId: 'sample',
  environment: 'test',
  installationId: 'account/installation',
  consumerAppId: 'sample/app',
};
const binding = (capabilityId) => ({
  capabilityId,
  packageId: 'platform/services',
  version: '1.0.0',
  sha256: 'a'.repeat(64),
});
const ids = process.argv[4]
  ? JSON.parse(process.argv[4])
  : { text: randomUUID(), model: randomUUID(), revoked: randomUUID() };
if (process.argv[2] === '--issue') {
  const store = new CapabilityReferenceStore(process.argv[3]),
    refs = new CapabilityReferences({ store });
  refs.issuePersistentText(scope, 'durable snapshot', ids.text);
  refs.issuePersistentModel(scope, 'local/model', 4, ids.model);
  refs.issuePersistentText(scope, 'revoked', ids.revoked);
  refs.revokePersistent(scope, ids.revoked);
  console.log('READY');
  setInterval(() => {}, 1000);
} else if (process.argv[2] === '--restore') {
  const store = new CapabilityReferenceStore(process.argv[3]),
    refs = new CapabilityReferences({ store });
  try {
    const broker = new CapabilityBroker(),
      bindings = { text: binding('platform/read-text'), model: binding('platform/infer') };
    refs.registerCapabilities(broker, bindings);
    const policy = {
      ...scope,
      entry: 'application',
      grants: ['resource:read', 'model:infer'],
      bindings: Object.values(bindings),
    };
    const req = (capabilityId, referenceId) => ({
      protocolVersion: 1,
      requestId: randomUUID(),
      capabilityId,
      input:
        capabilityId === 'platform/infer' ? { referenceId, prompt: 'original' } : { referenceId },
    });
    const read = req('platform/read-text', ids.text),
      session = broker.createSession(policy);
    const output = await broker.invoke(session, read);
    assert.ok(output.ok);
    assert.equal(output.value.value, 'durable snapshot');
    for (const patch of [
      { tenantId: 'other' },
      { environment: 'production' },
      { installationId: 'other-account' },
      { consumerAppId: 'other' },
    ]) {
      const reply = await broker.invoke(broker.createSession({ ...policy, ...patch }), read);
      assert.ok(reply.ok);
      assert.equal(reply.value.status, 'error');
    }
    assert.throws(() => refs.issuePersistentText(scope, 'replacement', ids.text));
    assert.throws(() => refs.issuePersistentText(scope, 'reused', ids.revoked));
    assert.equal(store.read(scope, ids.revoked).revision, 2);
    const wrong = await broker.invoke(session, req('platform/read-text', ids.model));
    assert.ok(wrong.ok);
    assert.equal(wrong.value.status, 'error');
    let inference = 0;
    const original = req('platform/infer', ids.model),
      provider = {
        infer: async () => {
          inference++;
          return 'inferred';
        },
        query: async (_prompt, _scope, id) => ({ originalRequestId: id }),
      };
    await assert.rejects(refs.queryModel(scope, original));
    assert.throws(() => refs.bindPersistentModelProvider(scope, ids.model, 'wrong', 4, provider));
    assert.throws(() =>
      refs.bindPersistentModelProvider(scope, ids.model, 'local/model', 5, provider),
    );
    refs.bindPersistentModelProvider(scope, ids.model, 'local/model', 4, provider);
    provider.query = async () => 'replaced';
    assert.deepEqual(await refs.queryModel(scope, original), {
      originalRequestId: original.requestId,
    });
    assert.equal(inference, 0);
    const approval = broker.issueApproval(session, original);
    assert.ok(approval.ok);
    const result = await broker.invoke(session, original, { approval: approval.value.approval });
    assert.ok(result.ok);
    assert.equal(result.value.value, 'inferred');
    assert.equal(inference, 1);
    refs.revokePersistent(scope, ids.model);
    await assert.rejects(refs.queryModel(scope, original));
    console.log(
      JSON.stringify({
        passed: 5,
        inferenceCalls: inference,
        modelCharges: 0,
        checks: [
          'actual process termination and text recovery',
          'four scope dimensions and wrong kind refused',
          'immutable snapshots and durable tombstones',
          'explicit exact provider rebinding and query-only lookup',
          'original Broker approval and persistent model revocation',
        ],
      }),
    );
  } finally {
    store.close();
  }
} else {
  if (process.argv.length !== 2) throw Error('No arguments expected.');
  const directory = await mkdtemp(join(tmpdir(), 'sitoo-persistent-reference-sample-'));
  let child;
  try {
    const path = join(directory, 'refs.sqlite');
    child = spawn(process.execPath, [import.meta.filename, '--issue', path, JSON.stringify(ids)], {
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(Error('Child not ready')), 10000);
      child.stdout.on('data', (bytes) => {
        if (String(bytes).includes('READY')) {
          clearTimeout(timer);
          resolve();
        }
      });
      child.once('error', reject);
      child.once('exit', () => {
        clearTimeout(timer);
        reject(Error('Child exited'));
      });
      child.stderr.resume();
    });
    await new Promise((resolve) => {
      child.once('exit', resolve);
      child.kill('SIGKILL');
    });
    const result = await promisify(execFile)(
      process.execPath,
      [import.meta.filename, '--restore', path, JSON.stringify(ids)],
      { windowsHide: true, timeout: 10000 },
    );
    process.stdout.write(result.stdout);
  } finally {
    if (child && child.exitCode === null && !child.killed)
      await new Promise((resolve) => {
        child.once('exit', resolve);
        child.kill('SIGKILL');
      });
    const target = relative(tmpdir(), directory);
    if (
      isAbsolute(target) ||
      target.startsWith('..') ||
      !target.startsWith('sitoo-persistent-reference-sample-')
    )
      throw Error('Unsafe cleanup');
    await rm(directory, { recursive: true, force: true });
  }
}
