import { spawn } from 'node:child_process';
import { join } from 'node:path';
import { isolatedCommand } from './process-isolation.mjs';

// 独立发行物入口：与serve使用同一协议，资源控制失败时不降级执行。
try {
  const command = await isolatedCommand(import.meta.dirname, process.execPath);
  const environment = { ...process.env };
  delete environment.NODE_OPTIONS;
  delete environment.NODE_PATH;
  delete environment.ELECTRON_RUN_AS_NODE;
  const child = spawn(
    command.executable,
    [...command.args, join(import.meta.dirname, 'sitoo-capability.mjs'), ...process.argv.slice(2)],
    { env: environment, windowsHide: true, stdio: 'inherit' },
  );
  child.on('error', () => {
    process.exitCode = 70;
  });
  child.on('exit', (code) => {
    process.exitCode = code ?? 70;
  });
  for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => child.kill());
} catch {
  console.error('PROCESS_ISOLATION_UNAVAILABLE');
  process.exitCode = 70;
}
