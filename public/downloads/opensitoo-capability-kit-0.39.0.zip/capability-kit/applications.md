# 独立应用发布物与能力依赖安装

维护日期：2026-10-09。状态：维护中。能力包模块/独立包工具 0.9.0，开发宿主/工具包 0.7.0；可信 Node 开发路径，安装 schema 3 不变。不是已有 `static-platform`/spkg 的替代格式，不新增浏览器 SDK 或 Desktop 接口。

## 已安装应用读取（开发宿主 0.6.0）

`GET /v1/application` 无路径参数和查询参数，使用现有 `Authorization: Bearer <本地开发令牌>`。仅 host.json v3、application 消费入口、active 持久授权且当前安装根包含 static-application-v1 时可读。v1/v2、conversation 入口或仅能力根返回 403 FORBIDDEN；没有或错误令牌为 401。0.7.0 允许精确宿主 Origin，拒绝 null/外部 Origin 与外部 Host，无 CORS。此资源接口返回数据；执行容器另见[页面手册](./pages.md)。

成功 200，响应 `{ok:true,value:{applicationId,packageId,version,sha256,entry,files}}`。sha256 是签名清单摘要；files 为清单中的 `{path,bytes,sha256,source}` 数组，source 是校验后的 UTF-8 字符串。只包含顶层应用资源，不包含依赖 Guest 源码、凭据、宿主路径或管理配置。响应为 `application/json; charset=utf-8`，no-store、nosniff；HTML/JS 作为数据返回，不在宿主执行。

每次读取重新加载当前完整安装并验证文件摘要、签名/有效期/撤回和应用身份，复核原授权快照与启动时完整安装计划。撤权或授权修订、信任撤回、内容篡改、更新、卸载均拒绝旧读取；页面更新即使保持能力绑定也拒绝。可信操作者重新启动宿主才采用新计划；如果能力绑定变化，还须先显式更新持久授权。合法信任文件无法读取/解析等宿主异常返回 503 UNAVAILABLE，不披露路径或堆栈。多消费者各自读取自己的根，没有 applicationId 切换参数。

此接口是 E3 页面加载的前置条件，不能直接导航此接口来运行应用。0.7.0 新增[隔离页面与通用任务桥](./pages.md)；自然语言入口、SDK 和 Desktop 接入仍待实现。契约见 API 参考，读取验证见 E3 第一批记录。可重复仓库外验证：`node scripts/verify-shared-capabilities.mjs --application-reads [--keep]`，启用应用安装及两消费者 application 入口，共 14 项；保留原 `--applications` 11 项入口。

## 格式与边界

新增 `StaticApplicationPackageManifest`，与原 `CapabilityPackageManifest` 组成 `InstallablePackageManifest`。`VerifiedCapabilityPackage.manifest` 接受两者，原内容校验/目录读取、署名、离线发布和安装方法均复用。文件名仍为 `capability-package.json`，以 execution 区分类型；旧工具拒绝新类型，升级独立工具后才可处理。

```json
{
  "formatVersion": 1,
  "execution": "static-application-v1",
  "packageId": "bob/app",
  "version": "1.0.0",
  "application": { "applicationId": "bob.shared", "entry": "index.html" },
  "dependencies": [{ "packageId": "bob/consumer", "range": "1.0.0" }],
  "capabilities": [],
  "files": [{ "path": "index.html", "bytes": 123, "sha256": "填入真实64位摘要" }]
}
```

示例中的 bytes/sha256 是占位，不能直接发布；参考项目的 `application.mjs` 会根据实际文件生成。version 为规范 SemVer；依赖使用既有范围解析，最终安装的是完整精确闭包。

所有字段严格校验。application 恰含 applicationId/entry；ID 长度最多 128、由小写字母开头且只包含小写字母/数字/点/连字符，必须以包 namespace 加点开头。entry 必须是已声明的 `.html` 文件。capabilities 必须为空，应用不能携带 Guest 执行函数。业务实现独立发布为能力依赖。

页面内容限 UTF-8 `.html/.css/.js/.json`；相对路径、大小/文件数量预算、摘要、大小写冲突、符号链接和多余文件等按包内容规则校验，根清单文件不能同时列为 payload。拒绝二进制、任意原生后端及未声明文件。`sources` 字段对应用表示已验证文本 payload，不能据字段名称把它送入 Guest 执行器。

此格式只验证与存储页面，不渲染 HTML、不执行页面 JS、不开放页面桥或权限；页面入口的浏览器沙盒/资源服务和自然语言入口在 E3 接入。不要将成功安装等同已经启动应用或已批准脚本。

## 根与依赖

应用只能作为安装计划的**唯一顶层根**；不能作为另一应用或能力的依赖。应用 applicationId 必须与可信根中的 applicationId 相同。多个应用分别使用不同安装根，共享相同能力内容，不共享授权、任务或数据。

非法类型、字段、入口、路径或 payload 返回 INVALID_INPUT，预算错误保持既有规则；应用作为依赖解析为 CONFLICT，应用/安装根身份不符、混合根或剥掉应用的更新为 FORBIDDEN。CLI 与模块均使用既有安全错误封装，不返回源码、凭据或本机路径。

prepare/commit 在同一 SQLite 安装库原子提交应用及完整能力闭包；有任一缺失、冲突、签名/身份失败时，不暴露半个应用。读取安装/租约时重新验证当前信任、完整精确计划和应用身份。更新不能将已有应用换成能力根；原能力根仍支持旧方法以保持兼容。

页面发布物不产生 CapabilityBinding；调用 binding 来自依赖能力。任务租约快照仍保存完整计划，包含应用发布物与所有依赖，因此任务进行中、结果 unknown 或已分派取消时不能更新/卸载根。当前授权、权限审查、代码回收与独立数据迁移规则均保留，安装不自动授权或迁移数据。

## 可重复验收

```powershell
node scripts/capability-packages.mjs
node scripts/capability-kit.mjs
node scripts/verify-shared-capabilities.mjs --applications
```

验证器在仓库外独立构建 alice 能力和 bob/carol 业务能力，另生成三份独立签名应用发布物。11 项场景实际检查应用与依赖的同库安装、真实委托执行、业务健康、在途保护、授权更新、多版本、代码/数据分别回退和卸载保留。`--keep` 成功时保留新开发夹具，开发信任有效期一小时。

新增 `node scripts/verify-shared-capabilities.mjs --faults` 自动包含应用模式，共 18 项，覆盖完整应用安装/更新的真实进程退出、SQLite 写入失败注入、原请求恢复/abort 和 unknown 完整租约保护，见组合故障证据。历史 E2 验证时页面只展示安装说明，CLI 消费端负责真实调用；后续 0.7.0 已提供隔离页面任务桥，自然语言仍未接入；触发器自身不代表真实磁盘耗尽；后续容量记录已补齐真实 NTFS ENOSPC 并通过 E2 独立开发门禁。

共享参考 · 安装事务 · 业务执行与租约 · 本批交付证据 · API 参考 · 当前状态 · 返回文档总目录

`--capacity-faults` 自动包含应用/组合故障，共 20 项，通过重新签名的有界页面夹具及 SQLite max_page_count 触发原生 SQLITE_FULL，验原应用安装/更新请求恢复；见容量耗尽证据。不修改应用源码或包格式，不代表物理卷耗尽门禁已通过。

[返回工具包说明](./README.md)
