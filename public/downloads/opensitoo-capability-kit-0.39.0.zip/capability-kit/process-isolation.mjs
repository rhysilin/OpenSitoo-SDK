import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';

/** 只供可信宿主使用；应用输入不能选择启动器、限额或可执行文件。 */
export async function isolatedCommand(directory, executable) {
  if (process.platform !== 'win32' || process.arch !== 'x64')
    throw new Error('PROCESS_ISOLATION_UNAVAILABLE');
  const manifest = JSON.parse(await readFile(join(directory, 'isolation-manifest.json'), 'utf8'));
  if (
    manifest.version !== 1 ||
    manifest.mode !== 'windows-job-quickjs-v1' ||
    manifest.file !== 'sitoo-job.exe' ||
    manifest.memoryMiB !== 512 ||
    manifest.cpuPercent !== 25 ||
    manifest.activeProcessLimit !== 1
  )
    throw new Error('PROCESS_ISOLATION_UNAVAILABLE');
  const launcher = join(directory, 'sitoo-job.exe');
  if (
    createHash('sha256')
      .update(await readFile(launcher))
      .digest('hex') !== manifest.sha256
  )
    throw new Error('PROCESS_ISOLATION_UNAVAILABLE');
  return { executable: launcher, args: ['512', '25', '--owner', String(process.pid), executable] };
}
