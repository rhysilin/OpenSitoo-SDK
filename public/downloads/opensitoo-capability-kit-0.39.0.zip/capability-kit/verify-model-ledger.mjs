// Trusted zero-fee process acceptance. Run from a copied kit, never in an app/Guest.
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { createServer } from 'node:http';
import { fork } from 'node:child_process';
import { once } from 'node:events';
import { generateKeyPairSync, randomUUID, randomBytes, createHash } from 'node:crypto';
import { mkdtemp, writeFile, readFile, rm } from 'node:fs/promises';
import { join, relative, isAbsolute } from 'node:path';
import { tmpdir } from 'node:os';
import { setTimeout as delay } from 'node:timers/promises';
import {
  CapabilityReferences,
  CapabilityReferenceStore,
  ModelRequestLedger,
  createDurableModelProvider,
  CapabilityInstallationStore,
  CapabilityAuthorizationStore,
  CapabilityPackageTrust,
  CapabilityReleaseStore,
  verifyCapabilityPackage,
  signCapabilityPackage,
  startDevelopmentHost,
  createModelTaskQuery,
} from './service-host.mjs';
const unwrap = (result) => {
  assert.ok(result.ok, JSON.stringify(result));
  return result.value;
};
const digest = (value) => createHash('sha256').update(value).digest('hex');
const message = (child, type) =>
  new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      cleanup();
      reject(Error('IPC timeout ' + type));
    }, 10000);
    const receive = (value) => {
      if (value.type === type) {
        cleanup();
        resolve(value);
      }
    };
    const exited = (code) => {
      cleanup();
      reject(Error('Child exited ' + code + ' before ' + type));
    };
    const cleanup = () => {
      clearTimeout(timeout);
      child.off('message', receive);
      child.off('exit', exited);
    };
    child.on('message', receive);
    child.on('exit', exited);
  });
const [mode, directory, parameter] = process.argv.slice(2);
if (mode === 'upstream') {
  // Independent process/database: durable effect survives the service host being killed.
  const db = new DatabaseSync(join(directory, 'upstream.sqlite'));
  db.exec(
    "PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; CREATE TABLE results(id TEXT PRIMARY KEY, request_id TEXT, hash TEXT, value TEXT); CREATE TABLE counts(kind TEXT PRIMARY KEY, n INTEGER); INSERT INTO counts VALUES ('infer',0),('query',0)",
  );
  let available = false,
    barrier = false,
    release;
  process.on('message', (control) => {
    if (control.type === 'control') {
      available = control.available;
      barrier = control.barrier;
      process.send({ type: 'controlled' });
    }
    if (control.type === 'release') release?.();
  });
  const server = createServer(async (req, res) => {
    try {
      let bytes = '';
      for await (const chunk of req) bytes += chunk;
      const record = JSON.parse(bytes);
      assert.equal(req.method, 'POST');
      const kind = req.url === '/infer' ? 'infer' : req.url === '/query' ? 'query' : undefined;
      assert.ok(kind);
      db.prepare('UPDATE counts SET n=n+1 WHERE kind=?').run(kind);
      if (kind === 'infer') {
        const value = JSON.stringify({
          text: record.prompt.toUpperCase(),
          association: record.upstreamRequestId,
        });
        db.prepare('INSERT INTO results VALUES (?,?,?,?)').run(
          record.upstreamRequestId,
          record.requestId,
          record.inputSha256,
          value,
        );
      } else {
        if (!available) throw Error('query unavailable');
        if (barrier) {
          const wait = new Promise((resolve) => {
            release = resolve;
          });
          process.send({ type: 'query-barrier' });
          await wait;
          release = undefined;
        }
      }
      const row = db.prepare('SELECT * FROM results WHERE id=?').get(record.upstreamRequestId);
      if (!row || row.request_id !== record.requestId || row.hash !== record.inputSha256)
        throw Error('original not found');
      res.end(row.value);
    } catch {
      res.statusCode = 503;
      res.end('{}');
    }
  });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  process.send({ type: 'ready', url: 'http://127.0.0.1:' + server.address().port });
} else if (mode === 'host') {
  const metadata = JSON.parse(await readFile(join(directory, 'metadata.json'), 'utf8'));
  const store = new CapabilityReferenceStore(join(directory, 'references.sqlite'));
  const references = new CapabilityReferences({ store });
  const ledger = new ModelRequestLedger(join(directory, 'ledger.sqlite'));
  for (const item of metadata.owners) {
    references.bindPersistentModelProvider(
      item.scope,
      item.id,
      'local/ledger-fixture',
      1,
      createDurableModelProvider({
        ledger,
        references: store,
        scope: item.scope,
        referenceId: item.id,
        binding: metadata.binding,
        upstream: {
          infer: async (record, signal) => {
            if (parameter === 'before-effect') {
              process.send({ type: 'dispatch-barrier', requestId: record.requestId });
              await new Promise(() => {});
            }
            const reply = await fetch(metadata.upstream + '/infer', {
              method: 'POST',
              body: JSON.stringify(record),
              signal,
            });
            if (!reply.ok) throw Error('upstream failed');
            const result = await reply.json();
            // The effect is committed upstream, but the service ledger has no result yet.
            if (parameter === 'after-effect') {
              process.send({ type: 'dispatch-barrier', requestId: record.requestId });
              await new Promise(() => {});
            }
            return result;
          },
          query: async (record, signal) => {
            const reply = await fetch(metadata.upstream + '/query', {
              method: 'POST',
              body: JSON.stringify(record),
              signal,
            });
            if (!reply.ok) throw Error('original unavailable');
            return reply.json();
          },
        },
      }),
    );
  }
  const host = await startDevelopmentHost({
    configPath: join(directory, 'host.json'),
    dataDirectory: join(directory, 'tasks'),
    installedServices: references.createCapabilities(metadata.bindings),
    confirmationToken: metadata.operatorToken,
    taskQuery: createModelTaskQuery(references),
  });
  process.send({ type: 'ready', url: host.url });
  process.on('message', async (value) => {
    if (value.type === 'close') {
      await host.close();
      ledger.close();
      store.close();
      process.exit(0);
    }
  });
} else {
  assert.equal(mode, undefined, 'Usage: node verify-model-ledger.mjs');
  const work = await mkdtemp(join(tmpdir(), 'sitoo-model-ledger-'));
  const children = new Set(),
    results = [];
  let host, url;
  const start = (role, arg) => {
    const child = fork(import.meta.filename, [role, work, ...(arg ? [arg] : [])], {
      cwd: work,
      windowsHide: true,
      stdio: ['ignore', 'inherit', 'inherit', 'ipc'],
    });
    children.add(child);
    child.on('exit', () => children.delete(child));
    return child;
  };
  const stop = async (child, killed = false) => {
    const exit = once(child, 'exit');
    if (killed) {
      killedHosts.push({ pid: child.pid, signal: 'SIGKILL' });
      child.kill('SIGKILL');
    } else child.send({ type: 'close' });
    await exit;
  };
  const check = (name) => {
    results.push(name);
    console.log('PASS ' + name);
  };
  const killedHosts = [];
  let releases, referenceStore, upstreamDB;
  const installations = [],
    authorizations = [];
  try {
    const upstream = start('upstream'),
      ready = await message(upstream, 'ready');
    const references = new CapabilityReferences();
    const dummy = (capabilityId) => ({
      capabilityId,
      packageId: 'platform/services',
      version: '1.0.0',
      sha256: 'a'.repeat(64),
    });
    const capabilities = references
      .createCapabilities({ text: dummy('platform/read-text'), model: dummy('platform/infer') })
      .map(({ declaration: { binding, ...contract } }) => ({
        capabilityId: binding.capabilityId,
        ...contract,
      }));
    const native = unwrap(
      verifyCapabilityPackage(
        JSON.stringify({
          formatVersion: 1,
          execution: 'host-service-v1',
          packageId: 'platform/services',
          version: '1.0.0',
          files: [],
          dependencies: [],
          capabilities,
        }),
        new Map(),
      ),
    );
    const application = (name, version = '1.0.0') => {
      const source = '<!doctype html><title>Ledger acceptance</title>';
      return unwrap(
        verifyCapabilityPackage(
          JSON.stringify({
            formatVersion: 1,
            execution: 'static-application-v1',
            packageId: 'alice/' + name,
            version,
            application: { applicationId: 'alice.' + name, entry: 'index.html' },
            dependencies: [{ packageId: 'platform/services', range: '1.0.0' }],
            capabilities: [],
            files: [
              { path: 'index.html', bytes: Buffer.byteLength(source), sha256: digest(source) },
            ],
          }),
          new Map([['index.html', Buffer.from(source)]]),
        ),
      );
    };
    const apps = [application('app-a'), application('app-b')],
      updated = application('app-a', '1.1.0');
    const keys = generateKeyPairSync('ed25519'),
      now = Date.now();
    const trusted = ['platform', 'alice'].map((namespace) => ({
      keyId: namespace,
      namespace,
      environments: ['development'],
      publicKeyPem: keys.publicKey.export({ format: 'pem', type: 'spki' }).toString(),
      notBefore: now - 1000,
      notAfter: now + 300000,
      revoked: false,
    }));
    const trust = new CapabilityPackageTrust(trusted);
    await writeFile(join(work, 'trust.json'), JSON.stringify(trusted));
    releases = new CapabilityReleaseStore(join(work, 'releases.sqlite'));
    const published = [native, ...apps, updated].map((pkg) =>
      unwrap(
        releases.publish(
          pkg,
          unwrap(
            signCapabilityPackage(pkg, keys.privateKey, {
              keyId: pkg.manifest.packageId.split('/')[0],
              environment: 'development',
              issuedAt: now,
              expiresAt: now + 300000,
            }),
          ),
          trust,
        ),
      ),
    );
    const consumers = [],
      owners = [];
    referenceStore = new CapabilityReferenceStore(join(work, 'references.sqlite'));
    for (let i = 0; i < 2; i++) {
      const root = {
        tenantId: 'tenant',
        accountId: 'account',
        applicationId: apps[i].manifest.application.applicationId,
        environment: 'development',
      };
      const installation = new CapabilityInstallationStore(join(work, 'installation.sqlite'), root);
      installations.push(installation);
      unwrap(
        installation.prepare(
          'install',
          [{ packageId: apps[i].manifest.packageId, range: '1.0.0' }],
          [published[0], published[i + 1]],
          releases,
          trust,
        ),
      );
      unwrap(installation.commit('install', releases, trust));
      const plan = unwrap(installation.load(trust)).plan;
      const scope = {
        tenantId: root.tenantId,
        environment: root.environment,
        installationId: digest(
          JSON.stringify([root.tenantId, root.accountId, root.applicationId, root.environment]),
        ),
        consumerAppId: root.applicationId,
      };
      const id = randomUUID();
      referenceStore.issue(scope, id, {
        kind: 'model',
        providerId: 'local/ledger-fixture',
        providerRevision: 1,
      });
      owners.push({ scope, id });
      for (const entry of ['application', 'conversation']) {
        const auth = new CapabilityAuthorizationStore(
          join(work, 'authorization.sqlite'),
          root,
          entry,
        );
        authorizations.push(auth);
        unwrap(
          auth.set('grant', 0, {
            entry,
            bindings: plan.bindings,
            grants: ['resource:read', 'model:infer'],
          }),
        );
        consumers.push({ token: randomBytes(32).toString('hex'), root, entry });
      }
    }
    const operatorToken = randomBytes(32).toString('hex'),
      binding = native.bindings.find((b) => b.capabilityId === 'platform/infer');
    await writeFile(
      join(work, 'metadata.json'),
      JSON.stringify({
        owners,
        operatorToken,
        upstream: ready.url,
        binding,
        bindings: {
          text: native.bindings.find((b) => b.capabilityId === 'platform/read-text'),
          model: binding,
        },
      }),
    );
    await writeFile(
      join(work, 'host.json'),
      JSON.stringify({
        version: 3,
        installationPath: 'installation.sqlite',
        trustPath: 'trust.json',
        authorizationPath: 'authorization.sqlite',
        consumers,
      }),
    );
    upstreamDB = new DatabaseSync(join(work, 'upstream.sqlite'));
    const count = (kind) => upstreamDB.prepare('SELECT n FROM counts WHERE kind=?').get(kind).n;
    const boot = async (arg) => {
      host = start('host', arg);
      url = (await message(host, 'ready')).url;
    };
    const call = async (index, path, body, approval = false) =>
      (
        await fetch(url + path, {
          method: body === undefined ? 'GET' : 'POST',
          headers: {
            authorization: 'Bearer ' + consumers[index].token,
            'content-type': 'application/json',
            ...(approval ? { 'x-fixture-confirmation': operatorToken } : {}),
          },
          ...(body === undefined ? {} : { body: JSON.stringify(body) }),
        })
      ).json();
    const until = async (index, id, status) => {
      for (let n = 0; n < 150; n++) {
        const task = unwrap(await call(index, '/v1/tasks/' + id));
        if (task.status === status) return task;
        await delay(10);
      }
      throw Error('Task timeout ' + status);
    };
    const submit = async (index, prompt) => {
      const request = {
        protocolVersion: 1,
        requestId: randomUUID(),
        capabilityId: 'platform/infer',
        input: { referenceId: owners[Math.floor(index / 2)].id, prompt },
      };
      const task = unwrap(await call(index, '/v1/tasks', request));
      assert.equal(task.status, 'needs-approval');
      return { request, task };
    };
    const approve = (index, task) =>
      call(index, '/v1/confirmations/' + task.taskId, { revision: task.revision }, true);
    const control = async (available, barrier = false) => {
      const ack = message(upstream, 'controlled');
      upstream.send({ type: 'control', available, barrier });
      await ack;
    };
    await boot('after-effect');
    const original = await submit(0, 'original');
    const dispatched = message(host, 'dispatch-barrier');
    unwrap(await approve(0, original.task));
    await dispatched;
    assert.equal(count('infer'), 1);
    await stop(host, true);
    await boot();
    const originalUnknown = await until(0, original.task.taskId, 'unknown');
    const pinned = unwrap(installations[0].getLease(original.task.taskId));
    assert.equal(pinned.status, 'active');
    assert.equal(pinned.plan.packages.length, 2);
    const ledger = new ModelRequestLedger(join(work, 'ledger.sqlite'));
    const row = ledger.read(owners[0].scope, original.request.requestId);
    assert.equal(row.status, 'dispatched');
    assert.equal(row.binding.sha256, binding.sha256);
    assert.equal(row.referenceId, owners[0].id);
    assert.equal(row.inputSha256, digest(JSON.stringify(original.request.input)));
    assert.equal(
      upstreamDB.prepare('SELECT COUNT(*) AS n FROM results WHERE id=?').get(row.upstreamRequestId)
        .n,
      1,
    );
    ledger.close();
    check(
      'actual SIGKILL after durable upstream effect restores original unknown and complete two-package pin',
    );
    assert.equal(unwrap(await call(0, '/v1/tasks', original.request)).taskId, original.task.taskId);
    assert.equal((await call(2, '/v1/tasks/' + original.task.taskId)).ok, false);
    assert.equal((await call(2, '/v1/tasks/' + original.task.taskId + '/reconcile', {})).ok, false);
    unwrap(
      installations[0].prepareUpdate(
        'update',
        [{ packageId: 'alice/app-a', range: '1.1.0' }],
        [published[0], published[3]],
        releases,
        trust,
      ),
    );
    assert.equal(installations[0].commit('update', releases, trust).ok, false);
    unwrap(installations[0].prepareUninstall('blocked-uninstall'));
    assert.equal(installations[0].commitUninstall('blocked-uninstall').ok, false);
    const collected = unwrap(installations[0].collectUnused());
    assert.equal(collected.removed, 0);
    assert.equal(unwrap(installations[0].getLease(original.task.taskId)).plan.packages.length, 2);
    assert.equal((await call(0, '/v1/tasks/' + original.task.taskId + '/reconcile', {})).ok, false);
    assert.equal(unwrap(installations[0].getLease(original.task.taskId)).status, 'active');
    assert.equal(count('infer'), 1);
    check(
      'duplicate/foreign requests and unavailable original query never redispatch or release pin',
    );
    await control(true, true);
    const barrier = message(upstream, 'query-barrier');
    const reconciliation = call(0, '/v1/tasks/' + original.task.taskId + '/reconcile', {});
    await barrier;
    const current = unwrap(authorizations[0].read());
    unwrap(
      authorizations[0].set(
        'revoke',
        current.revision,
        { ...current.policy, grants: [] },
        'revoked',
      ),
    );
    upstream.send({ type: 'release' });
    assert.equal((await reconciliation).ok, false);
    assert.equal(unwrap(installations[0].getLease(original.task.taskId)).status, 'active');
    check('revocation during real upstream HTTP query preserves original unknown and full pin');
    await stop(host);
    unwrap(authorizations[0].set('restore', current.revision + 1, current.policy));
    await control(true);
    await boot();
    const completed = unwrap(await call(0, '/v1/tasks/' + original.task.taskId + '/reconcile', {}));
    assert.equal(completed.status, 'completed');
    assert.deepEqual(completed.result.value, {
      text: 'ORIGINAL',
      association: row.upstreamRequestId,
    });
    assert.equal(unwrap(installations[0].getLease(original.task.taskId)).status, 'released');
    const queried = count('query');
    unwrap(await call(0, '/v1/tasks/' + original.task.taskId + '/reconcile', {}));
    assert.equal(count('query'), queried);
    assert.equal(count('infer'), 1);
    check(
      'explicit reauthorization and rebuild accepts only original result and releases pin once; inference remains one',
    );
    await stop(host);
    await boot('before-effect');
    const absent = await submit(2, 'no-effect');
    const before = message(host, 'dispatch-barrier');
    unwrap(await approve(2, absent.task));
    await before;
    await stop(host, true);
    await boot();
    const absentUnknown = await until(2, absent.task.taskId, 'unknown');
    assert.equal((await call(2, '/v1/tasks/' + absent.task.taskId + '/reconcile', {})).ok, false);
    assert.equal(unwrap(await call(2, '/v1/tasks', absent.request)).taskId, absent.task.taskId);
    assert.equal(unwrap(installations[1].getLease(absent.task.taskId)).status, 'active');
    assert.equal(count('infer'), 1);
    check(
      'actual pre-effect SIGKILL and absent upstream proof stay unknown/pinned without inference fallback',
    );
    console.log(
      JSON.stringify({
        passed: results.length,
        inferenceCalls: count('infer'),
        queryCalls: count('query'),
        actualHostKills: killedHosts.length,
        killedHosts,
        originalRequestId: original.request.requestId,
        originalTaskId: original.task.taskId,
        upstreamRequestId: row.upstreamRequestId,
        inputSha256: row.inputSha256,
        binding: row.binding,
        originalRecovery: { status: originalUnknown.status, pin: pinned.status },
        reconciled: {
          status: completed.status,
          pin: unwrap(installations[0].getLease(original.task.taskId)).status,
        },
        absentRequestId: absent.request.requestId,
        absentTaskId: absent.task.taskId,
        absentRecovery: {
          status: absentUnknown.status,
          pin: unwrap(installations[1].getLease(absent.task.taskId)).status,
        },
        modelCharges: 0,
      }),
    );
  } finally {
    for (const child of [...children]) {
      const exited = once(child, 'exit');
      child.kill('SIGKILL');
      await exited;
    }
    upstreamDB?.close();
    referenceStore?.close();
    releases?.close();
    for (const store of [...authorizations, ...installations]) store.close();
    const target = relative(tmpdir(), work);
    if (isAbsolute(target) || target.startsWith('..') || !target.startsWith('sitoo-model-ledger-'))
      throw Error('Unsafe cleanup');
    await rm(work, { recursive: true, force: true });
  }
}
