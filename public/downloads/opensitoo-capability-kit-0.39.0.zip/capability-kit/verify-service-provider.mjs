// Trusted, zero-fee integration sample. Applications must use the task SDK instead.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, relative, isAbsolute } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import {
  CapabilityBroker,
  CapabilityTasks,
  CapabilityReferences,
  createModelTaskQuery,
} from './service-host.mjs';

const directory = await mkdtemp(join(tmpdir(), 'sitoo-service-provider-'));
const scope = {
  tenantId: 'sample',
  environment: 'test',
  installationId: 'installation',
  consumerAppId: 'app/a',
};
const binding = (capabilityId) => ({
  capabilityId,
  packageId: 'platform/sample',
  version: '1.0.0',
  sha256: 'a'.repeat(64),
});
const bindings = { text: binding('platform/read-text'), model: binding('platform/infer') };
const policy = {
  ...scope,
  entry: 'application',
  grants: ['model:infer'],
  bindings: Object.values(bindings),
};
const broker = new CapabilityBroker();
const references = new CapabilityReferences();
references.registerCapabilities(broker, bindings);
const session = broker.createSession(policy);
const foreign = broker.createSession({ ...policy, consumerAppId: 'app/b' });
const ledger = new DatabaseSync(join(directory, 'provider.sqlite'));
ledger.exec(
  'CREATE TABLE results(owner TEXT, request_id TEXT, prompt TEXT, result TEXT, PRIMARY KEY(owner,request_id));',
);
const owner = (value) =>
  JSON.stringify([value.tenantId, value.environment, value.installationId, value.consumerAppId]);
let inferenceCalls = 0,
  queryCalls = 0,
  available = false;
const provider = {
  async infer(prompt, context, requestId) {
    inferenceCalls++;
    ledger
      .prepare('INSERT INTO results VALUES (?,?,?,?)')
      .run(owner(context), requestId, prompt, JSON.stringify({ text: prompt.toUpperCase() }));
    throw new Error('Sample response lost after durable execution.');
  },
  async query(prompt, context, requestId) {
    queryCalls++;
    if (!available) throw new Error('Sample upstream unavailable.');
    const row = ledger
      .prepare('SELECT * FROM results WHERE owner=? AND request_id=?')
      .get(owner(context), requestId);
    if (!row || row.prompt !== prompt) throw new Error('Original request absent.');
    return JSON.parse(row.result);
  },
};
const referenceId = references.issueModelProvider(scope, provider);
const request = {
  protocolVersion: 1,
  requestId: randomUUID(),
  capabilityId: 'platform/infer',
  input: { referenceId, prompt: 'original' },
};
const unwrap = (result) => {
  assert.ok(result.ok, JSON.stringify(result));
  return result.value;
};
const pins = new Set();
const options = {
  path: join(directory, 'tasks.sqlite'),
  broker,
  allowEffects: true,
  query: createModelTaskQuery(references),
  packageLeases: {
    acquire(task) {
      pins.add(task.taskId);
      return { ok: true, value: null };
    },
    release(task) {
      pins.delete(task.taskId);
      return { ok: true, value: null };
    },
  },
};
let tasks = new CapabilityTasks(options);
const results = [];
const check = (name) => {
  results.push(name);
  console.log('PASS ' + name);
};
try {
  const accepted = unwrap(tasks.submit(session, request));
  assert.equal(accepted.status, 'needs-approval');
  assert.equal(inferenceCalls, 0);
  assert.equal((await tasks.reconcile(session, accepted.taskId)).ok, false);
  assert.equal(queryCalls, 0);
  assert.equal(tasks.approve(foreign, accepted.taskId, accepted.revision).ok, false);
  check('no execution or upstream query before trusted approval; foreign approval denied');
  unwrap(tasks.approve(session, accepted.taskId, accepted.revision));
  for (let i = 0; i < 100 && unwrap(tasks.get(session, accepted.taskId)).status !== 'unknown'; i++)
    await delay(10);
  assert.equal(unwrap(tasks.get(session, accepted.taskId)).status, 'unknown');
  assert.equal(inferenceCalls, 1);
  assert.ok(pins.has(accepted.taskId));
  assert.equal(unwrap(tasks.submit(session, request)).taskId, accepted.taskId);
  check('lost response retains original task and pin; duplicate never executes');
  tasks.close();
  tasks = new CapabilityTasks(options);
  assert.equal(unwrap(tasks.get(session, accepted.taskId)).status, 'unknown');
  const unavailable = await tasks.reconcile(session, accepted.taskId);
  assert.equal(unavailable.ok, false);
  assert.equal(unavailable.error.code, 'RESULT_UNKNOWN');
  assert.equal(unwrap(tasks.get(session, accepted.taskId)).status, 'unknown');
  assert.ok(pins.has(accepted.taskId));
  assert.equal(inferenceCalls, 1);
  check('reopen and unavailable lookup preserve unknown and pin without inference');
  assert.equal((await tasks.reconcile(foreign, accepted.taskId)).ok, false);
  assert.equal(queryCalls, 1);
  available = true;
  const completed = unwrap(await tasks.reconcile(session, accepted.taskId));
  assert.equal(completed.status, 'completed');
  assert.deepEqual(completed.result.value, { text: 'ORIGINAL' });
  assert.equal(pins.size, 0);
  check('original owner/request/prompt lookup completes and releases original pin');
  unwrap(await tasks.reconcile(session, accepted.taskId));
  assert.equal(queryCalls, 2);
  assert.equal(inferenceCalls, 1);
  assert.equal(ledger.prepare('SELECT COUNT(*) AS count FROM results').get().count, 1);
  check('terminal query is durable and never calls provider again');
  const missing = references.issueModel(scope, provider.infer);
  await assert.rejects(
    references.queryModel(scope, {
      ...request,
      input: { referenceId: missing, prompt: 'original' },
    }),
  );
  references.revoke(referenceId);
  await assert.rejects(references.queryModel(scope, request));
  assert.equal(inferenceCalls, 1);
  assert.equal(queryCalls, 2);
  check('missing query or revoked reference never falls back to inference');
  console.log(
    JSON.stringify({
      passed: results.length,
      results,
      inferenceCalls,
      queryCalls,
      modelCharges: 0,
    }),
  );
} finally {
  tasks.close();
  ledger.close();
  const relativePath = relative(tmpdir(), directory);
  if (
    isAbsolute(relativePath) ||
    relativePath.startsWith('..') ||
    !relativePath.startsWith('sitoo-service-provider-')
  )
    throw new Error('Unsafe cleanup target.');
  await rm(directory, { recursive: true, force: true });
}
