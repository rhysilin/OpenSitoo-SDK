# 开发对话规划与共享任务

返回总目录 · 当前状态 · 开发工具包 · 隔离页面 · 本批交付证据

开发宿主 0.10.0（工具包 0.11.0）提供实验性对话规划端口。它将文本转换为能力调用提案，经原代理 schema 校验后交给原持久任务服务执行。没有另一份业务实现，也没有按应用 ID 接线。最新模型证据见第五批记录；Pi、Desktop 与生产身份未验收。

## 身份与发现

仅已安装 v3 配置的 `entry: conversation` 身份可使用本接口。可信操作者须在持久授权库单独授权 conversation，并配置独立 bearer；application 授权不自动变成对话授权。配置版本与数据库 schema 均不变。

`GET /v1/conversation/tools` 返回 `{ok:true,value:{planSha256,tools}}`。每个工具是原能力声明：binding、interfaceVersion、inputSchema、outputSchema、permissions、allowedEntries、delegates、effects。只包含当前精确安装绑定、允许 conversation、权限已授权且无收费/外部写入效果的能力。签名、当前信任、内容、完整安装计划和授权快照均重新核验；无 Guest 源码、宿主路径、令牌或模型凭据。页端身份、v1/v2、旧快照、撤权或卸载返回 FORBIDDEN。

## 规划与执行

`POST /v1/conversation/plan` 只接受 `{requestId,text}`。requestId 是小写 UUID，text 为 1–8192 字符。宿主向可信 `ConversationPlanner` 适配端口传入文本、原请求 ID、已过滤工具和 AbortSignal；五秒超时返回 UNAVAILABLE。调用前和返回后再次检查安装与授权。规划适配器应响应取消；下载应用不能提供此宿主端口。

适配器只返回 `{capabilityId,input}`。额外字段、范围外能力、错误参数被拒绝；原 `broker.prepare` 校验原 inputSchema、权限和无效果执行条件。成功返回 `{ok:true,value:{request,binding,planSha256}}`，request 是标准 protocolVersion 1 请求。规划不创建任务、不执行业务、不获得批准。

执行时将同一个 request 提交至 `POST /v1/tasks`，附 `X-Sitoo-Conversation: <planSha256>`；读请求体后也再次检查，旧完整计划拒绝新提交。任务 ID、租约、QuickJS、嵌套授权、schema 和请求去重均沿用原服务。原任务查询不要求该 pin，未知任务不自动重跑或释放。此摘要是开发适配器附加门禁，不替代 bearer 或生产认证；原无摘要 CLI 任务契约保持兼容。

同一安装范围内，页面与对话可查询同一原任务，入口执行许可仍分别校验；不同应用/账户/环境不能查询彼此任务。更新后须显式刷新所需入口授权并重新启动开发宿主，新提案才能使用新实现。规划请求自身不持久化或去重，提案重复生成不应当作业务重试。

## 本地无费用验收

显式启用 `node sitoo-capability.mjs serve-conversation-fixture host.json task-data`。普通 `serve` 不启用模型规划，规划返回 UNAVAILABLE，但已授权工具发现仍可用。

夹具仅识别 `请调用 <capabilityId> 处理：<text>`，为具备 text/childRequestId 参数的测试工具生成提案。它不模拟业务输出、不做 trim/uppercase，也不是通用自然语言模型。子请求 ID 从原请求 ID 稳定派生。真实业务由签名能力包及共享依赖执行。

随包零依赖客户端：设置当前进程的 `SITOO_CONVERSATION_TOKEN`，执行 `node conversation-client.mjs <loopback-url> <new-proposal.json> "请调用 bob/prepare 处理： hello "`。凭据不要放在命令参数或提交到仓库。客户端将文本和完整提案用独占新建文件保存后才提交任务；重复调用同一文件直接提交原 request，不再次规划，文本改变则拒绝。输出原任务视图，最终结果用原任务 GET 查询；业务文件可能包含敏感输入，应保留在本地。

验证命令：`node scripts/verify-shared-capabilities.mjs --conversation --browser-pages --keep`；浏览器环境变量配置见页面手册。仓库外两应用分别获页面/对话授权，实际共享执行、原请求重试、业务升级、回退和卸载同时验收。0.9.0 浏览器对话见下方；真实模型适配见下方；SDK/产品门禁待后续。

## 浏览器对话（0.9.0）

打开宿主 `/development/conversation`（或从应用预览底部进入），输入单独签发的对话开发令牌。页面显示当前授权工具；输入需求后点击“生成提案”，查看原 request、binding 和完整计划摘要，再点击“提交提案”。本地夹具示例 `请调用 bob/prepare 处理： hello `；真实模型接入见下方 0.10.0。生成提案不执行业务，提交后只轮询原任务，unknown 不自动重跑。

令牌只保存在可信页面模块内存，输入清空，不写 localStorage/sessionStorage、URL 或全局对象。提案和结果用 textContent 展示，不将模型内容变成 DOM；没有把对话令牌传给应用 iframe。断开连接清除页面并中止浏览器请求，宿主已提交任务仍保留；迟到响应不能覆盖新身份窗口。

提交响应丢失时，“提交提案”仍使用相同 request 和摘要，服务返回同一任务；不会自动换 requestId 或重新规划。浏览器提案仅保留在当前连接内存，关闭后通过“刷新任务列表”查看最近 100 条任务并点选查询，不自动重建提案。CLI 提案文件仍是独立可用的恢复方式。

撤权或卸载后，已知 bearer 可只读连接并查询原任务；工具发现失败时不开放需求输入/新规划。错误 bearer 不开放查询。任务记录按原安装范围隔离，两入口同范围可查询同一记录；查询不等于重新获得执行授权。

仅 v3 精确宿主 Origin 开放工具/规划/任务。application 浏览器任务保持 X-Sitoo-Application；conversation 的 POST /v1/tasks 必须带 X-Sitoo-Conversation，并在读体后复核。对话 GET 原任务/列表不需要当前计划摘要；null、外部 Origin、service 浏览器任务仍拒绝，不开放 CORS。旧无 Origin CLI 契约不变。

`node scripts/verify-shared-capabilities.mjs --conversation-browser --keep` 同时验证真实页面、真实对话、共享业务升级/回退/卸载、丢响应原请求重试和连接切换。当前证据：第四批浏览器交付。

## 本机模型与手动回退（0.10.0）

显式命令：`node sitoo-capability.mjs serve-conversation-model host.json task-data planner.json`。可信 planner.json：`{"version":1,"endpoint":"http://127.0.0.1:3000/v1/chat/completions","model":"gemini-3.8-flash","apiKey":"本地已有凭据"}`。apiKey 可省略，仅对不需要认证的测试端点适用；不要放入源码、命令参数、应用包、URL 或日志。只允许 http/127.0.0.1/精确 Chat Completions 路径，不允许远端、query、URL 凭据或重定向。endpoint 可指定本机端口。模型配置是单独的可信文件，不改变 host v3 或数据库。

请求采用 [New API OpenAI 兼容协议](https://docs.newapi.pro/zh/docs/api/ai-model/chat/openai/createchatcompletion)，不依赖 Desktop 接口。工具按 capabilityId 排序映射为 tool_0 等函数名，以避免能力 ID 的斜线不符合 [OpenAI 函数名称契约](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create)。参数是仅含 input 的对象，其 schema 来自原声明；支持原非对象 inputSchema。返回必须是唯一 assistant function tool_call；拒绝、未知名称、多调用、非法 JSON 或参数均不能执行。最多 64 工具、请求和响应 64 KiB、非流式输出上限 1024 token，单次 HTTP 20 秒；不自动重试。此命令宿主规划上限 30 秒、浏览器/CLI 规划等待 35 秒；普通宿主默认仍五秒。预算约束不等于模型实际费用保证。

用户已批准本次可信规划使用收费 New API 模型；每次“生成提案”都可能产生费用，提案生成不持久去重。业务重试请保留原提案并重试提交，不重新生成。Guest billable/externalWrite 仍过滤掉，消费 bearer 与模型 apiKey 互不传递。

模型不可用时在浏览器“手动填写工具参数”选择当前已授权工具，按展示的 inputSchema 填写 JSON，点击“校验确定性提案”，检查后再提交。对应 `POST /v1/conversation/prepare` 接收标准 protocolVersion 1 请求，调用原 broker.prepare，返回 `{request,binding,planSha256}`；不需要启用模型，不产生规划费用，也不创建任务。保持 v3 conversation 身份、当前信任/安装/授权与精确同源限制；非法参数 400、授权变化 403。编辑参数会使旧提案失效，不自动回退执行。

第五批交付与验收记录真实模型、无费用失败夹具及剩余产品边界。

## 产品对话工具入口

Desktop 0.0.13 的接入及证据见第十批交付与SDK/Desktop 手册。市场入口只启用确定性的工具发现、JSON 参数校验、预览和明确提交，复用本手册原 HTTP/任务链路；自然语言规划与 Pi 通用工具尚待接入，不能将开发宿主模型规划验收视为产品模型验收。页面与对话同应用共用原任务，授权分别检查。

## Pi 工作台共享工具

Desktop 0.0.14 接入真实 Pi 通用工具、桌面明确确认与原任务回送，见第十一批交付与SDK/Desktop 手册。现有确定性工具窗口保留；自然语言规划在 Pi 工作台进行，模型走既有主进程通道。公共宿主 HTTP/SDK 不变，模型不能通过文本自批任务或改变消费身份。

[返回工具包说明](./README.md)
