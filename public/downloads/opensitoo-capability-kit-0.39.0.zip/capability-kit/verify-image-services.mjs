// Trusted, zero-fee, copied-kit contract acceptance. No repository/private imports.
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, relative, isAbsolute } from 'node:path';
import { randomUUID } from 'node:crypto';
import {
  CapabilityBroker,
  CapabilityReferenceStore,
  ModelRequestLedger,
  createImageService,
} from './service-host.mjs';
const directory = await mkdtemp(join(tmpdir(), 'sitoo-image-contract-'));
const store = new CapabilityReferenceStore(join(directory, 'refs.sqlite'));
let ledger = new ModelRequestLedger(join(directory, 'images.sqlite'));
const scope = {
  tenantId: 'fixture',
  environment: 'test',
  installationId: 'account/install',
  consumerAppId: 'consumer-a',
};
const binding = {
  capabilityId: 'platform/generate-image',
  packageId: 'platform/images',
  version: '1.0.0',
  sha256: 'a'.repeat(64),
};
const id = randomUUID();
store.issue(scope, id, {
  kind: 'model',
  providerId: 'image/' + 'b'.repeat(64),
  providerRevision: 1,
});
let generates = 0,
  queries = 0;
const output = { imageTaskId: randomUUID(), artifactId: 'original:image' };
const upstream = {
  infer: async () => {
    generates++;
    throw Error('Lost original response');
  },
  query: async () => {
    queries++;
    return output;
  },
};
const create = () => createImageService({ binding, store, ledger, upstream });
const broker = new CapabilityBroker();
let service = create();
broker.register(service.declaration, service.execute);
const caller = {
  ...scope,
  entry: 'application',
  bindings: [binding],
  grants: ['model:infer', 'resource:read'],
};
const session = broker.createSession(caller);
const request = {
  protocolVersion: 1,
  requestId: randomUUID(),
  capabilityId: binding.capabilityId,
  input: { referenceId: id, prompt: 'original' },
};
const context = {
  ...scope,
  entry: 'application',
  resolvedPackage: {
    packageId: binding.packageId,
    version: binding.version,
    sha256: binding.sha256,
  },
  grants: caller.grants,
  delegation: [],
};
try {
  assert.equal((await broker.invoke(session, request)).error.code, 'FORBIDDEN');
  assert.equal(generates, 0);
  const first = await broker.invoke(session, request, {
    approval: broker.issueApproval(session, request).value.approval,
  });
  assert.equal(first.value.error.code, 'RESULT_UNKNOWN');
  assert.equal(generates, 1);
  const original = ledger.read(scope, request.requestId);
  assert.equal(original.status, 'dispatched');
  ledger.close();
  ledger = new ModelRequestLedger(join(directory, 'images.sqlite'));
  service = create();
  assert.equal(
    (await service.execute(request, context, async () => {})).error.code,
    'RESULT_UNKNOWN',
  );
  assert.equal(generates, 1);
  const task = {
    taskId: randomUUID(),
    requestId: request.requestId,
    capabilityId: binding.capabilityId,
    binding,
    status: 'unknown',
    revision: 1,
    createdAt: '',
    updatedAt: '',
  };
  const result = await service.query(task, undefined, { request, caller });
  assert.deepEqual(result.value, output);
  assert.equal(generates, 1);
  assert.equal(queries, 1);
  const cached = await service.query(task, undefined, { request, caller });
  assert.deepEqual(cached.value, output);
  assert.equal(queries, 1);
  await assert.rejects(
    service.query(task, undefined, { request, caller: { ...caller, consumerAppId: 'foreign' } }),
  );
  store.revoke(scope, id);
  await assert.rejects(service.query(task, undefined, { request, caller }));
  console.log(
    JSON.stringify({
      passed: 5,
      outsideRepository: true,
      generate: generates,
      query: queries,
      fee: 0,
    }),
  );
} finally {
  ledger.close();
  store.close();
  const target = relative(tmpdir(), directory);
  if (isAbsolute(target) || target.startsWith('..') || !target.startsWith('sitoo-image-contract-'))
    throw Error('Unsafe cleanup');
  await rm(directory, { recursive: true, force: true });
}
