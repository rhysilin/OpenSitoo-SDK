// packages/installed-host/browser-frame.mjs
function bridge(channel) {
  let port2;
  const pending = /* @__PURE__ */ new Map();
  const ready = new Promise((resolve) => {
    const receive = (event) => {
      if (event.source !== parent || event.data?.channel !== channel || !event.ports[0]) return;
      window.removeEventListener("message", receive);
      port2 = event.ports[0];
      port2.onmessage = ({ data }) => {
        const waiter = pending.get(data?.id);
        if (!waiter) return;
        pending.delete(data.id);
        clearTimeout(waiter.timer);
        waiter.resolve(data.result);
      };
      resolve();
    };
    window.addEventListener("message", receive);
  });
  const request = async (method, input) => {
    if (pending.size >= 32) throw new Error("Development bridge busy.");
    const id = crypto.randomUUID();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new Error("Development bridge timeout; query the original task."));
      }, 1e4);
      pending.set(id, { resolve, timer });
      void ready.then(() => {
        if (pending.has(id)) port2.postMessage({ id, method, input });
      });
    });
  };
  Object.defineProperty(window, "sitooDevelopmentTasks", {
    value: Object.freeze({
      submit: (input) => request("submit", input),
      get: (taskId) => request("get", taskId),
      cancel: (taskId) => request("cancel", taskId),
      list: () => request("list", null),
      artifact: (taskId) => request("artifact", taskId)
    }),
    writable: false,
    configurable: false
  });
  parent.postMessage({ kind: "sitoo-development-ready", channel }, "*");
}
function renderSignedApplication(application, state, scriptNonce) {
  const sources = new Map(application.files.map((file) => [file.path, file.source]));
  const html = sources.get(application.entry);
  if (typeof html !== "string") throw new Error();
  const doc = new DOMParser().parseFromString(html, "text/html");
  const asset = (path, extension) => {
    if (typeof path !== "string" || /^(?:[a-z][a-z0-9+.-]*:|\/)/i.test(path)) throw new Error();
    const base = new URL(application.entry, "https://application.invalid/");
    const url = new URL(path, base);
    if (url.origin !== base.origin || url.search || url.hash) throw new Error();
    const name = decodeURIComponent(url.pathname.slice(1));
    if (!name.endsWith(extension) || !sources.has(name)) throw new Error();
    return sources.get(name);
  };
  doc.querySelectorAll("base,meta[http-equiv],iframe,frame,object,embed").forEach((node) => node.remove());
  for (const script of doc.querySelectorAll("script")) {
    if (script.type && !["text/javascript", "application/javascript"].includes(script.type) || script.hasAttribute("async") || script.hasAttribute("defer"))
      throw new Error();
    const source = script.hasAttribute("src") ? asset(script.getAttribute("src"), ".js") : script.textContent;
    script.removeAttribute("integrity");
    script.removeAttribute("src");
    script.removeAttribute("nonce");
    script.setAttribute("data-sitoo-development-script", "");
    script.textContent = source.replace(/<\/script/gi, "<\\/script");
  }
  for (const link of doc.querySelectorAll("link")) {
    if (link.rel !== "stylesheet") {
      link.remove();
      continue;
    }
    const style = doc.createElement("style");
    style.media = link.media;
    style.textContent = asset(link.getAttribute("href"), ".css").replace(/<\/style/gi, "<\\/style");
    link.replaceWith(style);
  }
  const policy = doc.createElement("meta");
  policy.httpEquiv = "Content-Security-Policy";
  policy.content = "default-src 'none'; script-src 'none'; script-src-elem 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; frame-src 'none'; worker-src 'none'; base-uri 'none'; form-action 'none'; object-src 'none'";
  const bootstrap = doc.createElement("script");
  bootstrap.setAttribute("data-sitoo-development-script", "");
  bootstrap.textContent = "(" + bridge.toString() + ")(" + JSON.stringify(state.channel) + ");";
  doc.head.prepend(policy, bootstrap);
  const frame2 = document.createElement("iframe");
  frame2.title = application.applicationId;
  frame2.setAttribute("sandbox", "allow-scripts allow-forms");
  frame2.setAttribute("referrerpolicy", "no-referrer");
  state.frame = frame2;
  frame2.srcdoc = "<!doctype html>" + doc.documentElement.outerHTML.replaceAll(
    'data-sitoo-development-script=""',
    'nonce="' + scriptNonce + '"'
  );
  return frame2;
}

// packages/browser-host/client.mjs
var $ = (id) => document.getElementById(id);
var session;
var current;
var proposal;
var port;
var frame;
var generation = 0;
var nonce = document.querySelector('meta[name="development-script-nonce"]').content;
var errors = {
  UNAUTHENTICATED: "\u767B\u5F55\u5DF2\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u767B\u5F55\u3002",
  CSRF_REJECTED: "\u4F1A\u8BDD\u6216\u8303\u56F4\u5DF2\u53D8\u5316\uFF0C\u8BF7\u5237\u65B0\u540E\u91CD\u8BD5\u3002",
  BROWSER_CONTEXT_EXPIRED: "\u5F53\u524D\u5E94\u7528\u8FDE\u63A5\u5DF2\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u3002",
  BROWSER_ENTRY_UNAUTHORIZED: "\u8BF7\u5148\u660E\u786E\u6388\u6743\u6240\u9009\u5165\u53E3\uFF0C\u66F4\u65B0\u540E\u9700\u91CD\u65B0\u6388\u6743\u3002",
  BROWSER_CAPABILITY_UNSUPPORTED: "\u6B64\u5BBF\u4E3B\u5C1A\u4E0D\u652F\u6301\u8BE5\u5E94\u7528\u4F9D\u8D56\u7684\u539F\u751F\u670D\u52A1\u3002",
  BROWSER_APPLICATION_UNSUPPORTED: "\u8BF7\u9009\u62E9\u58F0\u660E\u517C\u5BB9\u7684\u9759\u6001\u5E94\u7528\u3002",
  BROWSER_MODEL_UNAVAILABLE: "\u5C1A\u672A\u914D\u7F6E\u89C4\u5212\u670D\u52A1\uFF0C\u53EF\u4F7F\u7528\u624B\u52A8\u63D0\u6848\u3002",
  BROWSER_PREVIEW_STALE: "\u7248\u672C\u6216\u6743\u9650\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u68C0\u67E5\u3002",
  BROWSER_PREVIEW_INVALID: "\u786E\u8BA4\u5DF2\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u68C0\u67E5\u3002",
  CONFLICT: "\u64CD\u4F5C\u4E0E\u5F53\u524D\u72B6\u6001\u51B2\u7A81\uFF0C\u8BF7\u5148\u6838\u5BF9\u539F\u4EFB\u52A1\u3001\u5728\u9014\u7248\u672C\u548C\u64CD\u4F5C\u8BB0\u5F55\u3002",
  FORBIDDEN: "\u5F53\u524D\u8EAB\u4EFD\u6216\u6743\u9650\u4E0D\u5141\u8BB8\u6B64\u64CD\u4F5C\u3002",
  BROWSER_HOST_UNAVAILABLE: "\u5BBF\u4E3B\u6682\u4E0D\u53EF\u7528\uFF0C\u8BF7\u67E5\u8BE2\u539F\u4EFB\u52A1\uFF0C\u4E0D\u8981\u81EA\u52A8\u91CD\u65B0\u63D0\u4EA4\u3002"
};
function message(error) {
  return errors[error.message] ?? "\u64CD\u4F5C\u672A\u5B8C\u6210\uFF0C\u8BF7\u5237\u65B0\u6743\u9650\u5E76\u67E5\u8BE2\u539F\u8BB0\u5F55\u3002";
}
async function api(action, body, method = "POST", raw = false) {
  if (!session) throw Error("UNAUTHENTICATED");
  const response = await fetch("/v1/browser/" + action, {
    method,
    headers: { "content-type": "application/json", "x-csrf-token": session.csrf },
    ...method === "GET" ? {} : { body: JSON.stringify(body ?? {}) }
  });
  const result = await response.json();
  if (raw && response.ok && typeof result.ok === "boolean") return result;
  if (response.status === 401 || result.error?.code === "CSRF_REJECTED") {
    disconnect(true);
    session = null;
  }
  if (!response.ok || !result.ok) throw Error(result.error?.code ?? "BROWSER_HOST_UNAVAILABLE");
  return result.value;
}
var run = (work) => async () => {
  try {
    await work();
  } catch (error) {
    $("status").textContent = message(error);
  }
};
function button(text, action) {
  const b = document.createElement("button");
  b.textContent = text;
  b.addEventListener("click", run(action));
  return b;
}
async function confirm(detail) {
  const dialog = $("confirmation");
  $("review").textContent = JSON.stringify(detail, null, 2);
  dialog.showModal();
  return new Promise(
    (yes) => dialog.addEventListener("close", () => yes(dialog.returnValue === "confirm"), { once: true })
  );
}
function disconnect(clearData = false) {
  generation++;
  port?.close();
  port = null;
  frame = null;
  current = null;
  proposal = null;
  $("frame").replaceChildren();
  $("submit").disabled = true;
  $("proposal").textContent = "\u5C1A\u65E0\u63D0\u6848";
  if (clearData) {
    $("result").textContent = "\u5C1A\u65E0\u4EFB\u52A1";
    $("tasks").replaceChildren();
    $("history-app").value = "";
    $("tool").replaceChildren();
    $("schema").textContent = "";
    $("arguments").value = "{}";
    $("prompt").value = "";
  }
}
async function manage(input) {
  const preview = await api("preview", input);
  if (await confirm(preview)) {
    await api("confirm", { token: preview.token, confirmed: true });
    await refresh();
  }
}
async function open(application, entry) {
  disconnect();
  const sequence = generation;
  const selected = await api("open", { application, entry });
  if (sequence !== generation) return;
  current = { ...selected, channel: crypto.randomUUID() };
  $("history-app").value = application;
  $("entry-status").textContent = application + " \xB7 " + entry;
  if (entry === "application") {
    const descriptor = await api("contexts/" + current.context + "/application");
    try {
      frame = renderSignedApplication(descriptor, current, nonce);
    } catch {
      throw Error("BROWSER_APPLICATION_UNSUPPORTED");
    }
    $("frame").replaceChildren(frame);
  }
  const catalog = await api("contexts/" + current.context + "/tools");
  $("tool").replaceChildren(
    ...catalog.tools.map((t) => {
      const option = document.createElement("option");
      option.value = t.binding.capabilityId;
      option.textContent = t.binding.capabilityId;
      option.dataset.schema = JSON.stringify(t.inputSchema, null, 2);
      return option;
    })
  );
  showSchema();
  $("status").textContent = "\u5E94\u7528\u5DF2\u6253\u5F00\uFF1B\u4EC5\u6240\u9009\u5165\u53E3\u53EF\u63D0\u4EA4\u8BF7\u6C42\u3002";
}
function showSchema() {
  $("schema").textContent = $("tool").selectedOptions[0]?.dataset.schema ?? "\u6CA1\u6709\u9002\u7528\u5DE5\u5177\u3002";
}
async function refresh() {
  const response = await fetch("/v1/session"), result = await response.json();
  if (!response.ok) {
    session = null;
    disconnect(true);
    throw Error(result.error?.code ?? "UNAUTHENTICATED");
  }
  if (session && (session.actor.id !== result.actor.id || session.scope !== result.scope || session.csrf !== result.csrf))
    disconnect(true);
  session = result;
  $("identity").textContent = session.actor.name;
  $("scope").replaceChildren();
  for (const item of [{ id: "", name: "\u4E2A\u4EBA\u8303\u56F4" }, ...session.organizations]) {
    const option = document.createElement("option");
    option.value = item.id;
    option.textContent = item.name;
    $("scope").append(option);
  }
  $("scope").value = session.scope ?? "";
  const state = await api("list", {}, "GET");
  $("catalog").replaceChildren();
  $("installed").replaceChildren();
  $("operations").replaceChildren();
  for (const item of state.catalog) {
    const line = document.createElement("p");
    line.append(
      document.createTextNode(item.packageId + " \xB7 " + item.version + " "),
      button(
        "\u68C0\u67E5\u5B89\u88C5",
        () => manage({ kind: "install", project: item.id, release: item.release })
      )
    );
    $("catalog").append(line);
  }
  for (const item of state.applications) {
    const section = document.createElement("div"), title = document.createElement("h3");
    title.textContent = item.application;
    section.append(title);
    const available = state.catalog.find((p) => p.id === item.project);
    if (available)
      section.append(
        button(
          "\u68C0\u67E5\u66F4\u65B0",
          () => manage({ kind: "update", project: available.id, release: available.release })
        )
      );
    section.append(
      button("\u68C0\u67E5\u5378\u8F7D", () => manage({ kind: "uninstall", application: item.application }))
    );
    for (const entry of item.entries ?? []) {
      const labels = { application: "\u5E94\u7528\u9875\u9762", conversation: "\u5BF9\u8BDD", service: "\u7A0B\u5E8F" }, line = document.createElement("p");
      line.append(
        document.createTextNode(
          labels[entry.entry] + " \xB7 " + entry.status + (entry.bindingsCurrent ? " " : "\uFF08\u9700\u6838\u5BF9\u7248\u672C\uFF09 ")
        )
      );
      line.append(
        button(
          "\u6388\u6743" + labels[entry.entry],
          () => manage({ kind: "authorize", application: item.application, entry: entry.entry })
        ),
        button(
          "\u64A4\u9500" + labels[entry.entry],
          () => manage({ kind: "revoke", application: item.application, entry: entry.entry })
        ),
        button("\u6253\u5F00" + labels[entry.entry], () => open(item.application, entry.entry))
      );
      section.append(line);
    }
    $("installed").append(section);
  }
  for (const operation of state.operations) {
    const line = document.createElement("p");
    line.textContent = operation.application + " \xB7 " + operation.kind + " \xB7 " + operation.state + " \xB7 " + operation.id;
    if (operation.state === "prepared")
      line.append(
        button("\u7EE7\u7EED\u539F\u64CD\u4F5C", async () => {
          if (await confirm(operation)) {
            await api("resume", { requestId: operation.id });
            await refresh();
          }
        })
      );
    $("operations").append(line);
  }
  $("status").textContent = "\u4F1A\u8BDD\u4E0E\u5F53\u524D\u8303\u56F4\u5DF2\u6838\u5BF9\u3002";
}
window.addEventListener("message", (event) => {
  const selected = current, sequence = generation;
  if (!selected || !frame || port || event.source !== frame.contentWindow || event.origin !== "null" || event.data?.kind !== "sitoo-development-ready" || event.data.channel !== selected.channel)
    return;
  const pair = new MessageChannel();
  port = pair.port1;
  frame.contentWindow.postMessage({ channel: selected.channel }, "*", [pair.port2]);
  const seen = /* @__PURE__ */ new Set();
  let active = 0;
  pair.port1.onmessage = async ({ data }) => {
    if (generation !== sequence || current !== selected || !data || typeof data.id !== "string" || seen.has(data.id))
      return;
    const reply = (result) => {
      if (generation === sequence) pair.port1.postMessage({ id: data.id, result });
    };
    if (active >= 32 || seen.size >= 1024 || JSON.stringify(data).length > 65536 || Object.keys(data).sort().join(",") !== "id,input,method" || !/^[a-f0-9-]{36}$/.test(data.id))
      return reply({
        ok: false,
        error: { code: "INVALID_INPUT", message: "The request is invalid." }
      });
    seen.add(data.id);
    active++;
    try {
      let input;
      if (data.method === "submit") input = data.input;
      else if (data.method === "list" && data.input === null) input = {};
      else if (["get", "cancel", "artifact"].includes(data.method) && typeof data.input === "string" && /^[a-f0-9-]{36}$/.test(data.input))
        input = { taskId: data.input };
      else throw Error("FORBIDDEN");
      reply(await api("contexts/" + selected.context + "/" + data.method, input, "POST", true));
    } catch (error) {
      reply({
        ok: false,
        error: { code: "UNAVAILABLE", message: "The capability is unavailable." }
      });
      $("status").textContent = message(error);
    } finally {
      active--;
    }
  };
});
$("refresh").addEventListener("click", run(refresh));
$("scope").addEventListener(
  "change",
  run(async () => {
    const old = session;
    disconnect(true);
    const response = await fetch("/v1/scope", {
      method: "POST",
      headers: { "content-type": "application/json", "x-csrf-token": old.csrf },
      body: JSON.stringify({ organization: $("scope").value || null })
    });
    if (!response.ok) throw Error("CSRF_REJECTED");
    await refresh();
  })
);
$("logout").addEventListener(
  "click",
  run(async () => {
    disconnect(true);
    await fetch("/v1/logout", {
      method: "POST",
      headers: { "content-type": "application/json", "x-csrf-token": session.csrf },
      body: "{}"
    });
    session = null;
    $("status").textContent = "\u5DF2\u9000\u51FA\uFF1B\u539F\u4EFB\u52A1\u4ECD\u4FDD\u7559\u3002";
  })
);
$("close-frame").addEventListener("click", () => disconnect());
$("tool").addEventListener("change", showSchema);
$("prepare").addEventListener(
  "click",
  run(async () => {
    if (!current) throw Error("BROWSER_ENTRY_UNAUTHORIZED");
    proposal = await api("contexts/" + current.context + "/prepare", {
      capabilityId: $("tool").value,
      input: JSON.parse($("arguments").value)
    });
    $("proposal").textContent = JSON.stringify(proposal, null, 2);
    $("submit").disabled = false;
  })
);
$("plan").addEventListener(
  "click",
  run(async () => {
    if (!current) throw Error("BROWSER_ENTRY_UNAUTHORIZED");
    proposal = await api("contexts/" + current.context + "/plan", { prompt: $("prompt").value });
    $("proposal").textContent = JSON.stringify(proposal, null, 2);
    $("submit").disabled = false;
  })
);
$("submit").addEventListener(
  "click",
  run(async () => {
    if (!proposal || !current) throw Error("BROWSER_CONTEXT_EXPIRED");
    const task = await api("contexts/" + current.context + "/submit", proposal);
    $("result").textContent = JSON.stringify(task, null, 2);
    await history();
  })
);
async function history() {
  const tasks = await api("history", { application: $("history-app").value });
  $("tasks").replaceChildren();
  for (const task of tasks) {
    const item = document.createElement("p");
    item.textContent = task.taskId + " \xB7 " + task.status;
    item.dataset.taskId = task.taskId;
    item.append(
      button("\u67E5\u770B\u539F\u7ED3\u679C", async () => {
        $("result").textContent = JSON.stringify(
          await api("history", { application: $("history-app").value, taskId: task.taskId }),
          null,
          2
        );
      })
    );
    if (task.status === "needs-approval" && current?.application === $("history-app").value)
      item.append(
        button("\u6838\u5BF9\u5E76\u786E\u8BA4\u526F\u4F5C\u7528", async () => {
          const review = await api("contexts/" + current.context + "/confirmation", {
            taskId: task.taskId
          });
          if (await confirm(review)) {
            await api("contexts/" + current.context + "/approve", {
              taskId: task.taskId,
              revision: review.revision,
              confirmed: true
            });
            await history();
          }
        })
      );
    $("tasks").append(item);
  }
}
$("history").addEventListener("click", run(history));
window.addEventListener("pagehide", disconnect);
run(refresh)();
