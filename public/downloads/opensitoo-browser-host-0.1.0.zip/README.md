# OpenSitoo 浏览器宿主 0.1.0

需要Windows x64、Node24。此发行物只开放显式回环HTTPS工程演练，不是已通过真实托管/身份/容量门禁的公网部署。无需Desktop源码、Pi或npm安装。

准备独立受保护配置、TLS证书、OIDC机密客户端、production签名键、dataManagement删除登记及独立数据目录，使用中心0.8.0配置。browserHost必须包含profile=loopback-browser-rehearsal-v1、绝对dataDirectory及本目录的绝对runtimeDirectory；webRoot指向本目录admin-web。秘密和数据库不要放在公开静态目录或提交仓库。

启动：设置SITOO_CENTER_CONFIG为配置JSON的绝对路径，然后运行node browser-server.mjs。访问配置origin的/browser并登录，检查安装、明确授权入口后打开。安装不自动授权，应用/对话/程序分别授权。程序请求同源/v1/browser接口并提供当前会话/CSRF，不能使用开发Bearer。

仅兼容签名静态页面、经典JS/CSS、受限QuickJS和能力任务SDK；原生服务、模块脚本、App SDK原生桥未支持时明确拒绝。应用iframe只有消费通道，不能安装、授权或确认副作用。关闭页面不取消已提交任务；中断后查原任务，unknown与pin不能自动清理。更新需重新核对新版本授权。

数据库schema8由独立目录运行，旧版本不能打开或降级。备份工具需1.1.0或更新，宿主账本与中心数据分别登记，目录内owner.json只用于运维归属识别。中心删除使旧身份与入口失效；独立宿主数据的导出/清理由可信运维用数据工具在停服窗口处理，不冒称浏览器获得文件管理权限。

规划端口可显式配置planningModel={version:1,endpoint:http://127.0.0.1:端口/v1/chat/completions,model:模型名}。只用于本机演练，无配置时手动提案仍可用。模型只提案，不确认或执行；不要把API密钥传给浏览器。
