import{createRequire as __r05CreateRequire}from'node:module';const require=__r05CreateRequire(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/constants.js
var require_constants = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/constants.js"(exports, module) {
    "use strict";
    var SEMVER_SPEC_VERSION = "2.0.0";
    var MAX_LENGTH = 256;
    var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || /* istanbul ignore next */
    9007199254740991;
    var MAX_SAFE_COMPONENT_LENGTH = 16;
    var MAX_SAFE_BUILD_LENGTH = MAX_LENGTH - 6;
    var RELEASE_TYPES = [
      "major",
      "premajor",
      "minor",
      "preminor",
      "patch",
      "prepatch",
      "prerelease"
    ];
    module.exports = {
      MAX_LENGTH,
      MAX_SAFE_COMPONENT_LENGTH,
      MAX_SAFE_BUILD_LENGTH,
      MAX_SAFE_INTEGER,
      RELEASE_TYPES,
      SEMVER_SPEC_VERSION,
      FLAG_INCLUDE_PRERELEASE: 1,
      FLAG_LOOSE: 2
    };
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/debug.js
var require_debug = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/debug.js"(exports, module) {
    "use strict";
    var debug = typeof process === "object" && process.env && process.env.NODE_DEBUG && /\bsemver\b/i.test(process.env.NODE_DEBUG) ? (...args) => console.error("SEMVER", ...args) : () => {
    };
    module.exports = debug;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/re.js
var require_re = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/re.js"(exports, module) {
    "use strict";
    var {
      MAX_SAFE_COMPONENT_LENGTH,
      MAX_SAFE_BUILD_LENGTH,
      MAX_LENGTH
    } = require_constants();
    var debug = require_debug();
    exports = module.exports = {};
    var re = exports.re = [];
    var safeRe = exports.safeRe = [];
    var src = exports.src = [];
    var safeSrc = exports.safeSrc = [];
    var t = exports.t = {};
    var R = 0;
    var LETTERDASHNUMBER = "[a-zA-Z0-9-]";
    var safeRegexReplacements = [
      ["\\s", 1],
      ["\\d", MAX_LENGTH],
      [LETTERDASHNUMBER, MAX_SAFE_BUILD_LENGTH]
    ];
    var makeSafeRegex = (value2) => {
      for (const [token, max] of safeRegexReplacements) {
        value2 = value2.split(`${token}*`).join(`${token}{0,${max}}`).split(`${token}+`).join(`${token}{1,${max}}`);
      }
      return value2;
    };
    var createToken = (name, value2, isGlobal) => {
      const safe = makeSafeRegex(value2);
      const index = R++;
      debug(name, index, value2);
      t[name] = index;
      src[index] = value2;
      safeSrc[index] = safe;
      re[index] = new RegExp(value2, isGlobal ? "g" : void 0);
      safeRe[index] = new RegExp(safe, isGlobal ? "g" : void 0);
    };
    createToken("NUMERICIDENTIFIER", "0|[1-9]\\d*");
    createToken("NUMERICIDENTIFIERLOOSE", "\\d+");
    createToken("NONNUMERICIDENTIFIER", `\\d*[a-zA-Z-]${LETTERDASHNUMBER}*`);
    createToken("MAINVERSION", `(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})\\.(${src[t.NUMERICIDENTIFIER]})`);
    createToken("MAINVERSIONLOOSE", `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})\\.(${src[t.NUMERICIDENTIFIERLOOSE]})`);
    createToken("PRERELEASEIDENTIFIER", `(?:${src[t.NONNUMERICIDENTIFIER]}|${src[t.NUMERICIDENTIFIER]})`);
    createToken("PRERELEASEIDENTIFIERLOOSE", `(?:${src[t.NONNUMERICIDENTIFIER]}|${src[t.NUMERICIDENTIFIERLOOSE]})`);
    createToken("PRERELEASE", `(?:-(${src[t.PRERELEASEIDENTIFIER]}(?:\\.${src[t.PRERELEASEIDENTIFIER]})*))`);
    createToken("PRERELEASELOOSE", `(?:-?(${src[t.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${src[t.PRERELEASEIDENTIFIERLOOSE]})*))`);
    createToken("BUILDIDENTIFIER", `${LETTERDASHNUMBER}+`);
    createToken("BUILD", `(?:\\+(${src[t.BUILDIDENTIFIER]}(?:\\.${src[t.BUILDIDENTIFIER]})*))`);
    createToken("FULLPLAIN", `v?${src[t.MAINVERSION]}${src[t.PRERELEASE]}?${src[t.BUILD]}?`);
    createToken("FULL", `^${src[t.FULLPLAIN]}$`);
    createToken("LOOSEPLAIN", `[v=\\s]*${src[t.MAINVERSIONLOOSE]}${src[t.PRERELEASELOOSE]}?${src[t.BUILD]}?`);
    createToken("LOOSE", `^${src[t.LOOSEPLAIN]}$`);
    createToken("GTLT", "((?:<|>)?=?)");
    createToken("XRANGEIDENTIFIERLOOSE", `${src[t.NUMERICIDENTIFIERLOOSE]}|x|X|\\*`);
    createToken("XRANGEIDENTIFIER", `${src[t.NUMERICIDENTIFIER]}|x|X|\\*`);
    createToken("XRANGEPLAIN", `[v=\\s]*(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:\\.(${src[t.XRANGEIDENTIFIER]})(?:${src[t.PRERELEASE]})?${src[t.BUILD]}?)?)?`);
    createToken("XRANGEPLAINLOOSE", `[v=\\s]*(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})(?:${src[t.PRERELEASELOOSE]})?${src[t.BUILD]}?)?)?`);
    createToken("XRANGE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAIN]}$`);
    createToken("XRANGELOOSE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("COERCEPLAIN", `${"(^|[^\\d])(\\d{1,"}${MAX_SAFE_COMPONENT_LENGTH}})(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?`);
    createToken("COERCE", `${src[t.COERCEPLAIN]}(?:$|[^\\d])`);
    createToken("COERCEFULL", src[t.COERCEPLAIN] + `(?:${src[t.PRERELEASE]})?(?:${src[t.BUILD]})?(?:$|[^\\d])`);
    createToken("COERCERTL", src[t.COERCE], true);
    createToken("COERCERTLFULL", src[t.COERCEFULL], true);
    createToken("LONETILDE", "(?:~>?)");
    createToken("TILDETRIM", `(\\s*)${src[t.LONETILDE]}\\s+`, true);
    exports.tildeTrimReplace = "$1~";
    createToken("TILDE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAIN]}$`);
    createToken("TILDELOOSE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("LONECARET", "(?:\\^)");
    createToken("CARETTRIM", `(\\s*)${src[t.LONECARET]}\\s+`, true);
    exports.caretTrimReplace = "$1^";
    createToken("CARET", `^${src[t.LONECARET]}${src[t.XRANGEPLAIN]}$`);
    createToken("CARETLOOSE", `^${src[t.LONECARET]}${src[t.XRANGEPLAINLOOSE]}$`);
    createToken("COMPARATORLOOSE", `^${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]})$|^$`);
    createToken("COMPARATOR", `^${src[t.GTLT]}\\s*(${src[t.FULLPLAIN]})$|^$`);
    createToken("COMPARATORTRIM", `(\\s*)${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]}|${src[t.XRANGEPLAIN]})`, true);
    exports.comparatorTrimReplace = "$1$2$3";
    createToken("HYPHENRANGE", `^\\s*(${src[t.XRANGEPLAIN]})\\s+-\\s+(${src[t.XRANGEPLAIN]})\\s*$`);
    createToken("HYPHENRANGELOOSE", `^\\s*(${src[t.XRANGEPLAINLOOSE]})\\s+-\\s+(${src[t.XRANGEPLAINLOOSE]})\\s*$`);
    createToken("STAR", "(<|>)?=?\\s*\\*");
    createToken("GTE0", "^\\s*>=\\s*0\\.0\\.0\\s*$");
    createToken("GTE0PRE", "^\\s*>=\\s*0\\.0\\.0-0\\s*$");
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/parse-options.js
var require_parse_options = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/parse-options.js"(exports, module) {
    "use strict";
    var looseOption = Object.freeze({ loose: true });
    var emptyOpts = Object.freeze({});
    var parseOptions = (options) => {
      if (!options) {
        return emptyOpts;
      }
      if (typeof options !== "object") {
        return looseOption;
      }
      return options;
    };
    module.exports = parseOptions;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/identifiers.js
var require_identifiers = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/identifiers.js"(exports, module) {
    "use strict";
    var numeric = /^[0-9]+$/;
    var compareIdentifiers = (a, b) => {
      if (typeof a === "number" && typeof b === "number") {
        return a === b ? 0 : a < b ? -1 : 1;
      }
      const anum = numeric.test(a);
      const bnum = numeric.test(b);
      if (anum && bnum) {
        a = +a;
        b = +b;
      }
      return a === b ? 0 : anum && !bnum ? -1 : bnum && !anum ? 1 : a < b ? -1 : 1;
    };
    var rcompareIdentifiers = (a, b) => compareIdentifiers(b, a);
    module.exports = {
      compareIdentifiers,
      rcompareIdentifiers
    };
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/semver.js
var require_semver = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/semver.js"(exports, module) {
    "use strict";
    var debug = require_debug();
    var { MAX_LENGTH, MAX_SAFE_INTEGER } = require_constants();
    var { safeRe: re, t } = require_re();
    var parseOptions = require_parse_options();
    var { compareIdentifiers } = require_identifiers();
    var isPrereleaseIdentifier = (prerelease, identifier3) => {
      const identifiers = identifier3.split(".");
      if (identifiers.length > prerelease.length) {
        return false;
      }
      for (let i = 0; i < identifiers.length; i++) {
        if (compareIdentifiers(prerelease[i], identifiers[i]) !== 0) {
          return false;
        }
      }
      return true;
    };
    var SemVer = class _SemVer {
      constructor(version, options) {
        options = parseOptions(options);
        if (version instanceof _SemVer) {
          if (version.loose === !!options.loose && version.includePrerelease === !!options.includePrerelease) {
            return version;
          } else {
            version = version.version;
          }
        } else if (typeof version !== "string") {
          throw new TypeError(`Invalid version. Must be a string. Got type "${typeof version}".`);
        }
        if (version.length > MAX_LENGTH) {
          throw new TypeError(
            `version is longer than ${MAX_LENGTH} characters`
          );
        }
        debug("SemVer", version, options);
        this.options = options;
        this.loose = !!options.loose;
        this.includePrerelease = !!options.includePrerelease;
        const m = version.trim().match(options.loose ? re[t.LOOSE] : re[t.FULL]);
        if (!m) {
          throw new TypeError(`Invalid Version: ${version}`);
        }
        this.raw = version;
        this.major = +m[1];
        this.minor = +m[2];
        this.patch = +m[3];
        if (this.major > MAX_SAFE_INTEGER || this.major < 0) {
          throw new TypeError("Invalid major version");
        }
        if (this.minor > MAX_SAFE_INTEGER || this.minor < 0) {
          throw new TypeError("Invalid minor version");
        }
        if (this.patch > MAX_SAFE_INTEGER || this.patch < 0) {
          throw new TypeError("Invalid patch version");
        }
        if (!m[4]) {
          this.prerelease = [];
        } else {
          this.prerelease = m[4].split(".").map((id3) => {
            if (/^[0-9]+$/.test(id3)) {
              const num = +id3;
              if (num >= 0 && num < MAX_SAFE_INTEGER) {
                return num;
              }
            }
            return id3;
          });
        }
        this.build = m[5] ? m[5].split(".") : [];
        this.format();
      }
      format() {
        this.version = `${this.major}.${this.minor}.${this.patch}`;
        if (this.prerelease.length) {
          this.version += `-${this.prerelease.join(".")}`;
        }
        return this.version;
      }
      toString() {
        return this.version;
      }
      compare(other) {
        debug("SemVer.compare", this.version, this.options, other);
        if (!(other instanceof _SemVer)) {
          if (typeof other === "string" && other === this.version) {
            return 0;
          }
          other = new _SemVer(other, this.options);
        }
        if (other.version === this.version) {
          return 0;
        }
        return this.compareMain(other) || this.comparePre(other);
      }
      compareMain(other) {
        if (!(other instanceof _SemVer)) {
          other = new _SemVer(other, this.options);
        }
        if (this.major < other.major) {
          return -1;
        }
        if (this.major > other.major) {
          return 1;
        }
        if (this.minor < other.minor) {
          return -1;
        }
        if (this.minor > other.minor) {
          return 1;
        }
        if (this.patch < other.patch) {
          return -1;
        }
        if (this.patch > other.patch) {
          return 1;
        }
        return 0;
      }
      comparePre(other) {
        if (!(other instanceof _SemVer)) {
          other = new _SemVer(other, this.options);
        }
        if (this.prerelease.length && !other.prerelease.length) {
          return -1;
        } else if (!this.prerelease.length && other.prerelease.length) {
          return 1;
        } else if (!this.prerelease.length && !other.prerelease.length) {
          return 0;
        }
        let i = 0;
        do {
          const a = this.prerelease[i];
          const b = other.prerelease[i];
          debug("prerelease compare", i, a, b);
          if (a === void 0 && b === void 0) {
            return 0;
          } else if (b === void 0) {
            return 1;
          } else if (a === void 0) {
            return -1;
          } else if (a === b) {
            continue;
          } else {
            return compareIdentifiers(a, b);
          }
        } while (++i);
      }
      compareBuild(other) {
        if (!(other instanceof _SemVer)) {
          other = new _SemVer(other, this.options);
        }
        let i = 0;
        do {
          const a = this.build[i];
          const b = other.build[i];
          debug("build compare", i, a, b);
          if (a === void 0 && b === void 0) {
            return 0;
          } else if (b === void 0) {
            return 1;
          } else if (a === void 0) {
            return -1;
          } else if (a === b) {
            continue;
          } else {
            return compareIdentifiers(a, b);
          }
        } while (++i);
      }
      // preminor will bump the version up to the next minor release, and immediately
      // down to pre-release. premajor and prepatch work the same way.
      inc(release, identifier3, identifierBase) {
        if (release.startsWith("pre")) {
          if (!identifier3 && identifierBase === false) {
            throw new Error("invalid increment argument: identifier is empty");
          }
          if (identifier3) {
            const match = `-${identifier3}`.match(this.options.loose ? re[t.PRERELEASELOOSE] : re[t.PRERELEASE]);
            if (!match || match[1] !== identifier3) {
              throw new Error(`invalid identifier: ${identifier3}`);
            }
          }
        }
        switch (release) {
          case "premajor":
            this.prerelease.length = 0;
            this.patch = 0;
            this.minor = 0;
            this.major++;
            this.inc("pre", identifier3, identifierBase);
            break;
          case "preminor":
            this.prerelease.length = 0;
            this.patch = 0;
            this.minor++;
            this.inc("pre", identifier3, identifierBase);
            break;
          case "prepatch":
            this.prerelease.length = 0;
            this.inc("patch", identifier3, identifierBase);
            this.inc("pre", identifier3, identifierBase);
            break;
          // If the input is a non-prerelease version, this acts the same as
          // prepatch.
          case "prerelease":
            if (this.prerelease.length === 0) {
              this.inc("patch", identifier3, identifierBase);
            }
            this.inc("pre", identifier3, identifierBase);
            break;
          case "release":
            if (this.prerelease.length === 0) {
              throw new Error(`version ${this.raw} is not a prerelease`);
            }
            this.prerelease.length = 0;
            break;
          case "major":
            if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0) {
              this.major++;
            }
            this.minor = 0;
            this.patch = 0;
            this.prerelease = [];
            break;
          case "minor":
            if (this.patch !== 0 || this.prerelease.length === 0) {
              this.minor++;
            }
            this.patch = 0;
            this.prerelease = [];
            break;
          case "patch":
            if (this.prerelease.length === 0) {
              this.patch++;
            }
            this.prerelease = [];
            break;
          // This probably shouldn't be used publicly.
          // 1.0.0 'pre' would become 1.0.0-0 which is the wrong direction.
          case "pre": {
            const base = Number(identifierBase) ? 1 : 0;
            if (this.prerelease.length === 0) {
              this.prerelease = [base];
            } else {
              let i = this.prerelease.length;
              while (--i >= 0) {
                if (typeof this.prerelease[i] === "number") {
                  this.prerelease[i]++;
                  i = -2;
                }
              }
              if (i === -1) {
                if (identifier3 === this.prerelease.join(".") && identifierBase === false) {
                  throw new Error("invalid increment argument: identifier already exists");
                }
                this.prerelease.push(base);
              }
            }
            if (identifier3) {
              let prerelease = [identifier3, base];
              if (identifierBase === false) {
                prerelease = [identifier3];
              }
              if (isPrereleaseIdentifier(this.prerelease, identifier3)) {
                const prereleaseBase = this.prerelease[identifier3.split(".").length];
                if (isNaN(prereleaseBase)) {
                  this.prerelease = prerelease;
                }
              } else {
                this.prerelease = prerelease;
              }
            }
            break;
          }
          default:
            throw new Error(`invalid increment argument: ${release}`);
        }
        this.raw = this.format();
        if (this.build.length) {
          this.raw += `+${this.build.join(".")}`;
        }
        return this;
      }
    };
    module.exports = SemVer;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/parse.js
var require_parse = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/parse.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var parse2 = (version, options, throwErrors = false) => {
      if (version instanceof SemVer) {
        return version;
      }
      try {
        return new SemVer(version, options);
      } catch (er) {
        if (!throwErrors) {
          return null;
        }
        throw er;
      }
    };
    module.exports = parse2;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/valid.js
var require_valid = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/valid.js"(exports, module) {
    "use strict";
    var parse2 = require_parse();
    var valid = (version, options) => {
      const v = parse2(version, options);
      return v ? v.version : null;
    };
    module.exports = valid;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/clean.js
var require_clean = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/clean.js"(exports, module) {
    "use strict";
    var parse2 = require_parse();
    var clean = (version, options) => {
      const s = parse2(version.trim().replace(/^[=v]+/, ""), options);
      return s ? s.version : null;
    };
    module.exports = clean;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/inc.js
var require_inc = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/inc.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var inc = (version, release, options, identifier3, identifierBase) => {
      if (typeof options === "string") {
        identifierBase = identifier3;
        identifier3 = options;
        options = void 0;
      }
      try {
        return new SemVer(
          version instanceof SemVer ? version.version : version,
          options
        ).inc(release, identifier3, identifierBase).version;
      } catch (er) {
        return null;
      }
    };
    module.exports = inc;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/diff.js
var require_diff = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/diff.js"(exports, module) {
    "use strict";
    var parse2 = require_parse();
    var diff = (version1, version2) => {
      const v1 = parse2(version1, null, true);
      const v2 = parse2(version2, null, true);
      const comparison = v1.compare(v2);
      if (comparison === 0) {
        return null;
      }
      const v1Higher = comparison > 0;
      const highVersion = v1Higher ? v1 : v2;
      const lowVersion = v1Higher ? v2 : v1;
      const highHasPre = !!highVersion.prerelease.length;
      const lowHasPre = !!lowVersion.prerelease.length;
      if (lowHasPre && !highHasPre) {
        if (!lowVersion.patch && !lowVersion.minor) {
          return "major";
        }
        if (lowVersion.compareMain(highVersion) === 0) {
          if (lowVersion.minor && !lowVersion.patch) {
            return "minor";
          }
          return "patch";
        }
      }
      const prefix = highHasPre ? "pre" : "";
      if (v1.major !== v2.major) {
        return prefix + "major";
      }
      if (v1.minor !== v2.minor) {
        return prefix + "minor";
      }
      if (v1.patch !== v2.patch) {
        return prefix + "patch";
      }
      return "prerelease";
    };
    module.exports = diff;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/major.js
var require_major = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/major.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var major = (a, loose) => new SemVer(a, loose).major;
    module.exports = major;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/minor.js
var require_minor = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/minor.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var minor = (a, loose) => new SemVer(a, loose).minor;
    module.exports = minor;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/patch.js
var require_patch = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/patch.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var patch = (a, loose) => new SemVer(a, loose).patch;
    module.exports = patch;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/prerelease.js
var require_prerelease = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/prerelease.js"(exports, module) {
    "use strict";
    var parse2 = require_parse();
    var prerelease = (version, options) => {
      const parsed = parse2(version, options);
      return parsed && parsed.prerelease.length ? parsed.prerelease : null;
    };
    module.exports = prerelease;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare.js
var require_compare = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var compare2 = (a, b, loose) => new SemVer(a, loose).compare(new SemVer(b, loose));
    module.exports = compare2;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rcompare.js
var require_rcompare = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rcompare.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var rcompare = (a, b, loose) => compare2(b, a, loose);
    module.exports = rcompare;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-loose.js
var require_compare_loose = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-loose.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var compareLoose = (a, b) => compare2(a, b, true);
    module.exports = compareLoose;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-build.js
var require_compare_build = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/compare-build.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var compareBuild = (a, b, loose) => {
      const versionA = new SemVer(a, loose);
      const versionB = new SemVer(b, loose);
      return versionA.compare(versionB) || versionA.compareBuild(versionB);
    };
    module.exports = compareBuild;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/sort.js
var require_sort = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/sort.js"(exports, module) {
    "use strict";
    var compareBuild = require_compare_build();
    var sort = (list, loose) => list.sort((a, b) => compareBuild(a, b, loose));
    module.exports = sort;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rsort.js
var require_rsort = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/rsort.js"(exports, module) {
    "use strict";
    var compareBuild = require_compare_build();
    var rsort = (list, loose) => list.sort((a, b) => compareBuild(b, a, loose));
    module.exports = rsort;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gt.js
var require_gt = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gt.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var gt = (a, b, loose) => compare2(a, b, loose) > 0;
    module.exports = gt;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lt.js
var require_lt = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lt.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var lt = (a, b, loose) => compare2(a, b, loose) < 0;
    module.exports = lt;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/eq.js
var require_eq = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/eq.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var eq = (a, b, loose) => compare2(a, b, loose) === 0;
    module.exports = eq;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/neq.js
var require_neq = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/neq.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var neq = (a, b, loose) => compare2(a, b, loose) !== 0;
    module.exports = neq;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gte.js
var require_gte = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/gte.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var gte = (a, b, loose) => compare2(a, b, loose) >= 0;
    module.exports = gte;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lte.js
var require_lte = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/lte.js"(exports, module) {
    "use strict";
    var compare2 = require_compare();
    var lte = (a, b, loose) => compare2(a, b, loose) <= 0;
    module.exports = lte;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/cmp.js
var require_cmp = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/cmp.js"(exports, module) {
    "use strict";
    var eq = require_eq();
    var neq = require_neq();
    var gt = require_gt();
    var gte = require_gte();
    var lt = require_lt();
    var lte = require_lte();
    var cmp = (a, op, b, loose) => {
      switch (op) {
        case "===":
          if (typeof a === "object") {
            a = a.version;
          }
          if (typeof b === "object") {
            b = b.version;
          }
          return a === b;
        case "!==":
          if (typeof a === "object") {
            a = a.version;
          }
          if (typeof b === "object") {
            b = b.version;
          }
          return a !== b;
        case "":
        case "=":
        case "==":
          return eq(a, b, loose);
        case "!=":
          return neq(a, b, loose);
        case ">":
          return gt(a, b, loose);
        case ">=":
          return gte(a, b, loose);
        case "<":
          return lt(a, b, loose);
        case "<=":
          return lte(a, b, loose);
        default:
          throw new TypeError(`Invalid operator: ${op}`);
      }
    };
    module.exports = cmp;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/coerce.js
var require_coerce = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/coerce.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var parse2 = require_parse();
    var { safeRe: re, t } = require_re();
    var coerce = (version, options) => {
      if (version instanceof SemVer) {
        return version;
      }
      if (typeof version === "number") {
        version = String(version);
      }
      if (typeof version !== "string") {
        return null;
      }
      options = options || {};
      let match = null;
      if (!options.rtl) {
        match = version.match(options.includePrerelease ? re[t.COERCEFULL] : re[t.COERCE]);
      } else {
        const coerceRtlRegex = options.includePrerelease ? re[t.COERCERTLFULL] : re[t.COERCERTL];
        let next;
        while ((next = coerceRtlRegex.exec(version)) && (!match || match.index + match[0].length !== version.length)) {
          if (!match || next.index + next[0].length !== match.index + match[0].length) {
            match = next;
          }
          coerceRtlRegex.lastIndex = next.index + next[1].length + next[2].length;
        }
        coerceRtlRegex.lastIndex = -1;
      }
      if (match === null) {
        return null;
      }
      const major = match[2];
      const minor = match[3] || "0";
      const patch = match[4] || "0";
      const prerelease = options.includePrerelease && match[5] ? `-${match[5]}` : "";
      const build = options.includePrerelease && match[6] ? `+${match[6]}` : "";
      return parse2(`${major}.${minor}.${patch}${prerelease}${build}`, options);
    };
    module.exports = coerce;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/truncate.js
var require_truncate = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/truncate.js"(exports, module) {
    "use strict";
    var parse2 = require_parse();
    var constants = require_constants();
    var SemVer = require_semver();
    var truncate = (version, truncation, options) => {
      if (!constants.RELEASE_TYPES.includes(truncation)) {
        return null;
      }
      const clonedVersion = cloneInputVersion(version, options);
      return clonedVersion && doTruncation(clonedVersion, truncation);
    };
    var cloneInputVersion = (version, options) => {
      const versionStringToParse = version instanceof SemVer ? version.version : version;
      return parse2(versionStringToParse, options);
    };
    var doTruncation = (version, truncation) => {
      if (isPrerelease(truncation)) {
        return version.version;
      }
      version.prerelease = [];
      switch (truncation) {
        case "major":
          version.minor = 0;
          version.patch = 0;
          break;
        case "minor":
          version.patch = 0;
          break;
      }
      return version.format();
    };
    var isPrerelease = (type) => {
      return type.startsWith("pre");
    };
    module.exports = truncate;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/lrucache.js
var require_lrucache = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/internal/lrucache.js"(exports, module) {
    "use strict";
    var LRUCache = class {
      constructor() {
        this.max = 1e3;
        this.map = /* @__PURE__ */ new Map();
      }
      get(key) {
        const value2 = this.map.get(key);
        if (value2 === void 0) {
          return void 0;
        } else {
          this.map.delete(key);
          this.map.set(key, value2);
          return value2;
        }
      }
      delete(key) {
        return this.map.delete(key);
      }
      set(key, value2) {
        const deleted = this.delete(key);
        if (!deleted && value2 !== void 0) {
          if (this.map.size >= this.max) {
            const firstKey = this.map.keys().next().value;
            this.delete(firstKey);
          }
          this.map.set(key, value2);
        }
        return this;
      }
    };
    module.exports = LRUCache;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/range.js
var require_range = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/range.js"(exports, module) {
    "use strict";
    var SPACE_CHARACTERS = /\s+/g;
    var Range = class _Range {
      constructor(range, options) {
        options = parseOptions(options);
        if (range instanceof _Range) {
          if (range.loose === !!options.loose && range.includePrerelease === !!options.includePrerelease) {
            return range;
          } else {
            return new _Range(range.raw, options);
          }
        }
        if (range instanceof Comparator) {
          this.raw = range.value;
          this.set = [[range]];
          this.formatted = void 0;
          return this;
        }
        this.options = options;
        this.loose = !!options.loose;
        this.includePrerelease = !!options.includePrerelease;
        this.raw = range.trim().replace(SPACE_CHARACTERS, " ");
        this.set = this.raw.split("||").map((r) => this.parseRange(r.trim())).filter((c) => c.length);
        if (!this.set.length) {
          throw new TypeError(`Invalid SemVer Range: ${this.raw}`);
        }
        if (this.set.length > 1) {
          const first = this.set[0];
          this.set = this.set.filter((c) => !isNullSet(c[0]));
          if (this.set.length === 0) {
            this.set = [first];
          } else if (this.set.length > 1) {
            for (const c of this.set) {
              if (c.length === 1 && isAny(c[0])) {
                this.set = [c];
                break;
              }
            }
          }
        }
        this.formatted = void 0;
      }
      get range() {
        if (this.formatted === void 0) {
          this.formatted = "";
          for (let i = 0; i < this.set.length; i++) {
            if (i > 0) {
              this.formatted += "||";
            }
            const comps = this.set[i];
            for (let k = 0; k < comps.length; k++) {
              if (k > 0) {
                this.formatted += " ";
              }
              this.formatted += comps[k].toString().trim();
            }
          }
        }
        return this.formatted;
      }
      format() {
        return this.range;
      }
      toString() {
        return this.range;
      }
      parseRange(range) {
        range = range.replace(BUILDSTRIPRE, "");
        const memoOpts = (this.options.includePrerelease && FLAG_INCLUDE_PRERELEASE) | (this.options.loose && FLAG_LOOSE);
        const memoKey = memoOpts + ":" + range;
        const cached = cache2.get(memoKey);
        if (cached) {
          return cached;
        }
        const loose = this.options.loose;
        const hr = loose ? re[t.HYPHENRANGELOOSE] : re[t.HYPHENRANGE];
        range = range.replace(hr, hyphenReplace(this.options.includePrerelease));
        debug("hyphen replace", range);
        range = range.replace(re[t.COMPARATORTRIM], comparatorTrimReplace);
        debug("comparator trim", range);
        range = range.replace(re[t.TILDETRIM], tildeTrimReplace);
        debug("tilde trim", range);
        range = range.replace(re[t.CARETTRIM], caretTrimReplace);
        debug("caret trim", range);
        let rangeList = range.split(" ").map((comp) => parseComparator(comp, this.options)).join(" ").split(/\s+/).map((comp) => replaceGTE0(comp, this.options));
        if (loose) {
          rangeList = rangeList.filter((comp) => {
            debug("loose invalid filter", comp, this.options);
            return !!comp.match(re[t.COMPARATORLOOSE]);
          });
        }
        debug("range list", rangeList);
        const rangeMap = /* @__PURE__ */ new Map();
        const comparators = rangeList.map((comp) => new Comparator(comp, this.options));
        for (const comp of comparators) {
          if (isNullSet(comp)) {
            return [comp];
          }
          rangeMap.set(comp.value, comp);
        }
        if (rangeMap.size > 1 && rangeMap.has("")) {
          rangeMap.delete("");
        }
        const result = [...rangeMap.values()];
        cache2.set(memoKey, result);
        return result;
      }
      intersects(range, options) {
        if (!(range instanceof _Range)) {
          throw new TypeError("a Range is required");
        }
        return this.set.some((thisComparators) => {
          return isSatisfiable(thisComparators, options) && range.set.some((rangeComparators) => {
            return isSatisfiable(rangeComparators, options) && thisComparators.every((thisComparator) => {
              return rangeComparators.every((rangeComparator) => {
                return thisComparator.intersects(rangeComparator, options);
              });
            });
          });
        });
      }
      // if ANY of the sets match ALL of its comparators, then pass
      test(version) {
        if (!version) {
          return false;
        }
        if (typeof version === "string") {
          try {
            version = new SemVer(version, this.options);
          } catch (er) {
            return false;
          }
        }
        for (let i = 0; i < this.set.length; i++) {
          if (testSet(this.set[i], version, this.options)) {
            return true;
          }
        }
        return false;
      }
    };
    module.exports = Range;
    var LRU = require_lrucache();
    var cache2 = new LRU();
    var parseOptions = require_parse_options();
    var Comparator = require_comparator();
    var debug = require_debug();
    var SemVer = require_semver();
    var {
      safeRe: re,
      src,
      t,
      comparatorTrimReplace,
      tildeTrimReplace,
      caretTrimReplace
    } = require_re();
    var { FLAG_INCLUDE_PRERELEASE, FLAG_LOOSE } = require_constants();
    var BUILDSTRIPRE = new RegExp(src[t.BUILD], "g");
    var isNullSet = (c) => c.value === "<0.0.0-0";
    var isAny = (c) => c.value === "";
    var isSatisfiable = (comparators, options) => {
      let result = true;
      const remainingComparators = comparators.slice();
      let testComparator = remainingComparators.pop();
      while (result && remainingComparators.length) {
        result = remainingComparators.every((otherComparator) => {
          return testComparator.intersects(otherComparator, options);
        });
        testComparator = remainingComparators.pop();
      }
      return result;
    };
    var parseComparator = (comp, options) => {
      comp = comp.replace(re[t.BUILD], "");
      debug("comp", comp, options);
      comp = replaceCarets(comp, options);
      debug("caret", comp);
      comp = replaceTildes(comp, options);
      debug("tildes", comp);
      comp = replaceXRanges(comp, options);
      debug("xrange", comp);
      comp = replaceStars(comp, options);
      debug("stars", comp);
      return comp;
    };
    var isX = (id3) => !id3 || id3.toLowerCase() === "x" || id3 === "*";
    var invalidXRangeOrder = (M, m, p) => isX(M) && !isX(m) || isX(m) && p && !isX(p);
    var replaceTildes = (comp, options) => {
      return comp.trim().split(/\s+/).map((c) => replaceTilde(c, options)).join(" ");
    };
    var replaceTilde = (comp, options) => {
      const r = options.loose ? re[t.TILDELOOSE] : re[t.TILDE];
      const z = options.includePrerelease ? "-0" : "";
      return comp.replace(r, (_, M, m, p, pr) => {
        debug("tilde", comp, _, M, m, p, pr);
        let ret;
        if (isX(M)) {
          ret = "";
        } else if (isX(m)) {
          ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
        } else if (isX(p)) {
          ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
        } else if (pr) {
          debug("replaceTilde pr", pr);
          ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
        } else {
          ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
        }
        debug("tilde return", ret);
        return ret;
      });
    };
    var replaceCarets = (comp, options) => {
      return comp.trim().split(/\s+/).map((c) => replaceCaret(c, options)).join(" ");
    };
    var replaceCaret = (comp, options) => {
      debug("caret", comp, options);
      const r = options.loose ? re[t.CARETLOOSE] : re[t.CARET];
      const z = options.includePrerelease ? "-0" : "";
      return comp.replace(r, (_, M, m, p, pr) => {
        debug("caret", comp, _, M, m, p, pr);
        let ret;
        if (isX(M)) {
          ret = "";
        } else if (isX(m)) {
          ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
        } else if (isX(p)) {
          if (M === "0") {
            ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
          } else {
            ret = `>=${M}.${m}.0${z} <${+M + 1}.0.0-0`;
          }
        } else if (pr) {
          debug("replaceCaret pr", pr);
          if (M === "0") {
            if (m === "0") {
              ret = `>=${M}.${m}.${p}-${pr} <${M}.${m}.${+p + 1}-0`;
            } else {
              ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
            }
          } else {
            ret = `>=${M}.${m}.${p}-${pr} <${+M + 1}.0.0-0`;
          }
        } else {
          debug("no pr");
          if (M === "0") {
            if (m === "0") {
              ret = `>=${M}.${m}.${p} <${M}.${m}.${+p + 1}-0`;
            } else {
              ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
            }
          } else {
            ret = `>=${M}.${m}.${p} <${+M + 1}.0.0-0`;
          }
        }
        debug("caret return", ret);
        return ret;
      });
    };
    var replaceXRanges = (comp, options) => {
      debug("replaceXRanges", comp, options);
      return comp.split(/\s+/).map((c) => replaceXRange(c, options)).join(" ");
    };
    var replaceXRange = (comp, options) => {
      comp = comp.trim();
      const r = options.loose ? re[t.XRANGELOOSE] : re[t.XRANGE];
      return comp.replace(r, (ret, gtlt, M, m, p, pr) => {
        debug("xRange", comp, ret, gtlt, M, m, p, pr);
        if (invalidXRangeOrder(M, m, p)) {
          return comp;
        }
        const xM = isX(M);
        const xm = xM || isX(m);
        const xp = xm || isX(p);
        const anyX = xp;
        if (gtlt === "=" && anyX) {
          gtlt = "";
        }
        pr = options.includePrerelease ? "-0" : "";
        if (xM) {
          if (gtlt === ">" || gtlt === "<") {
            ret = "<0.0.0-0";
          } else {
            ret = "*";
          }
        } else if (gtlt && anyX) {
          if (xm) {
            m = 0;
          }
          p = 0;
          if (gtlt === ">") {
            gtlt = ">=";
            if (xm) {
              M = +M + 1;
              m = 0;
              p = 0;
            } else {
              m = +m + 1;
              p = 0;
            }
          } else if (gtlt === "<=") {
            gtlt = "<";
            if (xm) {
              M = +M + 1;
            } else {
              m = +m + 1;
            }
          }
          if (gtlt === "<") {
            pr = "-0";
          }
          ret = `${gtlt + M}.${m}.${p}${pr}`;
        } else if (xm) {
          ret = `>=${M}.0.0${pr} <${+M + 1}.0.0-0`;
        } else if (xp) {
          ret = `>=${M}.${m}.0${pr} <${M}.${+m + 1}.0-0`;
        }
        debug("xRange return", ret);
        return ret;
      });
    };
    var replaceStars = (comp, options) => {
      debug("replaceStars", comp, options);
      return comp.trim().replace(re[t.STAR], "");
    };
    var replaceGTE0 = (comp, options) => {
      debug("replaceGTE0", comp, options);
      return comp.trim().replace(re[options.includePrerelease ? t.GTE0PRE : t.GTE0], "");
    };
    var hyphenReplace = (incPr) => ($0, from, fM, fm, fp, fpr, fb, to, tM, tm, tp, tpr) => {
      if (isX(fM)) {
        from = "";
      } else if (isX(fm)) {
        from = `>=${fM}.0.0${incPr ? "-0" : ""}`;
      } else if (isX(fp)) {
        from = `>=${fM}.${fm}.0${incPr ? "-0" : ""}`;
      } else if (fpr) {
        from = `>=${from}`;
      } else {
        from = `>=${from}${incPr ? "-0" : ""}`;
      }
      if (isX(tM)) {
        to = "";
      } else if (isX(tm)) {
        to = `<${+tM + 1}.0.0-0`;
      } else if (isX(tp)) {
        to = `<${tM}.${+tm + 1}.0-0`;
      } else if (tpr) {
        to = `<=${tM}.${tm}.${tp}-${tpr}`;
      } else if (incPr) {
        to = `<${tM}.${tm}.${+tp + 1}-0`;
      } else {
        to = `<=${to}`;
      }
      return `${from} ${to}`.trim();
    };
    var testSet = (set, version, options) => {
      for (let i = 0; i < set.length; i++) {
        if (!set[i].test(version)) {
          return false;
        }
      }
      if (version.prerelease.length && !options.includePrerelease) {
        for (let i = 0; i < set.length; i++) {
          debug(set[i].semver);
          if (set[i].semver === Comparator.ANY) {
            continue;
          }
          if (set[i].semver.prerelease.length > 0) {
            const allowed = set[i].semver;
            if (allowed.major === version.major && allowed.minor === version.minor && allowed.patch === version.patch) {
              return true;
            }
          }
        }
        return false;
      }
      return true;
    };
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/comparator.js
var require_comparator = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/classes/comparator.js"(exports, module) {
    "use strict";
    var ANY = /* @__PURE__ */ Symbol("SemVer ANY");
    var Comparator = class _Comparator {
      static get ANY() {
        return ANY;
      }
      constructor(comp, options) {
        options = parseOptions(options);
        if (comp instanceof _Comparator) {
          if (comp.loose === !!options.loose) {
            return comp;
          } else {
            comp = comp.value;
          }
        }
        comp = comp.trim().split(/\s+/).join(" ");
        debug("comparator", comp, options);
        this.options = options;
        this.loose = !!options.loose;
        this.parse(comp);
        if (this.semver === ANY) {
          this.value = "";
        } else {
          this.value = this.operator + this.semver.version;
        }
        debug("comp", this);
      }
      parse(comp) {
        const r = this.options.loose ? re[t.COMPARATORLOOSE] : re[t.COMPARATOR];
        const m = comp.match(r);
        if (!m) {
          throw new TypeError(`Invalid comparator: ${comp}`);
        }
        this.operator = m[1] !== void 0 ? m[1] : "";
        if (this.operator === "=") {
          this.operator = "";
        }
        if (!m[2]) {
          this.semver = ANY;
        } else {
          this.semver = new SemVer(m[2], this.options.loose);
        }
      }
      toString() {
        return this.value;
      }
      test(version) {
        debug("Comparator.test", version, this.options.loose);
        if (this.semver === ANY || version === ANY) {
          return true;
        }
        if (typeof version === "string") {
          try {
            version = new SemVer(version, this.options);
          } catch (er) {
            return false;
          }
        }
        return cmp(version, this.operator, this.semver, this.options);
      }
      intersects(comp, options) {
        if (!(comp instanceof _Comparator)) {
          throw new TypeError("a Comparator is required");
        }
        if (this.operator === "") {
          if (this.value === "") {
            return true;
          }
          return new Range(comp.value, options).test(this.value);
        } else if (comp.operator === "") {
          if (comp.value === "") {
            return true;
          }
          return new Range(this.value, options).test(comp.semver);
        }
        options = parseOptions(options);
        if (options.includePrerelease && (this.value === "<0.0.0-0" || comp.value === "<0.0.0-0")) {
          return false;
        }
        if (!options.includePrerelease && (this.value.startsWith("<0.0.0") || comp.value.startsWith("<0.0.0"))) {
          return false;
        }
        if (this.operator.startsWith(">") && comp.operator.startsWith(">")) {
          return true;
        }
        if (this.operator.startsWith("<") && comp.operator.startsWith("<")) {
          return true;
        }
        if (this.semver.version === comp.semver.version && this.operator.includes("=") && comp.operator.includes("=")) {
          return true;
        }
        if (cmp(this.semver, "<", comp.semver, options) && this.operator.startsWith(">") && comp.operator.startsWith("<")) {
          return true;
        }
        if (cmp(this.semver, ">", comp.semver, options) && this.operator.startsWith("<") && comp.operator.startsWith(">")) {
          return true;
        }
        return false;
      }
    };
    module.exports = Comparator;
    var parseOptions = require_parse_options();
    var { safeRe: re, t } = require_re();
    var cmp = require_cmp();
    var debug = require_debug();
    var SemVer = require_semver();
    var Range = require_range();
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/satisfies.js
var require_satisfies = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/functions/satisfies.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var satisfies = (version, range, options) => {
      try {
        range = new Range(range, options);
      } catch (er) {
        return false;
      }
      return range.test(version);
    };
    module.exports = satisfies;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/to-comparators.js
var require_to_comparators = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/to-comparators.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var toComparators = (range, options) => new Range(range, options).set.map((comp) => comp.map((c) => c.value).join(" ").trim().split(" "));
    module.exports = toComparators;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/max-satisfying.js
var require_max_satisfying = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/max-satisfying.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var Range = require_range();
    var maxSatisfying = (versions, range, options) => {
      let max = null;
      let maxSV = null;
      let rangeObj = null;
      try {
        rangeObj = new Range(range, options);
      } catch (er) {
        return null;
      }
      versions.forEach((v) => {
        if (rangeObj.test(v)) {
          if (!max || maxSV.compare(v) === -1) {
            max = v;
            maxSV = new SemVer(max, options);
          }
        }
      });
      return max;
    };
    module.exports = maxSatisfying;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-satisfying.js
var require_min_satisfying = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-satisfying.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var Range = require_range();
    var minSatisfying = (versions, range, options) => {
      let min = null;
      let minSV = null;
      let rangeObj = null;
      try {
        rangeObj = new Range(range, options);
      } catch (er) {
        return null;
      }
      versions.forEach((v) => {
        if (rangeObj.test(v)) {
          if (!min || minSV.compare(v) === 1) {
            min = v;
            minSV = new SemVer(min, options);
          }
        }
      });
      return min;
    };
    module.exports = minSatisfying;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-version.js
var require_min_version = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/min-version.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var Range = require_range();
    var gt = require_gt();
    var minVersion = (range, loose) => {
      range = new Range(range, loose);
      let minver = new SemVer("0.0.0");
      if (range.test(minver)) {
        return minver;
      }
      minver = new SemVer("0.0.0-0");
      if (range.test(minver)) {
        return minver;
      }
      minver = null;
      for (let i = 0; i < range.set.length; ++i) {
        const comparators = range.set[i];
        let setMin = null;
        comparators.forEach((comparator) => {
          const compver = new SemVer(comparator.semver.version);
          switch (comparator.operator) {
            case ">":
              if (compver.prerelease.length === 0) {
                compver.patch++;
              } else {
                compver.prerelease.push(0);
              }
              compver.raw = compver.format();
            /* fallthrough */
            case "":
            case ">=":
              if (!setMin || gt(compver, setMin)) {
                setMin = compver;
              }
              break;
            case "<":
            case "<=":
              break;
            /* istanbul ignore next */
            default:
              throw new Error(`Unexpected operation: ${comparator.operator}`);
          }
        });
        if (setMin && (!minver || gt(minver, setMin))) {
          minver = setMin;
        }
      }
      if (minver && range.test(minver)) {
        return minver;
      }
      return null;
    };
    module.exports = minVersion;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/valid.js
var require_valid2 = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/valid.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var validRange = (range, options) => {
      try {
        return new Range(range, options).range || "*";
      } catch (er) {
        return null;
      }
    };
    module.exports = validRange;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/outside.js
var require_outside = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/outside.js"(exports, module) {
    "use strict";
    var SemVer = require_semver();
    var Comparator = require_comparator();
    var { ANY } = Comparator;
    var Range = require_range();
    var satisfies = require_satisfies();
    var gt = require_gt();
    var lt = require_lt();
    var lte = require_lte();
    var gte = require_gte();
    var outside = (version, range, hilo, options) => {
      version = new SemVer(version, options);
      range = new Range(range, options);
      let gtfn, ltefn, ltfn, comp, ecomp;
      switch (hilo) {
        case ">":
          gtfn = gt;
          ltefn = lte;
          ltfn = lt;
          comp = ">";
          ecomp = ">=";
          break;
        case "<":
          gtfn = lt;
          ltefn = gte;
          ltfn = gt;
          comp = "<";
          ecomp = "<=";
          break;
        default:
          throw new TypeError('Must provide a hilo val of "<" or ">"');
      }
      if (satisfies(version, range, options)) {
        return false;
      }
      for (let i = 0; i < range.set.length; ++i) {
        const comparators = range.set[i];
        let high = null;
        let low = null;
        comparators.forEach((comparator) => {
          if (comparator.semver === ANY) {
            comparator = new Comparator(">=0.0.0");
          }
          high = high || comparator;
          low = low || comparator;
          if (gtfn(comparator.semver, high.semver, options)) {
            high = comparator;
          } else if (ltfn(comparator.semver, low.semver, options)) {
            low = comparator;
          }
        });
        if (high.operator === comp || high.operator === ecomp) {
          return false;
        }
        if ((!low.operator || low.operator === comp) && ltefn(version, low.semver)) {
          return false;
        } else if (low.operator === ecomp && ltfn(version, low.semver)) {
          return false;
        }
      }
      return true;
    };
    module.exports = outside;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/gtr.js
var require_gtr = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/gtr.js"(exports, module) {
    "use strict";
    var outside = require_outside();
    var gtr = (version, range, options) => outside(version, range, ">", options);
    module.exports = gtr;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/ltr.js
var require_ltr = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/ltr.js"(exports, module) {
    "use strict";
    var outside = require_outside();
    var ltr = (version, range, options) => outside(version, range, "<", options);
    module.exports = ltr;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/intersects.js
var require_intersects = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/intersects.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var intersects = (r1, r2, options) => {
      r1 = new Range(r1, options);
      r2 = new Range(r2, options);
      return r1.intersects(r2, options);
    };
    module.exports = intersects;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/simplify.js
var require_simplify = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/simplify.js"(exports, module) {
    "use strict";
    var satisfies = require_satisfies();
    var compare2 = require_compare();
    module.exports = (versions, range, options) => {
      const set = [];
      let first = null;
      let prev = null;
      const v = versions.sort((a, b) => compare2(a, b, options));
      for (const version of v) {
        const included = satisfies(version, range, options);
        if (included) {
          prev = version;
          if (!first) {
            first = version;
          }
        } else {
          if (prev) {
            set.push([first, prev]);
          }
          prev = null;
          first = null;
        }
      }
      if (first) {
        set.push([first, null]);
      }
      const ranges = [];
      for (const [min, max] of set) {
        if (min === max) {
          ranges.push(min);
        } else if (!max && min === v[0]) {
          ranges.push("*");
        } else if (!max) {
          ranges.push(`>=${min}`);
        } else if (min === v[0]) {
          ranges.push(`<=${max}`);
        } else {
          ranges.push(`${min} - ${max}`);
        }
      }
      const simplified = ranges.join(" || ");
      const original = typeof range.raw === "string" ? range.raw : String(range);
      return simplified.length < original.length ? simplified : range;
    };
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/subset.js
var require_subset = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/ranges/subset.js"(exports, module) {
    "use strict";
    var Range = require_range();
    var Comparator = require_comparator();
    var { ANY } = Comparator;
    var satisfies = require_satisfies();
    var compare2 = require_compare();
    var subset = (sub, dom, options = {}) => {
      if (sub === dom) {
        return true;
      }
      sub = new Range(sub, options);
      dom = new Range(dom, options);
      let sawNonNull = false;
      OUTER: for (const simpleSub of sub.set) {
        for (const simpleDom of dom.set) {
          const isSub = simpleSubset(simpleSub, simpleDom, options);
          sawNonNull = sawNonNull || isSub !== null;
          if (isSub) {
            continue OUTER;
          }
        }
        if (sawNonNull) {
          return false;
        }
      }
      return true;
    };
    var minimumVersionWithPreRelease = [new Comparator(">=0.0.0-0")];
    var minimumVersion = [new Comparator(">=0.0.0")];
    var simpleSubset = (sub, dom, options) => {
      if (sub === dom) {
        return true;
      }
      if (sub.length === 1 && sub[0].semver === ANY) {
        if (dom.length === 1 && dom[0].semver === ANY) {
          return true;
        } else if (options.includePrerelease) {
          sub = minimumVersionWithPreRelease;
        } else {
          sub = minimumVersion;
        }
      }
      if (dom.length === 1 && dom[0].semver === ANY) {
        if (options.includePrerelease) {
          return true;
        } else {
          dom = minimumVersion;
        }
      }
      const eqSet = /* @__PURE__ */ new Set();
      let gt, lt;
      for (const c of sub) {
        if (c.operator === ">" || c.operator === ">=") {
          gt = higherGT(gt, c, options);
        } else if (c.operator === "<" || c.operator === "<=") {
          lt = lowerLT(lt, c, options);
        } else {
          eqSet.add(c.semver);
        }
      }
      if (eqSet.size > 1) {
        return null;
      }
      let gtltComp;
      if (gt && lt) {
        gtltComp = compare2(gt.semver, lt.semver, options);
        if (gtltComp > 0) {
          return null;
        } else if (gtltComp === 0 && (gt.operator !== ">=" || lt.operator !== "<=")) {
          return null;
        }
      }
      for (const eq of eqSet) {
        if (gt && !satisfies(eq, String(gt), options)) {
          return null;
        }
        if (lt && !satisfies(eq, String(lt), options)) {
          return null;
        }
        for (const c of dom) {
          if (!satisfies(eq, String(c), options)) {
            return false;
          }
        }
        return true;
      }
      let higher, lower;
      let hasDomLT, hasDomGT;
      let needDomLTPre = lt && !options.includePrerelease && lt.semver.prerelease.length ? lt.semver : false;
      let needDomGTPre = gt && !options.includePrerelease && gt.semver.prerelease.length ? gt.semver : false;
      if (needDomLTPre && needDomLTPre.prerelease.length === 1 && lt.operator === "<" && needDomLTPre.prerelease[0] === 0) {
        needDomLTPre = false;
      }
      for (const c of dom) {
        hasDomGT = hasDomGT || c.operator === ">" || c.operator === ">=";
        hasDomLT = hasDomLT || c.operator === "<" || c.operator === "<=";
        if (gt) {
          if (needDomGTPre) {
            if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomGTPre.major && c.semver.minor === needDomGTPre.minor && c.semver.patch === needDomGTPre.patch) {
              needDomGTPre = false;
            }
          }
          if (c.operator === ">" || c.operator === ">=") {
            higher = higherGT(gt, c, options);
            if (higher === c && higher !== gt) {
              return false;
            }
          } else if (gt.operator === ">=" && !c.test(gt.semver)) {
            return false;
          }
        }
        if (lt) {
          if (needDomLTPre) {
            if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomLTPre.major && c.semver.minor === needDomLTPre.minor && c.semver.patch === needDomLTPre.patch) {
              needDomLTPre = false;
            }
          }
          if (c.operator === "<" || c.operator === "<=") {
            lower = lowerLT(lt, c, options);
            if (lower === c && lower !== lt) {
              return false;
            }
          } else if (lt.operator === "<=" && !c.test(lt.semver)) {
            return false;
          }
        }
        if (!c.operator && (lt || gt) && gtltComp !== 0) {
          return false;
        }
      }
      if (gt && hasDomLT && !lt && gtltComp !== 0) {
        return false;
      }
      if (lt && hasDomGT && !gt && gtltComp !== 0) {
        return false;
      }
      if (needDomGTPre || needDomLTPre) {
        return false;
      }
      return true;
    };
    var higherGT = (a, b, options) => {
      if (!a) {
        return b;
      }
      const comp = compare2(a.semver, b.semver, options);
      return comp > 0 ? a : comp < 0 ? b : b.operator === ">" && a.operator === ">=" ? b : a;
    };
    var lowerLT = (a, b, options) => {
      if (!a) {
        return b;
      }
      const comp = compare2(a.semver, b.semver, options);
      return comp < 0 ? a : comp > 0 ? b : b.operator === "<" && a.operator === "<=" ? b : a;
    };
    module.exports = subset;
  }
});

// node_modules/.pnpm/semver@7.8.5/node_modules/semver/index.js
var require_semver2 = __commonJS({
  "node_modules/.pnpm/semver@7.8.5/node_modules/semver/index.js"(exports, module) {
    "use strict";
    var internalRe = require_re();
    var constants = require_constants();
    var SemVer = require_semver();
    var identifiers = require_identifiers();
    var parse2 = require_parse();
    var valid = require_valid();
    var clean = require_clean();
    var inc = require_inc();
    var diff = require_diff();
    var major = require_major();
    var minor = require_minor();
    var patch = require_patch();
    var prerelease = require_prerelease();
    var compare2 = require_compare();
    var rcompare = require_rcompare();
    var compareLoose = require_compare_loose();
    var compareBuild = require_compare_build();
    var sort = require_sort();
    var rsort = require_rsort();
    var gt = require_gt();
    var lt = require_lt();
    var eq = require_eq();
    var neq = require_neq();
    var gte = require_gte();
    var lte = require_lte();
    var cmp = require_cmp();
    var coerce = require_coerce();
    var truncate = require_truncate();
    var Comparator = require_comparator();
    var Range = require_range();
    var satisfies = require_satisfies();
    var toComparators = require_to_comparators();
    var maxSatisfying = require_max_satisfying();
    var minSatisfying = require_min_satisfying();
    var minVersion = require_min_version();
    var validRange = require_valid2();
    var outside = require_outside();
    var gtr = require_gtr();
    var ltr = require_ltr();
    var intersects = require_intersects();
    var simplifyRange = require_simplify();
    var subset = require_subset();
    module.exports = {
      parse: parse2,
      valid,
      clean,
      inc,
      diff,
      major,
      minor,
      patch,
      prerelease,
      compare: compare2,
      rcompare,
      compareLoose,
      compareBuild,
      sort,
      rsort,
      gt,
      lt,
      eq,
      neq,
      gte,
      lte,
      cmp,
      coerce,
      truncate,
      Comparator,
      Range,
      satisfies,
      toComparators,
      maxSatisfying,
      minSatisfying,
      minVersion,
      validRange,
      outside,
      gtr,
      ltr,
      intersects,
      simplifyRange,
      subset,
      SemVer,
      re: internalRe.re,
      src: internalRe.src,
      tokens: internalRe.t,
      SEMVER_SPEC_VERSION: constants.SEMVER_SPEC_VERSION,
      RELEASE_TYPES: constants.RELEASE_TYPES,
      compareIdentifiers: identifiers.compareIdentifiers,
      rcompareIdentifiers: identifiers.rcompareIdentifiers
    };
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/codegen/code.js
var require_code = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/codegen/code.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.regexpCode = exports.getEsmExportName = exports.getProperty = exports.safeStringify = exports.stringify = exports.strConcat = exports.addCodeArg = exports.str = exports._ = exports.nil = exports._Code = exports.Name = exports.IDENTIFIER = exports._CodeOrName = void 0;
    var _CodeOrName = class {
    };
    exports._CodeOrName = _CodeOrName;
    exports.IDENTIFIER = /^[a-z$_][a-z$_0-9]*$/i;
    var Name = class extends _CodeOrName {
      constructor(s) {
        super();
        if (!exports.IDENTIFIER.test(s))
          throw new Error("CodeGen: name must be a valid identifier");
        this.str = s;
      }
      toString() {
        return this.str;
      }
      emptyStr() {
        return false;
      }
      get names() {
        return { [this.str]: 1 };
      }
    };
    exports.Name = Name;
    var _Code = class extends _CodeOrName {
      constructor(code) {
        super();
        this._items = typeof code === "string" ? [code] : code;
      }
      toString() {
        return this.str;
      }
      emptyStr() {
        if (this._items.length > 1)
          return false;
        const item = this._items[0];
        return item === "" || item === '""';
      }
      get str() {
        var _a;
        return (_a = this._str) !== null && _a !== void 0 ? _a : this._str = this._items.reduce((s, c) => `${s}${c}`, "");
      }
      get names() {
        var _a;
        return (_a = this._names) !== null && _a !== void 0 ? _a : this._names = this._items.reduce((names, c) => {
          if (c instanceof Name)
            names[c.str] = (names[c.str] || 0) + 1;
          return names;
        }, {});
      }
    };
    exports._Code = _Code;
    exports.nil = new _Code("");
    function _(strs, ...args) {
      const code = [strs[0]];
      let i = 0;
      while (i < args.length) {
        addCodeArg(code, args[i]);
        code.push(strs[++i]);
      }
      return new _Code(code);
    }
    exports._ = _;
    var plus = new _Code("+");
    function str(strs, ...args) {
      const expr = [safeStringify(strs[0])];
      let i = 0;
      while (i < args.length) {
        expr.push(plus);
        addCodeArg(expr, args[i]);
        expr.push(plus, safeStringify(strs[++i]));
      }
      optimize(expr);
      return new _Code(expr);
    }
    exports.str = str;
    function addCodeArg(code, arg) {
      if (arg instanceof _Code)
        code.push(...arg._items);
      else if (arg instanceof Name)
        code.push(arg);
      else
        code.push(interpolate(arg));
    }
    exports.addCodeArg = addCodeArg;
    function optimize(expr) {
      let i = 1;
      while (i < expr.length - 1) {
        if (expr[i] === plus) {
          const res = mergeExprItems(expr[i - 1], expr[i + 1]);
          if (res !== void 0) {
            expr.splice(i - 1, 3, res);
            continue;
          }
          expr[i++] = "+";
        }
        i++;
      }
    }
    function mergeExprItems(a, b) {
      if (b === '""')
        return a;
      if (a === '""')
        return b;
      if (typeof a == "string") {
        if (b instanceof Name || a[a.length - 1] !== '"')
          return;
        if (typeof b != "string")
          return `${a.slice(0, -1)}${b}"`;
        if (b[0] === '"')
          return a.slice(0, -1) + b.slice(1);
        return;
      }
      if (typeof b == "string" && b[0] === '"' && !(a instanceof Name))
        return `"${a}${b.slice(1)}`;
      return;
    }
    function strConcat(c1, c2) {
      return c2.emptyStr() ? c1 : c1.emptyStr() ? c2 : str`${c1}${c2}`;
    }
    exports.strConcat = strConcat;
    function interpolate(x) {
      return typeof x == "number" || typeof x == "boolean" || x === null ? x : safeStringify(Array.isArray(x) ? x.join(",") : x);
    }
    function stringify(x) {
      return new _Code(safeStringify(x));
    }
    exports.stringify = stringify;
    function safeStringify(x) {
      return JSON.stringify(x).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
    }
    exports.safeStringify = safeStringify;
    function getProperty(key) {
      return typeof key == "string" && exports.IDENTIFIER.test(key) ? new _Code(`.${key}`) : _`[${key}]`;
    }
    exports.getProperty = getProperty;
    function getEsmExportName(key) {
      if (typeof key == "string" && exports.IDENTIFIER.test(key)) {
        return new _Code(`${key}`);
      }
      throw new Error(`CodeGen: invalid export name: ${key}, use explicit $id name mapping`);
    }
    exports.getEsmExportName = getEsmExportName;
    function regexpCode(rx) {
      return new _Code(rx.toString());
    }
    exports.regexpCode = regexpCode;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/codegen/scope.js
var require_scope = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/codegen/scope.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ValueScope = exports.ValueScopeName = exports.Scope = exports.varKinds = exports.UsedValueState = void 0;
    var code_1 = require_code();
    var ValueError = class extends Error {
      constructor(name) {
        super(`CodeGen: "code" for ${name} not defined`);
        this.value = name.value;
      }
    };
    var UsedValueState;
    (function(UsedValueState2) {
      UsedValueState2[UsedValueState2["Started"] = 0] = "Started";
      UsedValueState2[UsedValueState2["Completed"] = 1] = "Completed";
    })(UsedValueState || (exports.UsedValueState = UsedValueState = {}));
    exports.varKinds = {
      const: new code_1.Name("const"),
      let: new code_1.Name("let"),
      var: new code_1.Name("var")
    };
    var Scope = class {
      constructor({ prefixes, parent } = {}) {
        this._names = {};
        this._prefixes = prefixes;
        this._parent = parent;
      }
      toName(nameOrPrefix) {
        return nameOrPrefix instanceof code_1.Name ? nameOrPrefix : this.name(nameOrPrefix);
      }
      name(prefix) {
        return new code_1.Name(this._newName(prefix));
      }
      _newName(prefix) {
        const ng = this._names[prefix] || this._nameGroup(prefix);
        return `${prefix}${ng.index++}`;
      }
      _nameGroup(prefix) {
        var _a, _b;
        if (((_b = (_a = this._parent) === null || _a === void 0 ? void 0 : _a._prefixes) === null || _b === void 0 ? void 0 : _b.has(prefix)) || this._prefixes && !this._prefixes.has(prefix)) {
          throw new Error(`CodeGen: prefix "${prefix}" is not allowed in this scope`);
        }
        return this._names[prefix] = { prefix, index: 0 };
      }
    };
    exports.Scope = Scope;
    var ValueScopeName = class extends code_1.Name {
      constructor(prefix, nameStr) {
        super(nameStr);
        this.prefix = prefix;
      }
      setValue(value2, { property, itemIndex }) {
        this.value = value2;
        this.scopePath = (0, code_1._)`.${new code_1.Name(property)}[${itemIndex}]`;
      }
    };
    exports.ValueScopeName = ValueScopeName;
    var line = (0, code_1._)`\n`;
    var ValueScope = class extends Scope {
      constructor(opts) {
        super(opts);
        this._values = {};
        this._scope = opts.scope;
        this.opts = { ...opts, _n: opts.lines ? line : code_1.nil };
      }
      get() {
        return this._scope;
      }
      name(prefix) {
        return new ValueScopeName(prefix, this._newName(prefix));
      }
      value(nameOrPrefix, value2) {
        var _a;
        if (value2.ref === void 0)
          throw new Error("CodeGen: ref must be passed in value");
        const name = this.toName(nameOrPrefix);
        const { prefix } = name;
        const valueKey = (_a = value2.key) !== null && _a !== void 0 ? _a : value2.ref;
        let vs = this._values[prefix];
        if (vs) {
          const _name = vs.get(valueKey);
          if (_name)
            return _name;
        } else {
          vs = this._values[prefix] = /* @__PURE__ */ new Map();
        }
        vs.set(valueKey, name);
        const s = this._scope[prefix] || (this._scope[prefix] = []);
        const itemIndex = s.length;
        s[itemIndex] = value2.ref;
        name.setValue(value2, { property: prefix, itemIndex });
        return name;
      }
      getValue(prefix, keyOrRef) {
        const vs = this._values[prefix];
        if (!vs)
          return;
        return vs.get(keyOrRef);
      }
      scopeRefs(scopeName, values = this._values) {
        return this._reduceValues(values, (name) => {
          if (name.scopePath === void 0)
            throw new Error(`CodeGen: name "${name}" has no value`);
          return (0, code_1._)`${scopeName}${name.scopePath}`;
        });
      }
      scopeCode(values = this._values, usedValues, getCode) {
        return this._reduceValues(values, (name) => {
          if (name.value === void 0)
            throw new Error(`CodeGen: name "${name}" has no value`);
          return name.value.code;
        }, usedValues, getCode);
      }
      _reduceValues(values, valueCode, usedValues = {}, getCode) {
        let code = code_1.nil;
        for (const prefix in values) {
          const vs = values[prefix];
          if (!vs)
            continue;
          const nameSet = usedValues[prefix] = usedValues[prefix] || /* @__PURE__ */ new Map();
          vs.forEach((name) => {
            if (nameSet.has(name))
              return;
            nameSet.set(name, UsedValueState.Started);
            let c = valueCode(name);
            if (c) {
              const def = this.opts.es5 ? exports.varKinds.var : exports.varKinds.const;
              code = (0, code_1._)`${code}${def} ${name} = ${c};${this.opts._n}`;
            } else if (c = getCode === null || getCode === void 0 ? void 0 : getCode(name)) {
              code = (0, code_1._)`${code}${c}${this.opts._n}`;
            } else {
              throw new ValueError(name);
            }
            nameSet.set(name, UsedValueState.Completed);
          });
        }
        return code;
      }
    };
    exports.ValueScope = ValueScope;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/codegen/index.js
var require_codegen = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/codegen/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.or = exports.and = exports.not = exports.CodeGen = exports.operators = exports.varKinds = exports.ValueScopeName = exports.ValueScope = exports.Scope = exports.Name = exports.regexpCode = exports.stringify = exports.getProperty = exports.nil = exports.strConcat = exports.str = exports._ = void 0;
    var code_1 = require_code();
    var scope_1 = require_scope();
    var code_2 = require_code();
    Object.defineProperty(exports, "_", { enumerable: true, get: function() {
      return code_2._;
    } });
    Object.defineProperty(exports, "str", { enumerable: true, get: function() {
      return code_2.str;
    } });
    Object.defineProperty(exports, "strConcat", { enumerable: true, get: function() {
      return code_2.strConcat;
    } });
    Object.defineProperty(exports, "nil", { enumerable: true, get: function() {
      return code_2.nil;
    } });
    Object.defineProperty(exports, "getProperty", { enumerable: true, get: function() {
      return code_2.getProperty;
    } });
    Object.defineProperty(exports, "stringify", { enumerable: true, get: function() {
      return code_2.stringify;
    } });
    Object.defineProperty(exports, "regexpCode", { enumerable: true, get: function() {
      return code_2.regexpCode;
    } });
    Object.defineProperty(exports, "Name", { enumerable: true, get: function() {
      return code_2.Name;
    } });
    var scope_2 = require_scope();
    Object.defineProperty(exports, "Scope", { enumerable: true, get: function() {
      return scope_2.Scope;
    } });
    Object.defineProperty(exports, "ValueScope", { enumerable: true, get: function() {
      return scope_2.ValueScope;
    } });
    Object.defineProperty(exports, "ValueScopeName", { enumerable: true, get: function() {
      return scope_2.ValueScopeName;
    } });
    Object.defineProperty(exports, "varKinds", { enumerable: true, get: function() {
      return scope_2.varKinds;
    } });
    exports.operators = {
      GT: new code_1._Code(">"),
      GTE: new code_1._Code(">="),
      LT: new code_1._Code("<"),
      LTE: new code_1._Code("<="),
      EQ: new code_1._Code("==="),
      NEQ: new code_1._Code("!=="),
      NOT: new code_1._Code("!"),
      OR: new code_1._Code("||"),
      AND: new code_1._Code("&&"),
      ADD: new code_1._Code("+")
    };
    var Node = class {
      optimizeNodes() {
        return this;
      }
      optimizeNames(_names, _constants) {
        return this;
      }
    };
    var Def = class extends Node {
      constructor(varKind, name, rhs) {
        super();
        this.varKind = varKind;
        this.name = name;
        this.rhs = rhs;
      }
      render({ es5, _n }) {
        const varKind = es5 ? scope_1.varKinds.var : this.varKind;
        const rhs = this.rhs === void 0 ? "" : ` = ${this.rhs}`;
        return `${varKind} ${this.name}${rhs};` + _n;
      }
      optimizeNames(names, constants) {
        if (!names[this.name.str])
          return;
        if (this.rhs)
          this.rhs = optimizeExpr(this.rhs, names, constants);
        return this;
      }
      get names() {
        return this.rhs instanceof code_1._CodeOrName ? this.rhs.names : {};
      }
    };
    var Assign = class extends Node {
      constructor(lhs, rhs, sideEffects) {
        super();
        this.lhs = lhs;
        this.rhs = rhs;
        this.sideEffects = sideEffects;
      }
      render({ _n }) {
        return `${this.lhs} = ${this.rhs};` + _n;
      }
      optimizeNames(names, constants) {
        if (this.lhs instanceof code_1.Name && !names[this.lhs.str] && !this.sideEffects)
          return;
        this.rhs = optimizeExpr(this.rhs, names, constants);
        return this;
      }
      get names() {
        const names = this.lhs instanceof code_1.Name ? {} : { ...this.lhs.names };
        return addExprNames(names, this.rhs);
      }
    };
    var AssignOp = class extends Assign {
      constructor(lhs, op, rhs, sideEffects) {
        super(lhs, rhs, sideEffects);
        this.op = op;
      }
      render({ _n }) {
        return `${this.lhs} ${this.op}= ${this.rhs};` + _n;
      }
    };
    var Label = class extends Node {
      constructor(label) {
        super();
        this.label = label;
        this.names = {};
      }
      render({ _n }) {
        return `${this.label}:` + _n;
      }
    };
    var Break = class extends Node {
      constructor(label) {
        super();
        this.label = label;
        this.names = {};
      }
      render({ _n }) {
        const label = this.label ? ` ${this.label}` : "";
        return `break${label};` + _n;
      }
    };
    var Throw = class extends Node {
      constructor(error3) {
        super();
        this.error = error3;
      }
      render({ _n }) {
        return `throw ${this.error};` + _n;
      }
      get names() {
        return this.error.names;
      }
    };
    var AnyCode = class extends Node {
      constructor(code) {
        super();
        this.code = code;
      }
      render({ _n }) {
        return `${this.code};` + _n;
      }
      optimizeNodes() {
        return `${this.code}` ? this : void 0;
      }
      optimizeNames(names, constants) {
        this.code = optimizeExpr(this.code, names, constants);
        return this;
      }
      get names() {
        return this.code instanceof code_1._CodeOrName ? this.code.names : {};
      }
    };
    var ParentNode = class extends Node {
      constructor(nodes = []) {
        super();
        this.nodes = nodes;
      }
      render(opts) {
        return this.nodes.reduce((code, n) => code + n.render(opts), "");
      }
      optimizeNodes() {
        const { nodes } = this;
        let i = nodes.length;
        while (i--) {
          const n = nodes[i].optimizeNodes();
          if (Array.isArray(n))
            nodes.splice(i, 1, ...n);
          else if (n)
            nodes[i] = n;
          else
            nodes.splice(i, 1);
        }
        return nodes.length > 0 ? this : void 0;
      }
      optimizeNames(names, constants) {
        const { nodes } = this;
        let i = nodes.length;
        while (i--) {
          const n = nodes[i];
          if (n.optimizeNames(names, constants))
            continue;
          subtractNames(names, n.names);
          nodes.splice(i, 1);
        }
        return nodes.length > 0 ? this : void 0;
      }
      get names() {
        return this.nodes.reduce((names, n) => addNames(names, n.names), {});
      }
    };
    var BlockNode = class extends ParentNode {
      render(opts) {
        return "{" + opts._n + super.render(opts) + "}" + opts._n;
      }
    };
    var Root = class extends ParentNode {
    };
    var Else = class extends BlockNode {
    };
    Else.kind = "else";
    var If = class _If extends BlockNode {
      constructor(condition, nodes) {
        super(nodes);
        this.condition = condition;
      }
      render(opts) {
        let code = `if(${this.condition})` + super.render(opts);
        if (this.else)
          code += "else " + this.else.render(opts);
        return code;
      }
      optimizeNodes() {
        super.optimizeNodes();
        const cond = this.condition;
        if (cond === true)
          return this.nodes;
        let e = this.else;
        if (e) {
          const ns = e.optimizeNodes();
          e = this.else = Array.isArray(ns) ? new Else(ns) : ns;
        }
        if (e) {
          if (cond === false)
            return e instanceof _If ? e : e.nodes;
          if (this.nodes.length)
            return this;
          return new _If(not(cond), e instanceof _If ? [e] : e.nodes);
        }
        if (cond === false || !this.nodes.length)
          return void 0;
        return this;
      }
      optimizeNames(names, constants) {
        var _a;
        this.else = (_a = this.else) === null || _a === void 0 ? void 0 : _a.optimizeNames(names, constants);
        if (!(super.optimizeNames(names, constants) || this.else))
          return;
        this.condition = optimizeExpr(this.condition, names, constants);
        return this;
      }
      get names() {
        const names = super.names;
        addExprNames(names, this.condition);
        if (this.else)
          addNames(names, this.else.names);
        return names;
      }
    };
    If.kind = "if";
    var For = class extends BlockNode {
    };
    For.kind = "for";
    var ForLoop = class extends For {
      constructor(iteration) {
        super();
        this.iteration = iteration;
      }
      render(opts) {
        return `for(${this.iteration})` + super.render(opts);
      }
      optimizeNames(names, constants) {
        if (!super.optimizeNames(names, constants))
          return;
        this.iteration = optimizeExpr(this.iteration, names, constants);
        return this;
      }
      get names() {
        return addNames(super.names, this.iteration.names);
      }
    };
    var ForRange = class extends For {
      constructor(varKind, name, from, to) {
        super();
        this.varKind = varKind;
        this.name = name;
        this.from = from;
        this.to = to;
      }
      render(opts) {
        const varKind = opts.es5 ? scope_1.varKinds.var : this.varKind;
        const { name, from, to } = this;
        return `for(${varKind} ${name}=${from}; ${name}<${to}; ${name}++)` + super.render(opts);
      }
      get names() {
        const names = addExprNames(super.names, this.from);
        return addExprNames(names, this.to);
      }
    };
    var ForIter = class extends For {
      constructor(loop, varKind, name, iterable) {
        super();
        this.loop = loop;
        this.varKind = varKind;
        this.name = name;
        this.iterable = iterable;
      }
      render(opts) {
        return `for(${this.varKind} ${this.name} ${this.loop} ${this.iterable})` + super.render(opts);
      }
      optimizeNames(names, constants) {
        if (!super.optimizeNames(names, constants))
          return;
        this.iterable = optimizeExpr(this.iterable, names, constants);
        return this;
      }
      get names() {
        return addNames(super.names, this.iterable.names);
      }
    };
    var Func = class extends BlockNode {
      constructor(name, args, async) {
        super();
        this.name = name;
        this.args = args;
        this.async = async;
      }
      render(opts) {
        const _async = this.async ? "async " : "";
        return `${_async}function ${this.name}(${this.args})` + super.render(opts);
      }
    };
    Func.kind = "func";
    var Return = class extends ParentNode {
      render(opts) {
        return "return " + super.render(opts);
      }
    };
    Return.kind = "return";
    var Try = class extends BlockNode {
      render(opts) {
        let code = "try" + super.render(opts);
        if (this.catch)
          code += this.catch.render(opts);
        if (this.finally)
          code += this.finally.render(opts);
        return code;
      }
      optimizeNodes() {
        var _a, _b;
        super.optimizeNodes();
        (_a = this.catch) === null || _a === void 0 ? void 0 : _a.optimizeNodes();
        (_b = this.finally) === null || _b === void 0 ? void 0 : _b.optimizeNodes();
        return this;
      }
      optimizeNames(names, constants) {
        var _a, _b;
        super.optimizeNames(names, constants);
        (_a = this.catch) === null || _a === void 0 ? void 0 : _a.optimizeNames(names, constants);
        (_b = this.finally) === null || _b === void 0 ? void 0 : _b.optimizeNames(names, constants);
        return this;
      }
      get names() {
        const names = super.names;
        if (this.catch)
          addNames(names, this.catch.names);
        if (this.finally)
          addNames(names, this.finally.names);
        return names;
      }
    };
    var Catch = class extends BlockNode {
      constructor(error3) {
        super();
        this.error = error3;
      }
      render(opts) {
        return `catch(${this.error})` + super.render(opts);
      }
    };
    Catch.kind = "catch";
    var Finally = class extends BlockNode {
      render(opts) {
        return "finally" + super.render(opts);
      }
    };
    Finally.kind = "finally";
    var CodeGen = class {
      constructor(extScope, opts = {}) {
        this._values = {};
        this._blockStarts = [];
        this._constants = {};
        this.opts = { ...opts, _n: opts.lines ? "\n" : "" };
        this._extScope = extScope;
        this._scope = new scope_1.Scope({ parent: extScope });
        this._nodes = [new Root()];
      }
      toString() {
        return this._root.render(this.opts);
      }
      // returns unique name in the internal scope
      name(prefix) {
        return this._scope.name(prefix);
      }
      // reserves unique name in the external scope
      scopeName(prefix) {
        return this._extScope.name(prefix);
      }
      // reserves unique name in the external scope and assigns value to it
      scopeValue(prefixOrName, value2) {
        const name = this._extScope.value(prefixOrName, value2);
        const vs = this._values[name.prefix] || (this._values[name.prefix] = /* @__PURE__ */ new Set());
        vs.add(name);
        return name;
      }
      getScopeValue(prefix, keyOrRef) {
        return this._extScope.getValue(prefix, keyOrRef);
      }
      // return code that assigns values in the external scope to the names that are used internally
      // (same names that were returned by gen.scopeName or gen.scopeValue)
      scopeRefs(scopeName) {
        return this._extScope.scopeRefs(scopeName, this._values);
      }
      scopeCode() {
        return this._extScope.scopeCode(this._values);
      }
      _def(varKind, nameOrPrefix, rhs, constant) {
        const name = this._scope.toName(nameOrPrefix);
        if (rhs !== void 0 && constant)
          this._constants[name.str] = rhs;
        this._leafNode(new Def(varKind, name, rhs));
        return name;
      }
      // `const` declaration (`var` in es5 mode)
      const(nameOrPrefix, rhs, _constant) {
        return this._def(scope_1.varKinds.const, nameOrPrefix, rhs, _constant);
      }
      // `let` declaration with optional assignment (`var` in es5 mode)
      let(nameOrPrefix, rhs, _constant) {
        return this._def(scope_1.varKinds.let, nameOrPrefix, rhs, _constant);
      }
      // `var` declaration with optional assignment
      var(nameOrPrefix, rhs, _constant) {
        return this._def(scope_1.varKinds.var, nameOrPrefix, rhs, _constant);
      }
      // assignment code
      assign(lhs, rhs, sideEffects) {
        return this._leafNode(new Assign(lhs, rhs, sideEffects));
      }
      // `+=` code
      add(lhs, rhs) {
        return this._leafNode(new AssignOp(lhs, exports.operators.ADD, rhs));
      }
      // appends passed SafeExpr to code or executes Block
      code(c) {
        if (typeof c == "function")
          c();
        else if (c !== code_1.nil)
          this._leafNode(new AnyCode(c));
        return this;
      }
      // returns code for object literal for the passed argument list of key-value pairs
      object(...keyValues) {
        const code = ["{"];
        for (const [key, value2] of keyValues) {
          if (code.length > 1)
            code.push(",");
          code.push(key);
          if (key !== value2 || this.opts.es5) {
            code.push(":");
            (0, code_1.addCodeArg)(code, value2);
          }
        }
        code.push("}");
        return new code_1._Code(code);
      }
      // `if` clause (or statement if `thenBody` and, optionally, `elseBody` are passed)
      if(condition, thenBody, elseBody) {
        this._blockNode(new If(condition));
        if (thenBody && elseBody) {
          this.code(thenBody).else().code(elseBody).endIf();
        } else if (thenBody) {
          this.code(thenBody).endIf();
        } else if (elseBody) {
          throw new Error('CodeGen: "else" body without "then" body');
        }
        return this;
      }
      // `else if` clause - invalid without `if` or after `else` clauses
      elseIf(condition) {
        return this._elseNode(new If(condition));
      }
      // `else` clause - only valid after `if` or `else if` clauses
      else() {
        return this._elseNode(new Else());
      }
      // end `if` statement (needed if gen.if was used only with condition)
      endIf() {
        return this._endBlockNode(If, Else);
      }
      _for(node, forBody) {
        this._blockNode(node);
        if (forBody)
          this.code(forBody).endFor();
        return this;
      }
      // a generic `for` clause (or statement if `forBody` is passed)
      for(iteration, forBody) {
        return this._for(new ForLoop(iteration), forBody);
      }
      // `for` statement for a range of values
      forRange(nameOrPrefix, from, to, forBody, varKind = this.opts.es5 ? scope_1.varKinds.var : scope_1.varKinds.let) {
        const name = this._scope.toName(nameOrPrefix);
        return this._for(new ForRange(varKind, name, from, to), () => forBody(name));
      }
      // `for-of` statement (in es5 mode replace with a normal for loop)
      forOf(nameOrPrefix, iterable, forBody, varKind = scope_1.varKinds.const) {
        const name = this._scope.toName(nameOrPrefix);
        if (this.opts.es5) {
          const arr = iterable instanceof code_1.Name ? iterable : this.var("_arr", iterable);
          return this.forRange("_i", 0, (0, code_1._)`${arr}.length`, (i) => {
            this.var(name, (0, code_1._)`${arr}[${i}]`);
            forBody(name);
          });
        }
        return this._for(new ForIter("of", varKind, name, iterable), () => forBody(name));
      }
      // `for-in` statement.
      // With option `ownProperties` replaced with a `for-of` loop for object keys
      forIn(nameOrPrefix, obj, forBody, varKind = this.opts.es5 ? scope_1.varKinds.var : scope_1.varKinds.const) {
        if (this.opts.ownProperties) {
          return this.forOf(nameOrPrefix, (0, code_1._)`Object.keys(${obj})`, forBody);
        }
        const name = this._scope.toName(nameOrPrefix);
        return this._for(new ForIter("in", varKind, name, obj), () => forBody(name));
      }
      // end `for` loop
      endFor() {
        return this._endBlockNode(For);
      }
      // `label` statement
      label(label) {
        return this._leafNode(new Label(label));
      }
      // `break` statement
      break(label) {
        return this._leafNode(new Break(label));
      }
      // `return` statement
      return(value2) {
        const node = new Return();
        this._blockNode(node);
        this.code(value2);
        if (node.nodes.length !== 1)
          throw new Error('CodeGen: "return" should have one node');
        return this._endBlockNode(Return);
      }
      // `try` statement
      try(tryBody, catchCode, finallyCode) {
        if (!catchCode && !finallyCode)
          throw new Error('CodeGen: "try" without "catch" and "finally"');
        const node = new Try();
        this._blockNode(node);
        this.code(tryBody);
        if (catchCode) {
          const error3 = this.name("e");
          this._currNode = node.catch = new Catch(error3);
          catchCode(error3);
        }
        if (finallyCode) {
          this._currNode = node.finally = new Finally();
          this.code(finallyCode);
        }
        return this._endBlockNode(Catch, Finally);
      }
      // `throw` statement
      throw(error3) {
        return this._leafNode(new Throw(error3));
      }
      // start self-balancing block
      block(body2, nodeCount) {
        this._blockStarts.push(this._nodes.length);
        if (body2)
          this.code(body2).endBlock(nodeCount);
        return this;
      }
      // end the current self-balancing block
      endBlock(nodeCount) {
        const len = this._blockStarts.pop();
        if (len === void 0)
          throw new Error("CodeGen: not in self-balancing block");
        const toClose = this._nodes.length - len;
        if (toClose < 0 || nodeCount !== void 0 && toClose !== nodeCount) {
          throw new Error(`CodeGen: wrong number of nodes: ${toClose} vs ${nodeCount} expected`);
        }
        this._nodes.length = len;
        return this;
      }
      // `function` heading (or definition if funcBody is passed)
      func(name, args = code_1.nil, async, funcBody) {
        this._blockNode(new Func(name, args, async));
        if (funcBody)
          this.code(funcBody).endFunc();
        return this;
      }
      // end function definition
      endFunc() {
        return this._endBlockNode(Func);
      }
      optimize(n = 1) {
        while (n-- > 0) {
          this._root.optimizeNodes();
          this._root.optimizeNames(this._root.names, this._constants);
        }
      }
      _leafNode(node) {
        this._currNode.nodes.push(node);
        return this;
      }
      _blockNode(node) {
        this._currNode.nodes.push(node);
        this._nodes.push(node);
      }
      _endBlockNode(N1, N2) {
        const n = this._currNode;
        if (n instanceof N1 || N2 && n instanceof N2) {
          this._nodes.pop();
          return this;
        }
        throw new Error(`CodeGen: not in block "${N2 ? `${N1.kind}/${N2.kind}` : N1.kind}"`);
      }
      _elseNode(node) {
        const n = this._currNode;
        if (!(n instanceof If)) {
          throw new Error('CodeGen: "else" without "if"');
        }
        this._currNode = n.else = node;
        return this;
      }
      get _root() {
        return this._nodes[0];
      }
      get _currNode() {
        const ns = this._nodes;
        return ns[ns.length - 1];
      }
      set _currNode(node) {
        const ns = this._nodes;
        ns[ns.length - 1] = node;
      }
    };
    exports.CodeGen = CodeGen;
    function addNames(names, from) {
      for (const n in from)
        names[n] = (names[n] || 0) + (from[n] || 0);
      return names;
    }
    function addExprNames(names, from) {
      return from instanceof code_1._CodeOrName ? addNames(names, from.names) : names;
    }
    function optimizeExpr(expr, names, constants) {
      if (expr instanceof code_1.Name)
        return replaceName(expr);
      if (!canOptimize(expr))
        return expr;
      return new code_1._Code(expr._items.reduce((items, c) => {
        if (c instanceof code_1.Name)
          c = replaceName(c);
        if (c instanceof code_1._Code)
          items.push(...c._items);
        else
          items.push(c);
        return items;
      }, []));
      function replaceName(n) {
        const c = constants[n.str];
        if (c === void 0 || names[n.str] !== 1)
          return n;
        delete names[n.str];
        return c;
      }
      function canOptimize(e) {
        return e instanceof code_1._Code && e._items.some((c) => c instanceof code_1.Name && names[c.str] === 1 && constants[c.str] !== void 0);
      }
    }
    function subtractNames(names, from) {
      for (const n in from)
        names[n] = (names[n] || 0) - (from[n] || 0);
    }
    function not(x) {
      return typeof x == "boolean" || typeof x == "number" || x === null ? !x : (0, code_1._)`!${par(x)}`;
    }
    exports.not = not;
    var andCode = mappend(exports.operators.AND);
    function and(...args) {
      return args.reduce(andCode);
    }
    exports.and = and;
    var orCode = mappend(exports.operators.OR);
    function or(...args) {
      return args.reduce(orCode);
    }
    exports.or = or;
    function mappend(op) {
      return (x, y) => x === code_1.nil ? y : y === code_1.nil ? x : (0, code_1._)`${par(x)} ${op} ${par(y)}`;
    }
    function par(x) {
      return x instanceof code_1.Name ? x : (0, code_1._)`(${x})`;
    }
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/util.js
var require_util = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/util.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.checkStrictMode = exports.getErrorPath = exports.Type = exports.useFunc = exports.setEvaluated = exports.evaluatedPropsToName = exports.mergeEvaluated = exports.eachItem = exports.unescapeJsonPointer = exports.escapeJsonPointer = exports.escapeFragment = exports.unescapeFragment = exports.schemaRefOrVal = exports.schemaHasRulesButRef = exports.schemaHasRules = exports.checkUnknownRules = exports.alwaysValidSchema = exports.toHash = void 0;
    var codegen_1 = require_codegen();
    var code_1 = require_code();
    function toHash(arr) {
      const hash3 = {};
      for (const item of arr)
        hash3[item] = true;
      return hash3;
    }
    exports.toHash = toHash;
    function alwaysValidSchema(it, schema) {
      if (typeof schema == "boolean")
        return schema;
      if (Object.keys(schema).length === 0)
        return true;
      checkUnknownRules(it, schema);
      return !schemaHasRules(schema, it.self.RULES.all);
    }
    exports.alwaysValidSchema = alwaysValidSchema;
    function checkUnknownRules(it, schema = it.schema) {
      const { opts, self } = it;
      if (!opts.strictSchema)
        return;
      if (typeof schema === "boolean")
        return;
      const rules = self.RULES.keywords;
      for (const key in schema) {
        if (!rules[key])
          checkStrictMode(it, `unknown keyword: "${key}"`);
      }
    }
    exports.checkUnknownRules = checkUnknownRules;
    function schemaHasRules(schema, rules) {
      if (typeof schema == "boolean")
        return !schema;
      for (const key in schema)
        if (rules[key])
          return true;
      return false;
    }
    exports.schemaHasRules = schemaHasRules;
    function schemaHasRulesButRef(schema, RULES) {
      if (typeof schema == "boolean")
        return !schema;
      for (const key in schema)
        if (key !== "$ref" && RULES.all[key])
          return true;
      return false;
    }
    exports.schemaHasRulesButRef = schemaHasRulesButRef;
    function schemaRefOrVal({ topSchemaRef, schemaPath }, schema, keyword, $data) {
      if (!$data) {
        if (typeof schema == "number" || typeof schema == "boolean")
          return schema;
        if (typeof schema == "string")
          return (0, codegen_1._)`${schema}`;
      }
      return (0, codegen_1._)`${topSchemaRef}${schemaPath}${(0, codegen_1.getProperty)(keyword)}`;
    }
    exports.schemaRefOrVal = schemaRefOrVal;
    function unescapeFragment(str) {
      return unescapeJsonPointer(decodeURIComponent(str));
    }
    exports.unescapeFragment = unescapeFragment;
    function escapeFragment(str) {
      return encodeURIComponent(escapeJsonPointer(str));
    }
    exports.escapeFragment = escapeFragment;
    function escapeJsonPointer(str) {
      if (typeof str == "number")
        return `${str}`;
      return str.replace(/~/g, "~0").replace(/\//g, "~1");
    }
    exports.escapeJsonPointer = escapeJsonPointer;
    function unescapeJsonPointer(str) {
      return str.replace(/~1/g, "/").replace(/~0/g, "~");
    }
    exports.unescapeJsonPointer = unescapeJsonPointer;
    function eachItem(xs, f) {
      if (Array.isArray(xs)) {
        for (const x of xs)
          f(x);
      } else {
        f(xs);
      }
    }
    exports.eachItem = eachItem;
    function makeMergeEvaluated({ mergeNames, mergeToName, mergeValues, resultToName }) {
      return (gen, from, to, toName) => {
        const res = to === void 0 ? from : to instanceof codegen_1.Name ? (from instanceof codegen_1.Name ? mergeNames(gen, from, to) : mergeToName(gen, from, to), to) : from instanceof codegen_1.Name ? (mergeToName(gen, to, from), from) : mergeValues(from, to);
        return toName === codegen_1.Name && !(res instanceof codegen_1.Name) ? resultToName(gen, res) : res;
      };
    }
    exports.mergeEvaluated = {
      props: makeMergeEvaluated({
        mergeNames: (gen, from, to) => gen.if((0, codegen_1._)`${to} !== true && ${from} !== undefined`, () => {
          gen.if((0, codegen_1._)`${from} === true`, () => gen.assign(to, true), () => gen.assign(to, (0, codegen_1._)`${to} || {}`).code((0, codegen_1._)`Object.assign(${to}, ${from})`));
        }),
        mergeToName: (gen, from, to) => gen.if((0, codegen_1._)`${to} !== true`, () => {
          if (from === true) {
            gen.assign(to, true);
          } else {
            gen.assign(to, (0, codegen_1._)`${to} || {}`);
            setEvaluated(gen, to, from);
          }
        }),
        mergeValues: (from, to) => from === true ? true : { ...from, ...to },
        resultToName: evaluatedPropsToName
      }),
      items: makeMergeEvaluated({
        mergeNames: (gen, from, to) => gen.if((0, codegen_1._)`${to} !== true && ${from} !== undefined`, () => gen.assign(to, (0, codegen_1._)`${from} === true ? true : ${to} > ${from} ? ${to} : ${from}`)),
        mergeToName: (gen, from, to) => gen.if((0, codegen_1._)`${to} !== true`, () => gen.assign(to, from === true ? true : (0, codegen_1._)`${to} > ${from} ? ${to} : ${from}`)),
        mergeValues: (from, to) => from === true ? true : Math.max(from, to),
        resultToName: (gen, items) => gen.var("items", items)
      })
    };
    function evaluatedPropsToName(gen, ps) {
      if (ps === true)
        return gen.var("props", true);
      const props = gen.var("props", (0, codegen_1._)`{}`);
      if (ps !== void 0)
        setEvaluated(gen, props, ps);
      return props;
    }
    exports.evaluatedPropsToName = evaluatedPropsToName;
    function setEvaluated(gen, props, ps) {
      Object.keys(ps).forEach((p) => gen.assign((0, codegen_1._)`${props}${(0, codegen_1.getProperty)(p)}`, true));
    }
    exports.setEvaluated = setEvaluated;
    var snippets = {};
    function useFunc(gen, f) {
      return gen.scopeValue("func", {
        ref: f,
        code: snippets[f.code] || (snippets[f.code] = new code_1._Code(f.code))
      });
    }
    exports.useFunc = useFunc;
    var Type;
    (function(Type2) {
      Type2[Type2["Num"] = 0] = "Num";
      Type2[Type2["Str"] = 1] = "Str";
    })(Type || (exports.Type = Type = {}));
    function getErrorPath(dataProp, dataPropType, jsPropertySyntax) {
      if (dataProp instanceof codegen_1.Name) {
        const isNumber = dataPropType === Type.Num;
        return jsPropertySyntax ? isNumber ? (0, codegen_1._)`"[" + ${dataProp} + "]"` : (0, codegen_1._)`"['" + ${dataProp} + "']"` : isNumber ? (0, codegen_1._)`"/" + ${dataProp}` : (0, codegen_1._)`"/" + ${dataProp}.replace(/~/g, "~0").replace(/\\//g, "~1")`;
      }
      return jsPropertySyntax ? (0, codegen_1.getProperty)(dataProp).toString() : "/" + escapeJsonPointer(dataProp);
    }
    exports.getErrorPath = getErrorPath;
    function checkStrictMode(it, msg, mode = it.opts.strictSchema) {
      if (!mode)
        return;
      msg = `strict mode: ${msg}`;
      if (mode === true)
        throw new Error(msg);
      it.self.logger.warn(msg);
    }
    exports.checkStrictMode = checkStrictMode;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/names.js
var require_names = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/names.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var names = {
      // validation function arguments
      data: new codegen_1.Name("data"),
      // data passed to validation function
      // args passed from referencing schema
      valCxt: new codegen_1.Name("valCxt"),
      // validation/data context - should not be used directly, it is destructured to the names below
      instancePath: new codegen_1.Name("instancePath"),
      parentData: new codegen_1.Name("parentData"),
      parentDataProperty: new codegen_1.Name("parentDataProperty"),
      rootData: new codegen_1.Name("rootData"),
      // root data - same as the data passed to the first/top validation function
      dynamicAnchors: new codegen_1.Name("dynamicAnchors"),
      // used to support recursiveRef and dynamicRef
      // function scoped variables
      vErrors: new codegen_1.Name("vErrors"),
      // null or array of validation errors
      errors: new codegen_1.Name("errors"),
      // counter of validation errors
      this: new codegen_1.Name("this"),
      // "globals"
      self: new codegen_1.Name("self"),
      scope: new codegen_1.Name("scope"),
      // JTD serialize/parse name for JSON string and position
      json: new codegen_1.Name("json"),
      jsonPos: new codegen_1.Name("jsonPos"),
      jsonLen: new codegen_1.Name("jsonLen"),
      jsonPart: new codegen_1.Name("jsonPart")
    };
    exports.default = names;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/errors.js
var require_errors = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/errors.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.extendErrors = exports.resetErrorsCount = exports.reportExtraError = exports.reportError = exports.keyword$DataError = exports.keywordError = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var names_1 = require_names();
    exports.keywordError = {
      message: ({ keyword }) => (0, codegen_1.str)`must pass "${keyword}" keyword validation`
    };
    exports.keyword$DataError = {
      message: ({ keyword, schemaType }) => schemaType ? (0, codegen_1.str)`"${keyword}" keyword must be ${schemaType} ($data)` : (0, codegen_1.str)`"${keyword}" keyword is invalid ($data)`
    };
    function reportError(cxt, error3 = exports.keywordError, errorPaths, overrideAllErrors) {
      const { it } = cxt;
      const { gen, compositeRule, allErrors } = it;
      const errObj = errorObjectCode(cxt, error3, errorPaths);
      if (overrideAllErrors !== null && overrideAllErrors !== void 0 ? overrideAllErrors : compositeRule || allErrors) {
        addError(gen, errObj);
      } else {
        returnErrors(it, (0, codegen_1._)`[${errObj}]`);
      }
    }
    exports.reportError = reportError;
    function reportExtraError(cxt, error3 = exports.keywordError, errorPaths) {
      const { it } = cxt;
      const { gen, compositeRule, allErrors } = it;
      const errObj = errorObjectCode(cxt, error3, errorPaths);
      addError(gen, errObj);
      if (!(compositeRule || allErrors)) {
        returnErrors(it, names_1.default.vErrors);
      }
    }
    exports.reportExtraError = reportExtraError;
    function resetErrorsCount(gen, errsCount) {
      gen.assign(names_1.default.errors, errsCount);
      gen.if((0, codegen_1._)`${names_1.default.vErrors} !== null`, () => gen.if(errsCount, () => gen.assign((0, codegen_1._)`${names_1.default.vErrors}.length`, errsCount), () => gen.assign(names_1.default.vErrors, null)));
    }
    exports.resetErrorsCount = resetErrorsCount;
    function extendErrors({ gen, keyword, schemaValue, data, errsCount, it }) {
      if (errsCount === void 0)
        throw new Error("ajv implementation error");
      const err = gen.name("err");
      gen.forRange("i", errsCount, names_1.default.errors, (i) => {
        gen.const(err, (0, codegen_1._)`${names_1.default.vErrors}[${i}]`);
        gen.if((0, codegen_1._)`${err}.instancePath === undefined`, () => gen.assign((0, codegen_1._)`${err}.instancePath`, (0, codegen_1.strConcat)(names_1.default.instancePath, it.errorPath)));
        gen.assign((0, codegen_1._)`${err}.schemaPath`, (0, codegen_1.str)`${it.errSchemaPath}/${keyword}`);
        if (it.opts.verbose) {
          gen.assign((0, codegen_1._)`${err}.schema`, schemaValue);
          gen.assign((0, codegen_1._)`${err}.data`, data);
        }
      });
    }
    exports.extendErrors = extendErrors;
    function addError(gen, errObj) {
      const err = gen.const("err", errObj);
      gen.if((0, codegen_1._)`${names_1.default.vErrors} === null`, () => gen.assign(names_1.default.vErrors, (0, codegen_1._)`[${err}]`), (0, codegen_1._)`${names_1.default.vErrors}.push(${err})`);
      gen.code((0, codegen_1._)`${names_1.default.errors}++`);
    }
    function returnErrors(it, errs) {
      const { gen, validateName, schemaEnv } = it;
      if (schemaEnv.$async) {
        gen.throw((0, codegen_1._)`new ${it.ValidationError}(${errs})`);
      } else {
        gen.assign((0, codegen_1._)`${validateName}.errors`, errs);
        gen.return(false);
      }
    }
    var E = {
      keyword: new codegen_1.Name("keyword"),
      schemaPath: new codegen_1.Name("schemaPath"),
      // also used in JTD errors
      params: new codegen_1.Name("params"),
      propertyName: new codegen_1.Name("propertyName"),
      message: new codegen_1.Name("message"),
      schema: new codegen_1.Name("schema"),
      parentSchema: new codegen_1.Name("parentSchema")
    };
    function errorObjectCode(cxt, error3, errorPaths) {
      const { createErrors } = cxt.it;
      if (createErrors === false)
        return (0, codegen_1._)`{}`;
      return errorObject(cxt, error3, errorPaths);
    }
    function errorObject(cxt, error3, errorPaths = {}) {
      const { gen, it } = cxt;
      const keyValues = [
        errorInstancePath(it, errorPaths),
        errorSchemaPath(cxt, errorPaths)
      ];
      extraErrorProps(cxt, error3, keyValues);
      return gen.object(...keyValues);
    }
    function errorInstancePath({ errorPath }, { instancePath }) {
      const instPath = instancePath ? (0, codegen_1.str)`${errorPath}${(0, util_1.getErrorPath)(instancePath, util_1.Type.Str)}` : errorPath;
      return [names_1.default.instancePath, (0, codegen_1.strConcat)(names_1.default.instancePath, instPath)];
    }
    function errorSchemaPath({ keyword, it: { errSchemaPath } }, { schemaPath, parentSchema }) {
      let schPath = parentSchema ? errSchemaPath : (0, codegen_1.str)`${errSchemaPath}/${keyword}`;
      if (schemaPath) {
        schPath = (0, codegen_1.str)`${schPath}${(0, util_1.getErrorPath)(schemaPath, util_1.Type.Str)}`;
      }
      return [E.schemaPath, schPath];
    }
    function extraErrorProps(cxt, { params, message: message2 }, keyValues) {
      const { keyword, data, schemaValue, it } = cxt;
      const { opts, propertyName, topSchemaRef, schemaPath } = it;
      keyValues.push([E.keyword, keyword], [E.params, typeof params == "function" ? params(cxt) : params || (0, codegen_1._)`{}`]);
      if (opts.messages) {
        keyValues.push([E.message, typeof message2 == "function" ? message2(cxt) : message2]);
      }
      if (opts.verbose) {
        keyValues.push([E.schema, schemaValue], [E.parentSchema, (0, codegen_1._)`${topSchemaRef}${schemaPath}`], [names_1.default.data, data]);
      }
      if (propertyName)
        keyValues.push([E.propertyName, propertyName]);
    }
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/boolSchema.js
var require_boolSchema = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/boolSchema.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.boolOrEmptySchema = exports.topBoolOrEmptySchema = void 0;
    var errors_1 = require_errors();
    var codegen_1 = require_codegen();
    var names_1 = require_names();
    var boolError = {
      message: "boolean schema is false"
    };
    function topBoolOrEmptySchema(it) {
      const { gen, schema, validateName } = it;
      if (schema === false) {
        falseSchemaError(it, false);
      } else if (typeof schema == "object" && schema.$async === true) {
        gen.return(names_1.default.data);
      } else {
        gen.assign((0, codegen_1._)`${validateName}.errors`, null);
        gen.return(true);
      }
    }
    exports.topBoolOrEmptySchema = topBoolOrEmptySchema;
    function boolOrEmptySchema(it, valid) {
      const { gen, schema } = it;
      if (schema === false) {
        gen.var(valid, false);
        falseSchemaError(it);
      } else {
        gen.var(valid, true);
      }
    }
    exports.boolOrEmptySchema = boolOrEmptySchema;
    function falseSchemaError(it, overrideAllErrors) {
      const { gen, data } = it;
      const cxt = {
        gen,
        keyword: "false schema",
        data,
        schema: false,
        schemaCode: false,
        schemaValue: false,
        params: {},
        it
      };
      (0, errors_1.reportError)(cxt, boolError, void 0, overrideAllErrors);
    }
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/rules.js
var require_rules = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/rules.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getRules = exports.isJSONType = void 0;
    var _jsonTypes = ["string", "number", "integer", "boolean", "null", "object", "array"];
    var jsonTypes = new Set(_jsonTypes);
    function isJSONType(x) {
      return typeof x == "string" && jsonTypes.has(x);
    }
    exports.isJSONType = isJSONType;
    function getRules() {
      const groups = {
        number: { type: "number", rules: [] },
        string: { type: "string", rules: [] },
        array: { type: "array", rules: [] },
        object: { type: "object", rules: [] }
      };
      return {
        types: { ...groups, integer: true, boolean: true, null: true },
        rules: [{ rules: [] }, groups.number, groups.string, groups.array, groups.object],
        post: { rules: [] },
        all: {},
        keywords: {}
      };
    }
    exports.getRules = getRules;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/applicability.js
var require_applicability = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/applicability.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.shouldUseRule = exports.shouldUseGroup = exports.schemaHasRulesForType = void 0;
    function schemaHasRulesForType({ schema, self }, type) {
      const group = self.RULES.types[type];
      return group && group !== true && shouldUseGroup(schema, group);
    }
    exports.schemaHasRulesForType = schemaHasRulesForType;
    function shouldUseGroup(schema, group) {
      return group.rules.some((rule) => shouldUseRule(schema, rule));
    }
    exports.shouldUseGroup = shouldUseGroup;
    function shouldUseRule(schema, rule) {
      var _a;
      return schema[rule.keyword] !== void 0 || ((_a = rule.definition.implements) === null || _a === void 0 ? void 0 : _a.some((kwd) => schema[kwd] !== void 0));
    }
    exports.shouldUseRule = shouldUseRule;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/dataType.js
var require_dataType = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/dataType.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.reportTypeError = exports.checkDataTypes = exports.checkDataType = exports.coerceAndCheckDataType = exports.getJSONTypes = exports.getSchemaTypes = exports.DataType = void 0;
    var rules_1 = require_rules();
    var applicability_1 = require_applicability();
    var errors_1 = require_errors();
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var DataType;
    (function(DataType2) {
      DataType2[DataType2["Correct"] = 0] = "Correct";
      DataType2[DataType2["Wrong"] = 1] = "Wrong";
    })(DataType || (exports.DataType = DataType = {}));
    function getSchemaTypes(schema) {
      const types = getJSONTypes(schema.type);
      const hasNull = types.includes("null");
      if (hasNull) {
        if (schema.nullable === false)
          throw new Error("type: null contradicts nullable: false");
      } else {
        if (!types.length && schema.nullable !== void 0) {
          throw new Error('"nullable" cannot be used without "type"');
        }
        if (schema.nullable === true)
          types.push("null");
      }
      return types;
    }
    exports.getSchemaTypes = getSchemaTypes;
    function getJSONTypes(ts) {
      const types = Array.isArray(ts) ? ts : ts ? [ts] : [];
      if (types.every(rules_1.isJSONType))
        return types;
      throw new Error("type must be JSONType or JSONType[]: " + types.join(","));
    }
    exports.getJSONTypes = getJSONTypes;
    function coerceAndCheckDataType(it, types) {
      const { gen, data, opts } = it;
      const coerceTo = coerceToTypes(types, opts.coerceTypes);
      const checkTypes = types.length > 0 && !(coerceTo.length === 0 && types.length === 1 && (0, applicability_1.schemaHasRulesForType)(it, types[0]));
      if (checkTypes) {
        const wrongType = checkDataTypes(types, data, opts.strictNumbers, DataType.Wrong);
        gen.if(wrongType, () => {
          if (coerceTo.length)
            coerceData(it, types, coerceTo);
          else
            reportTypeError(it);
        });
      }
      return checkTypes;
    }
    exports.coerceAndCheckDataType = coerceAndCheckDataType;
    var COERCIBLE = /* @__PURE__ */ new Set(["string", "number", "integer", "boolean", "null"]);
    function coerceToTypes(types, coerceTypes) {
      return coerceTypes ? types.filter((t) => COERCIBLE.has(t) || coerceTypes === "array" && t === "array") : [];
    }
    function coerceData(it, types, coerceTo) {
      const { gen, data, opts } = it;
      const dataType = gen.let("dataType", (0, codegen_1._)`typeof ${data}`);
      const coerced = gen.let("coerced", (0, codegen_1._)`undefined`);
      if (opts.coerceTypes === "array") {
        gen.if((0, codegen_1._)`${dataType} == 'object' && Array.isArray(${data}) && ${data}.length == 1`, () => gen.assign(data, (0, codegen_1._)`${data}[0]`).assign(dataType, (0, codegen_1._)`typeof ${data}`).if(checkDataTypes(types, data, opts.strictNumbers), () => gen.assign(coerced, data)));
      }
      gen.if((0, codegen_1._)`${coerced} !== undefined`);
      for (const t of coerceTo) {
        if (COERCIBLE.has(t) || t === "array" && opts.coerceTypes === "array") {
          coerceSpecificType(t);
        }
      }
      gen.else();
      reportTypeError(it);
      gen.endIf();
      gen.if((0, codegen_1._)`${coerced} !== undefined`, () => {
        gen.assign(data, coerced);
        assignParentData(it, coerced);
      });
      function coerceSpecificType(t) {
        switch (t) {
          case "string":
            gen.elseIf((0, codegen_1._)`${dataType} == "number" || ${dataType} == "boolean"`).assign(coerced, (0, codegen_1._)`"" + ${data}`).elseIf((0, codegen_1._)`${data} === null`).assign(coerced, (0, codegen_1._)`""`);
            return;
          case "number":
            gen.elseIf((0, codegen_1._)`${dataType} == "boolean" || ${data} === null
              || (${dataType} == "string" && ${data} && ${data} == +${data})`).assign(coerced, (0, codegen_1._)`+${data}`);
            return;
          case "integer":
            gen.elseIf((0, codegen_1._)`${dataType} === "boolean" || ${data} === null
              || (${dataType} === "string" && ${data} && ${data} == +${data} && !(${data} % 1))`).assign(coerced, (0, codegen_1._)`+${data}`);
            return;
          case "boolean":
            gen.elseIf((0, codegen_1._)`${data} === "false" || ${data} === 0 || ${data} === null`).assign(coerced, false).elseIf((0, codegen_1._)`${data} === "true" || ${data} === 1`).assign(coerced, true);
            return;
          case "null":
            gen.elseIf((0, codegen_1._)`${data} === "" || ${data} === 0 || ${data} === false`);
            gen.assign(coerced, null);
            return;
          case "array":
            gen.elseIf((0, codegen_1._)`${dataType} === "string" || ${dataType} === "number"
              || ${dataType} === "boolean" || ${data} === null`).assign(coerced, (0, codegen_1._)`[${data}]`);
        }
      }
    }
    function assignParentData({ gen, parentData, parentDataProperty }, expr) {
      gen.if((0, codegen_1._)`${parentData} !== undefined`, () => gen.assign((0, codegen_1._)`${parentData}[${parentDataProperty}]`, expr));
    }
    function checkDataType(dataType, data, strictNums, correct = DataType.Correct) {
      const EQ = correct === DataType.Correct ? codegen_1.operators.EQ : codegen_1.operators.NEQ;
      let cond;
      switch (dataType) {
        case "null":
          return (0, codegen_1._)`${data} ${EQ} null`;
        case "array":
          cond = (0, codegen_1._)`Array.isArray(${data})`;
          break;
        case "object":
          cond = (0, codegen_1._)`${data} && typeof ${data} == "object" && !Array.isArray(${data})`;
          break;
        case "integer":
          cond = numCond((0, codegen_1._)`!(${data} % 1) && !isNaN(${data})`);
          break;
        case "number":
          cond = numCond();
          break;
        default:
          return (0, codegen_1._)`typeof ${data} ${EQ} ${dataType}`;
      }
      return correct === DataType.Correct ? cond : (0, codegen_1.not)(cond);
      function numCond(_cond = codegen_1.nil) {
        return (0, codegen_1.and)((0, codegen_1._)`typeof ${data} == "number"`, _cond, strictNums ? (0, codegen_1._)`isFinite(${data})` : codegen_1.nil);
      }
    }
    exports.checkDataType = checkDataType;
    function checkDataTypes(dataTypes, data, strictNums, correct) {
      if (dataTypes.length === 1) {
        return checkDataType(dataTypes[0], data, strictNums, correct);
      }
      let cond;
      const types = (0, util_1.toHash)(dataTypes);
      if (types.array && types.object) {
        const notObj = (0, codegen_1._)`typeof ${data} != "object"`;
        cond = types.null ? notObj : (0, codegen_1._)`!${data} || ${notObj}`;
        delete types.null;
        delete types.array;
        delete types.object;
      } else {
        cond = codegen_1.nil;
      }
      if (types.number)
        delete types.integer;
      for (const t in types)
        cond = (0, codegen_1.and)(cond, checkDataType(t, data, strictNums, correct));
      return cond;
    }
    exports.checkDataTypes = checkDataTypes;
    var typeError = {
      message: ({ schema }) => `must be ${schema}`,
      params: ({ schema, schemaValue }) => typeof schema == "string" ? (0, codegen_1._)`{type: ${schema}}` : (0, codegen_1._)`{type: ${schemaValue}}`
    };
    function reportTypeError(it) {
      const cxt = getTypeErrorContext(it);
      (0, errors_1.reportError)(cxt, typeError);
    }
    exports.reportTypeError = reportTypeError;
    function getTypeErrorContext(it) {
      const { gen, data, schema } = it;
      const schemaCode = (0, util_1.schemaRefOrVal)(it, schema, "type");
      return {
        gen,
        keyword: "type",
        data,
        schema: schema.type,
        schemaCode,
        schemaValue: schemaCode,
        parentSchema: schema,
        params: {},
        it
      };
    }
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/defaults.js
var require_defaults = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/defaults.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.assignDefaults = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    function assignDefaults(it, ty) {
      const { properties, items } = it.schema;
      if (ty === "object" && properties) {
        for (const key in properties) {
          assignDefault(it, key, properties[key].default);
        }
      } else if (ty === "array" && Array.isArray(items)) {
        items.forEach((sch, i) => assignDefault(it, i, sch.default));
      }
    }
    exports.assignDefaults = assignDefaults;
    function assignDefault(it, prop, defaultValue) {
      const { gen, compositeRule, data, opts } = it;
      if (defaultValue === void 0)
        return;
      const childData = (0, codegen_1._)`${data}${(0, codegen_1.getProperty)(prop)}`;
      if (compositeRule) {
        (0, util_1.checkStrictMode)(it, `default is ignored for: ${childData}`);
        return;
      }
      let condition = (0, codegen_1._)`${childData} === undefined`;
      if (opts.useDefaults === "empty") {
        condition = (0, codegen_1._)`${condition} || ${childData} === null || ${childData} === ""`;
      }
      gen.if(condition, (0, codegen_1._)`${childData} = ${(0, codegen_1.stringify)(defaultValue)}`);
    }
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/code.js
var require_code2 = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/code.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateUnion = exports.validateArray = exports.usePattern = exports.callValidateCode = exports.schemaProperties = exports.allSchemaProperties = exports.noPropertyInData = exports.propertyInData = exports.isOwnProperty = exports.hasPropFunc = exports.reportMissingProp = exports.checkMissingProp = exports.checkReportMissingProp = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var names_1 = require_names();
    var util_2 = require_util();
    function checkReportMissingProp(cxt, prop) {
      const { gen, data, it } = cxt;
      gen.if(noPropertyInData(gen, data, prop, it.opts.ownProperties), () => {
        cxt.setParams({ missingProperty: (0, codegen_1._)`${prop}` }, true);
        cxt.error();
      });
    }
    exports.checkReportMissingProp = checkReportMissingProp;
    function checkMissingProp({ gen, data, it: { opts } }, properties, missing) {
      return (0, codegen_1.or)(...properties.map((prop) => (0, codegen_1.and)(noPropertyInData(gen, data, prop, opts.ownProperties), (0, codegen_1._)`${missing} = ${prop}`)));
    }
    exports.checkMissingProp = checkMissingProp;
    function reportMissingProp(cxt, missing) {
      cxt.setParams({ missingProperty: missing }, true);
      cxt.error();
    }
    exports.reportMissingProp = reportMissingProp;
    function hasPropFunc(gen) {
      return gen.scopeValue("func", {
        // eslint-disable-next-line @typescript-eslint/unbound-method
        ref: Object.prototype.hasOwnProperty,
        code: (0, codegen_1._)`Object.prototype.hasOwnProperty`
      });
    }
    exports.hasPropFunc = hasPropFunc;
    function isOwnProperty(gen, data, property) {
      return (0, codegen_1._)`${hasPropFunc(gen)}.call(${data}, ${property})`;
    }
    exports.isOwnProperty = isOwnProperty;
    function propertyInData(gen, data, property, ownProperties) {
      const cond = (0, codegen_1._)`${data}${(0, codegen_1.getProperty)(property)} !== undefined`;
      return ownProperties ? (0, codegen_1._)`${cond} && ${isOwnProperty(gen, data, property)}` : cond;
    }
    exports.propertyInData = propertyInData;
    function noPropertyInData(gen, data, property, ownProperties) {
      const cond = (0, codegen_1._)`${data}${(0, codegen_1.getProperty)(property)} === undefined`;
      return ownProperties ? (0, codegen_1.or)(cond, (0, codegen_1.not)(isOwnProperty(gen, data, property))) : cond;
    }
    exports.noPropertyInData = noPropertyInData;
    function allSchemaProperties(schemaMap) {
      return schemaMap ? Object.keys(schemaMap).filter((p) => p !== "__proto__") : [];
    }
    exports.allSchemaProperties = allSchemaProperties;
    function schemaProperties(it, schemaMap) {
      return allSchemaProperties(schemaMap).filter((p) => !(0, util_1.alwaysValidSchema)(it, schemaMap[p]));
    }
    exports.schemaProperties = schemaProperties;
    function callValidateCode({ schemaCode, data, it: { gen, topSchemaRef, schemaPath, errorPath }, it }, func, context, passSchema) {
      const dataAndSchema = passSchema ? (0, codegen_1._)`${schemaCode}, ${data}, ${topSchemaRef}${schemaPath}` : data;
      const valCxt = [
        [names_1.default.instancePath, (0, codegen_1.strConcat)(names_1.default.instancePath, errorPath)],
        [names_1.default.parentData, it.parentData],
        [names_1.default.parentDataProperty, it.parentDataProperty],
        [names_1.default.rootData, names_1.default.rootData]
      ];
      if (it.opts.dynamicRef)
        valCxt.push([names_1.default.dynamicAnchors, names_1.default.dynamicAnchors]);
      const args = (0, codegen_1._)`${dataAndSchema}, ${gen.object(...valCxt)}`;
      return context !== codegen_1.nil ? (0, codegen_1._)`${func}.call(${context}, ${args})` : (0, codegen_1._)`${func}(${args})`;
    }
    exports.callValidateCode = callValidateCode;
    var newRegExp = (0, codegen_1._)`new RegExp`;
    function usePattern({ gen, it: { opts } }, pattern) {
      const u = opts.unicodeRegExp ? "u" : "";
      const { regExp } = opts.code;
      const rx = regExp(pattern, u);
      return gen.scopeValue("pattern", {
        key: rx.toString(),
        ref: rx,
        code: (0, codegen_1._)`${regExp.code === "new RegExp" ? newRegExp : (0, util_2.useFunc)(gen, regExp)}(${pattern}, ${u})`
      });
    }
    exports.usePattern = usePattern;
    function validateArray(cxt) {
      const { gen, data, keyword, it } = cxt;
      const valid = gen.name("valid");
      if (it.allErrors) {
        const validArr = gen.let("valid", true);
        validateItems(() => gen.assign(validArr, false));
        return validArr;
      }
      gen.var(valid, true);
      validateItems(() => gen.break());
      return valid;
      function validateItems(notValid) {
        const len = gen.const("len", (0, codegen_1._)`${data}.length`);
        gen.forRange("i", 0, len, (i) => {
          cxt.subschema({
            keyword,
            dataProp: i,
            dataPropType: util_1.Type.Num
          }, valid);
          gen.if((0, codegen_1.not)(valid), notValid);
        });
      }
    }
    exports.validateArray = validateArray;
    function validateUnion(cxt) {
      const { gen, schema, keyword, it } = cxt;
      if (!Array.isArray(schema))
        throw new Error("ajv implementation error");
      const alwaysValid = schema.some((sch) => (0, util_1.alwaysValidSchema)(it, sch));
      if (alwaysValid && !it.opts.unevaluated)
        return;
      const valid = gen.let("valid", false);
      const schValid = gen.name("_valid");
      gen.block(() => schema.forEach((_sch, i) => {
        const schCxt = cxt.subschema({
          keyword,
          schemaProp: i,
          compositeRule: true
        }, schValid);
        gen.assign(valid, (0, codegen_1._)`${valid} || ${schValid}`);
        const merged = cxt.mergeValidEvaluated(schCxt, schValid);
        if (!merged)
          gen.if((0, codegen_1.not)(valid));
      }));
      cxt.result(valid, () => cxt.reset(), () => cxt.error(true));
    }
    exports.validateUnion = validateUnion;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/keyword.js
var require_keyword = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/keyword.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateKeywordUsage = exports.validSchemaType = exports.funcKeywordCode = exports.macroKeywordCode = void 0;
    var codegen_1 = require_codegen();
    var names_1 = require_names();
    var code_1 = require_code2();
    var errors_1 = require_errors();
    function macroKeywordCode(cxt, def) {
      const { gen, keyword, schema, parentSchema, it } = cxt;
      const macroSchema = def.macro.call(it.self, schema, parentSchema, it);
      const schemaRef = useKeyword(gen, keyword, macroSchema);
      if (it.opts.validateSchema !== false)
        it.self.validateSchema(macroSchema, true);
      const valid = gen.name("valid");
      cxt.subschema({
        schema: macroSchema,
        schemaPath: codegen_1.nil,
        errSchemaPath: `${it.errSchemaPath}/${keyword}`,
        topSchemaRef: schemaRef,
        compositeRule: true
      }, valid);
      cxt.pass(valid, () => cxt.error(true));
    }
    exports.macroKeywordCode = macroKeywordCode;
    function funcKeywordCode(cxt, def) {
      var _a;
      const { gen, keyword, schema, parentSchema, $data, it } = cxt;
      checkAsyncKeyword(it, def);
      const validate = !$data && def.compile ? def.compile.call(it.self, schema, parentSchema, it) : def.validate;
      const validateRef = useKeyword(gen, keyword, validate);
      const valid = gen.let("valid");
      cxt.block$data(valid, validateKeyword);
      cxt.ok((_a = def.valid) !== null && _a !== void 0 ? _a : valid);
      function validateKeyword() {
        if (def.errors === false) {
          assignValid();
          if (def.modifying)
            modifyData(cxt);
          reportErrs(() => cxt.error());
        } else {
          const ruleErrs = def.async ? validateAsync() : validateSync();
          if (def.modifying)
            modifyData(cxt);
          reportErrs(() => addErrs(cxt, ruleErrs));
        }
      }
      function validateAsync() {
        const ruleErrs = gen.let("ruleErrs", null);
        gen.try(() => assignValid((0, codegen_1._)`await `), (e) => gen.assign(valid, false).if((0, codegen_1._)`${e} instanceof ${it.ValidationError}`, () => gen.assign(ruleErrs, (0, codegen_1._)`${e}.errors`), () => gen.throw(e)));
        return ruleErrs;
      }
      function validateSync() {
        const validateErrs = (0, codegen_1._)`${validateRef}.errors`;
        gen.assign(validateErrs, null);
        assignValid(codegen_1.nil);
        return validateErrs;
      }
      function assignValid(_await = def.async ? (0, codegen_1._)`await ` : codegen_1.nil) {
        const passCxt = it.opts.passContext ? names_1.default.this : names_1.default.self;
        const passSchema = !("compile" in def && !$data || def.schema === false);
        gen.assign(valid, (0, codegen_1._)`${_await}${(0, code_1.callValidateCode)(cxt, validateRef, passCxt, passSchema)}`, def.modifying);
      }
      function reportErrs(errors) {
        var _a2;
        gen.if((0, codegen_1.not)((_a2 = def.valid) !== null && _a2 !== void 0 ? _a2 : valid), errors);
      }
    }
    exports.funcKeywordCode = funcKeywordCode;
    function modifyData(cxt) {
      const { gen, data, it } = cxt;
      gen.if(it.parentData, () => gen.assign(data, (0, codegen_1._)`${it.parentData}[${it.parentDataProperty}]`));
    }
    function addErrs(cxt, errs) {
      const { gen } = cxt;
      gen.if((0, codegen_1._)`Array.isArray(${errs})`, () => {
        gen.assign(names_1.default.vErrors, (0, codegen_1._)`${names_1.default.vErrors} === null ? ${errs} : ${names_1.default.vErrors}.concat(${errs})`).assign(names_1.default.errors, (0, codegen_1._)`${names_1.default.vErrors}.length`);
        (0, errors_1.extendErrors)(cxt);
      }, () => cxt.error());
    }
    function checkAsyncKeyword({ schemaEnv }, def) {
      if (def.async && !schemaEnv.$async)
        throw new Error("async keyword in sync schema");
    }
    function useKeyword(gen, keyword, result) {
      if (result === void 0)
        throw new Error(`keyword "${keyword}" failed to compile`);
      return gen.scopeValue("keyword", typeof result == "function" ? { ref: result } : { ref: result, code: (0, codegen_1.stringify)(result) });
    }
    function validSchemaType(schema, schemaType, allowUndefined = false) {
      return !schemaType.length || schemaType.some((st) => st === "array" ? Array.isArray(schema) : st === "object" ? schema && typeof schema == "object" && !Array.isArray(schema) : typeof schema == st || allowUndefined && typeof schema == "undefined");
    }
    exports.validSchemaType = validSchemaType;
    function validateKeywordUsage({ schema, opts, self, errSchemaPath }, def, keyword) {
      if (Array.isArray(def.keyword) ? !def.keyword.includes(keyword) : def.keyword !== keyword) {
        throw new Error("ajv implementation error");
      }
      const deps = def.dependencies;
      if (deps === null || deps === void 0 ? void 0 : deps.some((kwd) => !Object.prototype.hasOwnProperty.call(schema, kwd))) {
        throw new Error(`parent schema must have dependencies of ${keyword}: ${deps.join(",")}`);
      }
      if (def.validateSchema) {
        const valid = def.validateSchema(schema[keyword]);
        if (!valid) {
          const msg = `keyword "${keyword}" value is invalid at path "${errSchemaPath}": ` + self.errorsText(def.validateSchema.errors);
          if (opts.validateSchema === "log")
            self.logger.error(msg);
          else
            throw new Error(msg);
        }
      }
    }
    exports.validateKeywordUsage = validateKeywordUsage;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/subschema.js
var require_subschema = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/subschema.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.extendSubschemaMode = exports.extendSubschemaData = exports.getSubschema = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    function getSubschema(it, { keyword, schemaProp, schema, schemaPath, errSchemaPath, topSchemaRef }) {
      if (keyword !== void 0 && schema !== void 0) {
        throw new Error('both "keyword" and "schema" passed, only one allowed');
      }
      if (keyword !== void 0) {
        const sch = it.schema[keyword];
        return schemaProp === void 0 ? {
          schema: sch,
          schemaPath: (0, codegen_1._)`${it.schemaPath}${(0, codegen_1.getProperty)(keyword)}`,
          errSchemaPath: `${it.errSchemaPath}/${keyword}`
        } : {
          schema: sch[schemaProp],
          schemaPath: (0, codegen_1._)`${it.schemaPath}${(0, codegen_1.getProperty)(keyword)}${(0, codegen_1.getProperty)(schemaProp)}`,
          errSchemaPath: `${it.errSchemaPath}/${keyword}/${(0, util_1.escapeFragment)(schemaProp)}`
        };
      }
      if (schema !== void 0) {
        if (schemaPath === void 0 || errSchemaPath === void 0 || topSchemaRef === void 0) {
          throw new Error('"schemaPath", "errSchemaPath" and "topSchemaRef" are required with "schema"');
        }
        return {
          schema,
          schemaPath,
          topSchemaRef,
          errSchemaPath
        };
      }
      throw new Error('either "keyword" or "schema" must be passed');
    }
    exports.getSubschema = getSubschema;
    function extendSubschemaData(subschema, it, { dataProp, dataPropType: dpType, data, dataTypes, propertyName }) {
      if (data !== void 0 && dataProp !== void 0) {
        throw new Error('both "data" and "dataProp" passed, only one allowed');
      }
      const { gen } = it;
      if (dataProp !== void 0) {
        const { errorPath, dataPathArr, opts } = it;
        const nextData = gen.let("data", (0, codegen_1._)`${it.data}${(0, codegen_1.getProperty)(dataProp)}`, true);
        dataContextProps(nextData);
        subschema.errorPath = (0, codegen_1.str)`${errorPath}${(0, util_1.getErrorPath)(dataProp, dpType, opts.jsPropertySyntax)}`;
        subschema.parentDataProperty = (0, codegen_1._)`${dataProp}`;
        subschema.dataPathArr = [...dataPathArr, subschema.parentDataProperty];
      }
      if (data !== void 0) {
        const nextData = data instanceof codegen_1.Name ? data : gen.let("data", data, true);
        dataContextProps(nextData);
        if (propertyName !== void 0)
          subschema.propertyName = propertyName;
      }
      if (dataTypes)
        subschema.dataTypes = dataTypes;
      function dataContextProps(_nextData) {
        subschema.data = _nextData;
        subschema.dataLevel = it.dataLevel + 1;
        subschema.dataTypes = [];
        it.definedProperties = /* @__PURE__ */ new Set();
        subschema.parentData = it.data;
        subschema.dataNames = [...it.dataNames, _nextData];
      }
    }
    exports.extendSubschemaData = extendSubschemaData;
    function extendSubschemaMode(subschema, { jtdDiscriminator, jtdMetadata, compositeRule, createErrors, allErrors }) {
      if (compositeRule !== void 0)
        subschema.compositeRule = compositeRule;
      if (createErrors !== void 0)
        subschema.createErrors = createErrors;
      if (allErrors !== void 0)
        subschema.allErrors = allErrors;
      subschema.jtdDiscriminator = jtdDiscriminator;
      subschema.jtdMetadata = jtdMetadata;
    }
    exports.extendSubschemaMode = extendSubschemaMode;
  }
});

// node_modules/.pnpm/fast-deep-equal@3.1.3/node_modules/fast-deep-equal/index.js
var require_fast_deep_equal = __commonJS({
  "node_modules/.pnpm/fast-deep-equal@3.1.3/node_modules/fast-deep-equal/index.js"(exports, module) {
    "use strict";
    module.exports = function equal(a, b) {
      if (a === b) return true;
      if (a && b && typeof a == "object" && typeof b == "object") {
        if (a.constructor !== b.constructor) return false;
        var length, i, keys;
        if (Array.isArray(a)) {
          length = a.length;
          if (length != b.length) return false;
          for (i = length; i-- !== 0; )
            if (!equal(a[i], b[i])) return false;
          return true;
        }
        if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
        if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
        if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
        keys = Object.keys(a);
        length = keys.length;
        if (length !== Object.keys(b).length) return false;
        for (i = length; i-- !== 0; )
          if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
        for (i = length; i-- !== 0; ) {
          var key = keys[i];
          if (!equal(a[key], b[key])) return false;
        }
        return true;
      }
      return a !== a && b !== b;
    };
  }
});

// node_modules/.pnpm/json-schema-traverse@1.0.0/node_modules/json-schema-traverse/index.js
var require_json_schema_traverse = __commonJS({
  "node_modules/.pnpm/json-schema-traverse@1.0.0/node_modules/json-schema-traverse/index.js"(exports, module) {
    "use strict";
    var traverse = module.exports = function(schema, opts, cb) {
      if (typeof opts == "function") {
        cb = opts;
        opts = {};
      }
      cb = opts.cb || cb;
      var pre = typeof cb == "function" ? cb : cb.pre || function() {
      };
      var post = cb.post || function() {
      };
      _traverse(opts, pre, post, schema, "", schema);
    };
    traverse.keywords = {
      additionalItems: true,
      items: true,
      contains: true,
      additionalProperties: true,
      propertyNames: true,
      not: true,
      if: true,
      then: true,
      else: true
    };
    traverse.arrayKeywords = {
      items: true,
      allOf: true,
      anyOf: true,
      oneOf: true
    };
    traverse.propsKeywords = {
      $defs: true,
      definitions: true,
      properties: true,
      patternProperties: true,
      dependencies: true
    };
    traverse.skipKeywords = {
      default: true,
      enum: true,
      const: true,
      required: true,
      maximum: true,
      minimum: true,
      exclusiveMaximum: true,
      exclusiveMinimum: true,
      multipleOf: true,
      maxLength: true,
      minLength: true,
      pattern: true,
      format: true,
      maxItems: true,
      minItems: true,
      uniqueItems: true,
      maxProperties: true,
      minProperties: true
    };
    function _traverse(opts, pre, post, schema, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex) {
      if (schema && typeof schema == "object" && !Array.isArray(schema)) {
        pre(schema, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex);
        for (var key in schema) {
          var sch = schema[key];
          if (Array.isArray(sch)) {
            if (key in traverse.arrayKeywords) {
              for (var i = 0; i < sch.length; i++)
                _traverse(opts, pre, post, sch[i], jsonPtr + "/" + key + "/" + i, rootSchema, jsonPtr, key, schema, i);
            }
          } else if (key in traverse.propsKeywords) {
            if (sch && typeof sch == "object") {
              for (var prop in sch)
                _traverse(opts, pre, post, sch[prop], jsonPtr + "/" + key + "/" + escapeJsonPtr(prop), rootSchema, jsonPtr, key, schema, prop);
            }
          } else if (key in traverse.keywords || opts.allKeys && !(key in traverse.skipKeywords)) {
            _traverse(opts, pre, post, sch, jsonPtr + "/" + key, rootSchema, jsonPtr, key, schema);
          }
        }
        post(schema, jsonPtr, rootSchema, parentJsonPtr, parentKeyword, parentSchema, keyIndex);
      }
    }
    function escapeJsonPtr(str) {
      return str.replace(/~/g, "~0").replace(/\//g, "~1");
    }
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/resolve.js
var require_resolve = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/resolve.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getSchemaRefs = exports.resolveUrl = exports.normalizeId = exports._getFullPath = exports.getFullPath = exports.inlineRef = void 0;
    var util_1 = require_util();
    var equal = require_fast_deep_equal();
    var traverse = require_json_schema_traverse();
    var SIMPLE_INLINED = /* @__PURE__ */ new Set([
      "type",
      "format",
      "pattern",
      "maxLength",
      "minLength",
      "maxProperties",
      "minProperties",
      "maxItems",
      "minItems",
      "maximum",
      "minimum",
      "uniqueItems",
      "multipleOf",
      "required",
      "enum",
      "const"
    ]);
    function inlineRef(schema, limit = true) {
      if (typeof schema == "boolean")
        return true;
      if (limit === true)
        return !hasRef(schema);
      if (!limit)
        return false;
      return countKeys(schema) <= limit;
    }
    exports.inlineRef = inlineRef;
    var REF_KEYWORDS = /* @__PURE__ */ new Set([
      "$ref",
      "$recursiveRef",
      "$recursiveAnchor",
      "$dynamicRef",
      "$dynamicAnchor"
    ]);
    function hasRef(schema) {
      for (const key in schema) {
        if (REF_KEYWORDS.has(key))
          return true;
        const sch = schema[key];
        if (Array.isArray(sch) && sch.some(hasRef))
          return true;
        if (typeof sch == "object" && hasRef(sch))
          return true;
      }
      return false;
    }
    function countKeys(schema) {
      let count = 0;
      for (const key in schema) {
        if (key === "$ref")
          return Infinity;
        count++;
        if (SIMPLE_INLINED.has(key))
          continue;
        if (typeof schema[key] == "object") {
          (0, util_1.eachItem)(schema[key], (sch) => count += countKeys(sch));
        }
        if (count === Infinity)
          return Infinity;
      }
      return count;
    }
    function getFullPath(resolver, id3 = "", normalize) {
      if (normalize !== false)
        id3 = normalizeId(id3);
      const p = resolver.parse(id3);
      return _getFullPath(resolver, p);
    }
    exports.getFullPath = getFullPath;
    function _getFullPath(resolver, p) {
      const serialized = resolver.serialize(p);
      return serialized.split("#")[0] + "#";
    }
    exports._getFullPath = _getFullPath;
    var TRAILING_SLASH_HASH = /#\/?$/;
    function normalizeId(id3) {
      return id3 ? id3.replace(TRAILING_SLASH_HASH, "") : "";
    }
    exports.normalizeId = normalizeId;
    function resolveUrl(resolver, baseId, id3) {
      id3 = normalizeId(id3);
      return resolver.resolve(baseId, id3);
    }
    exports.resolveUrl = resolveUrl;
    var ANCHOR = /^[a-z_][-a-z0-9._]*$/i;
    function getSchemaRefs(schema, baseId) {
      if (typeof schema == "boolean")
        return {};
      const { schemaId, uriResolver } = this.opts;
      const schId = normalizeId(schema[schemaId] || baseId);
      const baseIds = { "": schId };
      const pathPrefix = getFullPath(uriResolver, schId, false);
      const localRefs = {};
      const schemaRefs = /* @__PURE__ */ new Set();
      traverse(schema, { allKeys: true }, (sch, jsonPtr, _, parentJsonPtr) => {
        if (parentJsonPtr === void 0)
          return;
        const fullPath = pathPrefix + jsonPtr;
        let innerBaseId = baseIds[parentJsonPtr];
        if (typeof sch[schemaId] == "string")
          innerBaseId = addRef.call(this, sch[schemaId]);
        addAnchor.call(this, sch.$anchor);
        addAnchor.call(this, sch.$dynamicAnchor);
        baseIds[jsonPtr] = innerBaseId;
        function addRef(ref) {
          const _resolve = this.opts.uriResolver.resolve;
          ref = normalizeId(innerBaseId ? _resolve(innerBaseId, ref) : ref);
          if (schemaRefs.has(ref))
            throw ambiguos(ref);
          schemaRefs.add(ref);
          let schOrRef = this.refs[ref];
          if (typeof schOrRef == "string")
            schOrRef = this.refs[schOrRef];
          if (typeof schOrRef == "object") {
            checkAmbiguosRef(sch, schOrRef.schema, ref);
          } else if (ref !== normalizeId(fullPath)) {
            if (ref[0] === "#") {
              checkAmbiguosRef(sch, localRefs[ref], ref);
              localRefs[ref] = sch;
            } else {
              this.refs[ref] = fullPath;
            }
          }
          return ref;
        }
        function addAnchor(anchor) {
          if (typeof anchor == "string") {
            if (!ANCHOR.test(anchor))
              throw new Error(`invalid anchor "${anchor}"`);
            addRef.call(this, `#${anchor}`);
          }
        }
      });
      return localRefs;
      function checkAmbiguosRef(sch1, sch2, ref) {
        if (sch2 !== void 0 && !equal(sch1, sch2))
          throw ambiguos(ref);
      }
      function ambiguos(ref) {
        return new Error(`reference "${ref}" resolves to more than one schema`);
      }
    }
    exports.getSchemaRefs = getSchemaRefs;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/index.js
var require_validate = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/validate/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.getData = exports.KeywordCxt = exports.validateFunctionCode = void 0;
    var boolSchema_1 = require_boolSchema();
    var dataType_1 = require_dataType();
    var applicability_1 = require_applicability();
    var dataType_2 = require_dataType();
    var defaults_1 = require_defaults();
    var keyword_1 = require_keyword();
    var subschema_1 = require_subschema();
    var codegen_1 = require_codegen();
    var names_1 = require_names();
    var resolve_1 = require_resolve();
    var util_1 = require_util();
    var errors_1 = require_errors();
    function validateFunctionCode(it) {
      if (isSchemaObj(it)) {
        checkKeywords(it);
        if (schemaCxtHasRules(it)) {
          topSchemaObjCode(it);
          return;
        }
      }
      validateFunction(it, () => (0, boolSchema_1.topBoolOrEmptySchema)(it));
    }
    exports.validateFunctionCode = validateFunctionCode;
    function validateFunction({ gen, validateName, schema, schemaEnv, opts }, body2) {
      if (opts.code.es5) {
        gen.func(validateName, (0, codegen_1._)`${names_1.default.data}, ${names_1.default.valCxt}`, schemaEnv.$async, () => {
          gen.code((0, codegen_1._)`"use strict"; ${funcSourceUrl(schema, opts)}`);
          destructureValCxtES5(gen, opts);
          gen.code(body2);
        });
      } else {
        gen.func(validateName, (0, codegen_1._)`${names_1.default.data}, ${destructureValCxt(opts)}`, schemaEnv.$async, () => gen.code(funcSourceUrl(schema, opts)).code(body2));
      }
    }
    function destructureValCxt(opts) {
      return (0, codegen_1._)`{${names_1.default.instancePath}="", ${names_1.default.parentData}, ${names_1.default.parentDataProperty}, ${names_1.default.rootData}=${names_1.default.data}${opts.dynamicRef ? (0, codegen_1._)`, ${names_1.default.dynamicAnchors}={}` : codegen_1.nil}}={}`;
    }
    function destructureValCxtES5(gen, opts) {
      gen.if(names_1.default.valCxt, () => {
        gen.var(names_1.default.instancePath, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.instancePath}`);
        gen.var(names_1.default.parentData, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.parentData}`);
        gen.var(names_1.default.parentDataProperty, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.parentDataProperty}`);
        gen.var(names_1.default.rootData, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.rootData}`);
        if (opts.dynamicRef)
          gen.var(names_1.default.dynamicAnchors, (0, codegen_1._)`${names_1.default.valCxt}.${names_1.default.dynamicAnchors}`);
      }, () => {
        gen.var(names_1.default.instancePath, (0, codegen_1._)`""`);
        gen.var(names_1.default.parentData, (0, codegen_1._)`undefined`);
        gen.var(names_1.default.parentDataProperty, (0, codegen_1._)`undefined`);
        gen.var(names_1.default.rootData, names_1.default.data);
        if (opts.dynamicRef)
          gen.var(names_1.default.dynamicAnchors, (0, codegen_1._)`{}`);
      });
    }
    function topSchemaObjCode(it) {
      const { schema, opts, gen } = it;
      validateFunction(it, () => {
        if (opts.$comment && schema.$comment)
          commentKeyword(it);
        checkNoDefault(it);
        gen.let(names_1.default.vErrors, null);
        gen.let(names_1.default.errors, 0);
        if (opts.unevaluated)
          resetEvaluated(it);
        typeAndKeywords(it);
        returnResults(it);
      });
      return;
    }
    function resetEvaluated(it) {
      const { gen, validateName } = it;
      it.evaluated = gen.const("evaluated", (0, codegen_1._)`${validateName}.evaluated`);
      gen.if((0, codegen_1._)`${it.evaluated}.dynamicProps`, () => gen.assign((0, codegen_1._)`${it.evaluated}.props`, (0, codegen_1._)`undefined`));
      gen.if((0, codegen_1._)`${it.evaluated}.dynamicItems`, () => gen.assign((0, codegen_1._)`${it.evaluated}.items`, (0, codegen_1._)`undefined`));
    }
    function funcSourceUrl(schema, opts) {
      const schId = typeof schema == "object" && schema[opts.schemaId];
      return schId && (opts.code.source || opts.code.process) ? (0, codegen_1._)`/*# sourceURL=${schId} */` : codegen_1.nil;
    }
    function subschemaCode(it, valid) {
      if (isSchemaObj(it)) {
        checkKeywords(it);
        if (schemaCxtHasRules(it)) {
          subSchemaObjCode(it, valid);
          return;
        }
      }
      (0, boolSchema_1.boolOrEmptySchema)(it, valid);
    }
    function schemaCxtHasRules({ schema, self }) {
      if (typeof schema == "boolean")
        return !schema;
      for (const key in schema)
        if (self.RULES.all[key])
          return true;
      return false;
    }
    function isSchemaObj(it) {
      return typeof it.schema != "boolean";
    }
    function subSchemaObjCode(it, valid) {
      const { schema, gen, opts } = it;
      if (opts.$comment && schema.$comment)
        commentKeyword(it);
      updateContext(it);
      checkAsyncSchema(it);
      const errsCount = gen.const("_errs", names_1.default.errors);
      typeAndKeywords(it, errsCount);
      gen.var(valid, (0, codegen_1._)`${errsCount} === ${names_1.default.errors}`);
    }
    function checkKeywords(it) {
      (0, util_1.checkUnknownRules)(it);
      checkRefsAndKeywords(it);
    }
    function typeAndKeywords(it, errsCount) {
      if (it.opts.jtd)
        return schemaKeywords(it, [], false, errsCount);
      const types = (0, dataType_1.getSchemaTypes)(it.schema);
      const checkedTypes = (0, dataType_1.coerceAndCheckDataType)(it, types);
      schemaKeywords(it, types, !checkedTypes, errsCount);
    }
    function checkRefsAndKeywords(it) {
      const { schema, errSchemaPath, opts, self } = it;
      if (schema.$ref && opts.ignoreKeywordsWithRef && (0, util_1.schemaHasRulesButRef)(schema, self.RULES)) {
        self.logger.warn(`$ref: keywords ignored in schema at path "${errSchemaPath}"`);
      }
    }
    function checkNoDefault(it) {
      const { schema, opts } = it;
      if (schema.default !== void 0 && opts.useDefaults && opts.strictSchema) {
        (0, util_1.checkStrictMode)(it, "default is ignored in the schema root");
      }
    }
    function updateContext(it) {
      const schId = it.schema[it.opts.schemaId];
      if (schId)
        it.baseId = (0, resolve_1.resolveUrl)(it.opts.uriResolver, it.baseId, schId);
    }
    function checkAsyncSchema(it) {
      if (it.schema.$async && !it.schemaEnv.$async)
        throw new Error("async schema in sync schema");
    }
    function commentKeyword({ gen, schemaEnv, schema, errSchemaPath, opts }) {
      const msg = schema.$comment;
      if (opts.$comment === true) {
        gen.code((0, codegen_1._)`${names_1.default.self}.logger.log(${msg})`);
      } else if (typeof opts.$comment == "function") {
        const schemaPath = (0, codegen_1.str)`${errSchemaPath}/$comment`;
        const rootName = gen.scopeValue("root", { ref: schemaEnv.root });
        gen.code((0, codegen_1._)`${names_1.default.self}.opts.$comment(${msg}, ${schemaPath}, ${rootName}.schema)`);
      }
    }
    function returnResults(it) {
      const { gen, schemaEnv, validateName, ValidationError, opts } = it;
      if (schemaEnv.$async) {
        gen.if((0, codegen_1._)`${names_1.default.errors} === 0`, () => gen.return(names_1.default.data), () => gen.throw((0, codegen_1._)`new ${ValidationError}(${names_1.default.vErrors})`));
      } else {
        gen.assign((0, codegen_1._)`${validateName}.errors`, names_1.default.vErrors);
        if (opts.unevaluated)
          assignEvaluated(it);
        gen.return((0, codegen_1._)`${names_1.default.errors} === 0`);
      }
    }
    function assignEvaluated({ gen, evaluated, props, items }) {
      if (props instanceof codegen_1.Name)
        gen.assign((0, codegen_1._)`${evaluated}.props`, props);
      if (items instanceof codegen_1.Name)
        gen.assign((0, codegen_1._)`${evaluated}.items`, items);
    }
    function schemaKeywords(it, types, typeErrors, errsCount) {
      const { gen, schema, data, allErrors, opts, self } = it;
      const { RULES } = self;
      if (schema.$ref && (opts.ignoreKeywordsWithRef || !(0, util_1.schemaHasRulesButRef)(schema, RULES))) {
        gen.block(() => keywordCode(it, "$ref", RULES.all.$ref.definition));
        return;
      }
      if (!opts.jtd)
        checkStrictTypes(it, types);
      gen.block(() => {
        for (const group of RULES.rules)
          groupKeywords(group);
        groupKeywords(RULES.post);
      });
      function groupKeywords(group) {
        if (!(0, applicability_1.shouldUseGroup)(schema, group))
          return;
        if (group.type) {
          gen.if((0, dataType_2.checkDataType)(group.type, data, opts.strictNumbers));
          iterateKeywords(it, group);
          if (types.length === 1 && types[0] === group.type && typeErrors) {
            gen.else();
            (0, dataType_2.reportTypeError)(it);
          }
          gen.endIf();
        } else {
          iterateKeywords(it, group);
        }
        if (!allErrors)
          gen.if((0, codegen_1._)`${names_1.default.errors} === ${errsCount || 0}`);
      }
    }
    function iterateKeywords(it, group) {
      const { gen, schema, opts: { useDefaults } } = it;
      if (useDefaults)
        (0, defaults_1.assignDefaults)(it, group.type);
      gen.block(() => {
        for (const rule of group.rules) {
          if ((0, applicability_1.shouldUseRule)(schema, rule)) {
            keywordCode(it, rule.keyword, rule.definition, group.type);
          }
        }
      });
    }
    function checkStrictTypes(it, types) {
      if (it.schemaEnv.meta || !it.opts.strictTypes)
        return;
      checkContextTypes(it, types);
      if (!it.opts.allowUnionTypes)
        checkMultipleTypes(it, types);
      checkKeywordTypes(it, it.dataTypes);
    }
    function checkContextTypes(it, types) {
      if (!types.length)
        return;
      if (!it.dataTypes.length) {
        it.dataTypes = types;
        return;
      }
      types.forEach((t) => {
        if (!includesType(it.dataTypes, t)) {
          strictTypesError(it, `type "${t}" not allowed by context "${it.dataTypes.join(",")}"`);
        }
      });
      narrowSchemaTypes(it, types);
    }
    function checkMultipleTypes(it, ts) {
      if (ts.length > 1 && !(ts.length === 2 && ts.includes("null"))) {
        strictTypesError(it, "use allowUnionTypes to allow union type keyword");
      }
    }
    function checkKeywordTypes(it, ts) {
      const rules = it.self.RULES.all;
      for (const keyword in rules) {
        const rule = rules[keyword];
        if (typeof rule == "object" && (0, applicability_1.shouldUseRule)(it.schema, rule)) {
          const { type } = rule.definition;
          if (type.length && !type.some((t) => hasApplicableType(ts, t))) {
            strictTypesError(it, `missing type "${type.join(",")}" for keyword "${keyword}"`);
          }
        }
      }
    }
    function hasApplicableType(schTs, kwdT) {
      return schTs.includes(kwdT) || kwdT === "number" && schTs.includes("integer");
    }
    function includesType(ts, t) {
      return ts.includes(t) || t === "integer" && ts.includes("number");
    }
    function narrowSchemaTypes(it, withTypes) {
      const ts = [];
      for (const t of it.dataTypes) {
        if (includesType(withTypes, t))
          ts.push(t);
        else if (withTypes.includes("integer") && t === "number")
          ts.push("integer");
      }
      it.dataTypes = ts;
    }
    function strictTypesError(it, msg) {
      const schemaPath = it.schemaEnv.baseId + it.errSchemaPath;
      msg += ` at "${schemaPath}" (strictTypes)`;
      (0, util_1.checkStrictMode)(it, msg, it.opts.strictTypes);
    }
    var KeywordCxt = class {
      constructor(it, def, keyword) {
        (0, keyword_1.validateKeywordUsage)(it, def, keyword);
        this.gen = it.gen;
        this.allErrors = it.allErrors;
        this.keyword = keyword;
        this.data = it.data;
        this.schema = it.schema[keyword];
        this.$data = def.$data && it.opts.$data && this.schema && this.schema.$data;
        this.schemaValue = (0, util_1.schemaRefOrVal)(it, this.schema, keyword, this.$data);
        this.schemaType = def.schemaType;
        this.parentSchema = it.schema;
        this.params = {};
        this.it = it;
        this.def = def;
        if (this.$data) {
          this.schemaCode = it.gen.const("vSchema", getData(this.$data, it));
        } else {
          this.schemaCode = this.schemaValue;
          if (!(0, keyword_1.validSchemaType)(this.schema, def.schemaType, def.allowUndefined)) {
            throw new Error(`${keyword} value must be ${JSON.stringify(def.schemaType)}`);
          }
        }
        if ("code" in def ? def.trackErrors : def.errors !== false) {
          this.errsCount = it.gen.const("_errs", names_1.default.errors);
        }
      }
      result(condition, successAction, failAction) {
        this.failResult((0, codegen_1.not)(condition), successAction, failAction);
      }
      failResult(condition, successAction, failAction) {
        this.gen.if(condition);
        if (failAction)
          failAction();
        else
          this.error();
        if (successAction) {
          this.gen.else();
          successAction();
          if (this.allErrors)
            this.gen.endIf();
        } else {
          if (this.allErrors)
            this.gen.endIf();
          else
            this.gen.else();
        }
      }
      pass(condition, failAction) {
        this.failResult((0, codegen_1.not)(condition), void 0, failAction);
      }
      fail(condition) {
        if (condition === void 0) {
          this.error();
          if (!this.allErrors)
            this.gen.if(false);
          return;
        }
        this.gen.if(condition);
        this.error();
        if (this.allErrors)
          this.gen.endIf();
        else
          this.gen.else();
      }
      fail$data(condition) {
        if (!this.$data)
          return this.fail(condition);
        const { schemaCode } = this;
        this.fail((0, codegen_1._)`${schemaCode} !== undefined && (${(0, codegen_1.or)(this.invalid$data(), condition)})`);
      }
      error(append, errorParams, errorPaths) {
        if (errorParams) {
          this.setParams(errorParams);
          this._error(append, errorPaths);
          this.setParams({});
          return;
        }
        this._error(append, errorPaths);
      }
      _error(append, errorPaths) {
        ;
        (append ? errors_1.reportExtraError : errors_1.reportError)(this, this.def.error, errorPaths);
      }
      $dataError() {
        (0, errors_1.reportError)(this, this.def.$dataError || errors_1.keyword$DataError);
      }
      reset() {
        if (this.errsCount === void 0)
          throw new Error('add "trackErrors" to keyword definition');
        (0, errors_1.resetErrorsCount)(this.gen, this.errsCount);
      }
      ok(cond) {
        if (!this.allErrors)
          this.gen.if(cond);
      }
      setParams(obj, assign) {
        if (assign)
          Object.assign(this.params, obj);
        else
          this.params = obj;
      }
      block$data(valid, codeBlock, $dataValid = codegen_1.nil) {
        this.gen.block(() => {
          this.check$data(valid, $dataValid);
          codeBlock();
        });
      }
      check$data(valid = codegen_1.nil, $dataValid = codegen_1.nil) {
        if (!this.$data)
          return;
        const { gen, schemaCode, schemaType, def } = this;
        gen.if((0, codegen_1.or)((0, codegen_1._)`${schemaCode} === undefined`, $dataValid));
        if (valid !== codegen_1.nil)
          gen.assign(valid, true);
        if (schemaType.length || def.validateSchema) {
          gen.elseIf(this.invalid$data());
          this.$dataError();
          if (valid !== codegen_1.nil)
            gen.assign(valid, false);
        }
        gen.else();
      }
      invalid$data() {
        const { gen, schemaCode, schemaType, def, it } = this;
        return (0, codegen_1.or)(wrong$DataType(), invalid$DataSchema());
        function wrong$DataType() {
          if (schemaType.length) {
            if (!(schemaCode instanceof codegen_1.Name))
              throw new Error("ajv implementation error");
            const st = Array.isArray(schemaType) ? schemaType : [schemaType];
            return (0, codegen_1._)`${(0, dataType_2.checkDataTypes)(st, schemaCode, it.opts.strictNumbers, dataType_2.DataType.Wrong)}`;
          }
          return codegen_1.nil;
        }
        function invalid$DataSchema() {
          if (def.validateSchema) {
            const validateSchemaRef = gen.scopeValue("validate$data", { ref: def.validateSchema });
            return (0, codegen_1._)`!${validateSchemaRef}(${schemaCode})`;
          }
          return codegen_1.nil;
        }
      }
      subschema(appl, valid) {
        const subschema = (0, subschema_1.getSubschema)(this.it, appl);
        (0, subschema_1.extendSubschemaData)(subschema, this.it, appl);
        (0, subschema_1.extendSubschemaMode)(subschema, appl);
        const nextContext = { ...this.it, ...subschema, items: void 0, props: void 0 };
        subschemaCode(nextContext, valid);
        return nextContext;
      }
      mergeEvaluated(schemaCxt, toName) {
        const { it, gen } = this;
        if (!it.opts.unevaluated)
          return;
        if (it.props !== true && schemaCxt.props !== void 0) {
          it.props = util_1.mergeEvaluated.props(gen, schemaCxt.props, it.props, toName);
        }
        if (it.items !== true && schemaCxt.items !== void 0) {
          it.items = util_1.mergeEvaluated.items(gen, schemaCxt.items, it.items, toName);
        }
      }
      mergeValidEvaluated(schemaCxt, valid) {
        const { it, gen } = this;
        if (it.opts.unevaluated && (it.props !== true || it.items !== true)) {
          gen.if(valid, () => this.mergeEvaluated(schemaCxt, codegen_1.Name));
          return true;
        }
      }
    };
    exports.KeywordCxt = KeywordCxt;
    function keywordCode(it, keyword, def, ruleType) {
      const cxt = new KeywordCxt(it, def, keyword);
      if ("code" in def) {
        def.code(cxt, ruleType);
      } else if (cxt.$data && def.validate) {
        (0, keyword_1.funcKeywordCode)(cxt, def);
      } else if ("macro" in def) {
        (0, keyword_1.macroKeywordCode)(cxt, def);
      } else if (def.compile || def.validate) {
        (0, keyword_1.funcKeywordCode)(cxt, def);
      }
    }
    var JSON_POINTER = /^\/(?:[^~]|~0|~1)*$/;
    var RELATIVE_JSON_POINTER = /^([0-9]+)(#|\/(?:[^~]|~0|~1)*)?$/;
    function getData($data, { dataLevel, dataNames, dataPathArr }) {
      let jsonPointer;
      let data;
      if ($data === "")
        return names_1.default.rootData;
      if ($data[0] === "/") {
        if (!JSON_POINTER.test($data))
          throw new Error(`Invalid JSON-pointer: ${$data}`);
        jsonPointer = $data;
        data = names_1.default.rootData;
      } else {
        const matches2 = RELATIVE_JSON_POINTER.exec($data);
        if (!matches2)
          throw new Error(`Invalid JSON-pointer: ${$data}`);
        const up = +matches2[1];
        jsonPointer = matches2[2];
        if (jsonPointer === "#") {
          if (up >= dataLevel)
            throw new Error(errorMsg("property/index", up));
          return dataPathArr[dataLevel - up];
        }
        if (up > dataLevel)
          throw new Error(errorMsg("data", up));
        data = dataNames[dataLevel - up];
        if (!jsonPointer)
          return data;
      }
      let expr = data;
      const segments = jsonPointer.split("/");
      for (const segment of segments) {
        if (segment) {
          data = (0, codegen_1._)`${data}${(0, codegen_1.getProperty)((0, util_1.unescapeJsonPointer)(segment))}`;
          expr = (0, codegen_1._)`${expr} && ${data}`;
        }
      }
      return expr;
      function errorMsg(pointerType, up) {
        return `Cannot access ${pointerType} ${up} levels up, current level is ${dataLevel}`;
      }
    }
    exports.getData = getData;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/validation_error.js
var require_validation_error = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/validation_error.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var ValidationError = class extends Error {
      constructor(errors) {
        super("validation failed");
        this.errors = errors;
        this.ajv = this.validation = true;
      }
    };
    exports.default = ValidationError;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/ref_error.js
var require_ref_error = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/ref_error.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var resolve_1 = require_resolve();
    var MissingRefError = class extends Error {
      constructor(resolver, baseId, ref, msg) {
        super(msg || `can't resolve reference ${ref} from id ${baseId}`);
        this.missingRef = (0, resolve_1.resolveUrl)(resolver, baseId, ref);
        this.missingSchema = (0, resolve_1.normalizeId)((0, resolve_1.getFullPath)(resolver, this.missingRef));
      }
    };
    exports.default = MissingRefError;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/index.js
var require_compile = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/compile/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.resolveSchema = exports.getCompilingSchema = exports.resolveRef = exports.compileSchema = exports.SchemaEnv = void 0;
    var codegen_1 = require_codegen();
    var validation_error_1 = require_validation_error();
    var names_1 = require_names();
    var resolve_1 = require_resolve();
    var util_1 = require_util();
    var validate_1 = require_validate();
    var SchemaEnv = class {
      constructor(env) {
        var _a;
        this.refs = {};
        this.dynamicAnchors = {};
        let schema;
        if (typeof env.schema == "object")
          schema = env.schema;
        this.schema = env.schema;
        this.schemaId = env.schemaId;
        this.root = env.root || this;
        this.baseId = (_a = env.baseId) !== null && _a !== void 0 ? _a : (0, resolve_1.normalizeId)(schema === null || schema === void 0 ? void 0 : schema[env.schemaId || "$id"]);
        this.schemaPath = env.schemaPath;
        this.localRefs = env.localRefs;
        this.meta = env.meta;
        this.$async = schema === null || schema === void 0 ? void 0 : schema.$async;
        this.refs = {};
      }
    };
    exports.SchemaEnv = SchemaEnv;
    function compileSchema(sch) {
      const _sch = getCompilingSchema.call(this, sch);
      if (_sch)
        return _sch;
      const rootId = (0, resolve_1.getFullPath)(this.opts.uriResolver, sch.root.baseId);
      const { es5, lines } = this.opts.code;
      const { ownProperties } = this.opts;
      const gen = new codegen_1.CodeGen(this.scope, { es5, lines, ownProperties });
      let _ValidationError;
      if (sch.$async) {
        _ValidationError = gen.scopeValue("Error", {
          ref: validation_error_1.default,
          code: (0, codegen_1._)`require("ajv/dist/runtime/validation_error").default`
        });
      }
      const validateName = gen.scopeName("validate");
      sch.validateName = validateName;
      const schemaCxt = {
        gen,
        allErrors: this.opts.allErrors,
        data: names_1.default.data,
        parentData: names_1.default.parentData,
        parentDataProperty: names_1.default.parentDataProperty,
        dataNames: [names_1.default.data],
        dataPathArr: [codegen_1.nil],
        // TODO can its length be used as dataLevel if nil is removed?
        dataLevel: 0,
        dataTypes: [],
        definedProperties: /* @__PURE__ */ new Set(),
        topSchemaRef: gen.scopeValue("schema", this.opts.code.source === true ? { ref: sch.schema, code: (0, codegen_1.stringify)(sch.schema) } : { ref: sch.schema }),
        validateName,
        ValidationError: _ValidationError,
        schema: sch.schema,
        schemaEnv: sch,
        rootId,
        baseId: sch.baseId || rootId,
        schemaPath: codegen_1.nil,
        errSchemaPath: sch.schemaPath || (this.opts.jtd ? "" : "#"),
        errorPath: (0, codegen_1._)`""`,
        opts: this.opts,
        self: this
      };
      let sourceCode;
      try {
        this._compilations.add(sch);
        (0, validate_1.validateFunctionCode)(schemaCxt);
        gen.optimize(this.opts.code.optimize);
        const validateCode = gen.toString();
        sourceCode = `${gen.scopeRefs(names_1.default.scope)}return ${validateCode}`;
        if (this.opts.code.process)
          sourceCode = this.opts.code.process(sourceCode, sch);
        const makeValidate = new Function(`${names_1.default.self}`, `${names_1.default.scope}`, sourceCode);
        const validate = makeValidate(this, this.scope.get());
        this.scope.value(validateName, { ref: validate });
        validate.errors = null;
        validate.schema = sch.schema;
        validate.schemaEnv = sch;
        if (sch.$async)
          validate.$async = true;
        if (this.opts.code.source === true) {
          validate.source = { validateName, validateCode, scopeValues: gen._values };
        }
        if (this.opts.unevaluated) {
          const { props, items } = schemaCxt;
          validate.evaluated = {
            props: props instanceof codegen_1.Name ? void 0 : props,
            items: items instanceof codegen_1.Name ? void 0 : items,
            dynamicProps: props instanceof codegen_1.Name,
            dynamicItems: items instanceof codegen_1.Name
          };
          if (validate.source)
            validate.source.evaluated = (0, codegen_1.stringify)(validate.evaluated);
        }
        sch.validate = validate;
        return sch;
      } catch (e) {
        delete sch.validate;
        delete sch.validateName;
        if (sourceCode)
          this.logger.error("Error compiling schema, function code:", sourceCode);
        throw e;
      } finally {
        this._compilations.delete(sch);
      }
    }
    exports.compileSchema = compileSchema;
    function resolveRef(root, baseId, ref) {
      var _a;
      ref = (0, resolve_1.resolveUrl)(this.opts.uriResolver, baseId, ref);
      const schOrFunc = root.refs[ref];
      if (schOrFunc)
        return schOrFunc;
      let _sch = resolve4.call(this, root, ref);
      if (_sch === void 0) {
        const schema = (_a = root.localRefs) === null || _a === void 0 ? void 0 : _a[ref];
        const { schemaId } = this.opts;
        if (schema)
          _sch = new SchemaEnv({ schema, schemaId, root, baseId });
      }
      if (_sch === void 0)
        return;
      return root.refs[ref] = inlineOrCompile.call(this, _sch);
    }
    exports.resolveRef = resolveRef;
    function inlineOrCompile(sch) {
      if ((0, resolve_1.inlineRef)(sch.schema, this.opts.inlineRefs))
        return sch.schema;
      return sch.validate ? sch : compileSchema.call(this, sch);
    }
    function getCompilingSchema(schEnv) {
      for (const sch of this._compilations) {
        if (sameSchemaEnv(sch, schEnv))
          return sch;
      }
    }
    exports.getCompilingSchema = getCompilingSchema;
    function sameSchemaEnv(s1, s2) {
      return s1.schema === s2.schema && s1.root === s2.root && s1.baseId === s2.baseId;
    }
    function resolve4(root, ref) {
      let sch;
      while (typeof (sch = this.refs[ref]) == "string")
        ref = sch;
      return sch || this.schemas[ref] || resolveSchema.call(this, root, ref);
    }
    function resolveSchema(root, ref) {
      const p = this.opts.uriResolver.parse(ref);
      const refPath = (0, resolve_1._getFullPath)(this.opts.uriResolver, p);
      let baseId = (0, resolve_1.getFullPath)(this.opts.uriResolver, root.baseId, void 0);
      if (Object.keys(root.schema).length > 0 && refPath === baseId) {
        return getJsonPointer.call(this, p, root);
      }
      const id3 = (0, resolve_1.normalizeId)(refPath);
      const schOrRef = this.refs[id3] || this.schemas[id3];
      if (typeof schOrRef == "string") {
        const sch = resolveSchema.call(this, root, schOrRef);
        if (typeof (sch === null || sch === void 0 ? void 0 : sch.schema) !== "object")
          return;
        return getJsonPointer.call(this, p, sch);
      }
      if (typeof (schOrRef === null || schOrRef === void 0 ? void 0 : schOrRef.schema) !== "object")
        return;
      if (!schOrRef.validate)
        compileSchema.call(this, schOrRef);
      if (id3 === (0, resolve_1.normalizeId)(ref)) {
        const { schema } = schOrRef;
        const { schemaId } = this.opts;
        const schId = schema[schemaId];
        if (schId)
          baseId = (0, resolve_1.resolveUrl)(this.opts.uriResolver, baseId, schId);
        return new SchemaEnv({ schema, schemaId, root, baseId });
      }
      return getJsonPointer.call(this, p, schOrRef);
    }
    exports.resolveSchema = resolveSchema;
    var PREVENT_SCOPE_CHANGE = /* @__PURE__ */ new Set([
      "properties",
      "patternProperties",
      "enum",
      "dependencies",
      "definitions"
    ]);
    function getJsonPointer(parsedRef, { baseId, schema, root }) {
      var _a;
      if (((_a = parsedRef.fragment) === null || _a === void 0 ? void 0 : _a[0]) !== "/")
        return;
      for (const part of parsedRef.fragment.slice(1).split("/")) {
        if (typeof schema === "boolean")
          return;
        const partSchema = schema[(0, util_1.unescapeFragment)(part)];
        if (partSchema === void 0)
          return;
        schema = partSchema;
        const schId = typeof schema === "object" && schema[this.opts.schemaId];
        if (!PREVENT_SCOPE_CHANGE.has(part) && schId) {
          baseId = (0, resolve_1.resolveUrl)(this.opts.uriResolver, baseId, schId);
        }
      }
      let env;
      if (typeof schema != "boolean" && schema.$ref && !(0, util_1.schemaHasRulesButRef)(schema, this.RULES)) {
        const $ref = (0, resolve_1.resolveUrl)(this.opts.uriResolver, baseId, schema.$ref);
        env = resolveSchema.call(this, root, $ref);
      }
      const { schemaId } = this.opts;
      env = env || new SchemaEnv({ schema, schemaId, root, baseId });
      if (env.schema !== env.root.schema)
        return env;
      return void 0;
    }
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/refs/data.json
var require_data = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/refs/data.json"(exports, module) {
    module.exports = {
      $id: "https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#",
      description: "Meta-schema for $data reference (JSON AnySchema extension proposal)",
      type: "object",
      required: ["$data"],
      properties: {
        $data: {
          type: "string",
          anyOf: [{ format: "relative-json-pointer" }, { format: "json-pointer" }]
        }
      },
      additionalProperties: false
    };
  }
});

// node_modules/.pnpm/fast-uri@3.1.8/node_modules/fast-uri/lib/utils.js
var require_utils = __commonJS({
  "node_modules/.pnpm/fast-uri@3.1.8/node_modules/fast-uri/lib/utils.js"(exports, module) {
    "use strict";
    var isUUID = RegExp.prototype.test.bind(/^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/iu);
    var isIPv4 = RegExp.prototype.test.bind(/^(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)$/u);
    var isPort = RegExp.prototype.test.bind(/^\d*$/u);
    var isHexPair = RegExp.prototype.test.bind(/^[\da-f]{2}$/iu);
    var isUnreserved = RegExp.prototype.test.bind(/^[\da-z\-._~]$/iu);
    var isPathCharacter = RegExp.prototype.test.bind(/^[A-Za-z0-9\-._~!$&'()*+,;=:@/]$/u);
    var isQueryFragmentCharacter = RegExp.prototype.test.bind(/^[A-Za-z0-9\-._~!$&'()*+,;=:@/?]$/u);
    var isUserinfoCharacter = RegExp.prototype.test.bind(/^[A-Za-z0-9\-._~!$&'()*+,;=:]$/u);
    var BYTE_HEX = new Array(256);
    {
      const HEX_DIGITS = "0123456789ABCDEF";
      for (let i = 0; i < 256; i++) {
        BYTE_HEX[i] = "%" + HEX_DIGITS[i >> 4] + HEX_DIGITS[i & 15];
      }
    }
    function percentEncodeNonAscii(cp) {
      if (cp < 2048) {
        return BYTE_HEX[192 | cp >> 6] + BYTE_HEX[128 | cp & 63];
      }
      if (cp < 65536) {
        return BYTE_HEX[224 | cp >> 12] + BYTE_HEX[128 | cp >> 6 & 63] + BYTE_HEX[128 | cp & 63];
      }
      return BYTE_HEX[240 | cp >> 18] + BYTE_HEX[128 | cp >> 12 & 63] + BYTE_HEX[128 | cp >> 6 & 63] + BYTE_HEX[128 | cp & 63];
    }
    function stringArrayToHexStripped(input) {
      let acc = "";
      let code = 0;
      let i = 0;
      for (i = 0; i < input.length; i++) {
        code = input[i].charCodeAt(0);
        if (code === 48) {
          continue;
        }
        if (!(code >= 48 && code <= 57 || code >= 65 && code <= 70 || code >= 97 && code <= 102)) {
          return "";
        }
        acc += input[i];
        break;
      }
      for (i += 1; i < input.length; i++) {
        code = input[i].charCodeAt(0);
        if (!(code >= 48 && code <= 57 || code >= 65 && code <= 70 || code >= 97 && code <= 102)) {
          return "";
        }
        acc += input[i];
      }
      return acc;
    }
    var isHextet = RegExp.prototype.test.bind(/^[\dA-Fa-f]{1,4}$/);
    var isIPvFuture = RegExp.prototype.test.bind(/^[vV][\dA-Fa-f]+\.[A-Za-z\d\-._~!$&'()*+,;=:]+$/);
    var isZoneCharacter = RegExp.prototype.test.bind(/^[A-Za-z\d\-._~]$/);
    var nonSimpleDomain = RegExp.prototype.test.bind(/[^!"$&'()*+,\-.;=_`a-z{}~]/u);
    function isZoneIdentifier(zone) {
      if (zone.length === 0) return false;
      for (let i = 0; i < zone.length; i++) {
        if (isZoneCharacter(zone[i])) continue;
        if (zone[i] === "%" && i + 2 < zone.length && isHexPair(zone.slice(i + 1, i + 3))) {
          i += 2;
          continue;
        }
        return false;
      }
      return true;
    }
    function compressIPv6ZeroRun(hextets) {
      let bestStart = -1;
      let bestLength = 0;
      let runStart = -1;
      let runLength = 0;
      for (let i = 0; i < hextets.length; i++) {
        if (hextets[i] === "0") {
          if (runStart === -1) runStart = i;
          runLength++;
          if (runLength > bestLength) {
            bestLength = runLength;
            bestStart = runStart;
          }
        } else {
          runStart = -1;
          runLength = 0;
        }
      }
      if (bestLength < 2) return hextets.join(":");
      const head = hextets.slice(0, bestStart).join(":");
      const tail = hextets.slice(bestStart + bestLength).join(":");
      return head + "::" + tail;
    }
    function normalizeIPv6Address(input) {
      const compression = input.indexOf("::");
      if (compression !== -1 && input.indexOf("::", compression + 1) !== -1) return void 0;
      const left = compression === -1 ? input.split(":") : input.slice(0, compression).split(":");
      const right = compression === -1 ? [] : input.slice(compression + 2).split(":");
      if (compression !== -1) {
        if (left.length === 1 && left[0] === "") left.length = 0;
        if (right.length === 1 && right[0] === "") right.length = 0;
      }
      const parts = left.concat(right);
      let hextetCount = 0;
      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        if (part === "") return void 0;
        if (part.indexOf(".") !== -1) {
          if (i !== parts.length - 1 || compression !== -1 && right.length === 0 || !isIPv4(part)) return void 0;
          hextetCount += 2;
          continue;
        }
        if (!isHextet(part)) return void 0;
        parts[i] = parseInt(part, 16).toString(16);
        hextetCount++;
      }
      if (compression === -1) {
        if (hextetCount !== 8) return void 0;
        return compressIPv6ZeroRun(parts);
      }
      if (hextetCount >= 8) return void 0;
      const expanded = parts.slice(0, left.length);
      for (let i = hextetCount; i < 8; i++) expanded.push("0");
      for (let i = left.length; i < parts.length; i++) expanded.push(parts[i]);
      return compressIPv6ZeroRun(expanded);
    }
    function normalizeIPv6(host) {
      const bracketed = host[0] === "[" && host[host.length - 1] === "]";
      const hasBracket = host[0] === "[" || host[host.length - 1] === "]";
      if (hasBracket && !bracketed) return { host, isIPV6: false, error: true };
      let input = bracketed ? host.slice(1, -1) : host;
      if (bracketed && isIPvFuture(input)) {
        input = input.toLowerCase();
        return { host: `[${input}]`, escapedHost: input, isIPV6: false, isIPVFuture: true };
      }
      if (findToken(input, ":") < 2) {
        return { host, isIPV6: false, error: bracketed };
      }
      let zoneIdentifier = "";
      const zoneSeparator = input.indexOf("%");
      if (zoneSeparator !== -1) {
        const separatorLength = input.slice(zoneSeparator, zoneSeparator + 3).toLowerCase() === "%25" ? 3 : 1;
        zoneIdentifier = input.slice(zoneSeparator + separatorLength);
        if (!isZoneIdentifier(zoneIdentifier)) return { host, isIPV6: false, error: true };
        input = input.slice(0, zoneSeparator);
      }
      const address = normalizeIPv6Address(input);
      if (address === void 0) return { host, isIPV6: false, error: true };
      return {
        host: address + (zoneIdentifier ? "%" + zoneIdentifier : ""),
        escapedHost: address + (zoneIdentifier ? "%25" + zoneIdentifier : ""),
        isIPV6: true
      };
    }
    function findToken(str, token) {
      let ind = 0;
      for (let i = 0; i < str.length; i++) {
        if (str[i] === token) ind++;
      }
      return ind;
    }
    function removeDotSegments(path2) {
      let input = path2;
      const output = [];
      let nextSlash = -1;
      let len = 0;
      while (len = input.length) {
        if (len === 1) {
          if (input === ".") {
            break;
          } else if (input === "/") {
            output.push("/");
            break;
          } else {
            output.push(input);
            break;
          }
        } else if (len === 2) {
          if (input[0] === ".") {
            if (input[1] === ".") {
              break;
            } else if (input[1] === "/") {
              input = input.slice(2);
              continue;
            }
          } else if (input[0] === "/") {
            if (input[1] === "." || input[1] === "/") {
              output.push("/");
              break;
            }
          }
        } else if (len === 3) {
          if (input === "/..") {
            if (output.length !== 0) {
              output.pop();
            }
            output.push("/");
            break;
          }
        }
        if (input[0] === ".") {
          if (input[1] === ".") {
            if (input[2] === "/") {
              input = input.slice(3);
              continue;
            }
          } else if (input[1] === "/") {
            input = input.slice(2);
            continue;
          }
        } else if (input[0] === "/") {
          if (input[1] === ".") {
            if (input[2] === "/") {
              input = input.slice(2);
              continue;
            } else if (input[2] === ".") {
              if (input[3] === "/") {
                input = input.slice(3);
                if (output.length !== 0) {
                  output.pop();
                }
                continue;
              }
            }
          }
        }
        if ((nextSlash = input.indexOf("/", 1)) === -1) {
          output.push(input);
          break;
        } else {
          output.push(input.slice(0, nextSlash));
          input = input.slice(nextSlash);
        }
      }
      return output.join("");
    }
    var HOST_DELIMS = { "@": "%40", "/": "%2F", "?": "%3F", "#": "%23", ":": "%3A" };
    var HOST_DELIM_RE = /[@/?#:]/g;
    var HOST_DELIM_NO_COLON_RE = /[@/?#]/g;
    function reescapeHostDelimiters(host, isIP) {
      const re = isIP ? HOST_DELIM_NO_COLON_RE : HOST_DELIM_RE;
      re.lastIndex = 0;
      return host.replace(re, (ch) => HOST_DELIMS[ch]);
    }
    function normalizePercentEncoding(input, decodeUnreserved = false) {
      if (input.indexOf("%") === -1) {
        return input;
      }
      let output = "";
      for (let i = 0; i < input.length; i++) {
        if (input[i] === "%" && i + 2 < input.length) {
          const hex = input.slice(i + 1, i + 3);
          if (isHexPair(hex)) {
            const normalizedHex = hex.toUpperCase();
            const decoded = String.fromCharCode(parseInt(normalizedHex, 16));
            if (decodeUnreserved && isUnreserved(decoded)) {
              output += decoded;
            } else {
              output += "%" + normalizedHex;
            }
            i += 2;
            continue;
          }
        }
        output += input[i];
      }
      return output;
    }
    function normalizePathEncoding(input) {
      let output = "";
      for (let i = 0; i < input.length; i++) {
        const ch = input[i];
        if (ch === "%" && i + 2 < input.length) {
          const hex = input.slice(i + 1, i + 3);
          if (isHexPair(hex)) {
            const normalizedHex = hex.toUpperCase();
            const decoded = String.fromCharCode(parseInt(normalizedHex, 16));
            if (decoded !== "." && isUnreserved(decoded)) {
              output += decoded;
            } else {
              output += "%" + normalizedHex;
            }
            i += 2;
            continue;
          }
        }
        if (isPathCharacter(ch)) {
          output += ch;
        } else {
          const code = input.charCodeAt(i);
          if (code < 128) {
            output += isEscapeSafe(code) ? ch : BYTE_HEX[code];
          } else if (code < 55296 || code > 57343) {
            output += percentEncodeNonAscii(code);
          } else if (code <= 56319 && i + 1 < input.length) {
            const low = input.charCodeAt(i + 1);
            if (low >= 56320 && low <= 57343) {
              output += percentEncodeNonAscii(65536 + (code - 55296 << 10) + (low - 56320));
              i++;
            } else {
              output += percentEncodeNonAscii(65533);
            }
          } else {
            output += percentEncodeNonAscii(65533);
          }
        }
      }
      return output;
    }
    function serializePathEncoding(input, pathNoScheme = false) {
      let output = "";
      let firstSegment = pathNoScheme && input[0] !== "/";
      for (let i = 0; i < input.length; i++) {
        const ch = input[i];
        if (ch === "%" && i + 2 < input.length) {
          const hex = input.slice(i + 1, i + 3);
          if (isHexPair(hex)) {
            output += "%" + hex.toUpperCase();
            i += 2;
            continue;
          }
        }
        if (ch === "/") {
          firstSegment = false;
        }
        if (isPathCharacter(ch) && (ch !== ":" || !firstSegment)) {
          output += ch;
        } else {
          const code = input.charCodeAt(i);
          if (code < 128) {
            output += BYTE_HEX[code];
          } else if (code < 55296 || code > 57343) {
            output += percentEncodeNonAscii(code);
          } else if (code <= 56319 && i + 1 < input.length) {
            const low = input.charCodeAt(i + 1);
            if (low >= 56320 && low <= 57343) {
              output += percentEncodeNonAscii(65536 + (code - 55296 << 10) + (low - 56320));
              i++;
            } else {
              output += percentEncodeNonAscii(65533);
            }
          } else {
            output += percentEncodeNonAscii(65533);
          }
        }
      }
      return output;
    }
    function encodeComponent(input, isAllowed) {
      let output = "";
      for (let i = 0; i < input.length; i++) {
        const ch = input[i];
        if (ch === "%" && i + 2 < input.length) {
          const hex = input.slice(i + 1, i + 3);
          if (isHexPair(hex)) {
            output += "%" + hex.toUpperCase();
            i += 2;
            continue;
          }
        }
        if (isAllowed(ch)) {
          output += ch;
        } else {
          const code = input.charCodeAt(i);
          if (code < 128) {
            output += BYTE_HEX[code];
          } else if (code < 55296 || code > 57343) {
            output += percentEncodeNonAscii(code);
          } else if (code <= 56319 && i + 1 < input.length) {
            const low = input.charCodeAt(i + 1);
            if (low >= 56320 && low <= 57343) {
              output += percentEncodeNonAscii(65536 + (code - 55296 << 10) + (low - 56320));
              i++;
            } else {
              output += percentEncodeNonAscii(65533);
            }
          } else {
            output += percentEncodeNonAscii(65533);
          }
        }
      }
      return output;
    }
    function encodeUserinfo(input) {
      return encodeComponent(input, isUserinfoCharacter);
    }
    function encodeQuery(input) {
      return encodeComponent(input, isQueryFragmentCharacter);
    }
    function encodeFragment(input) {
      return encodeComponent(input, isQueryFragmentCharacter);
    }
    function isEscapeSafe(cp) {
      return cp >= 48 && cp <= 57 || cp >= 65 && cp <= 90 || cp >= 97 && cp <= 122 || cp === 42 || cp === 43 || cp === 45 || cp === 46 || cp === 47 || cp === 64 || cp === 95;
    }
    function normalizeQueryFragmentEncoding(input) {
      let output = "";
      for (let i = 0; i < input.length; i++) {
        const ch = input[i];
        if (ch === "%" && i + 2 < input.length) {
          const hex = input.slice(i + 1, i + 3);
          if (isHexPair(hex)) {
            const normalizedHex = hex.toUpperCase();
            const decoded = String.fromCharCode(parseInt(normalizedHex, 16));
            if (isUnreserved(decoded)) {
              output += decoded;
            } else {
              output += "%" + normalizedHex;
            }
            i += 2;
            continue;
          }
        }
        if (isQueryFragmentCharacter(ch)) {
          output += ch;
        } else {
          const code = input.charCodeAt(i);
          if (code < 128) {
            output += isEscapeSafe(code) ? ch : BYTE_HEX[code];
          } else if (code < 55296 || code > 57343) {
            output += percentEncodeNonAscii(code);
          } else if (code <= 56319 && i + 1 < input.length) {
            const low = input.charCodeAt(i + 1);
            if (low >= 56320 && low <= 57343) {
              output += percentEncodeNonAscii(65536 + (code - 55296 << 10) + (low - 56320));
              i++;
            } else {
              output += percentEncodeNonAscii(65533);
            }
          } else {
            output += percentEncodeNonAscii(65533);
          }
        }
      }
      return output;
    }
    function escapePreservingEscapes(input) {
      let output = "";
      for (let i = 0; i < input.length; i++) {
        if (input[i] === "%" && i + 2 < input.length) {
          const hex = input.slice(i + 1, i + 3);
          if (isHexPair(hex)) {
            output += "%" + hex.toUpperCase();
            i += 2;
            continue;
          }
        }
        output += escape(input[i]);
      }
      return output;
    }
    function recomposeAuthority(component) {
      const uriTokens = [];
      if (component.userinfo !== void 0) {
        uriTokens.push(encodeUserinfo(component.userinfo));
        uriTokens.push("@");
      }
      if (component.host !== void 0) {
        let host = component.host;
        if (!isIPv4(host)) {
          let ipV6res = normalizeIPv6(host);
          if (ipV6res.isIPV6 !== true && ipV6res.isIPVFuture !== true) {
            host = normalizePercentEncoding(host, true);
            ipV6res = normalizeIPv6(host);
          }
          if (ipV6res.isIPV6 === true || ipV6res.isIPVFuture === true) {
            host = `[${ipV6res.escapedHost}]`;
          } else {
            host = reescapeHostDelimiters(host, false);
          }
        }
        uriTokens.push(host);
      }
      if (typeof component.port === "number" || typeof component.port === "string") {
        const port = String(component.port);
        if (!isPort(port)) {
          throw new TypeError("URI port is malformed.");
        }
        uriTokens.push(":");
        uriTokens.push(port);
      }
      return uriTokens.length ? uriTokens.join("") : void 0;
    }
    module.exports = {
      nonSimpleDomain,
      recomposeAuthority,
      reescapeHostDelimiters,
      normalizePercentEncoding,
      normalizePathEncoding,
      serializePathEncoding,
      normalizeQueryFragmentEncoding,
      encodeUserinfo,
      encodeQuery,
      encodeFragment,
      escapePreservingEscapes,
      removeDotSegments,
      isIPv4,
      isUUID,
      normalizeIPv6,
      stringArrayToHexStripped
    };
  }
});

// node_modules/.pnpm/fast-uri@3.1.8/node_modules/fast-uri/lib/schemes.js
var require_schemes = __commonJS({
  "node_modules/.pnpm/fast-uri@3.1.8/node_modules/fast-uri/lib/schemes.js"(exports, module) {
    "use strict";
    var { isUUID } = require_utils();
    var URN_REG = /^([\da-z][\d\-a-z]{0,31}):((?:[\w!$'()*+,\-./:;=@]|%[\da-f]{2})+)$/iu;
    var supportedSchemeNames = (
      /** @type {const} */
      [
        "http",
        "https",
        "ws",
        "wss",
        "urn",
        "urn:uuid"
      ]
    );
    function isValidSchemeName(name) {
      return supportedSchemeNames.indexOf(
        /** @type {*} */
        name
      ) !== -1;
    }
    function wsIsSecure(wsComponent) {
      if (wsComponent.secure === true) {
        return true;
      } else if (wsComponent.secure === false) {
        return false;
      } else if (wsComponent.scheme) {
        return wsComponent.scheme.length === 3 && (wsComponent.scheme[0] === "w" || wsComponent.scheme[0] === "W") && (wsComponent.scheme[1] === "s" || wsComponent.scheme[1] === "S") && (wsComponent.scheme[2] === "s" || wsComponent.scheme[2] === "S");
      } else {
        return false;
      }
    }
    function httpParse(component) {
      if (!component.host) {
        component.error = component.error || "HTTP URIs must have a host.";
      }
      return component;
    }
    function httpSerialize(component) {
      const secure = String(component.scheme).toLowerCase() === "https";
      if (component.port === (secure ? 443 : 80) || component.port === "") {
        component.port = void 0;
      }
      if (!component.path) {
        component.path = "/";
      }
      return component;
    }
    function wsParse(wsComponent) {
      wsComponent.secure = wsIsSecure(wsComponent);
      wsComponent.resourceName = (wsComponent.path || "/") + (wsComponent.query ? "?" + wsComponent.query : "");
      wsComponent.path = void 0;
      wsComponent.query = void 0;
      return wsComponent;
    }
    function wsSerialize(wsComponent) {
      if (wsComponent.port === (wsIsSecure(wsComponent) ? 443 : 80) || wsComponent.port === "") {
        wsComponent.port = void 0;
      }
      if (typeof wsComponent.secure === "boolean") {
        wsComponent.scheme = wsComponent.secure ? "wss" : "ws";
        wsComponent.secure = void 0;
      }
      if (wsComponent.resourceName) {
        const queryIndex = wsComponent.resourceName.indexOf("?");
        const path2 = queryIndex === -1 ? wsComponent.resourceName : wsComponent.resourceName.slice(0, queryIndex);
        wsComponent.path = path2 && path2 !== "/" ? path2 : void 0;
        wsComponent.query = queryIndex === -1 ? void 0 : wsComponent.resourceName.slice(queryIndex + 1);
        wsComponent.resourceName = void 0;
      }
      wsComponent.fragment = void 0;
      return wsComponent;
    }
    function urnParse(urnComponent, options) {
      if (!urnComponent.path) {
        urnComponent.error = "URN can not be parsed";
        return urnComponent;
      }
      const matches2 = urnComponent.path.match(URN_REG);
      if (matches2 && matches2[0] === urnComponent.path) {
        const scheme = options.scheme || urnComponent.scheme || "urn";
        urnComponent.nid = matches2[1].toLowerCase();
        urnComponent.nss = matches2[2];
        const urnScheme = `${scheme}:${options.nid || urnComponent.nid}`;
        const schemeHandler = getSchemeHandler(urnScheme);
        urnComponent.path = void 0;
        if (schemeHandler) {
          urnComponent = schemeHandler.parse(urnComponent, options);
        }
      } else {
        urnComponent.error = urnComponent.error || "URN can not be parsed.";
      }
      return urnComponent;
    }
    function urnSerialize(urnComponent, options) {
      if (urnComponent.nid === void 0) {
        throw new Error("URN without nid cannot be serialized");
      }
      const scheme = options.scheme || urnComponent.scheme || "urn";
      const nid = urnComponent.nid.toLowerCase();
      const urnScheme = `${scheme}:${options.nid || nid}`;
      const schemeHandler = getSchemeHandler(urnScheme);
      if (schemeHandler) {
        urnComponent = schemeHandler.serialize(urnComponent, options);
      }
      const uriComponent = urnComponent;
      const nss = urnComponent.nss;
      uriComponent.path = `${nid || options.nid}:${nss}`;
      options.skipEscape = true;
      return uriComponent;
    }
    function urnuuidParse(urnComponent, options) {
      const uuidComponent = urnComponent;
      uuidComponent.uuid = uuidComponent.nss;
      uuidComponent.nss = void 0;
      if (!options.tolerant && (!uuidComponent.uuid || !isUUID(uuidComponent.uuid))) {
        uuidComponent.error = uuidComponent.error || "UUID is not valid.";
      }
      return uuidComponent;
    }
    function urnuuidSerialize(uuidComponent) {
      const urnComponent = uuidComponent;
      urnComponent.nss = (uuidComponent.uuid || "").toLowerCase();
      return urnComponent;
    }
    var http = (
      /** @type {SchemeHandler} */
      {
        scheme: "http",
        domainHost: true,
        parse: httpParse,
        serialize: httpSerialize
      }
    );
    var https = (
      /** @type {SchemeHandler} */
      {
        scheme: "https",
        domainHost: http.domainHost,
        parse: httpParse,
        serialize: httpSerialize
      }
    );
    var ws = (
      /** @type {SchemeHandler} */
      {
        scheme: "ws",
        domainHost: true,
        parse: wsParse,
        serialize: wsSerialize
      }
    );
    var wss = (
      /** @type {SchemeHandler} */
      {
        scheme: "wss",
        domainHost: ws.domainHost,
        parse: ws.parse,
        serialize: ws.serialize
      }
    );
    var urn = (
      /** @type {SchemeHandler} */
      {
        scheme: "urn",
        parse: urnParse,
        serialize: urnSerialize,
        skipNormalize: true
      }
    );
    var urnuuid = (
      /** @type {SchemeHandler} */
      {
        scheme: "urn:uuid",
        parse: urnuuidParse,
        serialize: urnuuidSerialize,
        skipNormalize: true
      }
    );
    var SCHEMES = (
      /** @type {Record<SchemeName, SchemeHandler>} */
      {
        http,
        https,
        ws,
        wss,
        urn,
        "urn:uuid": urnuuid
      }
    );
    Object.setPrototypeOf(SCHEMES, null);
    function getSchemeHandler(scheme) {
      return scheme && (SCHEMES[
        /** @type {SchemeName} */
        scheme
      ] || SCHEMES[
        /** @type {SchemeName} */
        scheme.toLowerCase()
      ]) || void 0;
    }
    module.exports = {
      wsIsSecure,
      SCHEMES,
      isValidSchemeName,
      getSchemeHandler
    };
  }
});

// node_modules/.pnpm/fast-uri@3.1.8/node_modules/fast-uri/index.js
var require_fast_uri = __commonJS({
  "node_modules/.pnpm/fast-uri@3.1.8/node_modules/fast-uri/index.js"(exports, module) {
    "use strict";
    var { normalizeIPv6, removeDotSegments, recomposeAuthority, normalizePercentEncoding, normalizePathEncoding, serializePathEncoding, normalizeQueryFragmentEncoding, encodeQuery, encodeFragment, reescapeHostDelimiters, isIPv4, nonSimpleDomain } = require_utils();
    var { SCHEMES, getSchemeHandler } = require_schemes();
    var VALID_SCHEME = /^[A-Za-z][A-Za-z0-9+.-]*$/u;
    var MALFORMED_SCHEME_ERROR = "URI scheme is malformed.";
    function decodeValidScheme(scheme) {
      const decodedScheme = unescape(String(scheme));
      if (!VALID_SCHEME.test(decodedScheme)) {
        throw new TypeError(MALFORMED_SCHEME_ERROR);
      }
      return decodedScheme;
    }
    function normalize(uri, options) {
      if (typeof uri === "string") {
        uri = /** @type {T} */
        normalizeString(uri, options);
      } else if (typeof uri === "object") {
        uri = /** @type {T} */
        parse2(serialize(uri, options), options);
      }
      return uri;
    }
    function resolve4(baseURI, relativeURI, options) {
      const schemelessOptions = options ? Object.assign({ scheme: "null" }, options) : { scheme: "null" };
      const {
        parsed: baseParsed,
        malformedAuthorityOrPort: baseMalformed,
        malformedPercentEncoding: baseMalformedPercentEncoding,
        malformedSchemeSpecific: baseMalformedSchemeSpecific,
        malformedHost: baseMalformedHost,
        malformedScheme: baseMalformedScheme
      } = parseWithStatus(baseURI, schemelessOptions);
      const {
        parsed: relativeParsed,
        malformedAuthorityOrPort: relativeMalformed,
        malformedPercentEncoding: relativeMalformedPercentEncoding,
        malformedSchemeSpecific: relativeMalformedSchemeSpecific,
        malformedHost: relativeMalformedHost,
        malformedScheme: relativeMalformedScheme
      } = parseWithStatus(relativeURI, schemelessOptions);
      if (baseMalformed || relativeMalformed || baseMalformedPercentEncoding || relativeMalformedPercentEncoding || baseMalformedSchemeSpecific || relativeMalformedSchemeSpecific || baseMalformedHost || relativeMalformedHost || baseMalformedScheme || relativeMalformedScheme) {
        throw new Error(baseParsed.error || relativeParsed.error || "URI is malformed.");
      }
      const resolved = resolveComponent(baseParsed, relativeParsed, schemelessOptions, true);
      const resolvedSchemeHandler = getSchemeHandler(options && options.scheme || resolved.scheme);
      const resolvedHost = resolved.host;
      const resolvedHostIsIP = resolvedHost !== void 0 && resolvedHost !== "" && (isIPv4(resolvedHost) || normalizeIPv6(resolvedHost).isIPV6);
      canonicalizeHost(resolved, options || {}, resolvedSchemeHandler, resolvedHostIsIP);
      const encodedASCIIHost = resolvedHost && resolvedHost.indexOf("%") !== -1 && !new RegExp("\\P{ASCII}", "u").test(resolvedHost);
      if (resolved.error && !encodedASCIIHost) {
        throw new Error(resolved.error);
      }
      schemelessOptions.skipEscape = true;
      return serialize(resolved, schemelessOptions);
    }
    function resolveComponent(base, relative, options, skipNormalization) {
      const target = {};
      if (!skipNormalization) {
        base = parse2(serialize(base, options), options);
        relative = parse2(serialize(relative, options), options);
      }
      options = options || {};
      if (!options.tolerant && relative.scheme) {
        target.scheme = relative.scheme;
        target.userinfo = relative.userinfo;
        target.host = relative.host;
        target.port = relative.port;
        target.path = removeDotSegments(relative.path || "");
        target.query = relative.query;
      } else {
        if (relative.userinfo !== void 0 || relative.host !== void 0 || relative.port !== void 0) {
          target.userinfo = relative.userinfo;
          target.host = relative.host;
          target.port = relative.port;
          target.path = removeDotSegments(relative.path || "");
          target.query = relative.query;
        } else {
          if (!relative.path) {
            target.path = base.path;
            if (relative.query !== void 0) {
              target.query = relative.query;
            } else {
              target.query = base.query;
            }
          } else {
            if (relative.path[0] === "/") {
              target.path = removeDotSegments(relative.path);
            } else {
              if ((base.userinfo !== void 0 || base.host !== void 0 || base.port !== void 0) && !base.path) {
                target.path = "/" + relative.path;
              } else if (!base.path) {
                target.path = relative.path;
              } else {
                target.path = base.path.slice(0, base.path.lastIndexOf("/") + 1) + relative.path;
              }
              target.path = removeDotSegments(target.path);
            }
            target.query = relative.query;
          }
          target.userinfo = base.userinfo;
          target.host = base.host;
          target.port = base.port;
        }
        target.scheme = base.scheme;
      }
      target.fragment = relative.fragment;
      return target;
    }
    function equal(uriA, uriB, options) {
      const normalizedA = normalizeComparableURI(uriA, options);
      const normalizedB = normalizeComparableURI(uriB, options);
      return normalizedA !== void 0 && normalizedB !== void 0 && normalizedA === normalizedB;
    }
    function serialize(cmpts, opts) {
      const component = {
        host: cmpts.host,
        scheme: cmpts.scheme,
        userinfo: cmpts.userinfo,
        port: cmpts.port,
        path: cmpts.path,
        query: cmpts.query,
        nid: cmpts.nid,
        nss: cmpts.nss,
        uuid: cmpts.uuid,
        fragment: cmpts.fragment,
        reference: cmpts.reference,
        resourceName: cmpts.resourceName,
        secure: cmpts.secure,
        error: ""
      };
      const options = Object.assign({}, opts);
      const uriTokens = [];
      if (component.scheme) {
        component.scheme = decodeValidScheme(component.scheme);
      }
      const schemeHandler = getSchemeHandler(options.scheme || component.scheme);
      if (schemeHandler && schemeHandler.serialize) schemeHandler.serialize(component, options);
      const hasAuthority = component.userinfo !== void 0 || component.host !== void 0 || component.port !== void 0;
      const pathNoScheme = !options.skipEscape && component.scheme === void 0 && !hasAuthority;
      if (component.path !== void 0) {
        if (!options.skipEscape) {
          component.path = serializePathEncoding(component.path, pathNoScheme);
        } else {
          component.path = normalizePercentEncoding(component.path);
        }
      }
      if (options.reference !== "suffix" && component.scheme) {
        component.scheme = decodeValidScheme(component.scheme);
        uriTokens.push(component.scheme, ":");
      }
      const authority = recomposeAuthority(component);
      if (authority !== void 0) {
        if (options.reference !== "suffix") {
          uriTokens.push("//");
        }
        uriTokens.push(authority);
        if (component.path && component.path[0] !== "/") {
          uriTokens.push("/");
        }
      }
      if (component.path !== void 0) {
        let s = component.path;
        if (!options.absolutePath && (!schemeHandler || !schemeHandler.absolutePath)) {
          s = removeDotSegments(s);
        }
        if (pathNoScheme) {
          s = serializePathEncoding(s, true);
        }
        if (authority === void 0 && s[0] === "/" && s[1] === "/") {
          s = "/%2F" + s.slice(2);
        }
        uriTokens.push(s);
      }
      if (component.query !== void 0) {
        uriTokens.push("?", encodeQuery(component.query));
      }
      if (component.fragment !== void 0) {
        uriTokens.push("#", encodeFragment(component.fragment));
      }
      return uriTokens.join("");
    }
    var URI_PARSE = /^(?:([^#/:?]+):)?(?:\/\/((?:([^#/?@]*)@)?(\[[^#/?\]]+\]|[^#/:?]*)(?::(\d*))?))?([^#?]*)(?:\?([^#]*))?(?:#((?:.|[\n\r])*))?/u;
    var AUTHORITY_PREFIX = /^(?:[^#/:?]+:)?\/\/([^/?#]*)/;
    var AUTHORITY_INTRODUCER_REGION = /^(?:[^#/:?]+:)?([/\\\t\n\r]*)/;
    function getParseError(parsed, matches2) {
      if (matches2[2] !== void 0 && parsed.path && parsed.path[0] !== "/") {
        return 'URI path must start with "/" when authority is present.';
      }
      if (typeof parsed.port === "number" && (parsed.port < 0 || parsed.port > 65535)) {
        return "URI port is malformed.";
      }
      return void 0;
    }
    function hasMalformedPercentEncoding(component) {
      if (component === void 0) return false;
      let percent = component.indexOf("%");
      while (percent !== -1) {
        if (percent + 2 >= component.length || !/^[\da-f]{2}$/iu.test(component.slice(percent + 1, percent + 3))) {
          return true;
        }
        percent = component.indexOf("%", percent + 3);
      }
      return false;
    }
    function isIPLiteral(host) {
      return host[0] === "[" && host[host.length - 1] === "]";
    }
    function hasMalformedComponentPercentEncoding(matches2) {
      const host = matches2[4];
      return hasMalformedPercentEncoding(matches2[3]) || host !== void 0 && !isIPLiteral(host) && hasMalformedPercentEncoding(host) || hasMalformedPercentEncoding(matches2[6]) || hasMalformedPercentEncoding(matches2[7]) || hasMalformedPercentEncoding(matches2[8]);
    }
    function canonicalizeHost(parsed, options, schemeHandler, isIP) {
      if (!options.unicodeSupport && (!schemeHandler || !schemeHandler.unicodeSupport) && parsed.host && !isIPLiteral(parsed.host) && (options.domainHost || schemeHandler && schemeHandler.domainHost) && isIP === false && nonSimpleDomain(parsed.host)) {
        try {
          parsed.host = new URL("http://" + parsed.host).hostname;
        } catch (e) {
          parsed.error = parsed.error || "Host's domain name can not be converted to ASCII: " + e;
          return true;
        }
      }
      return false;
    }
    function parseWithStatus(uri, opts) {
      const options = Object.assign({}, opts);
      const parsed = {
        scheme: void 0,
        userinfo: void 0,
        host: "",
        port: void 0,
        path: "",
        query: void 0,
        fragment: void 0
      };
      let malformedAuthorityOrPort = false;
      let malformedPercentEncoding = false;
      let malformedSchemeSpecific = false;
      let malformedHost = false;
      let malformedIPLiteral = false;
      let malformedScheme = false;
      let isIP = false;
      if (options.reference === "suffix") {
        if (options.scheme) {
          uri = options.scheme + ":" + uri;
        } else {
          uri = "//" + uri;
        }
      }
      const authorityMatch = uri.match(AUTHORITY_PREFIX);
      if (authorityMatch !== null && authorityMatch[1].indexOf("\\") !== -1) {
        parsed.error = "URI authority must not contain a literal backslash.";
        malformedAuthorityOrPort = true;
      }
      const introducerMatch = uri.match(AUTHORITY_INTRODUCER_REGION);
      if (introducerMatch !== null) {
        const region = introducerMatch[1];
        const normalizedRegion = region.replace(/[\t\n\r]/g, "");
        if (normalizedRegion.length >= 2) {
          if (normalizedRegion.slice(0, 2) !== "//") {
            parsed.error = parsed.error || "URI authority must not contain a literal backslash.";
            malformedAuthorityOrPort = true;
          } else if (region.length !== normalizedRegion.length) {
            parsed.error = parsed.error || "URI authority introducer must not contain whitespace.";
            malformedAuthorityOrPort = true;
          }
        }
      }
      const matches2 = uri.match(URI_PARSE);
      if (matches2) {
        parsed.scheme = matches2[1];
        parsed.userinfo = matches2[3];
        parsed.host = matches2[4];
        parsed.port = parseInt(matches2[5], 10);
        parsed.path = matches2[6] || "";
        parsed.query = matches2[7];
        parsed.fragment = matches2[8];
        if (parsed.scheme !== void 0) {
          const decodedScheme = unescape(parsed.scheme);
          if (VALID_SCHEME.test(decodedScheme)) {
            parsed.scheme = decodedScheme.toLowerCase();
          } else {
            parsed.error = parsed.error || MALFORMED_SCHEME_ERROR;
            malformedScheme = true;
          }
        }
        malformedPercentEncoding = hasMalformedComponentPercentEncoding(matches2);
        if (malformedPercentEncoding) {
          parsed.error = parsed.error || "URI contains malformed percent-encoding.";
        }
        if (isNaN(parsed.port)) {
          parsed.port = matches2[5];
        }
        const parseError = getParseError(parsed, matches2);
        if (parseError !== void 0) {
          parsed.error = parsed.error || parseError;
          malformedAuthorityOrPort = true;
        }
        if (parsed.host) {
          const ipv4result = isIPv4(parsed.host);
          if (ipv4result === false) {
            const bracketedIPLiteral = isIPLiteral(parsed.host);
            const hasIPLiteralBracket = parsed.host.indexOf("[") !== -1 || parsed.host.indexOf("]") !== -1;
            const ipv6result = normalizeIPv6(parsed.host);
            isIP = ipv6result.isIPV6 || ipv6result.isIPVFuture === true;
            malformedIPLiteral = hasIPLiteralBracket && (!bracketedIPLiteral || ipv6result.error === true);
            parsed.host = isIP ? ipv6result.host : ipv6result.host.toLowerCase();
            if (malformedIPLiteral) {
              parsed.error = parsed.error || "URI host is malformed.";
              malformedAuthorityOrPort = true;
            }
          } else {
            isIP = true;
          }
        }
        if (parsed.scheme === void 0 && parsed.userinfo === void 0 && parsed.host === void 0 && parsed.port === void 0 && parsed.query === void 0 && !parsed.path) {
          parsed.reference = "same-document";
        } else if (parsed.scheme === void 0) {
          parsed.reference = "relative";
        } else if (parsed.fragment === void 0) {
          parsed.reference = "absolute";
        } else {
          parsed.reference = "uri";
        }
        if (options.reference && options.reference !== "suffix" && options.reference !== parsed.reference) {
          parsed.error = parsed.error || "URI is not a " + options.reference + " reference.";
        }
        const schemeHandler = getSchemeHandler(options.scheme || parsed.scheme);
        if (!malformedIPLiteral) {
          malformedHost = canonicalizeHost(parsed, options, schemeHandler, isIP);
        }
        if (uri.indexOf("%") !== -1 && parsed.host !== void 0 && !malformedIPLiteral) {
          let host = isIP ? parsed.host : normalizePercentEncoding(parsed.host, true);
          if (!isIP) {
            host = normalizePercentEncoding(host.toLowerCase());
          }
          parsed.host = reescapeHostDelimiters(host, isIP);
        }
        if (!schemeHandler || schemeHandler && !schemeHandler.skipNormalize) {
          if (parsed.path) {
            parsed.path = normalizePathEncoding(parsed.path);
          }
          if (parsed.query) {
            parsed.query = normalizeQueryFragmentEncoding(parsed.query);
          }
          if (parsed.fragment) {
            parsed.fragment = normalizeQueryFragmentEncoding(parsed.fragment);
          }
        }
        if (schemeHandler && schemeHandler.parse) {
          schemeHandler.parse(parsed, options);
          if (schemeHandler === SCHEMES.urn && parsed.nid === void 0) {
            malformedSchemeSpecific = true;
          }
        }
      } else {
        parsed.error = parsed.error || "URI can not be parsed.";
      }
      return { parsed, malformedAuthorityOrPort, malformedPercentEncoding, malformedSchemeSpecific, malformedHost, malformedScheme };
    }
    function parse2(uri, opts) {
      return parseWithStatus(uri, opts).parsed;
    }
    function normalizeString(uri, opts) {
      return normalizeStringWithStatus(uri, opts).normalized;
    }
    function normalizeStringWithStatus(uri, opts) {
      const { parsed, malformedAuthorityOrPort, malformedPercentEncoding, malformedSchemeSpecific, malformedHost, malformedScheme } = parseWithStatus(uri, opts);
      return {
        normalized: malformedAuthorityOrPort || malformedPercentEncoding || malformedSchemeSpecific || malformedHost || malformedScheme ? uri : serialize(parsed, opts),
        malformedAuthorityOrPort,
        malformedPercentEncoding,
        malformedSchemeSpecific,
        malformedHost,
        malformedScheme
      };
    }
    function normalizeComparableURI(uri, opts) {
      if (typeof uri !== "string" && typeof uri !== "object") {
        return void 0;
      }
      let value2;
      try {
        value2 = typeof uri === "string" ? uri : serialize(uri, opts);
      } catch {
        return void 0;
      }
      const { normalized, malformedAuthorityOrPort, malformedPercentEncoding, malformedSchemeSpecific, malformedHost, malformedScheme } = normalizeStringWithStatus(value2, opts);
      return malformedAuthorityOrPort || malformedPercentEncoding || malformedSchemeSpecific || malformedHost || malformedScheme ? void 0 : normalized;
    }
    var fastUri = {
      SCHEMES,
      normalize,
      resolve: resolve4,
      resolveComponent,
      equal,
      serialize,
      parse: parse2
    };
    module.exports = fastUri;
    module.exports.default = fastUri;
    module.exports.fastUri = fastUri;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/uri.js
var require_uri = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/uri.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var uri = require_fast_uri();
    uri.code = 'require("ajv/dist/runtime/uri").default';
    exports.default = uri;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/core.js
var require_core = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/core.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CodeGen = exports.Name = exports.nil = exports.stringify = exports.str = exports._ = exports.KeywordCxt = void 0;
    var validate_1 = require_validate();
    Object.defineProperty(exports, "KeywordCxt", { enumerable: true, get: function() {
      return validate_1.KeywordCxt;
    } });
    var codegen_1 = require_codegen();
    Object.defineProperty(exports, "_", { enumerable: true, get: function() {
      return codegen_1._;
    } });
    Object.defineProperty(exports, "str", { enumerable: true, get: function() {
      return codegen_1.str;
    } });
    Object.defineProperty(exports, "stringify", { enumerable: true, get: function() {
      return codegen_1.stringify;
    } });
    Object.defineProperty(exports, "nil", { enumerable: true, get: function() {
      return codegen_1.nil;
    } });
    Object.defineProperty(exports, "Name", { enumerable: true, get: function() {
      return codegen_1.Name;
    } });
    Object.defineProperty(exports, "CodeGen", { enumerable: true, get: function() {
      return codegen_1.CodeGen;
    } });
    var validation_error_1 = require_validation_error();
    var ref_error_1 = require_ref_error();
    var rules_1 = require_rules();
    var compile_1 = require_compile();
    var codegen_2 = require_codegen();
    var resolve_1 = require_resolve();
    var dataType_1 = require_dataType();
    var util_1 = require_util();
    var $dataRefSchema = require_data();
    var uri_1 = require_uri();
    var defaultRegExp = (str, flags) => new RegExp(str, flags);
    defaultRegExp.code = "new RegExp";
    var META_IGNORE_OPTIONS = ["removeAdditional", "useDefaults", "coerceTypes"];
    var EXT_SCOPE_NAMES = /* @__PURE__ */ new Set([
      "validate",
      "serialize",
      "parse",
      "wrapper",
      "root",
      "schema",
      "keyword",
      "pattern",
      "formats",
      "validate$data",
      "func",
      "obj",
      "Error"
    ]);
    var removedOptions = {
      errorDataPath: "",
      format: "`validateFormats: false` can be used instead.",
      nullable: '"nullable" keyword is supported by default.',
      jsonPointers: "Deprecated jsPropertySyntax can be used instead.",
      extendRefs: "Deprecated ignoreKeywordsWithRef can be used instead.",
      missingRefs: "Pass empty schema with $id that should be ignored to ajv.addSchema.",
      processCode: "Use option `code: {process: (code, schemaEnv: object) => string}`",
      sourceCode: "Use option `code: {source: true}`",
      strictDefaults: "It is default now, see option `strict`.",
      strictKeywords: "It is default now, see option `strict`.",
      uniqueItems: '"uniqueItems" keyword is always validated.',
      unknownFormats: "Disable strict mode or pass `true` to `ajv.addFormat` (or `formats` option).",
      cache: "Map is used as cache, schema object as key.",
      serialize: "Map is used as cache, schema object as key.",
      ajvErrors: "It is default now."
    };
    var deprecatedOptions = {
      ignoreKeywordsWithRef: "",
      jsPropertySyntax: "",
      unicode: '"minLength"/"maxLength" account for unicode characters by default.'
    };
    var MAX_EXPRESSION = 200;
    function requiredOptions(o) {
      var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0;
      const s = o.strict;
      const _optz = (_a = o.code) === null || _a === void 0 ? void 0 : _a.optimize;
      const optimize = _optz === true || _optz === void 0 ? 1 : _optz || 0;
      const regExp = (_c = (_b = o.code) === null || _b === void 0 ? void 0 : _b.regExp) !== null && _c !== void 0 ? _c : defaultRegExp;
      const uriResolver = (_d = o.uriResolver) !== null && _d !== void 0 ? _d : uri_1.default;
      return {
        strictSchema: (_f = (_e = o.strictSchema) !== null && _e !== void 0 ? _e : s) !== null && _f !== void 0 ? _f : true,
        strictNumbers: (_h = (_g = o.strictNumbers) !== null && _g !== void 0 ? _g : s) !== null && _h !== void 0 ? _h : true,
        strictTypes: (_k = (_j = o.strictTypes) !== null && _j !== void 0 ? _j : s) !== null && _k !== void 0 ? _k : "log",
        strictTuples: (_m = (_l = o.strictTuples) !== null && _l !== void 0 ? _l : s) !== null && _m !== void 0 ? _m : "log",
        strictRequired: (_p = (_o = o.strictRequired) !== null && _o !== void 0 ? _o : s) !== null && _p !== void 0 ? _p : false,
        code: o.code ? { ...o.code, optimize, regExp } : { optimize, regExp },
        loopRequired: (_q = o.loopRequired) !== null && _q !== void 0 ? _q : MAX_EXPRESSION,
        loopEnum: (_r = o.loopEnum) !== null && _r !== void 0 ? _r : MAX_EXPRESSION,
        meta: (_s = o.meta) !== null && _s !== void 0 ? _s : true,
        messages: (_t = o.messages) !== null && _t !== void 0 ? _t : true,
        inlineRefs: (_u = o.inlineRefs) !== null && _u !== void 0 ? _u : true,
        schemaId: (_v = o.schemaId) !== null && _v !== void 0 ? _v : "$id",
        addUsedSchema: (_w = o.addUsedSchema) !== null && _w !== void 0 ? _w : true,
        validateSchema: (_x = o.validateSchema) !== null && _x !== void 0 ? _x : true,
        validateFormats: (_y = o.validateFormats) !== null && _y !== void 0 ? _y : true,
        unicodeRegExp: (_z = o.unicodeRegExp) !== null && _z !== void 0 ? _z : true,
        int32range: (_0 = o.int32range) !== null && _0 !== void 0 ? _0 : true,
        uriResolver
      };
    }
    var Ajv2 = class {
      constructor(opts = {}) {
        this.schemas = {};
        this.refs = {};
        this.formats = /* @__PURE__ */ Object.create(null);
        this._compilations = /* @__PURE__ */ new Set();
        this._loading = {};
        this._cache = /* @__PURE__ */ new Map();
        opts = this.opts = { ...opts, ...requiredOptions(opts) };
        const { es5, lines } = this.opts.code;
        this.scope = new codegen_2.ValueScope({ scope: {}, prefixes: EXT_SCOPE_NAMES, es5, lines });
        this.logger = getLogger(opts.logger);
        const formatOpt = opts.validateFormats;
        opts.validateFormats = false;
        this.RULES = (0, rules_1.getRules)();
        checkOptions.call(this, removedOptions, opts, "NOT SUPPORTED");
        checkOptions.call(this, deprecatedOptions, opts, "DEPRECATED", "warn");
        this._metaOpts = getMetaSchemaOptions.call(this);
        if (opts.formats)
          addInitialFormats.call(this);
        this._addVocabularies();
        this._addDefaultMetaSchema();
        if (opts.keywords)
          addInitialKeywords.call(this, opts.keywords);
        if (typeof opts.meta == "object")
          this.addMetaSchema(opts.meta);
        addInitialSchemas.call(this);
        opts.validateFormats = formatOpt;
      }
      _addVocabularies() {
        this.addKeyword("$async");
      }
      _addDefaultMetaSchema() {
        const { $data, meta, schemaId } = this.opts;
        let _dataRefSchema = $dataRefSchema;
        if (schemaId === "id") {
          _dataRefSchema = { ...$dataRefSchema };
          _dataRefSchema.id = _dataRefSchema.$id;
          delete _dataRefSchema.$id;
        }
        if (meta && $data)
          this.addMetaSchema(_dataRefSchema, _dataRefSchema[schemaId], false);
      }
      defaultMeta() {
        const { meta, schemaId } = this.opts;
        return this.opts.defaultMeta = typeof meta == "object" ? meta[schemaId] || meta : void 0;
      }
      validate(schemaKeyRef, data) {
        let v;
        if (typeof schemaKeyRef == "string") {
          v = this.getSchema(schemaKeyRef);
          if (!v)
            throw new Error(`no schema with key or ref "${schemaKeyRef}"`);
        } else {
          v = this.compile(schemaKeyRef);
        }
        const valid = v(data);
        if (!("$async" in v))
          this.errors = v.errors;
        return valid;
      }
      compile(schema, _meta) {
        const sch = this._addSchema(schema, _meta);
        return sch.validate || this._compileSchemaEnv(sch);
      }
      compileAsync(schema, meta) {
        if (typeof this.opts.loadSchema != "function") {
          throw new Error("options.loadSchema should be a function");
        }
        const { loadSchema } = this.opts;
        return runCompileAsync.call(this, schema, meta);
        async function runCompileAsync(_schema, _meta) {
          await loadMetaSchema.call(this, _schema.$schema);
          const sch = this._addSchema(_schema, _meta);
          return sch.validate || _compileAsync.call(this, sch);
        }
        async function loadMetaSchema($ref) {
          if ($ref && !this.getSchema($ref)) {
            await runCompileAsync.call(this, { $ref }, true);
          }
        }
        async function _compileAsync(sch) {
          try {
            return this._compileSchemaEnv(sch);
          } catch (e) {
            if (!(e instanceof ref_error_1.default))
              throw e;
            checkLoaded.call(this, e);
            await loadMissingSchema.call(this, e.missingSchema);
            return _compileAsync.call(this, sch);
          }
        }
        function checkLoaded({ missingSchema: ref, missingRef }) {
          if (this.refs[ref]) {
            throw new Error(`AnySchema ${ref} is loaded but ${missingRef} cannot be resolved`);
          }
        }
        async function loadMissingSchema(ref) {
          const _schema = await _loadSchema.call(this, ref);
          if (!this.refs[ref])
            await loadMetaSchema.call(this, _schema.$schema);
          if (!this.refs[ref])
            this.addSchema(_schema, ref, meta);
        }
        async function _loadSchema(ref) {
          const p = this._loading[ref];
          if (p)
            return p;
          try {
            return await (this._loading[ref] = loadSchema(ref));
          } finally {
            delete this._loading[ref];
          }
        }
      }
      // Adds schema to the instance
      addSchema(schema, key, _meta, _validateSchema = this.opts.validateSchema) {
        if (Array.isArray(schema)) {
          for (const sch of schema)
            this.addSchema(sch, void 0, _meta, _validateSchema);
          return this;
        }
        let id3;
        if (typeof schema === "object") {
          const { schemaId } = this.opts;
          id3 = schema[schemaId];
          if (id3 !== void 0 && typeof id3 != "string") {
            throw new Error(`schema ${schemaId} must be string`);
          }
        }
        key = (0, resolve_1.normalizeId)(key || id3);
        this._checkUnique(key);
        this.schemas[key] = this._addSchema(schema, _meta, key, _validateSchema, true);
        return this;
      }
      // Add schema that will be used to validate other schemas
      // options in META_IGNORE_OPTIONS are alway set to false
      addMetaSchema(schema, key, _validateSchema = this.opts.validateSchema) {
        this.addSchema(schema, key, true, _validateSchema);
        return this;
      }
      //  Validate schema against its meta-schema
      validateSchema(schema, throwOrLogError) {
        if (typeof schema == "boolean")
          return true;
        let $schema;
        $schema = schema.$schema;
        if ($schema !== void 0 && typeof $schema != "string") {
          throw new Error("$schema must be a string");
        }
        $schema = $schema || this.opts.defaultMeta || this.defaultMeta();
        if (!$schema) {
          this.logger.warn("meta-schema not available");
          this.errors = null;
          return true;
        }
        const valid = this.validate($schema, schema);
        if (!valid && throwOrLogError) {
          const message2 = "schema is invalid: " + this.errorsText();
          if (this.opts.validateSchema === "log")
            this.logger.error(message2);
          else
            throw new Error(message2);
        }
        return valid;
      }
      // Get compiled schema by `key` or `ref`.
      // (`key` that was passed to `addSchema` or full schema reference - `schema.$id` or resolved id)
      getSchema(keyRef) {
        let sch;
        while (typeof (sch = getSchEnv.call(this, keyRef)) == "string")
          keyRef = sch;
        if (sch === void 0) {
          const { schemaId } = this.opts;
          const root = new compile_1.SchemaEnv({ schema: {}, schemaId });
          sch = compile_1.resolveSchema.call(this, root, keyRef);
          if (!sch)
            return;
          this.refs[keyRef] = sch;
        }
        return sch.validate || this._compileSchemaEnv(sch);
      }
      // Remove cached schema(s).
      // If no parameter is passed all schemas but meta-schemas are removed.
      // If RegExp is passed all schemas with key/id matching pattern but meta-schemas are removed.
      // Even if schema is referenced by other schemas it still can be removed as other schemas have local references.
      removeSchema(schemaKeyRef) {
        if (schemaKeyRef instanceof RegExp) {
          this._removeAllSchemas(this.schemas, schemaKeyRef);
          this._removeAllSchemas(this.refs, schemaKeyRef);
          return this;
        }
        switch (typeof schemaKeyRef) {
          case "undefined":
            this._removeAllSchemas(this.schemas);
            this._removeAllSchemas(this.refs);
            this._cache.clear();
            return this;
          case "string": {
            const sch = getSchEnv.call(this, schemaKeyRef);
            if (typeof sch == "object")
              this._cache.delete(sch.schema);
            delete this.schemas[schemaKeyRef];
            delete this.refs[schemaKeyRef];
            return this;
          }
          case "object": {
            const cacheKey = schemaKeyRef;
            this._cache.delete(cacheKey);
            let id3 = schemaKeyRef[this.opts.schemaId];
            if (id3) {
              id3 = (0, resolve_1.normalizeId)(id3);
              delete this.schemas[id3];
              delete this.refs[id3];
            }
            return this;
          }
          default:
            throw new Error("ajv.removeSchema: invalid parameter");
        }
      }
      // add "vocabulary" - a collection of keywords
      addVocabulary(definitions) {
        for (const def of definitions)
          this.addKeyword(def);
        return this;
      }
      addKeyword(kwdOrDef, def) {
        let keyword;
        if (typeof kwdOrDef == "string") {
          keyword = kwdOrDef;
          if (typeof def == "object") {
            this.logger.warn("these parameters are deprecated, see docs for addKeyword");
            def.keyword = keyword;
          }
        } else if (typeof kwdOrDef == "object" && def === void 0) {
          def = kwdOrDef;
          keyword = def.keyword;
          if (Array.isArray(keyword) && !keyword.length) {
            throw new Error("addKeywords: keyword must be string or non-empty array");
          }
        } else {
          throw new Error("invalid addKeywords parameters");
        }
        checkKeyword.call(this, keyword, def);
        if (!def) {
          (0, util_1.eachItem)(keyword, (kwd) => addRule.call(this, kwd));
          return this;
        }
        keywordMetaschema.call(this, def);
        const definition = {
          ...def,
          type: (0, dataType_1.getJSONTypes)(def.type),
          schemaType: (0, dataType_1.getJSONTypes)(def.schemaType)
        };
        (0, util_1.eachItem)(keyword, definition.type.length === 0 ? (k) => addRule.call(this, k, definition) : (k) => definition.type.forEach((t) => addRule.call(this, k, definition, t)));
        return this;
      }
      getKeyword(keyword) {
        const rule = this.RULES.all[keyword];
        return typeof rule == "object" ? rule.definition : !!rule;
      }
      // Remove keyword
      removeKeyword(keyword) {
        const { RULES } = this;
        delete RULES.keywords[keyword];
        delete RULES.all[keyword];
        for (const group of RULES.rules) {
          const i = group.rules.findIndex((rule) => rule.keyword === keyword);
          if (i >= 0)
            group.rules.splice(i, 1);
        }
        return this;
      }
      // Add format
      addFormat(name, format) {
        if (typeof format == "string")
          format = new RegExp(format);
        this.formats[name] = format;
        return this;
      }
      errorsText(errors = this.errors, { separator = ", ", dataVar = "data" } = {}) {
        if (!errors || errors.length === 0)
          return "No errors";
        return errors.map((e) => `${dataVar}${e.instancePath} ${e.message}`).reduce((text2, msg) => text2 + separator + msg);
      }
      $dataMetaSchema(metaSchema, keywordsJsonPointers) {
        const rules = this.RULES.all;
        metaSchema = JSON.parse(JSON.stringify(metaSchema));
        for (const jsonPointer of keywordsJsonPointers) {
          const segments = jsonPointer.split("/").slice(1);
          let keywords = metaSchema;
          for (const seg of segments)
            keywords = keywords[seg];
          for (const key in rules) {
            const rule = rules[key];
            if (typeof rule != "object")
              continue;
            const { $data } = rule.definition;
            const schema = keywords[key];
            if ($data && schema)
              keywords[key] = schemaOrData(schema);
          }
        }
        return metaSchema;
      }
      _removeAllSchemas(schemas, regex) {
        for (const keyRef in schemas) {
          const sch = schemas[keyRef];
          if (!regex || regex.test(keyRef)) {
            if (typeof sch == "string") {
              delete schemas[keyRef];
            } else if (sch && !sch.meta) {
              this._cache.delete(sch.schema);
              delete schemas[keyRef];
            }
          }
        }
      }
      _addSchema(schema, meta, baseId, validateSchema = this.opts.validateSchema, addSchema = this.opts.addUsedSchema) {
        let id3;
        const { schemaId } = this.opts;
        if (typeof schema == "object") {
          id3 = schema[schemaId];
        } else {
          if (this.opts.jtd)
            throw new Error("schema must be object");
          else if (typeof schema != "boolean")
            throw new Error("schema must be object or boolean");
        }
        let sch = this._cache.get(schema);
        if (sch !== void 0)
          return sch;
        baseId = (0, resolve_1.normalizeId)(id3 || baseId);
        const localRefs = resolve_1.getSchemaRefs.call(this, schema, baseId);
        sch = new compile_1.SchemaEnv({ schema, schemaId, meta, baseId, localRefs });
        this._cache.set(sch.schema, sch);
        if (addSchema && !baseId.startsWith("#")) {
          if (baseId)
            this._checkUnique(baseId);
          this.refs[baseId] = sch;
        }
        if (validateSchema)
          this.validateSchema(schema, true);
        return sch;
      }
      _checkUnique(id3) {
        if (this.schemas[id3] || this.refs[id3]) {
          throw new Error(`schema with key or id "${id3}" already exists`);
        }
      }
      _compileSchemaEnv(sch) {
        if (sch.meta)
          this._compileMetaSchema(sch);
        else
          compile_1.compileSchema.call(this, sch);
        if (!sch.validate)
          throw new Error("ajv implementation error");
        return sch.validate;
      }
      _compileMetaSchema(sch) {
        const currentOpts = this.opts;
        this.opts = this._metaOpts;
        try {
          compile_1.compileSchema.call(this, sch);
        } finally {
          this.opts = currentOpts;
        }
      }
    };
    Ajv2.ValidationError = validation_error_1.default;
    Ajv2.MissingRefError = ref_error_1.default;
    exports.default = Ajv2;
    function checkOptions(checkOpts, options, msg, log = "error") {
      for (const key in checkOpts) {
        const opt = key;
        if (opt in options)
          this.logger[log](`${msg}: option ${key}. ${checkOpts[opt]}`);
      }
    }
    function getSchEnv(keyRef) {
      keyRef = (0, resolve_1.normalizeId)(keyRef);
      return this.schemas[keyRef] || this.refs[keyRef];
    }
    function addInitialSchemas() {
      const optsSchemas = this.opts.schemas;
      if (!optsSchemas)
        return;
      if (Array.isArray(optsSchemas))
        this.addSchema(optsSchemas);
      else
        for (const key in optsSchemas)
          this.addSchema(optsSchemas[key], key);
    }
    function addInitialFormats() {
      for (const name in this.opts.formats) {
        const format = this.opts.formats[name];
        if (format)
          this.addFormat(name, format);
      }
    }
    function addInitialKeywords(defs) {
      if (Array.isArray(defs)) {
        this.addVocabulary(defs);
        return;
      }
      this.logger.warn("keywords option as map is deprecated, pass array");
      for (const keyword in defs) {
        const def = defs[keyword];
        if (!def.keyword)
          def.keyword = keyword;
        this.addKeyword(def);
      }
    }
    function getMetaSchemaOptions() {
      const metaOpts = { ...this.opts };
      for (const opt of META_IGNORE_OPTIONS)
        delete metaOpts[opt];
      return metaOpts;
    }
    var noLogs = { log() {
    }, warn() {
    }, error() {
    } };
    function getLogger(logger) {
      if (logger === false)
        return noLogs;
      if (logger === void 0)
        return console;
      if (logger.log && logger.warn && logger.error)
        return logger;
      throw new Error("logger must implement log, warn and error methods");
    }
    var KEYWORD_NAME = /^[a-z_$][a-z0-9_$:-]*$/i;
    function checkKeyword(keyword, def) {
      const { RULES } = this;
      (0, util_1.eachItem)(keyword, (kwd) => {
        if (RULES.keywords[kwd])
          throw new Error(`Keyword ${kwd} is already defined`);
        if (!KEYWORD_NAME.test(kwd))
          throw new Error(`Keyword ${kwd} has invalid name`);
      });
      if (!def)
        return;
      if (def.$data && !("code" in def || "validate" in def)) {
        throw new Error('$data keyword must have "code" or "validate" function');
      }
    }
    function addRule(keyword, definition, dataType) {
      var _a;
      const post = definition === null || definition === void 0 ? void 0 : definition.post;
      if (dataType && post)
        throw new Error('keyword with "post" flag cannot have "type"');
      const { RULES } = this;
      let ruleGroup = post ? RULES.post : RULES.rules.find(({ type: t }) => t === dataType);
      if (!ruleGroup) {
        ruleGroup = { type: dataType, rules: [] };
        RULES.rules.push(ruleGroup);
      }
      RULES.keywords[keyword] = true;
      if (!definition)
        return;
      const rule = {
        keyword,
        definition: {
          ...definition,
          type: (0, dataType_1.getJSONTypes)(definition.type),
          schemaType: (0, dataType_1.getJSONTypes)(definition.schemaType)
        }
      };
      if (definition.before)
        addBeforeRule.call(this, ruleGroup, rule, definition.before);
      else
        ruleGroup.rules.push(rule);
      RULES.all[keyword] = rule;
      (_a = definition.implements) === null || _a === void 0 ? void 0 : _a.forEach((kwd) => this.addKeyword(kwd));
    }
    function addBeforeRule(ruleGroup, rule, before) {
      const i = ruleGroup.rules.findIndex((_rule) => _rule.keyword === before);
      if (i >= 0) {
        ruleGroup.rules.splice(i, 0, rule);
      } else {
        ruleGroup.rules.push(rule);
        this.logger.warn(`rule ${before} is not defined`);
      }
    }
    function keywordMetaschema(def) {
      let { metaSchema } = def;
      if (metaSchema === void 0)
        return;
      if (def.$data && this.opts.$data)
        metaSchema = schemaOrData(metaSchema);
      def.validateSchema = this.compile(metaSchema, true);
    }
    var $dataRef = {
      $ref: "https://raw.githubusercontent.com/ajv-validator/ajv/master/lib/refs/data.json#"
    };
    function schemaOrData(schema) {
      return { anyOf: [schema, $dataRef] };
    }
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/core/id.js
var require_id = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/core/id.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var def = {
      keyword: "id",
      code() {
        throw new Error('NOT SUPPORTED: keyword "id", use "$id" for schema ID');
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/core/ref.js
var require_ref = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/core/ref.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.callRef = exports.getValidate = void 0;
    var ref_error_1 = require_ref_error();
    var code_1 = require_code2();
    var codegen_1 = require_codegen();
    var names_1 = require_names();
    var compile_1 = require_compile();
    var util_1 = require_util();
    var def = {
      keyword: "$ref",
      schemaType: "string",
      code(cxt) {
        const { gen, schema: $ref, it } = cxt;
        const { baseId, schemaEnv: env, validateName, opts, self } = it;
        const { root } = env;
        if (($ref === "#" || $ref === "#/") && baseId === root.baseId)
          return callRootRef();
        const schOrEnv = compile_1.resolveRef.call(self, root, baseId, $ref);
        if (schOrEnv === void 0)
          throw new ref_error_1.default(it.opts.uriResolver, baseId, $ref);
        if (schOrEnv instanceof compile_1.SchemaEnv)
          return callValidate(schOrEnv);
        return inlineRefSchema(schOrEnv);
        function callRootRef() {
          if (env === root)
            return callRef(cxt, validateName, env, env.$async);
          const rootName = gen.scopeValue("root", { ref: root });
          return callRef(cxt, (0, codegen_1._)`${rootName}.validate`, root, root.$async);
        }
        function callValidate(sch) {
          const v = getValidate(cxt, sch);
          callRef(cxt, v, sch, sch.$async);
        }
        function inlineRefSchema(sch) {
          const schName = gen.scopeValue("schema", opts.code.source === true ? { ref: sch, code: (0, codegen_1.stringify)(sch) } : { ref: sch });
          const valid = gen.name("valid");
          const schCxt = cxt.subschema({
            schema: sch,
            dataTypes: [],
            schemaPath: codegen_1.nil,
            topSchemaRef: schName,
            errSchemaPath: $ref
          }, valid);
          cxt.mergeEvaluated(schCxt);
          cxt.ok(valid);
        }
      }
    };
    function getValidate(cxt, sch) {
      const { gen } = cxt;
      return sch.validate ? gen.scopeValue("validate", { ref: sch.validate }) : (0, codegen_1._)`${gen.scopeValue("wrapper", { ref: sch })}.validate`;
    }
    exports.getValidate = getValidate;
    function callRef(cxt, v, sch, $async) {
      const { gen, it } = cxt;
      const { allErrors, schemaEnv: env, opts } = it;
      const passCxt = opts.passContext ? names_1.default.this : codegen_1.nil;
      if ($async)
        callAsyncRef();
      else
        callSyncRef();
      function callAsyncRef() {
        if (!env.$async)
          throw new Error("async schema referenced by sync schema");
        const valid = gen.let("valid");
        gen.try(() => {
          gen.code((0, codegen_1._)`await ${(0, code_1.callValidateCode)(cxt, v, passCxt)}`);
          addEvaluatedFrom(v);
          if (!allErrors)
            gen.assign(valid, true);
        }, (e) => {
          gen.if((0, codegen_1._)`!(${e} instanceof ${it.ValidationError})`, () => gen.throw(e));
          addErrorsFrom(e);
          if (!allErrors)
            gen.assign(valid, false);
        });
        cxt.ok(valid);
      }
      function callSyncRef() {
        cxt.result((0, code_1.callValidateCode)(cxt, v, passCxt), () => addEvaluatedFrom(v), () => addErrorsFrom(v));
      }
      function addErrorsFrom(source) {
        const errs = (0, codegen_1._)`${source}.errors`;
        gen.assign(names_1.default.vErrors, (0, codegen_1._)`${names_1.default.vErrors} === null ? ${errs} : ${names_1.default.vErrors}.concat(${errs})`);
        gen.assign(names_1.default.errors, (0, codegen_1._)`${names_1.default.vErrors}.length`);
      }
      function addEvaluatedFrom(source) {
        var _a;
        if (!it.opts.unevaluated)
          return;
        const schEvaluated = (_a = sch === null || sch === void 0 ? void 0 : sch.validate) === null || _a === void 0 ? void 0 : _a.evaluated;
        if (it.props !== true) {
          if (schEvaluated && !schEvaluated.dynamicProps) {
            if (schEvaluated.props !== void 0) {
              it.props = util_1.mergeEvaluated.props(gen, schEvaluated.props, it.props);
            }
          } else {
            const props = gen.var("props", (0, codegen_1._)`${source}.evaluated.props`);
            it.props = util_1.mergeEvaluated.props(gen, props, it.props, codegen_1.Name);
          }
        }
        if (it.items !== true) {
          if (schEvaluated && !schEvaluated.dynamicItems) {
            if (schEvaluated.items !== void 0) {
              it.items = util_1.mergeEvaluated.items(gen, schEvaluated.items, it.items);
            }
          } else {
            const items = gen.var("items", (0, codegen_1._)`${source}.evaluated.items`);
            it.items = util_1.mergeEvaluated.items(gen, items, it.items, codegen_1.Name);
          }
        }
      }
    }
    exports.callRef = callRef;
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/core/index.js
var require_core2 = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/core/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var id_1 = require_id();
    var ref_1 = require_ref();
    var core = [
      "$schema",
      "$id",
      "$defs",
      "$vocabulary",
      { keyword: "$comment" },
      "definitions",
      id_1.default,
      ref_1.default
    ];
    exports.default = core;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitNumber.js
var require_limitNumber = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitNumber.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var ops = codegen_1.operators;
    var KWDs = {
      maximum: { okStr: "<=", ok: ops.LTE, fail: ops.GT },
      minimum: { okStr: ">=", ok: ops.GTE, fail: ops.LT },
      exclusiveMaximum: { okStr: "<", ok: ops.LT, fail: ops.GTE },
      exclusiveMinimum: { okStr: ">", ok: ops.GT, fail: ops.LTE }
    };
    var error3 = {
      message: ({ keyword, schemaCode }) => (0, codegen_1.str)`must be ${KWDs[keyword].okStr} ${schemaCode}`,
      params: ({ keyword, schemaCode }) => (0, codegen_1._)`{comparison: ${KWDs[keyword].okStr}, limit: ${schemaCode}}`
    };
    var def = {
      keyword: Object.keys(KWDs),
      type: "number",
      schemaType: "number",
      $data: true,
      error: error3,
      code(cxt) {
        const { keyword, data, schemaCode } = cxt;
        cxt.fail$data((0, codegen_1._)`${data} ${KWDs[keyword].fail} ${schemaCode} || isNaN(${data})`);
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/multipleOf.js
var require_multipleOf = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/multipleOf.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var error3 = {
      message: ({ schemaCode }) => (0, codegen_1.str)`must be multiple of ${schemaCode}`,
      params: ({ schemaCode }) => (0, codegen_1._)`{multipleOf: ${schemaCode}}`
    };
    var def = {
      keyword: "multipleOf",
      type: "number",
      schemaType: "number",
      $data: true,
      error: error3,
      code(cxt) {
        const { gen, data, schemaCode, it } = cxt;
        const prec = it.opts.multipleOfPrecision;
        const res = gen.let("res");
        const invalid = prec ? (0, codegen_1._)`Math.abs(Math.round(${res}) - ${res}) > 1e-${prec}` : (0, codegen_1._)`${res} !== parseInt(${res})`;
        cxt.fail$data((0, codegen_1._)`(${schemaCode} === 0 || (${res} = ${data}/${schemaCode}, ${invalid}))`);
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/ucs2length.js
var require_ucs2length = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/ucs2length.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function ucs2length(str) {
      const len = str.length;
      let length = 0;
      let pos = 0;
      let value2;
      while (pos < len) {
        length++;
        value2 = str.charCodeAt(pos++);
        if (value2 >= 55296 && value2 <= 56319 && pos < len) {
          value2 = str.charCodeAt(pos);
          if ((value2 & 64512) === 56320)
            pos++;
        }
      }
      return length;
    }
    exports.default = ucs2length;
    ucs2length.code = 'require("ajv/dist/runtime/ucs2length").default';
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitLength.js
var require_limitLength = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitLength.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var ucs2length_1 = require_ucs2length();
    var error3 = {
      message({ keyword, schemaCode }) {
        const comp = keyword === "maxLength" ? "more" : "fewer";
        return (0, codegen_1.str)`must NOT have ${comp} than ${schemaCode} characters`;
      },
      params: ({ schemaCode }) => (0, codegen_1._)`{limit: ${schemaCode}}`
    };
    var def = {
      keyword: ["maxLength", "minLength"],
      type: "string",
      schemaType: "number",
      $data: true,
      error: error3,
      code(cxt) {
        const { keyword, data, schemaCode, it } = cxt;
        const op = keyword === "maxLength" ? codegen_1.operators.GT : codegen_1.operators.LT;
        const len = it.opts.unicode === false ? (0, codegen_1._)`${data}.length` : (0, codegen_1._)`${(0, util_1.useFunc)(cxt.gen, ucs2length_1.default)}(${data})`;
        cxt.fail$data((0, codegen_1._)`${len} ${op} ${schemaCode}`);
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/pattern.js
var require_pattern = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/pattern.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var code_1 = require_code2();
    var util_1 = require_util();
    var codegen_1 = require_codegen();
    var error3 = {
      message: ({ schemaCode }) => (0, codegen_1.str)`must match pattern "${schemaCode}"`,
      params: ({ schemaCode }) => (0, codegen_1._)`{pattern: ${schemaCode}}`
    };
    var def = {
      keyword: "pattern",
      type: "string",
      schemaType: "string",
      $data: true,
      error: error3,
      code(cxt) {
        const { gen, data, $data, schema, schemaCode, it } = cxt;
        const u = it.opts.unicodeRegExp ? "u" : "";
        if ($data) {
          const { regExp } = it.opts.code;
          const regExpCode = regExp.code === "new RegExp" ? (0, codegen_1._)`new RegExp` : (0, util_1.useFunc)(gen, regExp);
          const valid = gen.let("valid");
          gen.try(() => gen.assign(valid, (0, codegen_1._)`${regExpCode}(${schemaCode}, ${u}).test(${data})`), () => gen.assign(valid, false));
          cxt.fail$data((0, codegen_1._)`!${valid}`);
        } else {
          const regExp = (0, code_1.usePattern)(cxt, schema);
          cxt.fail$data((0, codegen_1._)`!${regExp}.test(${data})`);
        }
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitProperties.js
var require_limitProperties = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitProperties.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var error3 = {
      message({ keyword, schemaCode }) {
        const comp = keyword === "maxProperties" ? "more" : "fewer";
        return (0, codegen_1.str)`must NOT have ${comp} than ${schemaCode} properties`;
      },
      params: ({ schemaCode }) => (0, codegen_1._)`{limit: ${schemaCode}}`
    };
    var def = {
      keyword: ["maxProperties", "minProperties"],
      type: "object",
      schemaType: "number",
      $data: true,
      error: error3,
      code(cxt) {
        const { keyword, data, schemaCode } = cxt;
        const op = keyword === "maxProperties" ? codegen_1.operators.GT : codegen_1.operators.LT;
        cxt.fail$data((0, codegen_1._)`Object.keys(${data}).length ${op} ${schemaCode}`);
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/required.js
var require_required = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/required.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var code_1 = require_code2();
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var error3 = {
      message: ({ params: { missingProperty } }) => (0, codegen_1.str)`must have required property '${missingProperty}'`,
      params: ({ params: { missingProperty } }) => (0, codegen_1._)`{missingProperty: ${missingProperty}}`
    };
    var def = {
      keyword: "required",
      type: "object",
      schemaType: "array",
      $data: true,
      error: error3,
      code(cxt) {
        const { gen, schema, schemaCode, data, $data, it } = cxt;
        const { opts } = it;
        if (!$data && schema.length === 0)
          return;
        const useLoop = schema.length >= opts.loopRequired;
        if (it.allErrors)
          allErrorsMode();
        else
          exitOnErrorMode();
        if (opts.strictRequired) {
          const props = cxt.parentSchema.properties;
          const { definedProperties } = cxt.it;
          for (const requiredKey of schema) {
            if ((props === null || props === void 0 ? void 0 : props[requiredKey]) === void 0 && !definedProperties.has(requiredKey)) {
              const schemaPath = it.schemaEnv.baseId + it.errSchemaPath;
              const msg = `required property "${requiredKey}" is not defined at "${schemaPath}" (strictRequired)`;
              (0, util_1.checkStrictMode)(it, msg, it.opts.strictRequired);
            }
          }
        }
        function allErrorsMode() {
          if (useLoop || $data) {
            cxt.block$data(codegen_1.nil, loopAllRequired);
          } else {
            for (const prop of schema) {
              (0, code_1.checkReportMissingProp)(cxt, prop);
            }
          }
        }
        function exitOnErrorMode() {
          const missing = gen.let("missing");
          if (useLoop || $data) {
            const valid = gen.let("valid", true);
            cxt.block$data(valid, () => loopUntilMissing(missing, valid));
            cxt.ok(valid);
          } else {
            gen.if((0, code_1.checkMissingProp)(cxt, schema, missing));
            (0, code_1.reportMissingProp)(cxt, missing);
            gen.else();
          }
        }
        function loopAllRequired() {
          gen.forOf("prop", schemaCode, (prop) => {
            cxt.setParams({ missingProperty: prop });
            gen.if((0, code_1.noPropertyInData)(gen, data, prop, opts.ownProperties), () => cxt.error());
          });
        }
        function loopUntilMissing(missing, valid) {
          cxt.setParams({ missingProperty: missing });
          gen.forOf(missing, schemaCode, () => {
            gen.assign(valid, (0, code_1.propertyInData)(gen, data, missing, opts.ownProperties));
            gen.if((0, codegen_1.not)(valid), () => {
              cxt.error();
              gen.break();
            });
          }, codegen_1.nil);
        }
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitItems.js
var require_limitItems = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/limitItems.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var error3 = {
      message({ keyword, schemaCode }) {
        const comp = keyword === "maxItems" ? "more" : "fewer";
        return (0, codegen_1.str)`must NOT have ${comp} than ${schemaCode} items`;
      },
      params: ({ schemaCode }) => (0, codegen_1._)`{limit: ${schemaCode}}`
    };
    var def = {
      keyword: ["maxItems", "minItems"],
      type: "array",
      schemaType: "number",
      $data: true,
      error: error3,
      code(cxt) {
        const { keyword, data, schemaCode } = cxt;
        const op = keyword === "maxItems" ? codegen_1.operators.GT : codegen_1.operators.LT;
        cxt.fail$data((0, codegen_1._)`${data}.length ${op} ${schemaCode}`);
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/equal.js
var require_equal = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/runtime/equal.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var equal = require_fast_deep_equal();
    equal.code = 'require("ajv/dist/runtime/equal").default';
    exports.default = equal;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/uniqueItems.js
var require_uniqueItems = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/uniqueItems.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var dataType_1 = require_dataType();
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var equal_1 = require_equal();
    var error3 = {
      message: ({ params: { i, j } }) => (0, codegen_1.str)`must NOT have duplicate items (items ## ${j} and ${i} are identical)`,
      params: ({ params: { i, j } }) => (0, codegen_1._)`{i: ${i}, j: ${j}}`
    };
    var def = {
      keyword: "uniqueItems",
      type: "array",
      schemaType: "boolean",
      $data: true,
      error: error3,
      code(cxt) {
        const { gen, data, $data, schema, parentSchema, schemaCode, it } = cxt;
        if (!$data && !schema)
          return;
        const valid = gen.let("valid");
        const itemTypes = parentSchema.items ? (0, dataType_1.getSchemaTypes)(parentSchema.items) : [];
        cxt.block$data(valid, validateUniqueItems, (0, codegen_1._)`${schemaCode} === false`);
        cxt.ok(valid);
        function validateUniqueItems() {
          const i = gen.let("i", (0, codegen_1._)`${data}.length`);
          const j = gen.let("j");
          cxt.setParams({ i, j });
          gen.assign(valid, true);
          gen.if((0, codegen_1._)`${i} > 1`, () => (canOptimize() ? loopN : loopN2)(i, j));
        }
        function canOptimize() {
          return itemTypes.length > 0 && !itemTypes.some((t) => t === "object" || t === "array");
        }
        function loopN(i, j) {
          const item = gen.name("item");
          const wrongType = (0, dataType_1.checkDataTypes)(itemTypes, item, it.opts.strictNumbers, dataType_1.DataType.Wrong);
          const indices = gen.const("indices", (0, codegen_1._)`{}`);
          gen.for((0, codegen_1._)`;${i}--;`, () => {
            gen.let(item, (0, codegen_1._)`${data}[${i}]`);
            gen.if(wrongType, (0, codegen_1._)`continue`);
            if (itemTypes.length > 1)
              gen.if((0, codegen_1._)`typeof ${item} == "string"`, (0, codegen_1._)`${item} += "_"`);
            gen.if((0, codegen_1._)`typeof ${indices}[${item}] == "number"`, () => {
              gen.assign(j, (0, codegen_1._)`${indices}[${item}]`);
              cxt.error();
              gen.assign(valid, false).break();
            }).code((0, codegen_1._)`${indices}[${item}] = ${i}`);
          });
        }
        function loopN2(i, j) {
          const eql = (0, util_1.useFunc)(gen, equal_1.default);
          const outer = gen.name("outer");
          gen.label(outer).for((0, codegen_1._)`;${i}--;`, () => gen.for((0, codegen_1._)`${j} = ${i}; ${j}--;`, () => gen.if((0, codegen_1._)`${eql}(${data}[${i}], ${data}[${j}])`, () => {
            cxt.error();
            gen.assign(valid, false).break(outer);
          })));
        }
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/const.js
var require_const = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/const.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var equal_1 = require_equal();
    var error3 = {
      message: "must be equal to constant",
      params: ({ schemaCode }) => (0, codegen_1._)`{allowedValue: ${schemaCode}}`
    };
    var def = {
      keyword: "const",
      $data: true,
      error: error3,
      code(cxt) {
        const { gen, data, $data, schemaCode, schema } = cxt;
        if ($data || schema && typeof schema == "object") {
          cxt.fail$data((0, codegen_1._)`!${(0, util_1.useFunc)(gen, equal_1.default)}(${data}, ${schemaCode})`);
        } else {
          cxt.fail((0, codegen_1._)`${schema} !== ${data}`);
        }
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/enum.js
var require_enum = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/enum.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var equal_1 = require_equal();
    var error3 = {
      message: "must be equal to one of the allowed values",
      params: ({ schemaCode }) => (0, codegen_1._)`{allowedValues: ${schemaCode}}`
    };
    var def = {
      keyword: "enum",
      schemaType: "array",
      $data: true,
      error: error3,
      code(cxt) {
        const { gen, data, $data, schema, schemaCode, it } = cxt;
        if (!$data && schema.length === 0)
          throw new Error("enum must have non-empty array");
        const useLoop = schema.length >= it.opts.loopEnum;
        let eql;
        const getEql = () => eql !== null && eql !== void 0 ? eql : eql = (0, util_1.useFunc)(gen, equal_1.default);
        let valid;
        if (useLoop || $data) {
          valid = gen.let("valid");
          cxt.block$data(valid, loopEnum);
        } else {
          if (!Array.isArray(schema))
            throw new Error("ajv implementation error");
          const vSchema = gen.const("vSchema", schemaCode);
          valid = (0, codegen_1.or)(...schema.map((_x, i) => equalCode(vSchema, i)));
        }
        cxt.pass(valid);
        function loopEnum() {
          gen.assign(valid, false);
          gen.forOf("v", schemaCode, (v) => gen.if((0, codegen_1._)`${getEql()}(${data}, ${v})`, () => gen.assign(valid, true).break()));
        }
        function equalCode(vSchema, i) {
          const sch = schema[i];
          return typeof sch === "object" && sch !== null ? (0, codegen_1._)`${getEql()}(${data}, ${vSchema}[${i}])` : (0, codegen_1._)`${data} === ${sch}`;
        }
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/index.js
var require_validation = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/validation/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var limitNumber_1 = require_limitNumber();
    var multipleOf_1 = require_multipleOf();
    var limitLength_1 = require_limitLength();
    var pattern_1 = require_pattern();
    var limitProperties_1 = require_limitProperties();
    var required_1 = require_required();
    var limitItems_1 = require_limitItems();
    var uniqueItems_1 = require_uniqueItems();
    var const_1 = require_const();
    var enum_1 = require_enum();
    var validation3 = [
      // number
      limitNumber_1.default,
      multipleOf_1.default,
      // string
      limitLength_1.default,
      pattern_1.default,
      // object
      limitProperties_1.default,
      required_1.default,
      // array
      limitItems_1.default,
      uniqueItems_1.default,
      // any
      { keyword: "type", schemaType: ["string", "array"] },
      { keyword: "nullable", schemaType: "boolean" },
      const_1.default,
      enum_1.default
    ];
    exports.default = validation3;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/additionalItems.js
var require_additionalItems = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/additionalItems.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateAdditionalItems = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var error3 = {
      message: ({ params: { len } }) => (0, codegen_1.str)`must NOT have more than ${len} items`,
      params: ({ params: { len } }) => (0, codegen_1._)`{limit: ${len}}`
    };
    var def = {
      keyword: "additionalItems",
      type: "array",
      schemaType: ["boolean", "object"],
      before: "uniqueItems",
      error: error3,
      code(cxt) {
        const { parentSchema, it } = cxt;
        const { items } = parentSchema;
        if (!Array.isArray(items)) {
          (0, util_1.checkStrictMode)(it, '"additionalItems" is ignored when "items" is not an array of schemas');
          return;
        }
        validateAdditionalItems(cxt, items);
      }
    };
    function validateAdditionalItems(cxt, items) {
      const { gen, schema, data, keyword, it } = cxt;
      it.items = true;
      const len = gen.const("len", (0, codegen_1._)`${data}.length`);
      if (schema === false) {
        cxt.setParams({ len: items.length });
        cxt.pass((0, codegen_1._)`${len} <= ${items.length}`);
      } else if (typeof schema == "object" && !(0, util_1.alwaysValidSchema)(it, schema)) {
        const valid = gen.var("valid", (0, codegen_1._)`${len} <= ${items.length}`);
        gen.if((0, codegen_1.not)(valid), () => validateItems(valid));
        cxt.ok(valid);
      }
      function validateItems(valid) {
        gen.forRange("i", items.length, len, (i) => {
          cxt.subschema({ keyword, dataProp: i, dataPropType: util_1.Type.Num }, valid);
          if (!it.allErrors)
            gen.if((0, codegen_1.not)(valid), () => gen.break());
        });
      }
    }
    exports.validateAdditionalItems = validateAdditionalItems;
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/items.js
var require_items = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/items.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateTuple = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var code_1 = require_code2();
    var def = {
      keyword: "items",
      type: "array",
      schemaType: ["object", "array", "boolean"],
      before: "uniqueItems",
      code(cxt) {
        const { schema, it } = cxt;
        if (Array.isArray(schema))
          return validateTuple(cxt, "additionalItems", schema);
        it.items = true;
        if ((0, util_1.alwaysValidSchema)(it, schema))
          return;
        cxt.ok((0, code_1.validateArray)(cxt));
      }
    };
    function validateTuple(cxt, extraItems, schArr = cxt.schema) {
      const { gen, parentSchema, data, keyword, it } = cxt;
      checkStrictTuple(parentSchema);
      if (it.opts.unevaluated && schArr.length && it.items !== true) {
        it.items = util_1.mergeEvaluated.items(gen, schArr.length, it.items);
      }
      const valid = gen.name("valid");
      const len = gen.const("len", (0, codegen_1._)`${data}.length`);
      schArr.forEach((sch, i) => {
        if ((0, util_1.alwaysValidSchema)(it, sch))
          return;
        gen.if((0, codegen_1._)`${len} > ${i}`, () => cxt.subschema({
          keyword,
          schemaProp: i,
          dataProp: i
        }, valid));
        cxt.ok(valid);
      });
      function checkStrictTuple(sch) {
        const { opts, errSchemaPath } = it;
        const l = schArr.length;
        const fullTuple = l === sch.minItems && (l === sch.maxItems || sch[extraItems] === false);
        if (opts.strictTuples && !fullTuple) {
          const msg = `"${keyword}" is ${l}-tuple, but minItems or maxItems/${extraItems} are not specified or different at path "${errSchemaPath}"`;
          (0, util_1.checkStrictMode)(it, msg, opts.strictTuples);
        }
      }
    }
    exports.validateTuple = validateTuple;
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/prefixItems.js
var require_prefixItems = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/prefixItems.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var items_1 = require_items();
    var def = {
      keyword: "prefixItems",
      type: "array",
      schemaType: ["array"],
      before: "uniqueItems",
      code: (cxt) => (0, items_1.validateTuple)(cxt, "items")
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/items2020.js
var require_items2020 = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/items2020.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var code_1 = require_code2();
    var additionalItems_1 = require_additionalItems();
    var error3 = {
      message: ({ params: { len } }) => (0, codegen_1.str)`must NOT have more than ${len} items`,
      params: ({ params: { len } }) => (0, codegen_1._)`{limit: ${len}}`
    };
    var def = {
      keyword: "items",
      type: "array",
      schemaType: ["object", "boolean"],
      before: "uniqueItems",
      error: error3,
      code(cxt) {
        const { schema, parentSchema, it } = cxt;
        const { prefixItems } = parentSchema;
        it.items = true;
        if ((0, util_1.alwaysValidSchema)(it, schema))
          return;
        if (prefixItems)
          (0, additionalItems_1.validateAdditionalItems)(cxt, prefixItems);
        else
          cxt.ok((0, code_1.validateArray)(cxt));
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/contains.js
var require_contains = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/contains.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var error3 = {
      message: ({ params: { min, max } }) => max === void 0 ? (0, codegen_1.str)`must contain at least ${min} valid item(s)` : (0, codegen_1.str)`must contain at least ${min} and no more than ${max} valid item(s)`,
      params: ({ params: { min, max } }) => max === void 0 ? (0, codegen_1._)`{minContains: ${min}}` : (0, codegen_1._)`{minContains: ${min}, maxContains: ${max}}`
    };
    var def = {
      keyword: "contains",
      type: "array",
      schemaType: ["object", "boolean"],
      before: "uniqueItems",
      trackErrors: true,
      error: error3,
      code(cxt) {
        const { gen, schema, parentSchema, data, it } = cxt;
        let min;
        let max;
        const { minContains, maxContains } = parentSchema;
        if (it.opts.next) {
          min = minContains === void 0 ? 1 : minContains;
          max = maxContains;
        } else {
          min = 1;
        }
        const len = gen.const("len", (0, codegen_1._)`${data}.length`);
        cxt.setParams({ min, max });
        if (max === void 0 && min === 0) {
          (0, util_1.checkStrictMode)(it, `"minContains" == 0 without "maxContains": "contains" keyword ignored`);
          return;
        }
        if (max !== void 0 && min > max) {
          (0, util_1.checkStrictMode)(it, `"minContains" > "maxContains" is always invalid`);
          cxt.fail();
          return;
        }
        if ((0, util_1.alwaysValidSchema)(it, schema)) {
          let cond = (0, codegen_1._)`${len} >= ${min}`;
          if (max !== void 0)
            cond = (0, codegen_1._)`${cond} && ${len} <= ${max}`;
          cxt.pass(cond);
          return;
        }
        it.items = true;
        const valid = gen.name("valid");
        if (max === void 0 && min === 1) {
          validateItems(valid, () => gen.if(valid, () => gen.break()));
        } else if (min === 0) {
          gen.let(valid, true);
          if (max !== void 0)
            gen.if((0, codegen_1._)`${data}.length > 0`, validateItemsWithCount);
        } else {
          gen.let(valid, false);
          validateItemsWithCount();
        }
        cxt.result(valid, () => cxt.reset());
        function validateItemsWithCount() {
          const schValid = gen.name("_valid");
          const count = gen.let("count", 0);
          validateItems(schValid, () => gen.if(schValid, () => checkLimits(count)));
        }
        function validateItems(_valid, block) {
          gen.forRange("i", 0, len, (i) => {
            cxt.subschema({
              keyword: "contains",
              dataProp: i,
              dataPropType: util_1.Type.Num,
              compositeRule: true
            }, _valid);
            block();
          });
        }
        function checkLimits(count) {
          gen.code((0, codegen_1._)`${count}++`);
          if (max === void 0) {
            gen.if((0, codegen_1._)`${count} >= ${min}`, () => gen.assign(valid, true).break());
          } else {
            gen.if((0, codegen_1._)`${count} > ${max}`, () => gen.assign(valid, false).break());
            if (min === 1)
              gen.assign(valid, true);
            else
              gen.if((0, codegen_1._)`${count} >= ${min}`, () => gen.assign(valid, true));
          }
        }
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/dependencies.js
var require_dependencies = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/dependencies.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.validateSchemaDeps = exports.validatePropertyDeps = exports.error = void 0;
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var code_1 = require_code2();
    exports.error = {
      message: ({ params: { property, depsCount, deps } }) => {
        const property_ies = depsCount === 1 ? "property" : "properties";
        return (0, codegen_1.str)`must have ${property_ies} ${deps} when property ${property} is present`;
      },
      params: ({ params: { property, depsCount, deps, missingProperty } }) => (0, codegen_1._)`{property: ${property},
    missingProperty: ${missingProperty},
    depsCount: ${depsCount},
    deps: ${deps}}`
      // TODO change to reference
    };
    var def = {
      keyword: "dependencies",
      type: "object",
      schemaType: "object",
      error: exports.error,
      code(cxt) {
        const [propDeps, schDeps] = splitDependencies(cxt);
        validatePropertyDeps(cxt, propDeps);
        validateSchemaDeps(cxt, schDeps);
      }
    };
    function splitDependencies({ schema }) {
      const propertyDeps = {};
      const schemaDeps = {};
      for (const key in schema) {
        if (key === "__proto__")
          continue;
        const deps = Array.isArray(schema[key]) ? propertyDeps : schemaDeps;
        deps[key] = schema[key];
      }
      return [propertyDeps, schemaDeps];
    }
    function validatePropertyDeps(cxt, propertyDeps = cxt.schema) {
      const { gen, data, it } = cxt;
      if (Object.keys(propertyDeps).length === 0)
        return;
      const missing = gen.let("missing");
      for (const prop in propertyDeps) {
        const deps = propertyDeps[prop];
        if (deps.length === 0)
          continue;
        const hasProperty = (0, code_1.propertyInData)(gen, data, prop, it.opts.ownProperties);
        cxt.setParams({
          property: prop,
          depsCount: deps.length,
          deps: deps.join(", ")
        });
        if (it.allErrors) {
          gen.if(hasProperty, () => {
            for (const depProp of deps) {
              (0, code_1.checkReportMissingProp)(cxt, depProp);
            }
          });
        } else {
          gen.if((0, codegen_1._)`${hasProperty} && (${(0, code_1.checkMissingProp)(cxt, deps, missing)})`);
          (0, code_1.reportMissingProp)(cxt, missing);
          gen.else();
        }
      }
    }
    exports.validatePropertyDeps = validatePropertyDeps;
    function validateSchemaDeps(cxt, schemaDeps = cxt.schema) {
      const { gen, data, keyword, it } = cxt;
      const valid = gen.name("valid");
      for (const prop in schemaDeps) {
        if ((0, util_1.alwaysValidSchema)(it, schemaDeps[prop]))
          continue;
        gen.if(
          (0, code_1.propertyInData)(gen, data, prop, it.opts.ownProperties),
          () => {
            const schCxt = cxt.subschema({ keyword, schemaProp: prop }, valid);
            cxt.mergeValidEvaluated(schCxt, valid);
          },
          () => gen.var(valid, true)
          // TODO var
        );
        cxt.ok(valid);
      }
    }
    exports.validateSchemaDeps = validateSchemaDeps;
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/propertyNames.js
var require_propertyNames = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/propertyNames.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var error3 = {
      message: "property name must be valid",
      params: ({ params }) => (0, codegen_1._)`{propertyName: ${params.propertyName}}`
    };
    var def = {
      keyword: "propertyNames",
      type: "object",
      schemaType: ["object", "boolean"],
      error: error3,
      code(cxt) {
        const { gen, schema, data, it } = cxt;
        if ((0, util_1.alwaysValidSchema)(it, schema))
          return;
        const valid = gen.name("valid");
        gen.forIn("key", data, (key) => {
          cxt.setParams({ propertyName: key });
          cxt.subschema({
            keyword: "propertyNames",
            data: key,
            dataTypes: ["string"],
            propertyName: key,
            compositeRule: true
          }, valid);
          gen.if((0, codegen_1.not)(valid), () => {
            cxt.error(true);
            if (!it.allErrors)
              gen.break();
          });
        });
        cxt.ok(valid);
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/additionalProperties.js
var require_additionalProperties = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/additionalProperties.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var code_1 = require_code2();
    var codegen_1 = require_codegen();
    var names_1 = require_names();
    var util_1 = require_util();
    var error3 = {
      message: "must NOT have additional properties",
      params: ({ params }) => (0, codegen_1._)`{additionalProperty: ${params.additionalProperty}}`
    };
    var def = {
      keyword: "additionalProperties",
      type: ["object"],
      schemaType: ["boolean", "object"],
      allowUndefined: true,
      trackErrors: true,
      error: error3,
      code(cxt) {
        const { gen, schema, parentSchema, data, errsCount, it } = cxt;
        if (!errsCount)
          throw new Error("ajv implementation error");
        const { allErrors, opts } = it;
        it.props = true;
        if (opts.removeAdditional !== "all" && (0, util_1.alwaysValidSchema)(it, schema))
          return;
        const props = (0, code_1.allSchemaProperties)(parentSchema.properties);
        const patProps = (0, code_1.allSchemaProperties)(parentSchema.patternProperties);
        checkAdditionalProperties();
        cxt.ok((0, codegen_1._)`${errsCount} === ${names_1.default.errors}`);
        function checkAdditionalProperties() {
          gen.forIn("key", data, (key) => {
            if (!props.length && !patProps.length)
              additionalPropertyCode(key);
            else
              gen.if(isAdditional(key), () => additionalPropertyCode(key));
          });
        }
        function isAdditional(key) {
          let definedProp;
          if (props.length > 8) {
            const propsSchema = (0, util_1.schemaRefOrVal)(it, parentSchema.properties, "properties");
            definedProp = (0, code_1.isOwnProperty)(gen, propsSchema, key);
          } else if (props.length) {
            definedProp = (0, codegen_1.or)(...props.map((p) => (0, codegen_1._)`${key} === ${p}`));
          } else {
            definedProp = codegen_1.nil;
          }
          if (patProps.length) {
            definedProp = (0, codegen_1.or)(definedProp, ...patProps.map((p) => (0, codegen_1._)`${(0, code_1.usePattern)(cxt, p)}.test(${key})`));
          }
          return (0, codegen_1.not)(definedProp);
        }
        function deleteAdditional(key) {
          gen.code((0, codegen_1._)`delete ${data}[${key}]`);
        }
        function additionalPropertyCode(key) {
          if (opts.removeAdditional === "all" || opts.removeAdditional && schema === false) {
            deleteAdditional(key);
            return;
          }
          if (schema === false) {
            cxt.setParams({ additionalProperty: key });
            cxt.error();
            if (!allErrors)
              gen.break();
            return;
          }
          if (typeof schema == "object" && !(0, util_1.alwaysValidSchema)(it, schema)) {
            const valid = gen.name("valid");
            if (opts.removeAdditional === "failing") {
              applyAdditionalSchema(key, valid, false);
              gen.if((0, codegen_1.not)(valid), () => {
                cxt.reset();
                deleteAdditional(key);
              });
            } else {
              applyAdditionalSchema(key, valid);
              if (!allErrors)
                gen.if((0, codegen_1.not)(valid), () => gen.break());
            }
          }
        }
        function applyAdditionalSchema(key, valid, errors) {
          const subschema = {
            keyword: "additionalProperties",
            dataProp: key,
            dataPropType: util_1.Type.Str
          };
          if (errors === false) {
            Object.assign(subschema, {
              compositeRule: true,
              createErrors: false,
              allErrors: false
            });
          }
          cxt.subschema(subschema, valid);
        }
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/properties.js
var require_properties = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/properties.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var validate_1 = require_validate();
    var code_1 = require_code2();
    var util_1 = require_util();
    var additionalProperties_1 = require_additionalProperties();
    var def = {
      keyword: "properties",
      type: "object",
      schemaType: "object",
      code(cxt) {
        const { gen, schema, parentSchema, data, it } = cxt;
        if (it.opts.removeAdditional === "all" && parentSchema.additionalProperties === void 0) {
          additionalProperties_1.default.code(new validate_1.KeywordCxt(it, additionalProperties_1.default, "additionalProperties"));
        }
        const allProps = (0, code_1.allSchemaProperties)(schema);
        for (const prop of allProps) {
          it.definedProperties.add(prop);
        }
        if (it.opts.unevaluated && allProps.length && it.props !== true) {
          it.props = util_1.mergeEvaluated.props(gen, (0, util_1.toHash)(allProps), it.props);
        }
        const properties = allProps.filter((p) => !(0, util_1.alwaysValidSchema)(it, schema[p]));
        if (properties.length === 0)
          return;
        const valid = gen.name("valid");
        for (const prop of properties) {
          if (hasDefault(prop)) {
            applyPropertySchema(prop);
          } else {
            gen.if((0, code_1.propertyInData)(gen, data, prop, it.opts.ownProperties));
            applyPropertySchema(prop);
            if (!it.allErrors)
              gen.else().var(valid, true);
            gen.endIf();
          }
          cxt.it.definedProperties.add(prop);
          cxt.ok(valid);
        }
        function hasDefault(prop) {
          return it.opts.useDefaults && !it.compositeRule && schema[prop].default !== void 0;
        }
        function applyPropertySchema(prop) {
          cxt.subschema({
            keyword: "properties",
            schemaProp: prop,
            dataProp: prop
          }, valid);
        }
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/patternProperties.js
var require_patternProperties = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/patternProperties.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var code_1 = require_code2();
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var util_2 = require_util();
    var def = {
      keyword: "patternProperties",
      type: "object",
      schemaType: "object",
      code(cxt) {
        const { gen, schema, data, parentSchema, it } = cxt;
        const { opts } = it;
        const patterns = (0, code_1.allSchemaProperties)(schema);
        const alwaysValidPatterns = patterns.filter((p) => (0, util_1.alwaysValidSchema)(it, schema[p]));
        if (patterns.length === 0 || alwaysValidPatterns.length === patterns.length && (!it.opts.unevaluated || it.props === true)) {
          return;
        }
        const checkProperties = opts.strictSchema && !opts.allowMatchingProperties && parentSchema.properties;
        const valid = gen.name("valid");
        if (it.props !== true && !(it.props instanceof codegen_1.Name)) {
          it.props = (0, util_2.evaluatedPropsToName)(gen, it.props);
        }
        const { props } = it;
        validatePatternProperties();
        function validatePatternProperties() {
          for (const pat of patterns) {
            if (checkProperties)
              checkMatchingProperties(pat);
            if (it.allErrors) {
              validateProperties(pat);
            } else {
              gen.var(valid, true);
              validateProperties(pat);
              gen.if(valid);
            }
          }
        }
        function checkMatchingProperties(pat) {
          for (const prop in checkProperties) {
            if (new RegExp(pat).test(prop)) {
              (0, util_1.checkStrictMode)(it, `property ${prop} matches pattern ${pat} (use allowMatchingProperties)`);
            }
          }
        }
        function validateProperties(pat) {
          gen.forIn("key", data, (key) => {
            gen.if((0, codegen_1._)`${(0, code_1.usePattern)(cxt, pat)}.test(${key})`, () => {
              const alwaysValid = alwaysValidPatterns.includes(pat);
              if (!alwaysValid) {
                cxt.subschema({
                  keyword: "patternProperties",
                  schemaProp: pat,
                  dataProp: key,
                  dataPropType: util_2.Type.Str
                }, valid);
              }
              if (it.opts.unevaluated && props !== true) {
                gen.assign((0, codegen_1._)`${props}[${key}]`, true);
              } else if (!alwaysValid && !it.allErrors) {
                gen.if((0, codegen_1.not)(valid), () => gen.break());
              }
            });
          });
        }
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/not.js
var require_not = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/not.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var util_1 = require_util();
    var def = {
      keyword: "not",
      schemaType: ["object", "boolean"],
      trackErrors: true,
      code(cxt) {
        const { gen, schema, it } = cxt;
        if ((0, util_1.alwaysValidSchema)(it, schema)) {
          cxt.fail();
          return;
        }
        const valid = gen.name("valid");
        cxt.subschema({
          keyword: "not",
          compositeRule: true,
          createErrors: false,
          allErrors: false
        }, valid);
        cxt.failResult(valid, () => cxt.reset(), () => cxt.error());
      },
      error: { message: "must NOT be valid" }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/anyOf.js
var require_anyOf = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/anyOf.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var code_1 = require_code2();
    var def = {
      keyword: "anyOf",
      schemaType: "array",
      trackErrors: true,
      code: code_1.validateUnion,
      error: { message: "must match a schema in anyOf" }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/oneOf.js
var require_oneOf = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/oneOf.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var error3 = {
      message: "must match exactly one schema in oneOf",
      params: ({ params }) => (0, codegen_1._)`{passingSchemas: ${params.passing}}`
    };
    var def = {
      keyword: "oneOf",
      schemaType: "array",
      trackErrors: true,
      error: error3,
      code(cxt) {
        const { gen, schema, parentSchema, it } = cxt;
        if (!Array.isArray(schema))
          throw new Error("ajv implementation error");
        if (it.opts.discriminator && parentSchema.discriminator)
          return;
        const schArr = schema;
        const valid = gen.let("valid", false);
        const passing = gen.let("passing", null);
        const schValid = gen.name("_valid");
        cxt.setParams({ passing });
        gen.block(validateOneOf);
        cxt.result(valid, () => cxt.reset(), () => cxt.error(true));
        function validateOneOf() {
          schArr.forEach((sch, i) => {
            let schCxt;
            if ((0, util_1.alwaysValidSchema)(it, sch)) {
              gen.var(schValid, true);
            } else {
              schCxt = cxt.subschema({
                keyword: "oneOf",
                schemaProp: i,
                compositeRule: true
              }, schValid);
            }
            if (i > 0) {
              gen.if((0, codegen_1._)`${schValid} && ${valid}`).assign(valid, false).assign(passing, (0, codegen_1._)`[${passing}, ${i}]`).else();
            }
            gen.if(schValid, () => {
              gen.assign(valid, true);
              gen.assign(passing, i);
              if (schCxt)
                cxt.mergeEvaluated(schCxt, codegen_1.Name);
            });
          });
        }
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/allOf.js
var require_allOf = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/allOf.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var util_1 = require_util();
    var def = {
      keyword: "allOf",
      schemaType: "array",
      code(cxt) {
        const { gen, schema, it } = cxt;
        if (!Array.isArray(schema))
          throw new Error("ajv implementation error");
        const valid = gen.name("valid");
        schema.forEach((sch, i) => {
          if ((0, util_1.alwaysValidSchema)(it, sch))
            return;
          const schCxt = cxt.subschema({ keyword: "allOf", schemaProp: i }, valid);
          cxt.ok(valid);
          cxt.mergeEvaluated(schCxt);
        });
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/if.js
var require_if = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/if.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var util_1 = require_util();
    var error3 = {
      message: ({ params }) => (0, codegen_1.str)`must match "${params.ifClause}" schema`,
      params: ({ params }) => (0, codegen_1._)`{failingKeyword: ${params.ifClause}}`
    };
    var def = {
      keyword: "if",
      schemaType: ["object", "boolean"],
      trackErrors: true,
      error: error3,
      code(cxt) {
        const { gen, parentSchema, it } = cxt;
        if (parentSchema.then === void 0 && parentSchema.else === void 0) {
          (0, util_1.checkStrictMode)(it, '"if" without "then" and "else" is ignored');
        }
        const hasThen = hasSchema(it, "then");
        const hasElse = hasSchema(it, "else");
        if (!hasThen && !hasElse)
          return;
        const valid = gen.let("valid", true);
        const schValid = gen.name("_valid");
        validateIf();
        cxt.reset();
        if (hasThen && hasElse) {
          const ifClause = gen.let("ifClause");
          cxt.setParams({ ifClause });
          gen.if(schValid, validateClause("then", ifClause), validateClause("else", ifClause));
        } else if (hasThen) {
          gen.if(schValid, validateClause("then"));
        } else {
          gen.if((0, codegen_1.not)(schValid), validateClause("else"));
        }
        cxt.pass(valid, () => cxt.error(true));
        function validateIf() {
          const schCxt = cxt.subschema({
            keyword: "if",
            compositeRule: true,
            createErrors: false,
            allErrors: false
          }, schValid);
          cxt.mergeEvaluated(schCxt);
        }
        function validateClause(keyword, ifClause) {
          return () => {
            const schCxt = cxt.subschema({ keyword }, schValid);
            gen.assign(valid, schValid);
            cxt.mergeValidEvaluated(schCxt, valid);
            if (ifClause)
              gen.assign(ifClause, (0, codegen_1._)`${keyword}`);
            else
              cxt.setParams({ ifClause: keyword });
          };
        }
      }
    };
    function hasSchema(it, keyword) {
      const schema = it.schema[keyword];
      return schema !== void 0 && !(0, util_1.alwaysValidSchema)(it, schema);
    }
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/thenElse.js
var require_thenElse = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/thenElse.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var util_1 = require_util();
    var def = {
      keyword: ["then", "else"],
      schemaType: ["object", "boolean"],
      code({ keyword, parentSchema, it }) {
        if (parentSchema.if === void 0)
          (0, util_1.checkStrictMode)(it, `"${keyword}" without "if" is ignored`);
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/index.js
var require_applicator = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/applicator/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var additionalItems_1 = require_additionalItems();
    var prefixItems_1 = require_prefixItems();
    var items_1 = require_items();
    var items2020_1 = require_items2020();
    var contains_1 = require_contains();
    var dependencies_1 = require_dependencies();
    var propertyNames_1 = require_propertyNames();
    var additionalProperties_1 = require_additionalProperties();
    var properties_1 = require_properties();
    var patternProperties_1 = require_patternProperties();
    var not_1 = require_not();
    var anyOf_1 = require_anyOf();
    var oneOf_1 = require_oneOf();
    var allOf_1 = require_allOf();
    var if_1 = require_if();
    var thenElse_1 = require_thenElse();
    function getApplicator(draft2020 = false) {
      const applicator = [
        // any
        not_1.default,
        anyOf_1.default,
        oneOf_1.default,
        allOf_1.default,
        if_1.default,
        thenElse_1.default,
        // object
        propertyNames_1.default,
        additionalProperties_1.default,
        dependencies_1.default,
        properties_1.default,
        patternProperties_1.default
      ];
      if (draft2020)
        applicator.push(prefixItems_1.default, items2020_1.default);
      else
        applicator.push(additionalItems_1.default, items_1.default);
      applicator.push(contains_1.default);
      return applicator;
    }
    exports.default = getApplicator;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/format/format.js
var require_format = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/format/format.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var error3 = {
      message: ({ schemaCode }) => (0, codegen_1.str)`must match format "${schemaCode}"`,
      params: ({ schemaCode }) => (0, codegen_1._)`{format: ${schemaCode}}`
    };
    var def = {
      keyword: "format",
      type: ["number", "string"],
      schemaType: "string",
      $data: true,
      error: error3,
      code(cxt, ruleType) {
        const { gen, data, $data, schema, schemaCode, it } = cxt;
        const { opts, errSchemaPath, schemaEnv, self } = it;
        if (!opts.validateFormats)
          return;
        if ($data)
          validate$DataFormat();
        else
          validateFormat();
        function validate$DataFormat() {
          const fmts = gen.scopeValue("formats", {
            ref: self.formats,
            code: opts.code.formats
          });
          const fDef = gen.const("fDef", (0, codegen_1._)`${fmts}[${schemaCode}]`);
          const fType = gen.let("fType");
          const format = gen.let("format");
          gen.if((0, codegen_1._)`typeof ${fDef} == "object" && !(${fDef} instanceof RegExp)`, () => gen.assign(fType, (0, codegen_1._)`${fDef}.type || "string"`).assign(format, (0, codegen_1._)`${fDef}.validate`), () => gen.assign(fType, (0, codegen_1._)`"string"`).assign(format, fDef));
          cxt.fail$data((0, codegen_1.or)(unknownFmt(), invalidFmt()));
          function unknownFmt() {
            if (opts.strictSchema === false)
              return codegen_1.nil;
            return (0, codegen_1._)`${schemaCode} && !${format}`;
          }
          function invalidFmt() {
            const callFormat = schemaEnv.$async ? (0, codegen_1._)`(${fDef}.async ? await ${format}(${data}) : ${format}(${data}))` : (0, codegen_1._)`${format}(${data})`;
            const validData = (0, codegen_1._)`(typeof ${format} == "function" ? ${callFormat} : ${format}.test(${data}))`;
            return (0, codegen_1._)`${format} && ${format} !== true && ${fType} === ${ruleType} && !${validData}`;
          }
        }
        function validateFormat() {
          const formatDef = self.formats[schema];
          if (!formatDef) {
            unknownFormat();
            return;
          }
          if (formatDef === true)
            return;
          const [fmtType, format, fmtRef] = getFormat(formatDef);
          if (fmtType === ruleType)
            cxt.pass(validCondition());
          function unknownFormat() {
            if (opts.strictSchema === false) {
              self.logger.warn(unknownMsg());
              return;
            }
            throw new Error(unknownMsg());
            function unknownMsg() {
              return `unknown format "${schema}" ignored in schema at path "${errSchemaPath}"`;
            }
          }
          function getFormat(fmtDef) {
            const code = fmtDef instanceof RegExp ? (0, codegen_1.regexpCode)(fmtDef) : opts.code.formats ? (0, codegen_1._)`${opts.code.formats}${(0, codegen_1.getProperty)(schema)}` : void 0;
            const fmt = gen.scopeValue("formats", { key: schema, ref: fmtDef, code });
            if (typeof fmtDef == "object" && !(fmtDef instanceof RegExp)) {
              return [fmtDef.type || "string", fmtDef.validate, (0, codegen_1._)`${fmt}.validate`];
            }
            return ["string", fmtDef, fmt];
          }
          function validCondition() {
            if (typeof formatDef == "object" && !(formatDef instanceof RegExp) && formatDef.async) {
              if (!schemaEnv.$async)
                throw new Error("async format in sync schema");
              return (0, codegen_1._)`await ${fmtRef}(${data})`;
            }
            return typeof format == "function" ? (0, codegen_1._)`${fmtRef}(${data})` : (0, codegen_1._)`${fmtRef}.test(${data})`;
          }
        }
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/format/index.js
var require_format2 = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/format/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var format_1 = require_format();
    var format = [format_1.default];
    exports.default = format;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/metadata.js
var require_metadata = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/metadata.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.contentVocabulary = exports.metadataVocabulary = void 0;
    exports.metadataVocabulary = [
      "title",
      "description",
      "default",
      "deprecated",
      "readOnly",
      "writeOnly",
      "examples"
    ];
    exports.contentVocabulary = [
      "contentMediaType",
      "contentEncoding",
      "contentSchema"
    ];
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/draft7.js
var require_draft7 = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/draft7.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var core_1 = require_core2();
    var validation_1 = require_validation();
    var applicator_1 = require_applicator();
    var format_1 = require_format2();
    var metadata_1 = require_metadata();
    var draft7Vocabularies = [
      core_1.default,
      validation_1.default,
      (0, applicator_1.default)(),
      format_1.default,
      metadata_1.metadataVocabulary,
      metadata_1.contentVocabulary
    ];
    exports.default = draft7Vocabularies;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/discriminator/types.js
var require_types = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/discriminator/types.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.DiscrError = void 0;
    var DiscrError;
    (function(DiscrError2) {
      DiscrError2["Tag"] = "tag";
      DiscrError2["Mapping"] = "mapping";
    })(DiscrError || (exports.DiscrError = DiscrError = {}));
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/discriminator/index.js
var require_discriminator = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/vocabularies/discriminator/index.js"(exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var codegen_1 = require_codegen();
    var types_1 = require_types();
    var compile_1 = require_compile();
    var ref_error_1 = require_ref_error();
    var util_1 = require_util();
    var error3 = {
      message: ({ params: { discrError, tagName } }) => discrError === types_1.DiscrError.Tag ? `tag "${tagName}" must be string` : `value of tag "${tagName}" must be in oneOf`,
      params: ({ params: { discrError, tag: tag2, tagName } }) => (0, codegen_1._)`{error: ${discrError}, tag: ${tagName}, tagValue: ${tag2}}`
    };
    var def = {
      keyword: "discriminator",
      type: "object",
      schemaType: "object",
      error: error3,
      code(cxt) {
        const { gen, data, schema, parentSchema, it } = cxt;
        const { oneOf } = parentSchema;
        if (!it.opts.discriminator) {
          throw new Error("discriminator: requires discriminator option");
        }
        const tagName = schema.propertyName;
        if (typeof tagName != "string")
          throw new Error("discriminator: requires propertyName");
        if (schema.mapping)
          throw new Error("discriminator: mapping is not supported");
        if (!oneOf)
          throw new Error("discriminator: requires oneOf keyword");
        const valid = gen.let("valid", false);
        const tag2 = gen.const("tag", (0, codegen_1._)`${data}${(0, codegen_1.getProperty)(tagName)}`);
        gen.if((0, codegen_1._)`typeof ${tag2} == "string"`, () => validateMapping(), () => cxt.error(false, { discrError: types_1.DiscrError.Tag, tag: tag2, tagName }));
        cxt.ok(valid);
        function validateMapping() {
          const mapping = getMapping();
          gen.if(false);
          for (const tagValue in mapping) {
            gen.elseIf((0, codegen_1._)`${tag2} === ${tagValue}`);
            gen.assign(valid, applyTagSchema(mapping[tagValue]));
          }
          gen.else();
          cxt.error(false, { discrError: types_1.DiscrError.Mapping, tag: tag2, tagName });
          gen.endIf();
        }
        function applyTagSchema(schemaProp) {
          const _valid = gen.name("valid");
          const schCxt = cxt.subschema({ keyword: "oneOf", schemaProp }, _valid);
          cxt.mergeEvaluated(schCxt, codegen_1.Name);
          return _valid;
        }
        function getMapping() {
          var _a;
          const oneOfMapping = {};
          const topRequired = hasRequired(parentSchema);
          let tagRequired = true;
          for (let i = 0; i < oneOf.length; i++) {
            let sch = oneOf[i];
            if ((sch === null || sch === void 0 ? void 0 : sch.$ref) && !(0, util_1.schemaHasRulesButRef)(sch, it.self.RULES)) {
              const ref = sch.$ref;
              sch = compile_1.resolveRef.call(it.self, it.schemaEnv.root, it.baseId, ref);
              if (sch instanceof compile_1.SchemaEnv)
                sch = sch.schema;
              if (sch === void 0)
                throw new ref_error_1.default(it.opts.uriResolver, it.baseId, ref);
            }
            const propSch = (_a = sch === null || sch === void 0 ? void 0 : sch.properties) === null || _a === void 0 ? void 0 : _a[tagName];
            if (typeof propSch != "object") {
              throw new Error(`discriminator: oneOf subschemas (or referenced schemas) must have "properties/${tagName}"`);
            }
            tagRequired = tagRequired && (topRequired || hasRequired(sch));
            addMappings(propSch, i);
          }
          if (!tagRequired)
            throw new Error(`discriminator: "${tagName}" must be required`);
          return oneOfMapping;
          function hasRequired({ required }) {
            return Array.isArray(required) && required.includes(tagName);
          }
          function addMappings(sch, i) {
            if (sch.const) {
              addMapping(sch.const, i);
            } else if (sch.enum) {
              for (const tagValue of sch.enum) {
                addMapping(tagValue, i);
              }
            } else {
              throw new Error(`discriminator: "properties/${tagName}" must have "const" or "enum"`);
            }
          }
          function addMapping(tagValue, i) {
            if (typeof tagValue != "string" || tagValue in oneOfMapping) {
              throw new Error(`discriminator: "${tagName}" values must be unique strings`);
            }
            oneOfMapping[tagValue] = i;
          }
        }
      }
    };
    exports.default = def;
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/refs/json-schema-draft-07.json
var require_json_schema_draft_07 = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/refs/json-schema-draft-07.json"(exports, module) {
    module.exports = {
      $schema: "http://json-schema.org/draft-07/schema#",
      $id: "http://json-schema.org/draft-07/schema#",
      title: "Core schema meta-schema",
      definitions: {
        schemaArray: {
          type: "array",
          minItems: 1,
          items: { $ref: "#" }
        },
        nonNegativeInteger: {
          type: "integer",
          minimum: 0
        },
        nonNegativeIntegerDefault0: {
          allOf: [{ $ref: "#/definitions/nonNegativeInteger" }, { default: 0 }]
        },
        simpleTypes: {
          enum: ["array", "boolean", "integer", "null", "number", "object", "string"]
        },
        stringArray: {
          type: "array",
          items: { type: "string" },
          uniqueItems: true,
          default: []
        }
      },
      type: ["object", "boolean"],
      properties: {
        $id: {
          type: "string",
          format: "uri-reference"
        },
        $schema: {
          type: "string",
          format: "uri"
        },
        $ref: {
          type: "string",
          format: "uri-reference"
        },
        $comment: {
          type: "string"
        },
        title: {
          type: "string"
        },
        description: {
          type: "string"
        },
        default: true,
        readOnly: {
          type: "boolean",
          default: false
        },
        examples: {
          type: "array",
          items: true
        },
        multipleOf: {
          type: "number",
          exclusiveMinimum: 0
        },
        maximum: {
          type: "number"
        },
        exclusiveMaximum: {
          type: "number"
        },
        minimum: {
          type: "number"
        },
        exclusiveMinimum: {
          type: "number"
        },
        maxLength: { $ref: "#/definitions/nonNegativeInteger" },
        minLength: { $ref: "#/definitions/nonNegativeIntegerDefault0" },
        pattern: {
          type: "string",
          format: "regex"
        },
        additionalItems: { $ref: "#" },
        items: {
          anyOf: [{ $ref: "#" }, { $ref: "#/definitions/schemaArray" }],
          default: true
        },
        maxItems: { $ref: "#/definitions/nonNegativeInteger" },
        minItems: { $ref: "#/definitions/nonNegativeIntegerDefault0" },
        uniqueItems: {
          type: "boolean",
          default: false
        },
        contains: { $ref: "#" },
        maxProperties: { $ref: "#/definitions/nonNegativeInteger" },
        minProperties: { $ref: "#/definitions/nonNegativeIntegerDefault0" },
        required: { $ref: "#/definitions/stringArray" },
        additionalProperties: { $ref: "#" },
        definitions: {
          type: "object",
          additionalProperties: { $ref: "#" },
          default: {}
        },
        properties: {
          type: "object",
          additionalProperties: { $ref: "#" },
          default: {}
        },
        patternProperties: {
          type: "object",
          additionalProperties: { $ref: "#" },
          propertyNames: { format: "regex" },
          default: {}
        },
        dependencies: {
          type: "object",
          additionalProperties: {
            anyOf: [{ $ref: "#" }, { $ref: "#/definitions/stringArray" }]
          }
        },
        propertyNames: { $ref: "#" },
        const: true,
        enum: {
          type: "array",
          items: true,
          minItems: 1,
          uniqueItems: true
        },
        type: {
          anyOf: [
            { $ref: "#/definitions/simpleTypes" },
            {
              type: "array",
              items: { $ref: "#/definitions/simpleTypes" },
              minItems: 1,
              uniqueItems: true
            }
          ]
        },
        format: { type: "string" },
        contentMediaType: { type: "string" },
        contentEncoding: { type: "string" },
        if: { $ref: "#" },
        then: { $ref: "#" },
        else: { $ref: "#" },
        allOf: { $ref: "#/definitions/schemaArray" },
        anyOf: { $ref: "#/definitions/schemaArray" },
        oneOf: { $ref: "#/definitions/schemaArray" },
        not: { $ref: "#" }
      },
      default: true
    };
  }
});

// node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/ajv.js
var require_ajv = __commonJS({
  "node_modules/.pnpm/ajv@8.20.0/node_modules/ajv/dist/ajv.js"(exports, module) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.MissingRefError = exports.ValidationError = exports.CodeGen = exports.Name = exports.nil = exports.stringify = exports.str = exports._ = exports.KeywordCxt = exports.Ajv = void 0;
    var core_1 = require_core();
    var draft7_1 = require_draft7();
    var discriminator_1 = require_discriminator();
    var draft7MetaSchema = require_json_schema_draft_07();
    var META_SUPPORT_DATA = ["/properties"];
    var META_SCHEMA_ID = "http://json-schema.org/draft-07/schema";
    var Ajv2 = class extends core_1.default {
      _addVocabularies() {
        super._addVocabularies();
        draft7_1.default.forEach((v) => this.addVocabulary(v));
        if (this.opts.discriminator)
          this.addKeyword(discriminator_1.default);
      }
      _addDefaultMetaSchema() {
        super._addDefaultMetaSchema();
        if (!this.opts.meta)
          return;
        const metaSchema = this.opts.$data ? this.$dataMetaSchema(draft7MetaSchema, META_SUPPORT_DATA) : draft7MetaSchema;
        this.addMetaSchema(metaSchema, META_SCHEMA_ID, false);
        this.refs["http://json-schema.org/schema"] = META_SCHEMA_ID;
      }
      defaultMeta() {
        return this.opts.defaultMeta = super.defaultMeta() || (this.getSchema(META_SCHEMA_ID) ? META_SCHEMA_ID : void 0);
      }
    };
    exports.Ajv = Ajv2;
    module.exports = exports = Ajv2;
    module.exports.Ajv = Ajv2;
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = Ajv2;
    var validate_1 = require_validate();
    Object.defineProperty(exports, "KeywordCxt", { enumerable: true, get: function() {
      return validate_1.KeywordCxt;
    } });
    var codegen_1 = require_codegen();
    Object.defineProperty(exports, "_", { enumerable: true, get: function() {
      return codegen_1._;
    } });
    Object.defineProperty(exports, "str", { enumerable: true, get: function() {
      return codegen_1.str;
    } });
    Object.defineProperty(exports, "stringify", { enumerable: true, get: function() {
      return codegen_1.stringify;
    } });
    Object.defineProperty(exports, "nil", { enumerable: true, get: function() {
      return codegen_1.nil;
    } });
    Object.defineProperty(exports, "Name", { enumerable: true, get: function() {
      return codegen_1.Name;
    } });
    Object.defineProperty(exports, "CodeGen", { enumerable: true, get: function() {
      return codegen_1.CodeGen;
    } });
    var validation_error_1 = require_validation_error();
    Object.defineProperty(exports, "ValidationError", { enumerable: true, get: function() {
      return validation_error_1.default;
    } });
    var ref_error_1 = require_ref_error();
    Object.defineProperty(exports, "MissingRefError", { enumerable: true, get: function() {
      return ref_error_1.default;
    } });
  }
});

// server/src/main.mjs
import { readFile as readFile3 } from "node:fs/promises";
import { resolve as resolve3 } from "node:path";

// server/src/http.mjs
import { createServer } from "node:http";
import { createServer as createHttpsServer, request as httpsRequest } from "node:https";

// server/src/config.mjs
import { readFileSync as readFileSync3 } from "node:fs";
import { createSecureContext } from "node:tls";

// server/src/signing-keys.mjs
import { createPrivateKey as createPrivateKey2, createPublicKey as createPublicKey2 } from "node:crypto";
import { readFileSync as readFileSync2 } from "node:fs";

// server/src/store.mjs
import { DatabaseSync as DatabaseSync2 } from "node:sqlite";
import { randomBytes, randomUUID as randomUUID2, createHash as createHash2 } from "node:crypto";
import { mkdirSync as mkdirSync2 } from "node:fs";
import { dirname } from "node:path";

// packages/ecosystem-data/recovery.mjs
import { DatabaseSync } from "node:sqlite";
import { createHash, createPrivateKey, createPublicKey, randomUUID } from "node:crypto";
import {
  copyFileSync,
  existsSync,
  lstatSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  realpathSync,
  renameSync,
  rmSync,
  writeFileSync,
  openSync,
  closeSync,
  fsyncSync
} from "node:fs";
var digest = (value2) => createHash("sha256").update(value2).digest("hex");
var fail = (code) => {
  throw new Error(code);
};
var json = (file2) => JSON.parse(readFileSync(file2, "utf8"));
var id = (value2) => typeof value2 === "string" && /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,95}$/.test(value2);
function writeDurable(file2, data, exclusive = false) {
  const fd = openSync(file2, exclusive ? "wx" : "w", 384);
  try {
    writeFileSync(fd, data);
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
}
function readRegistry(file2, binding2) {
  if (lstatSync(file2).isSymbolicLink()) fail("SYMLINK_DENIED");
  const registry = json(file2);
  if (registry.version !== 1 || registry.binding !== binding2 || !Number.isSafeInteger(registry.revision) || registry.revision < 0 || !Array.isArray(registry.deleted))
    fail("REGISTRY_REQUIRED");
  if (registry.revision !== registry.deleted.length || new Set(registry.deleted.map((r) => r.owner)).size !== registry.deleted.length || registry.deleted.some((r) => !id(r.owner) || !Number.isSafeInteger(r.at) || r.at < 0))
    fail("REGISTRY_REQUIRED");
  return registry;
}
function registerDeletion(file2, binding2, owner) {
  if (!id(owner)) fail("INVALID_OWNER");
  const lock = file2 + ".lock";
  const fd = openSync(lock, "wx");
  try {
    const registry = readRegistry(file2, binding2);
    if (registry.deleted.some((r) => r.owner === owner)) return registry;
    registry.revision++;
    registry.deleted.push({ owner, at: Date.now() });
    const temporary = file2 + "." + randomUUID();
    writeDurable(temporary, JSON.stringify(registry));
    renameSync(temporary, file2);
    return registry;
  } finally {
    closeSync(fd);
    rmSync(lock);
  }
}

// server/src/store.mjs
var secret = () => randomBytes(32).toString("base64url");
var hash = (value2) => createHash2("sha256").update(value2).digest("hex");
var roles = ["owner", "admin", "developer", "reader"];
var Problem = class extends Error {
  constructor(code, status = 400) {
    super(code);
    this.code = code;
    this.status = status;
  }
};
function requireValue(condition, code, status = 400) {
  if (!condition) throw new Problem(code, status);
}
function text(value2, max = 100) {
  requireValue(
    typeof value2 === "string" && value2.trim().length > 0 && value2.length <= max,
    "INVALID_INPUT"
  );
  return value2.trim();
}
var IdentityStore = class {
  constructor(file2, issuer, now = () => Date.now(), deployment = {}) {
    this.environment = deployment.environment ?? "development";
    this.deploymentBinding = deployment.binding;
    this.allowedSubjects = deployment.invitedSubjects;
    this.dataPolicy = deployment.dataManagement;
    if (this.dataPolicy) readRegistry(this.dataPolicy.registry, this.dataPolicy.binding);
    mkdirSync2(dirname(file2), { recursive: true });
    this.db = new DatabaseSync2(file2, { timeout: 5e3 });
    this.issuer = issuer;
    this.now = now;
    const tables = this.all(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    );
    if (tables.length) {
      const known = tables.some((t) => t.name === "schema_version");
      const version = known ? this.get("SELECT max(version) AS version FROM schema_version").version : null;
      if (![1, 2, 3, 4, 5, 6, 7, 8].includes(version)) {
        this.db.close();
        throw new Problem("DATABASE_VERSION_UNSUPPORTED", 503);
      }
      if (version >= 7 && !this.dataPolicy) {
        this.db.close();
        throw new Problem("DATA_POLICY_REQUIRED", 503);
      }
      if (version >= 6 && this.environment === "production") {
        const history = this.all("SELECT * FROM signing_keys");
        if (!deployment.signingKeys || !history.every(
          (row) => deployment.signingKeys.some(
            (entry) => entry.keyId === row.key_id && entry.publicKey === row.public_key && entry.notBefore === row.not_before && entry.notAfter === row.not_after
          )
        )) {
          this.db.close();
          throw new Problem("SIGNING_HISTORY_REQUIRED", 503);
        }
      }
      const storedEnvironment = this.get("SELECT value FROM settings WHERE name='deployment_environment'")?.value ?? "development";
      const storedBinding = this.get(
        "SELECT value FROM settings WHERE name='deployment_binding'"
      )?.value;
      if (storedEnvironment !== this.environment || storedBinding && storedBinding !== this.deploymentBinding) {
        this.db.close();
        throw new Problem("DATABASE_ENVIRONMENT_MISMATCH", 503);
      }
      const storedIssuer = this.get("SELECT value FROM settings WHERE name='issuer'");
      if (storedIssuer?.value !== issuer) {
        this.db.close();
        throw new Problem("DATABASE_ISSUER_MISMATCH", 503);
      }
    }
    this.db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL;
      BEGIN IMMEDIATE;
      CREATE TABLE IF NOT EXISTS schema_version(version INTEGER PRIMARY KEY);
      INSERT OR IGNORE INTO schema_version VALUES(1);
      CREATE TABLE IF NOT EXISTS settings(name TEXT PRIMARY KEY, value TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS actors(id TEXT PRIMARY KEY, sub TEXT UNIQUE NOT NULL, name TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS organizations(id TEXT PRIMARY KEY, name TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS members(org TEXT REFERENCES organizations(id), actor TEXT REFERENCES actors(id), role TEXT NOT NULL CHECK(role IN ('owner','admin','developer','reader')), PRIMARY KEY(org,actor));
      CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY, actor TEXT REFERENCES actors(id), org TEXT, csrf TEXT NOT NULL, expires INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS invitations(id TEXT PRIMARY KEY, org TEXT REFERENCES organizations(id), target TEXT NOT NULL, role TEXT NOT NULL, expires INTEGER NOT NULL, state TEXT NOT NULL, creator TEXT REFERENCES actors(id));
      CREATE TABLE IF NOT EXISTS namespaces(name TEXT PRIMARY KEY COLLATE NOCASE, owner TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('personal','organization')));
      CREATE TABLE IF NOT EXISTS credentials(id TEXT PRIMARY KEY, hash TEXT UNIQUE NOT NULL, org TEXT REFERENCES organizations(id), actor TEXT REFERENCES actors(id), environment TEXT NOT NULL, name TEXT NOT NULL, revoked INTEGER NOT NULL DEFAULT 0, expires INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, at INTEGER NOT NULL, actor TEXT NOT NULL, org TEXT, action TEXT NOT NULL, target TEXT NOT NULL);`);
    requireValue(
      [1, 2, 3, 4, 5, 6, 7, 8].includes(
        this.get("SELECT max(version) AS version FROM schema_version").version
      ),
      "DATABASE_VERSION_UNSUPPORTED",
      503
    );
    if (this.environment === "production") {
      if (!this.all("PRAGMA table_info(sessions)").some((c) => c.name === "last_active")) {
        this.db.exec("ALTER TABLE sessions ADD COLUMN last_active INTEGER");
        this.run("UPDATE sessions SET last_active=?", this.now());
      }
      this.run("INSERT OR IGNORE INTO schema_version VALUES(5)");
    }
    this.run("INSERT OR IGNORE INTO settings VALUES('issuer',?)", issuer);
    requireValue(
      this.get("SELECT value FROM settings WHERE name='issuer'").value === issuer,
      "DATABASE_ISSUER_MISMATCH",
      503
    );
    this.run("INSERT OR IGNORE INTO settings VALUES('deployment_environment',?)", this.environment);
    if (this.deploymentBinding)
      this.run(
        "INSERT OR IGNORE INTO settings VALUES('deployment_binding',?)",
        this.deploymentBinding
      );
    if (this.allowedSubjects) {
      for (const actor of this.all("SELECT id,sub FROM actors")) {
        if (!this.allowedSubjects.includes(actor.sub)) {
          this.run("DELETE FROM sessions WHERE actor=?", actor.id);
          this.run("UPDATE credentials SET revoked=1 WHERE actor=?", actor.id);
          for (const table of ["publishing_credentials", "catalog_credentials"]) {
            if (tables.some((t) => t.name === table))
              this.run(`UPDATE ${table} SET revoked=1 WHERE actor=?`, actor.id);
          }
        }
      }
    }
    this.db.exec("COMMIT");
  }
  get(sql, ...values) {
    return this.db.prepare(sql).get(...values);
  }
  all(sql, ...values) {
    return this.db.prepare(sql).all(...values);
  }
  run(sql, ...values) {
    return this.db.prepare(sql).run(...values);
  }
  transaction(fn) {
    this.db.exec("BEGIN IMMEDIATE");
    try {
      const result = fn();
      this.db.exec("COMMIT");
      return result;
    } catch (error3) {
      this.db.exec("ROLLBACK");
      throw error3;
    }
  }
  record(actor, org, action, target) {
    this.run(
      "INSERT INTO audit(at,actor,org,action,target) VALUES(?,?,?,?,?)",
      this.now(),
      actor,
      org,
      action,
      target
    );
  }
  login(sub, name, previousToken) {
    const id3 = hash(`${this.issuer}\0${sub}`);
    this.assertDataOwner(id3);
    return this.transaction(() => {
      if (typeof previousToken === "string" && previousToken.length <= 100)
        this.run("DELETE FROM sessions WHERE hash=?", hash(previousToken));
      this.run(
        "INSERT INTO actors VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name",
        id3,
        sub,
        name
      );
      this.record(id3, null, "login", id3);
      return this.issue(id3, null);
    });
  }
  assertDataOwner(id3) {
    if (this.dataPolicy)
      requireValue(
        !readRegistry(this.dataPolicy.registry, this.dataPolicy.binding).deleted.some(
          (r) => r.owner === id3
        ),
        "OWNER_DATA_DELETED",
        403
      );
  }
  issue(actor, org) {
    this.assertDataOwner(actor);
    if (org) this.assertDataOwner(org);
    const token = secret(), csrf = secret();
    this.run(
      "INSERT INTO sessions(hash,actor,org,csrf,expires) VALUES(?,?,?,?,?)",
      hash(token),
      actor,
      org,
      csrf,
      this.now() + 8 * 36e5
    );
    if (this.environment === "production") {
      this.run("UPDATE sessions SET last_active=? WHERE hash=?", this.now(), hash(token));
      const excess = this.all(
        "SELECT hash FROM sessions WHERE actor=? ORDER BY expires DESC, rowid DESC LIMIT -1 OFFSET 5",
        actor
      );
      for (const session of excess) this.run("DELETE FROM sessions WHERE hash=?", session.hash);
    }
    return { token, csrf };
  }
  session(token) {
    requireValue(typeof token === "string" && token.length <= 100, "UNAUTHENTICATED", 401);
    const session = this.get(
      "SELECT * FROM sessions WHERE hash=? AND expires>?",
      hash(token),
      this.now()
    );
    requireValue(session, "UNAUTHENTICATED", 401);
    this.assertDataOwner(session.actor);
    if (session.org) this.assertDataOwner(session.org);
    if (this.environment === "production") {
      requireValue(session.last_active > this.now() - 30 * 6e4, "UNAUTHENTICATED", 401);
      this.run("UPDATE sessions SET last_active=? WHERE hash=?", this.now(), session.hash);
    }
    return session;
  }
  permission(session, org, allowed = roles) {
    this.assertDataOwner(session.actor);
    this.assertDataOwner(org);
    requireValue(session.org === org, "SCOPE_MISMATCH", 403);
    const membership = this.get(
      "SELECT role FROM members WHERE org=? AND actor=?",
      org,
      session.actor
    );
    requireValue(membership && allowed.includes(membership.role), "FORBIDDEN", 403);
    return membership.role;
  }
  rotate(session, org) {
    this.run("DELETE FROM sessions WHERE hash=?", session.hash);
    return this.issue(session.actor, org);
  }
  snapshot(session) {
    return {
      actor: this.get("SELECT id,sub,name FROM actors WHERE id=?", session.actor),
      scope: session.org,
      csrf: session.csrf,
      organizations: this.all(
        "SELECT o.id,o.name,m.role FROM organizations o JOIN members m ON m.org=o.id WHERE m.actor=? ORDER BY o.name",
        session.actor
      ),
      invitations: this.all(
        "SELECT i.id,i.org,o.name,i.role,i.expires FROM invitations i JOIN organizations o ON o.id=i.org WHERE i.target=(SELECT sub FROM actors WHERE id=?) AND i.state='pending' AND i.expires>?",
        session.actor,
        this.now()
      )
    };
  }
  switchScope(session, org) {
    return this.transaction(() => {
      if (org !== null)
        requireValue(
          this.get("SELECT 1 FROM members WHERE org=? AND actor=?", org, session.actor),
          "FORBIDDEN",
          403
        );
      this.record(session.actor, org, "scope.switch", org ?? "personal");
      return this.rotate(session, org);
    });
  }
  createOrganization(session, name) {
    return this.transaction(() => {
      const id3 = randomUUID2();
      this.run("INSERT INTO organizations VALUES(?,?)", id3, text(name));
      this.run("INSERT INTO members VALUES(?,?,?)", id3, session.actor, "owner");
      this.record(session.actor, id3, "organization.create", id3);
      return { id: id3, ...this.rotate(session, id3) };
    });
  }
  listMembers(session, org) {
    this.permission(session, org);
    return this.all(
      "SELECT a.id,a.sub,a.name,m.role FROM members m JOIN actors a ON a.id=m.actor WHERE m.org=?",
      org
    );
  }
  invite(session, org, target, role, hours = 24) {
    return this.transaction(() => {
      const caller = this.permission(session, org, ["owner", "admin"]);
      requireValue(
        roles.includes(role) && (caller === "owner" || !["owner", "admin"].includes(role)),
        "FORBIDDEN",
        403
      );
      requireValue(Number.isInteger(hours) && hours >= 1 && hours <= 168, "INVALID_INPUT");
      target = text(target, 200);
      requireValue(
        !this.get(
          "SELECT 1 FROM members m JOIN actors a ON a.id=m.actor WHERE m.org=? AND a.sub=?",
          org,
          target
        ),
        "ALREADY_MEMBER",
        409
      );
      const id3 = randomUUID2();
      this.run(
        "INSERT INTO invitations VALUES(?,?,?,?,?,?,?)",
        id3,
        org,
        target,
        role,
        this.now() + hours * 36e5,
        "pending",
        session.actor
      );
      this.record(session.actor, org, "invitation.create", id3);
      return { id: id3 };
    });
  }
  accept(session, id3) {
    return this.transaction(() => {
      const invitation = this.get("SELECT * FROM invitations WHERE id=?", id3);
      const actor = this.get("SELECT sub FROM actors WHERE id=?", session.actor);
      requireValue(invitation && invitation.target === actor.sub, "FORBIDDEN", 403);
      requireValue(
        invitation.state === "pending" && invitation.expires > this.now(),
        "INVITATION_UNAVAILABLE",
        409
      );
      const creator = this.get(
        "SELECT role FROM members WHERE org=? AND actor=?",
        invitation.org,
        invitation.creator
      );
      requireValue(
        creator && ["owner", "admin"].includes(creator.role) && (creator.role === "owner" || !["owner", "admin"].includes(invitation.role)),
        "INVITATION_UNAVAILABLE",
        409
      );
      requireValue(
        !this.get("SELECT 1 FROM members WHERE org=? AND actor=?", invitation.org, session.actor),
        "ALREADY_MEMBER",
        409
      );
      this.run("INSERT INTO members VALUES(?,?,?)", invitation.org, session.actor, invitation.role);
      this.run("UPDATE invitations SET state='accepted' WHERE id=?", id3);
      this.record(session.actor, invitation.org, "invitation.accept", id3);
      return { accepted: true };
    });
  }
  changeMember(session, org, actor, role) {
    return this.transaction(() => {
      const caller = this.permission(session, org, ["owner", "admin"]);
      const member = this.get("SELECT role FROM members WHERE org=? AND actor=?", org, actor);
      requireValue(member, "NOT_FOUND", 404);
      requireValue(role === null || roles.includes(role), "INVALID_INPUT");
      requireValue(
        caller === "owner" || !["owner", "admin"].includes(member.role) && !["owner", "admin"].includes(role),
        "FORBIDDEN",
        403
      );
      if (member.role === "owner" && role !== "owner")
        requireValue(
          this.get("SELECT count(*) AS n FROM members WHERE org=? AND role='owner'", org).n > 1,
          "LAST_OWNER",
          409
        );
      if (role === null) this.run("DELETE FROM members WHERE org=? AND actor=?", org, actor);
      else this.run("UPDATE members SET role=? WHERE org=? AND actor=?", role, org, actor);
      this.run("DELETE FROM sessions WHERE actor=?", actor);
      this.run("UPDATE credentials SET revoked=1 WHERE org=? AND actor=?", org, actor);
      if (this.get("SELECT 1 FROM sqlite_master WHERE type='table' AND name='catalog_credentials'"))
        this.run("UPDATE catalog_credentials SET revoked=1 WHERE org=? AND actor=?", org, actor);
      if (this.get("SELECT 1 FROM sqlite_master WHERE type='table' AND name='publishing_credentials'")) {
        this.run(
          "UPDATE publishing_credentials SET revoked=1 WHERE actor=? AND project IN (SELECT id FROM projects WHERE owner=? AND kind='organization')",
          actor,
          org
        );
        this.run(
          "UPDATE submissions SET state='invalidated',reason='Submitter permissions changed' WHERE submitter=? AND state='approved' AND project IN (SELECT id FROM projects WHERE owner=? AND kind='organization')",
          actor,
          org
        );
      }
      this.run(
        "UPDATE invitations SET state='revoked' WHERE org=? AND creator=? AND state='pending'",
        org,
        actor
      );
      this.record(session.actor, org, role === null ? "member.remove" : "member.role", actor);
      return { changed: true };
    });
  }
  namespaces(session) {
    if (session.org) this.permission(session, session.org);
    return this.all("SELECT name,kind FROM namespaces WHERE owner=?", session.org ?? session.actor);
  }
  createNamespace(session, value2) {
    return this.transaction(() => {
      if (session.org) this.permission(session, session.org, ["owner", "admin"]);
      const name = text(value2, 40).toLowerCase();
      requireValue(
        /^[a-z][a-z0-9-]{2,39}$/.test(name) && !["sitoo", "opensitoo", "admin", "system", "platform"].includes(name),
        "INVALID_NAMESPACE"
      );
      requireValue(
        !this.get("SELECT 1 FROM namespaces WHERE name=?", name),
        "NAMESPACE_CONFLICT",
        409
      );
      this.run(
        "INSERT INTO namespaces VALUES(?,?,?)",
        name,
        session.org ?? session.actor,
        session.org ? "organization" : "personal"
      );
      this.record(session.actor, session.org, "namespace.create", name);
      return { name };
    });
  }
  credentials(session, org) {
    this.permission(session, org, ["owner", "admin", "developer"]);
    return this.all(
      "SELECT id,environment,name,revoked,expires,actor FROM credentials WHERE org=?",
      org
    );
  }
  createCredential(session, org, name, environment) {
    return this.transaction(() => {
      this.permission(session, org, ["owner", "admin", "developer"]);
      requireValue(
        (this.environment === "production" ? ["production"] : ["development", "test"]).includes(
          environment
        ),
        "ENVIRONMENT_FORBIDDEN",
        403
      );
      const id3 = randomUUID2(), token = "sitoo_" + secret(), expires = this.now() + 30 * 864e5;
      this.run(
        "INSERT INTO credentials(id,hash,org,actor,environment,name,expires) VALUES(?,?,?,?,?,?,?)",
        id3,
        hash(token),
        org,
        session.actor,
        environment,
        text(name),
        expires
      );
      this.record(session.actor, org, "credential.create", id3);
      return { id: id3, token, expires, environment, scopes: ["namespace:read"] };
    });
  }
  revokeCredential(session, org, id3) {
    return this.transaction(() => {
      const role = this.permission(session, org, ["owner", "admin", "developer"]);
      const c = this.get("SELECT * FROM credentials WHERE org=? AND id=?", org, id3);
      requireValue(c, "NOT_FOUND", 404);
      requireValue(role !== "developer" || c.actor === session.actor, "FORBIDDEN", 403);
      this.run("UPDATE credentials SET revoked=1 WHERE id=?", id3);
      this.record(session.actor, org, "credential.revoke", id3);
      return { revoked: true };
    });
  }
  tokenNamespaces(token, environment) {
    const c = this.get(
      "SELECT * FROM credentials WHERE hash=? AND revoked=0 AND expires>?",
      hash(token),
      this.now()
    );
    requireValue(c, "UNAUTHENTICATED", 401);
    this.assertDataOwner(c.actor);
    if (c.org) this.assertDataOwner(c.org);
    requireValue(
      c.environment === environment && (this.environment === "production" ? ["production"] : ["development", "test"]).includes(
        environment
      ),
      "ENVIRONMENT_FORBIDDEN",
      403
    );
    requireValue(
      this.get(
        "SELECT 1 FROM members WHERE org=? AND actor=? AND role!=?",
        c.org,
        c.actor,
        "reader"
      ),
      "FORBIDDEN",
      403
    );
    return this.all("SELECT name,kind FROM namespaces WHERE owner=?", c.org);
  }
  audit(session, org) {
    this.permission(session, org, ["owner", "admin"]);
    return this.all(
      "SELECT id,at,actor,action,target FROM audit WHERE org=? ORDER BY id DESC LIMIT 100",
      org
    );
  }
  logout(session) {
    this.transaction(() => {
      this.run("DELETE FROM sessions WHERE hash=?", session.hash);
      this.record(session.actor, session.org, "logout", session.actor);
    });
  }
  close() {
    this.db.close();
  }
};

// server/src/signing-keys.mjs
function productionSigningKeys(config2) {
  requireValue(
    config2?.environment === "production" && !config2.privateKeyFile && !config2.keyId && Array.isArray(config2.keys) && config2.keys.length > 0 && config2.keys.length <= 16,
    "PRODUCTION_SIGNING_CONFIGURATION",
    503
  );
  const ids = /* @__PURE__ */ new Set(), fingerprints = /* @__PURE__ */ new Set();
  return config2.keys.map((entry) => {
    requireValue(
      /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(entry.keyId),
      "SIGNING_CONFIGURATION",
      503
    );
    requireValue(
      Number.isSafeInteger(entry.notBefore) && Number.isSafeInteger(entry.notAfter) && entry.notBefore >= 0 && entry.notAfter > entry.notBefore,
      "SIGNING_CONFIGURATION",
      503
    );
    const key = createPrivateKey2(readFileSync2(entry.privateKeyFile));
    requireValue(key.asymmetricKeyType === "ed25519", "SIGNING_CONFIGURATION", 503);
    const publicKey = createPublicKey2(key).export({ type: "spki", format: "pem" });
    requireValue(
      !ids.has(entry.keyId) && !fingerprints.has(hash(publicKey)),
      "SIGNING_CONFIGURATION",
      503
    );
    ids.add(entry.keyId);
    fingerprints.add(hash(publicKey));
    return {
      keyId: entry.keyId,
      notBefore: entry.notBefore,
      notAfter: entry.notAfter,
      key,
      publicKey
    };
  });
}
var SigningKeys = class {
  constructor(publishing, entries3) {
    this.publishing = publishing;
    this.store = publishing.store;
    this.entries = entries3;
    this.store.transaction(() => {
      this.store.db.exec(`CREATE TABLE IF NOT EXISTS signing_keys(key_id TEXT PRIMARY KEY, public_key TEXT UNIQUE NOT NULL, not_before INTEGER NOT NULL, not_after INTEGER NOT NULL, state TEXT NOT NULL CHECK(state IN ('staged','active','retired','revoked')));
        CREATE UNIQUE INDEX IF NOT EXISTS signing_active ON signing_keys(state) WHERE state='active';`);
      const history = this.list();
      requireValue(
        history.every((row) => entries3.some((e) => e.keyId === row.key_id)),
        "SIGNING_HISTORY_REQUIRED",
        503
      );
      for (const entry of entries3) {
        const old = history.find((row) => row.key_id === entry.keyId);
        requireValue(
          !old || old.public_key === entry.publicKey && old.not_before === entry.notBefore && old.not_after === entry.notAfter,
          "SIGNING_KEY_IMMUTABLE",
          503
        );
        if (!old) {
          this.store.run(
            "INSERT INTO signing_keys VALUES(?,?,?,?,'staged')",
            entry.keyId,
            entry.publicKey,
            entry.notBefore,
            entry.notAfter
          );
          this.store.record("configuration", null, "signing-key.introduce", entry.keyId);
        }
      }
      this.store.run("INSERT OR IGNORE INTO schema_version VALUES(6)");
    });
  }
  list() {
    return this.store.all("SELECT * FROM signing_keys ORDER BY key_id");
  }
  active() {
    const row = this.store.get("SELECT * FROM signing_keys WHERE state='active'");
    requireValue(
      row && row.not_before <= this.store.now() && row.not_after > this.store.now(),
      "SIGNING_KEY_UNAVAILABLE",
      503
    );
    return { ...row, key: this.entries.find((e) => e.keyId === row.key_id).key };
  }
  change(session, id3, input) {
    return this.store.transaction(() => {
      this.publishing.platform(session, "key-manager");
      const row = this.store.get("SELECT * FROM signing_keys WHERE key_id=?", id3);
      requireValue(row, "NOT_FOUND", 404);
      requireValue(["activate", "retire", "revoke"].includes(input.operation), "INVALID_INPUT");
      const reason = text(input.reason, 1e3);
      requireValue(
        row.state !== "revoked" || input.operation === "revoke",
        "KEY_REVOCATION_PERMANENT",
        409
      );
      if (input.operation === "activate") {
        requireValue(row.state === "staged" || row.state === "active", "KEY_NOT_STAGED", 409);
        requireValue(
          row.not_before <= this.store.now() && row.not_after > this.store.now(),
          "SIGNING_KEY_UNAVAILABLE",
          409
        );
        this.store.run(
          "UPDATE signing_keys SET state='retired' WHERE state='active' AND key_id<>?",
          id3
        );
      }
      const state = { activate: "active", retire: "retired", revoke: "revoked" }[input.operation];
      if (row.state !== state) {
        this.store.run("UPDATE signing_keys SET state=? WHERE key_id=?", state, id3);
        this.store.record(
          session.actor,
          null,
          "signing-key." + input.operation,
          JSON.stringify({ keyId: id3, reason })
        );
      }
      return { keyId: id3, state };
    });
  }
  policies(namespace2) {
    return this.list().filter((row) => row.state !== "staged").map((row) => ({
      keyId: this.publishing.signingId(namespace2, row.key_id),
      namespace: namespace2,
      environments: ["production"],
      publicKeyPem: row.public_key,
      notBefore: row.not_before,
      notAfter: row.not_after,
      revoked: !["active", "retired"].includes(row.state)
    }));
  }
};

// server/src/config.mjs
function deploymentConfig(config2) {
  const environment = config2.deploymentEnvironment ?? "development";
  requireValue(["development", "production"].includes(environment), "UNSAFE_CONFIGURATION", 503);
  const production = environment === "production";
  requireValue(
    config2.isolatedSessionCookies === void 0 || typeof config2.isolatedSessionCookies === "boolean",
    "UNSAFE_CONFIGURATION",
    503
  );
  const origin = new URL(config2.origin);
  const issuer = new URL(config2.issuer);
  for (const url2 of [origin, issuer]) {
    requireValue(
      !url2.username && !url2.password && !url2.search && !url2.hash && (url2.protocol === "https:" || !production && url2.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url2.hostname)),
      "UNSAFE_CONFIGURATION",
      503
    );
  }
  requireValue(origin.pathname === "/", "UNSAFE_CONFIGURATION", 503);
  requireValue(
    typeof config2.clientId === "string" && config2.clientId.trim() === config2.clientId && config2.clientId.length > 0 && config2.clientId.length <= 200,
    "IDENTITY_CONFIGURATION",
    503
  );
  requireValue(
    Array.isArray(config2.invitedSubjects) && config2.invitedSubjects.length > 0 && config2.invitedSubjects.every(
      (s) => typeof s === "string" && s.length > 0 && s.length <= 200
    ) && new Set(config2.invitedSubjects).size === config2.invitedSubjects.length,
    "IDENTITY_CONFIGURATION",
    503
  );
  let signingKeys;
  if (production) {
    requireValue(
      !["ecosystem-center", "desktop", "new-api"].includes(config2.clientId),
      "DEVELOPMENT_IDENTITY_FORBIDDEN",
      503
    );
    requireValue(
      (!config2.catalog || config2.publishing) && !config2.support,
      "PRODUCTION_PUBLISHING_UNAVAILABLE",
      503
    );
    if (config2.publishing) signingKeys = productionSigningKeys(config2.publishing);
    requireValue(config2.clientSecretFile, "CLIENT_AUTHENTICATION_REQUIRED", 503);
    requireValue(config2.tls?.certFile && config2.tls?.keyFile, "TLS_CONFIGURATION_REQUIRED", 503);
  }
  requireValue(
    Boolean(config2.tls) === (origin.protocol === "https:"),
    "TLS_CONFIGURATION_REQUIRED",
    503
  );
  let tls;
  if (config2.tls) {
    tls = {
      cert: readFileSync3(config2.tls.certFile),
      key: readFileSync3(config2.tls.keyFile),
      minVersion: "TLSv1.2"
    };
    createSecureContext(tls);
  }
  const clientSecret = config2.clientSecretFile ? readFileSync3(config2.clientSecretFile, "utf8").trim() : void 0;
  if (production) requireValue(clientSecret?.length >= 32, "CLIENT_AUTHENTICATION_REQUIRED", 503);
  const binding2 = {
    environment,
    origin: origin.origin,
    clientId: config2.clientId,
    issuer: issuer.href.replace(/\/$/, "")
  };
  let documentationUrl;
  if (config2.documentationUrl) {
    const docs = new URL(config2.documentationUrl);
    requireValue(
      !docs.username && !docs.password && (docs.protocol === "https:" || !production && docs.protocol === "http:" && ["127.0.0.1", "localhost"].includes(docs.hostname)),
      "UNSAFE_CONFIGURATION",
      503
    );
    documentationUrl = docs.href;
  } else if (!production) documentationUrl = "http://127.0.0.1:18700/";
  const suffix = hash(JSON.stringify(binding2)).slice(0, 24);
  return {
    ...binding2,
    signingKeys,
    tls,
    clientSecret,
    documentationUrl,
    identityCA: config2.identityCaFile ? readFileSync3(config2.identityCaFile) : void 0,
    sessionCookie: production ? "__Host-sitoo_center_" + suffix : config2.isolatedSessionCookies ? "sitoo_center_" + suffix : "sitoo_center",
    loginCookie: production ? "__Host-sitoo_login_" + suffix : config2.isolatedSessionCookies ? "sitoo_login_" + suffix : "sitoo_login",
    loginPath: production ? "/" : "/auth",
    binding: JSON.stringify(binding2)
  };
}

// server/src/http.mjs
import { randomUUID as randomUUID9 } from "node:crypto";

// server/src/data-management.mjs
import { randomUUID as randomUUID3 } from "node:crypto";
var DataManagement = class {
  constructor(store, config2) {
    this.store = store;
    this.config = config2;
    this.previews = /* @__PURE__ */ new Map();
    readRegistry(config2.registry, config2.binding);
    store.transaction(() => {
      store.db.exec(`CREATE TABLE IF NOT EXISTS deleted_owners(owner TEXT PRIMARY KEY,at INTEGER NOT NULL);
        INSERT OR IGNORE INTO schema_version VALUES(7);`);
    });
    for (const entry of readRegistry(config2.registry, config2.binding).deleted) {
      if (store.get("SELECT 1 FROM deleted_owners WHERE owner=?", entry.owner)) continue;
      const kind = store.get("SELECT 1 FROM organizations WHERE id=?", entry.owner) ? "organization" : store.get("SELECT 1 FROM actors WHERE id=?", entry.owner) ? "personal" : null;
      if (kind) this.erase({ id: entry.owner, kind }, "data-recovery");
    }
  }
  owner(session) {
    requireValue(
      this.store.get(
        "SELECT 1 FROM sessions WHERE hash=? AND expires>?",
        session.hash,
        this.store.now()
      ),
      "UNAUTHENTICATED",
      401
    );
    if (session.org) this.store.permission(session, session.org, ["owner"]);
    return { id: session.org ?? session.actor, kind: session.org ? "organization" : "personal" };
  }
  export(session) {
    const owner = this.owner(session), s = this.store;
    const has = (table) => Boolean(s.get("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", table));
    const projects = has("projects") ? s.all("SELECT * FROM projects WHERE owner=? AND kind=? ORDER BY id", owner.id, owner.kind) : [];
    const submissions = projects.flatMap(
      (p) => s.all(
        "SELECT id,project,version,digest,manifest,sources,state,submitted_at FROM submissions WHERE project=? ORDER BY id",
        p.id
      )
    );
    const result = {
      version: 1,
      environment: s.environment,
      owner,
      profile: session.org ? s.get("SELECT id,name FROM organizations WHERE id=?", session.org) : s.get("SELECT id,sub,name FROM actors WHERE id=?", session.actor),
      namespaces: s.all(
        "SELECT name FROM namespaces WHERE owner=? AND kind=? ORDER BY name",
        owner.id,
        owner.kind
      ),
      projects,
      submissions,
      credentials: session.org ? s.all(
        "SELECT id,environment,name,revoked,expires FROM credentials WHERE org=?",
        session.org
      ) : s.all(
        "SELECT id,environment,name,revoked,expires FROM credentials WHERE actor=? AND org IS NULL",
        session.actor
      ),
      feedback: has("feedback") ? projects.flatMap(
        (p) => s.all("SELECT id,title,description,state,revision FROM feedback WHERE project=?", p.id)
      ) : [],
      browserInstallations: has("browser_roots") ? session.org ? s.all(
        "SELECT application,project,release,actor FROM browser_roots WHERE org=?",
        session.org
      ) : s.all(
        "SELECT application,project,release FROM browser_roots WHERE actor=? AND org IS NULL",
        session.actor
      ) : []
    };
    s.record(session.actor, session.org, "data.export", owner.id);
    return result;
  }
  preview(session) {
    const owner = this.owner(session), s = this.store;
    if (!session.org)
      requireValue(
        !s.get("SELECT 1 FROM members WHERE actor=? AND role='owner'", session.actor),
        "ORGANIZATION_OWNERSHIP_REQUIRED",
        409
      );
    const data = this.export(session);
    const review = {
      owner,
      projects: data.projects.map((p) => p.id),
      submissions: data.submissions.map((r) => r.id),
      credentials: data.credentials.map((r) => r.id),
      dataDigest: digest(JSON.stringify(data)),
      retentionDays: 30,
      irreversible: true
    };
    const token = randomUUID3(), confirmation = digest(JSON.stringify(review));
    this.previews.set(token, {
      actor: session.actor,
      scope: session.org,
      review,
      confirmation,
      expires: s.now() + 3e5
    });
    if (this.previews.size > 128) this.previews.delete(this.previews.keys().next().value);
    return { token, confirmation, ...review };
  }
  apply(session, input) {
    const owner = this.owner(session), s = this.store, draft = this.previews.get(input?.token);
    requireValue(
      draft && draft.actor === session.actor && draft.scope === session.org && draft.expires > s.now() && input.confirmation === draft.confirmation && input.confirm === "DELETE",
      "DELETE_CONFIRMATION_REQUIRED",
      409
    );
    if (!session.org)
      requireValue(
        !s.get("SELECT 1 FROM members WHERE actor=? AND role='owner'", session.actor),
        "ORGANIZATION_OWNERSHIP_REQUIRED",
        409
      );
    const data = this.export(session);
    const review = {
      ...draft.review,
      projects: data.projects.map((p) => p.id),
      submissions: data.submissions.map((r) => r.id),
      credentials: data.credentials.map((r) => r.id),
      dataDigest: digest(JSON.stringify(data))
    };
    requireValue(
      digest(JSON.stringify(review)) === draft.confirmation,
      "DELETE_PREVIEW_CHANGED",
      409
    );
    registerDeletion(this.config.registry, this.config.binding, owner.id);
    this.erase(owner, session.actor);
    this.previews.delete(input.token);
    return { deleted: owner, backupPolicy: "quarantined", retentionDays: 30 };
  }
  erase(owner, actor) {
    const s = this.store;
    const projects = s.get("SELECT 1 FROM sqlite_master WHERE type='table' AND name='projects'") ? s.all("SELECT * FROM projects WHERE owner=? AND kind=?", owner.id, owner.kind) : [];
    const submissions = projects.flatMap(
      (p) => s.all("SELECT id,project FROM submissions WHERE project=?", p.id)
    );
    s.transaction(() => {
      const has = (table) => Boolean(s.get("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", table));
      const revoke = (table, where, value2) => {
        if (has(table)) s.run(`UPDATE ${table} SET revoked=1 WHERE ${where}`, value2);
      };
      for (const table of ["browser_roots", "browser_operations"])
        if (has(table)) {
          if (owner.kind === "organization") s.run(`DELETE FROM ${table} WHERE org=?`, owner.id);
          else s.run(`DELETE FROM ${table} WHERE actor=?`, owner.id);
        }
      if (owner.kind === "organization") {
        s.run("DELETE FROM sessions WHERE org=?", owner.id);
        revoke("credentials", "org=?", owner.id);
        revoke("catalog_credentials", "org=?", owner.id);
        for (const p of projects) revoke("publishing_credentials", "project=?", p.id);
        s.run("DELETE FROM invitations WHERE org=?", owner.id);
        s.run("DELETE FROM members WHERE org=?", owner.id);
        s.run("UPDATE organizations SET name='deleted' WHERE id=?", owner.id);
      } else {
        s.run("DELETE FROM sessions WHERE actor=?", owner.id);
        for (const table of ["credentials", "catalog_credentials", "publishing_credentials"])
          revoke(table, "actor=?", owner.id);
        s.run("DELETE FROM members WHERE actor=?", owner.id);
        const subject = s.get("SELECT sub FROM actors WHERE id=?", owner.id).sub;
        s.run("DELETE FROM invitations WHERE target=? OR creator=?", subject, owner.id);
        s.run("UPDATE actors SET sub=?,name='' WHERE id=?", "deleted:" + owner.id, owner.id);
      }
      s.run("DELETE FROM namespaces WHERE owner=? AND kind=?", owner.id, owner.kind);
      for (const project of projects) {
        if (has("catalog_channels"))
          s.run("DELETE FROM catalog_channels WHERE project=?", project.id);
        if (has("catalog_projects"))
          s.run("DELETE FROM catalog_projects WHERE project=?", project.id);
        if (has("catalog_optouts"))
          s.run("DELETE FROM catalog_optouts WHERE project=?", project.id);
        if (has("diagnostics")) s.run("DELETE FROM diagnostics WHERE project=?", project.id);
        if (has("feedback")) {
          s.run(
            "DELETE FROM feedback_events WHERE ticket IN (SELECT id FROM feedback WHERE project=?)",
            project.id
          );
          s.run("DELETE FROM feedback WHERE project=?", project.id);
        }
        for (const release of submissions.filter((r) => r.project === project.id)) {
          if (has("withdrawn"))
            s.run(
              "INSERT OR IGNORE INTO withdrawn VALUES(?,?,?,?)",
              release.id,
              actor,
              "owner-data-deleted",
              s.now()
            );
          if (has("withdrawn"))
            s.run("UPDATE withdrawn SET reason='owner-data-deleted' WHERE release=?", release.id);
          s.run(
            "UPDATE submissions SET manifest='{}',sources='{}',state='rejected',reason='owner-data-deleted' WHERE id=?",
            release.id
          );
          if (has("published")) s.run("UPDATE published SET envelope='{}' WHERE id=?", release.id);
        }
        s.run(
          "UPDATE projects SET name='deleted',author='',sdk='',license='' WHERE id=?",
          project.id
        );
      }
      s.run("INSERT OR IGNORE INTO deleted_owners VALUES(?,?)", owner.id, s.now());
      s.record(actor, owner.kind === "organization" ? owner.id : null, "data.delete", owner.id);
    });
  }
};

// packages/browser-host/controller.mjs
import { createHash as createHash7, randomUUID as randomUUID5, randomBytes as randomBytes2 } from "node:crypto";
import {
  mkdirSync as mkdirSync3,
  readFileSync as readFileSync4,
  writeFileSync as writeFileSync2,
  renameSync as renameSync2,
  realpathSync as realpathSync2,
  existsSync as existsSync3
} from "node:fs";
import { resolve, join as join4, isAbsolute } from "node:path";

// packages/capability-packages/src/index.ts
import { createHash as createHash4 } from "node:crypto";
var import_semver2 = __toESM(require_semver2(), 1);

// packages/capability-broker/src/index.ts
var import_ajv = __toESM(require_ajv(), 1);
var import_semver = __toESM(require_semver2(), 1);

// packages/capability-protocol/src/types.ts
var TASK_STATUSES = [
  "queued",
  "running",
  "needs-input",
  "needs-approval",
  "completed",
  "failed",
  "cancelled",
  "unknown"
];
var ERROR_MESSAGES = Object.freeze({
  UNAUTHENTICATED: "Authentication is required.",
  FORBIDDEN: "The capability is not authorized.",
  INVALID_INPUT: "The request is invalid.",
  INVALID_OUTPUT: "The capability response is invalid.",
  INCOMPATIBLE: "The protocol or capability is incompatible.",
  CONFLICT: "The request conflicts with an existing request.",
  LIMIT_EXCEEDED: "The request exceeds a platform limit.",
  UNAVAILABLE: "The capability is unavailable.",
  RESULT_UNKNOWN: "The result is unknown. Query the original task.",
  CANCELLED: "Execution was cancelled.",
  INTERNAL_ERROR: "The capability could not complete the request."
});

// packages/capability-protocol/src/schemas.ts
var UUID_PATTERN = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}(?![\\s\\S])";
var CAPABILITY_ID_PATTERN = "^[a-z][a-z0-9-]{0,62}/[a-z][a-z0-9.-]{0,126}(?![\\s\\S])";
var uuid = { type: "string", pattern: UUID_PATTERN, maxLength: 36 };
var capabilityId = { type: "string", pattern: CAPABILITY_ID_PATTERN, maxLength: 191 };
var object = (properties) => ({
  type: "object",
  properties,
  required: Object.keys(properties),
  additionalProperties: false
});
var requestSchema = object({
  protocolVersion: { const: 1 },
  requestId: uuid,
  capabilityId,
  input: {}
});
var taskReferenceSchema = object({
  taskId: {
    type: "string",
    pattern: "^[A-Za-z0-9][A-Za-z0-9._-]{0,127}(?![\\s\\S])",
    maxLength: 128
  },
  requestId: uuid,
  capabilityId,
  status: { enum: TASK_STATUSES }
});
var errorSchema = {
  anyOf: Object.entries(ERROR_MESSAGES).map(
    ([code, message2]) => object({ code: { const: code }, message: { const: message2 } })
  )
};
var responseSchema = {
  anyOf: [
    object({
      protocolVersion: { const: 1 },
      requestId: uuid,
      status: { const: "success" },
      value: {}
    }),
    object({
      protocolVersion: { const: 1 },
      requestId: uuid,
      status: { const: "accepted" },
      task: taskReferenceSchema
    }),
    object({
      protocolVersion: { const: 1 },
      requestId: uuid,
      status: { const: "error" },
      error: errorSchema
    })
  ]
};
function freeze(schema) {
  if (schema.properties) {
    Object.values(schema.properties).forEach(freeze);
    Object.freeze(schema.properties);
  }
  schema.anyOf?.forEach(freeze);
  if (schema.anyOf) Object.freeze(schema.anyOf);
  if (schema.required) Object.freeze(schema.required);
  if (schema.enum) Object.freeze(schema.enum);
  return Object.freeze(schema);
}
[requestSchema, taskReferenceSchema, responseSchema].forEach(freeze);

// packages/capability-protocol/src/index.ts
var PROTOCOL_LIMITS = Object.freeze({
  requestBytes: 64 * 1024,
  responseBytes: 128 * 1024,
  maxDepth: 32,
  maxNodes: 8192
});
function createCapabilityError(code) {
  const safeCode = Object.hasOwn(ERROR_MESSAGES, code) ? code : "INTERNAL_ERROR";
  return { code: safeCode, message: ERROR_MESSAGES[safeCode] };
}
function matches(value2, schema) {
  if (Object.hasOwn(schema, "const") && value2 !== schema.const) return false;
  if (schema.enum && (typeof value2 !== "string" || !schema.enum.includes(value2))) return false;
  if (schema.anyOf && !schema.anyOf.some((branch) => matches(value2, branch))) return false;
  if (schema.type === "string") {
    if (typeof value2 !== "string") return false;
    if (schema.maxLength !== void 0 && value2.length > schema.maxLength) return false;
    if (schema.pattern && !new RegExp(schema.pattern).test(value2)) return false;
  }
  if (schema.type === "object") {
    if (value2 === null || typeof value2 !== "object" || Array.isArray(value2)) return false;
    if (schema.required?.some((key) => !Object.hasOwn(value2, key))) return false;
    for (const key of Object.keys(value2)) {
      if (!Object.hasOwn(schema.properties ?? {}, key)) {
        if (schema.additionalProperties === false) return false;
      } else if (!matches(value2[key], schema.properties[key])) return false;
    }
  }
  return true;
}
function jsonSnapshot(value2, byteLimit) {
  let nodes = 0;
  let characters = 0;
  const ancestors = /* @__PURE__ */ new Set();
  function visit(item, depth) {
    if (++nodes > PROTOCOL_LIMITS.maxNodes || depth > PROTOCOL_LIMITS.maxDepth) throw new Error();
    if (typeof item === "string") {
      characters += item.length;
      if (characters > byteLimit) throw new Error();
      return;
    }
    if (item === null || typeof item === "boolean") return;
    if (typeof item === "number" && Number.isFinite(item)) return;
    if (typeof item !== "object" || ancestors.has(item)) throw new Error();
    const array = Array.isArray(item);
    const prototype = Object.getPrototypeOf(item);
    if (!array && prototype !== Object.prototype && prototype !== null) throw new Error();
    if (array && prototype !== Array.prototype) throw new Error();
    ancestors.add(item);
    const keys = Reflect.ownKeys(item);
    if (keys.length > PROTOCOL_LIMITS.maxNodes || array && keys.length !== item.length + 1)
      throw new Error();
    for (const key of keys) {
      if (array && key === "length") continue;
      const descriptor = Object.getOwnPropertyDescriptor(item, key);
      if (typeof key !== "string" || !descriptor?.enumerable || !Object.hasOwn(descriptor, "value"))
        throw new Error();
      if (!array) characters += key.length;
      if (characters > byteLimit) throw new Error();
      if (array && !/^(0|[1-9][0-9]*)$/.test(key)) throw new Error();
      visit(descriptor.value, depth + 1);
    }
    ancestors.delete(item);
  }
  visit(value2, 0);
  const encoded = JSON.stringify(value2);
  if (new TextEncoder().encode(encoded).byteLength > byteLimit) throw new Error();
  return JSON.parse(encoded);
}
function parse(value2, schema, bytes, code) {
  try {
    const snapshot4 = jsonSnapshot(value2, bytes);
    return matches(snapshot4, schema) ? { ok: true, value: snapshot4 } : { ok: false, error: createCapabilityError(code) };
  } catch {
    return { ok: false, error: createCapabilityError(code) };
  }
}
function parseCapabilityRequest(value2) {
  const result = parse(
    value2,
    requestSchema,
    PROTOCOL_LIMITS.requestBytes,
    "INVALID_INPUT"
  );
  if (!result.ok && value2 !== null && typeof value2 === "object") {
    try {
      const version = Object.getOwnPropertyDescriptor(value2, "protocolVersion");
      if (version && Object.hasOwn(version, "value") && typeof version.value === "number" && Number.isInteger(version.value) && version.value !== 1)
        return { ok: false, error: createCapabilityError("INCOMPATIBLE") };
    } catch {
    }
  }
  return result;
}
function parseCapabilityTaskReference(value2) {
  return parse(value2, taskReferenceSchema, PROTOCOL_LIMITS.responseBytes, "INVALID_OUTPUT");
}
function parseCapabilityResponse(value2, expectedRequest) {
  const result = parse(
    value2,
    responseSchema,
    PROTOCOL_LIMITS.responseBytes,
    "INVALID_OUTPUT"
  );
  if (!result.ok) return result;
  const response = result.value;
  if (expectedRequest && response.requestId !== expectedRequest.requestId || response.status === "accepted" && (response.task.requestId !== response.requestId || expectedRequest && response.task.capabilityId !== expectedRequest.capabilityId))
    return { ok: false, error: createCapabilityError("INVALID_OUTPUT") };
  return result;
}

// packages/capability-broker/src/index.ts
var fixtureId = "019c7714-3b77-74d1-9866-e1f484aae2ab";
var entries = ["application", "conversation", "service"];
var environments = ["development", "test", "production"];
var failure = (code) => ({
  ok: false,
  error: createCapabilityError(code)
});
var CapabilityRegistrationError = class extends Error {
  code;
  constructor(code) {
    super(createCapabilityError(code).message);
    this.code = code;
  }
};
function reject(code = "INVALID_INPUT") {
  throw new CapabilityRegistrationError(code);
}
function snapshot(value2) {
  const result = parseCapabilityRequest({
    protocolVersion: 1,
    requestId: fixtureId,
    capabilityId: "platform/validation",
    input: value2
  });
  if (!result.ok) reject();
  return result.value.input;
}
function freeze2(value2) {
  if (value2 && typeof value2 === "object") {
    Object.values(value2).forEach(freeze2);
    Object.freeze(value2);
  }
  return value2;
}
function exact(value2, keys) {
  return !!value2 && typeof value2 === "object" && !Array.isArray(value2) && Object.keys(value2).length === keys.length && keys.every((key) => Object.hasOwn(value2, key));
}
function identifier(value2) {
  return typeof value2 === "string" && parseCapabilityRequest({
    protocolVersion: 1,
    requestId: fixtureId,
    capabilityId: value2,
    input: null
  }).ok;
}
function strings(value2, check) {
  return Array.isArray(value2) && value2.length <= 64 && value2.every((item) => typeof item === "string" && check(item)) && new Set(value2).size === value2.length;
}
var permission = (value2) => value2.length <= 128 && /^[a-z][a-z0-9.-]*(?::[a-z][a-z0-9.-]*)+(?![\s\S])/.test(value2);
var scope = (value2) => typeof value2 === "string" && /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,191}(?![\s\S])/.test(value2);
function binding(value2) {
  return exact(value2, ["capabilityId", "packageId", "version", "sha256"]) && identifier(value2.capabilityId) && identifier(value2.packageId) && value2.capabilityId.split("/")[0] === value2.packageId.split("/")[0] && typeof value2.version === "string" && value2.version.length <= 128 && import_semver.default.valid(value2.version) === value2.version && typeof value2.sha256 === "string" && /^[a-f0-9]{64}(?![\s\S])/.test(value2.sha256);
}
var bindingKey = (value2) => JSON.stringify([value2.capabilityId, value2.packageId, value2.version, value2.sha256]);
function canonical(value2) {
  if (!value2 || typeof value2 !== "object") return JSON.stringify(value2);
  if (Array.isArray(value2)) return `[${value2.map(canonical).join(",")}]`;
  return `{${Object.keys(value2).sort().map((key) => `${JSON.stringify(key)}:${canonical(value2[key])}`).join(",")}}`;
}
function compile(schema) {
  if (typeof schema !== "boolean" && (!schema || typeof schema !== "object" || Array.isArray(schema)))
    reject();
  function check(value2) {
    if (!value2 || typeof value2 !== "object") return;
    if (!Array.isArray(value2)) {
      if (Object.hasOwn(value2, "$async") || Object.hasOwn(value2, "$id")) reject();
      if (Object.hasOwn(value2, "$ref") && (typeof value2.$ref !== "string" || !value2.$ref.startsWith("#")))
        reject();
    }
    Object.values(value2).forEach(check);
  }
  check(schema);
  try {
    return new import_ajv.Ajv({
      strict: true,
      allErrors: false,
      coerceTypes: false,
      useDefaults: false,
      removeAdditional: false
    }).compile(schema);
  } catch {
    return reject();
  }
}
var CapabilityBroker = class {
  #registry = /* @__PURE__ */ new Map();
  #packageDigests = /* @__PURE__ */ new Map();
  #sessions = /* @__PURE__ */ new WeakMap();
  #approvals = /* @__PURE__ */ new WeakMap();
  #diagnostic;
  constructor(options = {}) {
    this.#diagnostic = options.onDiagnostic;
  }
  register(raw, executor) {
    const declaration = snapshot(raw);
    if (!exact(declaration, [
      "binding",
      "interfaceVersion",
      "inputSchema",
      "outputSchema",
      "permissions",
      "allowedEntries",
      "delegates",
      "effects"
    ]) || !binding(declaration.binding) || declaration.interfaceVersion !== 1 || !strings(declaration.permissions, permission) || !strings(declaration.allowedEntries, (value2) => entries.includes(value2)) || !declaration.allowedEntries.length || !strings(declaration.delegates, identifier) || !exact(declaration.effects, ["billable", "externalWrite"]) || typeof declaration.effects.billable !== "boolean" || typeof declaration.effects.externalWrite !== "boolean" || typeof executor !== "function")
      reject();
    const key = bindingKey(declaration.binding);
    const packageKey = JSON.stringify([declaration.binding.packageId, declaration.binding.version]);
    const digest4 = this.#packageDigests.get(packageKey);
    if (this.#registry.has(key) || digest4 && digest4 !== declaration.binding.sha256)
      reject("CONFLICT");
    const input = compile(declaration.inputSchema);
    const output = compile(declaration.outputSchema);
    this.#registry.set(key, { declaration: freeze2(declaration), executor, input, output });
    this.#packageDigests.set(packageKey, declaration.binding.sha256);
  }
  createSession(raw) {
    const policy2 = snapshot(raw);
    if (!exact(policy2, [
      "tenantId",
      "environment",
      "installationId",
      "consumerAppId",
      "entry",
      "grants",
      "bindings"
    ]) || !scope(policy2.tenantId) || !scope(policy2.installationId) || !scope(policy2.consumerAppId) || !environments.includes(policy2.environment) || !entries.includes(policy2.entry) || !strings(policy2.grants, permission) || !Array.isArray(policy2.bindings) || policy2.bindings.length > 64 || !policy2.bindings.every(binding) || new Set(policy2.bindings.map((item) => item.capabilityId)).size !== policy2.bindings.length)
      reject();
    const session = Object.freeze({});
    this.#sessions.set(session, freeze2(policy2));
    return session;
  }
  revokeSession(session) {
    this.#sessions.delete(session);
  }
  /** Trusted host introspection; never expose the session policy to a guest. */
  getCaller(session) {
    const policy2 = this.#sessions.get(session);
    return policy2 ? { ok: true, value: policy2 } : failure("UNAUTHENTICATED");
  }
  /** Validate without executing. The task host can persist this exact binding first. */
  prepare(session, raw, options = {}) {
    const caller = this.getCaller(session);
    if (!caller.ok) return caller;
    const parsed = parseCapabilityRequest(raw);
    if (!parsed.ok) return parsed;
    const resolved = caller.value.bindings.find(
      (item) => item.capabilityId === parsed.value.capabilityId
    );
    if (!resolved) return failure("FORBIDDEN");
    const target = this.#registry.get(bindingKey(resolved));
    if (!target) return failure("UNAVAILABLE");
    const declaration = target.declaration;
    if (!declaration.allowedEntries.includes(caller.value.entry) || declaration.permissions.some((item) => !caller.value.grants.includes(item)) || !options.inspectEffects && (declaration.effects.billable || declaration.effects.externalWrite))
      return failure("FORBIDDEN");
    if (!target.input(parsed.value.input)) return failure("INVALID_INPUT");
    return {
      ok: true,
      value: freeze2({ request: parsed.value, binding: resolved, effects: declaration.effects })
    };
  }
  /** Called only after a trusted confirmation UI/action; does not authenticate a user itself. */
  issueApproval(session, raw, ttlMs = 3e4) {
    if (!Number.isInteger(ttlMs) || ttlMs < 1 || ttlMs > 3e5) return failure("INVALID_INPUT");
    const prepared = this.prepare(session, raw, { inspectEffects: true });
    if (!prepared.ok) return prepared;
    if (!prepared.value.effects.billable && !prepared.value.effects.externalWrite)
      return failure("CONFLICT");
    const approval = Object.freeze({});
    const expiresAt = Date.now() + ttlMs;
    this.#approvals.set(approval, {
      session,
      request: canonical(prepared.value.request),
      binding: bindingKey(prepared.value.binding),
      expiresAt
    });
    return { ok: true, value: { approval, expiresAt } };
  }
  /** Query results pass the same wire correlation and business output schema. */
  validateResult(session, raw, output) {
    const prepared = this.prepare(session, raw, { inspectEffects: true });
    if (!prepared.ok) return prepared;
    const parsed = parseCapabilityResponse(output, prepared.value.request);
    if (parsed.ok && parsed.value.status === "success" && !this.#registry.get(bindingKey(prepared.value.binding)).output(parsed.value.value))
      return failure("INVALID_OUTPUT");
    return parsed;
  }
  invoke(session, request, options = {}) {
    return this.#invoke(session, request, void 0, options);
  }
  async #invoke(session, raw, chain, options = {}) {
    const policy2 = this.#sessions.get(session);
    if (!policy2) return failure("UNAUTHENTICATED");
    if (options.signal?.aborted) return failure("CANCELLED");
    const parsed = parseCapabilityRequest(raw);
    if (!parsed.ok) return parsed;
    const request = freeze2(parsed.value);
    const started = Date.now();
    const resolved = policy2.bindings.find((item) => item.capabilityId === request.capabilityId);
    let result = failure("INTERNAL_ERROR");
    let effectDispatched = false;
    try {
      const target = resolved && this.#registry.get(bindingKey(resolved));
      if (chain && !chain.delegates.includes(request.capabilityId)) result = failure("FORBIDDEN");
      else if (!resolved) result = failure("FORBIDDEN");
      else if (!target) result = failure("UNAVAILABLE");
      else {
        const grants = chain?.grants ?? policy2.grants;
        const ancestors = chain?.ancestors ?? [];
        const declaration = target.declaration;
        if (ancestors.length >= 8) result = failure("LIMIT_EXCEEDED");
        else if (ancestors.includes(bindingKey(resolved))) result = failure("CONFLICT");
        else if (!declaration.allowedEntries.includes(policy2.entry) || declaration.permissions.some((item) => !grants.includes(item)))
          result = failure("FORBIDDEN");
        else if (!target.input(request.input)) result = failure("INVALID_INPUT");
        else if ((declaration.effects.billable || declaration.effects.externalWrite) && (chain || !this.#consumeApproval(options.approval, session, request, resolved)))
          result = failure("FORBIDDEN");
        else {
          const effective = grants.filter((item) => declaration.permissions.includes(item));
          const delegation = [
            ...chain?.delegation ?? [],
            { consumerAppId: policy2.consumerAppId, capabilityId: request.capabilityId }
          ];
          const context = freeze2({
            tenantId: policy2.tenantId,
            environment: policy2.environment,
            installationId: policy2.installationId,
            consumerAppId: policy2.consumerAppId,
            entry: policy2.entry,
            resolvedPackage: {
              packageId: resolved.packageId,
              version: resolved.version,
              sha256: resolved.sha256
            },
            grants: effective,
            delegation
          });
          let active = true;
          let output;
          try {
            effectDispatched = declaration.effects.billable || declaration.effects.externalWrite;
            output = await target.executor(
              request,
              context,
              async (nested, nestedOptions = {}) => {
                if (!active) return failure("FORBIDDEN");
                const signal = options.signal && nestedOptions.signal ? AbortSignal.any([options.signal, nestedOptions.signal]) : options.signal ?? nestedOptions.signal;
                return this.#invoke(
                  session,
                  nested,
                  {
                    rootRequestId: chain?.rootRequestId ?? request.requestId,
                    parentRequestId: request.requestId,
                    grants: effective,
                    ancestors: [...ancestors, bindingKey(resolved)],
                    delegation,
                    delegates: declaration.delegates
                  },
                  { signal }
                );
              },
              options
            );
          } finally {
            active = false;
          }
          result = parseCapabilityResponse(output, request);
          if (!result.ok && effectDispatched) result = failure("RESULT_UNKNOWN");
          if (result.ok && result.value.status === "success" && !target.output(result.value.value))
            result = failure(effectDispatched ? "RESULT_UNKNOWN" : "INVALID_OUTPUT");
        }
      }
    } catch {
      result = failure(effectDispatched ? "RESULT_UNKNOWN" : "INTERNAL_ERROR");
    }
    const diagnostic = freeze2({
      requestId: request.requestId,
      rootRequestId: chain?.rootRequestId ?? request.requestId,
      ...chain ? { parentRequestId: chain.parentRequestId } : {},
      capabilityId: request.capabilityId,
      tenantId: policy2.tenantId,
      environment: policy2.environment,
      installationId: policy2.installationId,
      consumerAppId: policy2.consumerAppId,
      ...resolved ? { binding: resolved } : {},
      depth: chain?.ancestors.length ?? 0,
      outcome: result.ok ? result.value.status : "error",
      ...!result.ok ? { code: result.error.code } : result.value.status === "error" ? { code: result.value.error.code } : {},
      durationMs: Math.max(0, Date.now() - started)
    });
    try {
      const logged = this.#diagnostic?.(diagnostic);
      if (logged) void logged.catch(() => {
      });
    } catch {
    }
    return result;
  }
  #consumeApproval(approval, session, request, binding2) {
    if (!approval) return false;
    const saved = this.#approvals.get(approval);
    this.#approvals.delete(approval);
    return !!saved && saved.session === session && saved.expiresAt > Date.now() && saved.binding === bindingKey(binding2) && saved.request === canonical(request);
  }
};

// packages/capability-packages/src/internal.ts
var verifiedPackages = /* @__PURE__ */ new WeakSet();

// packages/capability-packages/src/migrations.ts
import { DatabaseSync as DatabaseSync5 } from "node:sqlite";

// packages/capability-packages/src/installations.ts
import { DatabaseSync as DatabaseSync4 } from "node:sqlite";

// packages/capability-packages/src/releases.ts
import { DatabaseSync as DatabaseSync3 } from "node:sqlite";

// packages/capability-packages/src/signatures.ts
import { createPublicKey as createPublicKey3, sign, verify, KeyObject } from "node:crypto";
var SIGNATURE_LIMITS = Object.freeze({
  keys: 32,
  attestationBytes: 4096,
  maxValidityMs: 7 * 24 * 60 * 60 * 1e3
});
var keyId = /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}(?![\s\S])/;
var namespace = /^[a-z][a-z0-9.-]{0,63}(?![\s\S])/;
var environments2 = ["development", "test", "production"];
var SignatureError = class extends Error {
  code;
  constructor(code) {
    super(createCapabilityError(code).message);
    this.code = code;
  }
};
function fail2(code) {
  throw new SignatureError(code);
}
function exact2(value2, fields) {
  return !!value2 && typeof value2 === "object" && !Array.isArray(value2) && Object.keys(value2).length === fields.length && fields.every((key) => Object.hasOwn(value2, key));
}
function snapshot2(raw) {
  const result = parseCapabilityRequest({
    protocolVersion: 1,
    requestId: "019c7714-3b77-74d1-9866-e1f484aae2ab",
    capabilityId: "platform/signature-validation",
    input: raw
  });
  if (!result.ok) fail2("INVALID_INPUT");
  return result.value.input;
}
function metadata(raw) {
  const data = snapshot2(raw);
  if (!exact2(data, ["keyId", "environment", "issuedAt", "expiresAt"]) || typeof data.keyId !== "string" || !keyId.test(data.keyId) || !environments2.includes(data.environment) || !Number.isSafeInteger(data.issuedAt) || !Number.isSafeInteger(data.expiresAt) || data.issuedAt < 0 || data.expiresAt <= data.issuedAt || data.expiresAt - data.issuedAt > SIGNATURE_LIMITS.maxValidityMs)
    fail2("INVALID_INPUT");
  return data;
}
function payload(value2) {
  return Buffer.from(
    JSON.stringify([
      "sitoo-capability-release-attestation-v1",
      value2.formatVersion,
      value2.keyId,
      value2.environment,
      value2.packageId,
      value2.version,
      value2.sha256,
      value2.issuedAt,
      value2.expiresAt
    ])
  );
}
function validation(work) {
  try {
    return { ok: true, value: work() };
  } catch (error3) {
    return {
      ok: false,
      error: createCapabilityError(error3 instanceof SignatureError ? error3.code : "INVALID_INPUT")
    };
  }
}
function signCapabilityPackage(pkg, privateKey, options) {
  return validation(() => {
    if (!verifiedPackages.has(pkg) || !(privateKey instanceof KeyObject) || privateKey.type !== "private" || privateKey.asymmetricKeyType !== "ed25519")
      fail2("INVALID_INPUT");
    const claims = {
      formatVersion: 1,
      ...metadata(options),
      packageId: pkg.manifest.packageId,
      version: pkg.manifest.version,
      sha256: pkg.sha256
    };
    return Object.freeze({
      ...claims,
      signature: sign(null, payload(claims), privateKey).toString("base64")
    });
  });
}
var CapabilityPackageTrust = class {
  #keys = /* @__PURE__ */ new Map();
  constructor(raw) {
    const data = snapshot2(raw);
    if (!Array.isArray(data) || !data.length || data.length > SIGNATURE_LIMITS.keys)
      fail2("INVALID_INPUT");
    for (const entry of data) {
      if (!exact2(entry, [
        "keyId",
        "namespace",
        "environments",
        "publicKeyPem",
        "notBefore",
        "notAfter",
        "revoked"
      ]) || typeof entry.keyId !== "string" || !keyId.test(entry.keyId) || this.#keys.has(entry.keyId) || typeof entry.namespace !== "string" || !namespace.test(entry.namespace) || !Array.isArray(entry.environments) || !entry.environments.length || entry.environments.length > 3 || new Set(entry.environments).size !== entry.environments.length || !entry.environments.every((value2) => environments2.includes(value2)) || typeof entry.publicKeyPem !== "string" || entry.publicKeyPem.length > 4096 || !entry.publicKeyPem.startsWith("-----BEGIN PUBLIC KEY-----") || !Number.isSafeInteger(entry.notBefore) || !Number.isSafeInteger(entry.notAfter) || entry.notBefore < 0 || entry.notAfter <= entry.notBefore || typeof entry.revoked !== "boolean")
        fail2("INVALID_INPUT");
      let key;
      try {
        key = createPublicKey3(entry.publicKeyPem);
      } catch {
        fail2("INVALID_INPUT");
      }
      if (key.asymmetricKeyType !== "ed25519") fail2("INVALID_INPUT");
      const policy2 = entry;
      Object.freeze(policy2.environments);
      Object.freeze(policy2);
      this.#keys.set(policy2.keyId, { policy: policy2, key });
    }
  }
  verify(pkg, raw, now = Date.now()) {
    return validation(() => {
      if (!verifiedPackages.has(pkg) || !Number.isSafeInteger(now) || now < 0)
        fail2("INVALID_INPUT");
      const data = snapshot2(raw);
      if (!exact2(data, [
        "formatVersion",
        "keyId",
        "environment",
        "packageId",
        "version",
        "sha256",
        "issuedAt",
        "expiresAt",
        "signature"
      ]) || data.formatVersion !== 1 || typeof data.signature !== "string" || Buffer.byteLength(JSON.stringify(data)) > SIGNATURE_LIMITS.attestationBytes)
        fail2("INVALID_INPUT");
      const options = metadata({
        keyId: data.keyId,
        environment: data.environment,
        issuedAt: data.issuedAt,
        expiresAt: data.expiresAt
      });
      const key = this.#keys.get(options.keyId);
      if (!key || key.policy.revoked || pkg.manifest.packageId.split("/")[0] !== key.policy.namespace || !key.policy.environments.includes(options.environment) || now < key.policy.notBefore || now >= key.policy.notAfter || options.issuedAt < key.policy.notBefore || options.expiresAt > key.policy.notAfter || now < options.issuedAt || now >= options.expiresAt || data.packageId !== pkg.manifest.packageId || data.version !== pkg.manifest.version || data.sha256 !== pkg.sha256)
        fail2("FORBIDDEN");
      const signature = Buffer.from(data.signature, "base64");
      if (signature.length !== 64 || signature.toString("base64") !== data.signature)
        fail2("INVALID_INPUT");
      const attestation = data;
      if (!verify(null, payload(attestation), key.key, signature)) fail2("FORBIDDEN");
      return Object.freeze({ package: pkg, attestation: Object.freeze(attestation) });
    });
  }
};

// packages/capability-packages/src/releases.ts
var error = (code) => ({
  ok: false,
  error: createCapabilityError(code)
});
var CapabilityReleaseStore = class {
  #db;
  #closed = false;
  #readOnly = false;
  constructor(path2, options = {}) {
    this.#readOnly = options.readOnly === true;
    try {
      this.#db = new DatabaseSync3(path2, { readOnly: this.#readOnly });
      const version = this.#db.prepare("PRAGMA user_version").get()?.user_version;
      const application = this.#db.prepare("PRAGMA application_id").get()?.application_id;
      const tables = this.#db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
      if (!(version === 0 && application === 0 && !tables.length || version === 1 && application === 1396920402))
        throw new Error("Unsupported release store schema.");
      if (this.#readOnly) {
        if (version !== 1 || application !== 1396920402) throw new Error();
        this.#db.exec("PRAGMA busy_timeout=100;");
        return;
      }
      this.#db.exec(
        "PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; PRAGMA busy_timeout=100; BEGIN IMMEDIATE; CREATE TABLE IF NOT EXISTS releases(environment TEXT NOT NULL,package_id TEXT NOT NULL,version TEXT NOT NULL,sha256 TEXT NOT NULL,manifest TEXT NOT NULL,sources TEXT NOT NULL,PRIMARY KEY(environment,package_id,version)); CREATE TABLE IF NOT EXISTS attestations(environment TEXT NOT NULL,package_id TEXT NOT NULL,version TEXT NOT NULL,signature TEXT NOT NULL,envelope TEXT NOT NULL,PRIMARY KEY(environment,package_id,version,signature)); PRAGMA user_version=1; PRAGMA application_id=0x53435052; COMMIT;"
      );
    } catch {
      try {
        this.#db?.close();
      } catch {
      }
      throw new Error("Release store unavailable.");
    }
  }
  publish(pkg, attestation, trust, now = Date.now()) {
    if (this.#closed) return error("UNAVAILABLE");
    if (this.#readOnly) return error("FORBIDDEN");
    const checked2 = trust.verify(pkg, attestation, now);
    if (!checked2.ok) return checked2;
    const envelope = checked2.value.attestation;
    let transaction = false;
    try {
      this.#db.exec("BEGIN IMMEDIATE");
      transaction = true;
      const old = this.#db.prepare("SELECT sha256 FROM releases WHERE environment=? AND package_id=? AND version=?").get(envelope.environment, envelope.packageId, envelope.version);
      if (old && old.sha256 !== pkg.sha256) {
        this.#db.exec("ROLLBACK");
        transaction = false;
        return error("CONFLICT");
      }
      const existing = this.#db.prepare(
        "SELECT signature FROM attestations WHERE environment=? AND package_id=? AND version=? AND signature=?"
      ).get(envelope.environment, envelope.packageId, envelope.version, envelope.signature);
      if (!old && Number(this.#db.prepare("SELECT COUNT(*) AS count FROM releases").get().count) >= 128 || !existing && Number(this.#db.prepare("SELECT COUNT(*) AS count FROM attestations").get().count) >= 512) {
        this.#db.exec("ROLLBACK");
        transaction = false;
        return error("LIMIT_EXCEEDED");
      }
      if (!old)
        this.#db.prepare("INSERT INTO releases VALUES (?,?,?,?,?,?)").run(
          envelope.environment,
          envelope.packageId,
          envelope.version,
          pkg.sha256,
          JSON.stringify(pkg.manifest),
          JSON.stringify(pkg.sources)
        );
      if (!existing)
        this.#db.prepare("INSERT INTO attestations VALUES (?,?,?,?,?)").run(
          envelope.environment,
          envelope.packageId,
          envelope.version,
          envelope.signature,
          JSON.stringify(envelope)
        );
      this.#db.exec("COMMIT");
      transaction = false;
      return {
        ok: true,
        value: Object.freeze({
          packageId: envelope.packageId,
          version: envelope.version,
          sha256: pkg.sha256,
          environment: envelope.environment
        })
      };
    } catch {
      if (transaction)
        try {
          this.#db.exec("ROLLBACK");
        } catch {
        }
      return error("UNAVAILABLE");
    }
  }
  get(reference, trust, now = Date.now()) {
    if (this.#closed) return error("UNAVAILABLE");
    try {
      if (!reference || !Number.isSafeInteger(now) || now < 0 || Object.keys(reference).length !== 4 || typeof reference.packageId !== "string" || typeof reference.version !== "string" || !/^[a-f0-9]{64}(?![\s\S])/.test(reference.sha256) || !["development", "test", "production"].includes(reference.environment))
        return error("INVALID_INPUT");
      const row = this.#db.prepare(
        "SELECT * FROM releases WHERE environment=? AND package_id=? AND version=? AND sha256=?"
      ).get(reference.environment, reference.packageId, reference.version, reference.sha256);
      if (!row) return error("FORBIDDEN");
      const sources = JSON.parse(row.sources);
      const files = new Map(
        Object.entries(sources).map(([path2, source]) => [path2, Buffer.from(source, "utf8")])
      );
      const pkg = verifyCapabilityPackage(row.manifest, files);
      if (!pkg.ok || pkg.value.sha256 !== reference.sha256) return error("INVALID_INPUT");
      for (const record of this.#db.prepare(
        "SELECT envelope FROM attestations WHERE environment=? AND package_id=? AND version=? ORDER BY rowid DESC"
      ).all(reference.environment, reference.packageId, reference.version)) {
        const result = trust.verify(pkg.value, JSON.parse(record.envelope), now);
        if (result.ok && result.value.attestation.environment === reference.environment)
          return result;
      }
      return error("FORBIDDEN");
    } catch {
      return error("UNAVAILABLE");
    }
  }
  close() {
    if (!this.#closed) {
      this.#closed = true;
      this.#db.close();
    }
  }
};

// packages/capability-packages/src/installations.ts
import { createHash as createHash3 } from "node:crypto";
var INSTALLATION_LIMITS = Object.freeze({ roots: 128, packages: 128, transactions: 512 });
var LEASE_LIMITS = Object.freeze({ records: 1024 });
var error2 = (code) => ({
  ok: false,
  error: createCapabilityError(code)
});
var InstallationError = class extends Error {
  code;
  constructor(code) {
    super(createCapabilityError(code).message);
    this.code = code;
  }
};
function fail3(code) {
  throw new InstallationError(code);
}
function unwrap(result) {
  if (!result.ok) fail3(result.error.code);
  return result.value;
}
function freeze3(value2) {
  if (value2 && typeof value2 === "object") {
    Object.values(value2).forEach(freeze3);
    Object.freeze(value2);
  }
  return value2;
}
function snapshot3(raw) {
  return unwrap(
    parseCapabilityRequest({
      protocolVersion: 1,
      requestId: "019c7714-3b77-74d1-9866-e1f484aae2ab",
      capabilityId: "platform/installation-validation",
      input: raw
    })
  ).input;
}
var identifier2 = (value2) => typeof value2 === "string" && /^[a-zA-Z0-9][a-zA-Z0-9._/-]{0,127}(?![\s\S])/.test(value2);
function rootKey(raw) {
  const root = snapshot3(raw);
  if (!root || Object.keys(root).length !== 4 || !identifier2(root.tenantId) || !identifier2(root.accountId) || !identifier2(root.applicationId) || !["development", "test", "production"].includes(root.environment))
    fail3("INVALID_INPUT");
  return JSON.stringify([root.tenantId, root.accountId, root.applicationId, root.environment]);
}
function checkedPlan(roots, raw, environment, releases, trust, now, applicationId) {
  const references = snapshot3(raw);
  if (!Array.isArray(references) || !references.length || references.length > INSTALLATION_LIMITS.packages)
    fail3("INVALID_INPUT");
  const packages = references.map((reference) => {
    if (!reference || reference.environment !== environment) fail3("FORBIDDEN");
    const item = unwrap(releases.get(reference, trust, now));
    if (item.attestation.environment !== environment) fail3("FORBIDDEN");
    return item;
  });
  const plan = unwrap(
    resolveCapabilityDependencies(
      roots,
      packages.map((item) => item.package)
    )
  );
  if (plan.packages.length !== packages.length || plan.packages.some(
    (item) => !references.some(
      (ref) => ref.packageId === item.packageId && ref.version === item.version && ref.sha256 === item.sha256
    )
  ))
    fail3("CONFLICT");
  checkApplicationRoot(plan, packages, applicationId);
  return { plan, packages };
}
function checkApplicationRoot(plan, packages, applicationId) {
  const applications = packages.filter(
    (item) => item.package.manifest.execution === "static-application-v1"
  );
  if (!applications.length) return;
  const manifest = applications[0].package.manifest;
  if (manifest.execution !== "static-application-v1" || applications.length !== 1 || plan.roots.length !== 1 || plan.roots[0].packageId !== manifest.packageId || manifest.application.applicationId !== applicationId)
    fail3("FORBIDDEN");
}
var CapabilityInstallationStore = class {
  #db;
  #closed = false;
  #readOnly = false;
  #scope;
  #environment;
  #applicationId;
  constructor(path2, root, options = {}) {
    this.#readOnly = options.readOnly === true;
    try {
      this.#scope = rootKey(root);
      this.#environment = JSON.parse(this.#scope)[3];
      this.#applicationId = JSON.parse(this.#scope)[2];
      this.#db = new DatabaseSync4(path2, { readOnly: options.readOnly === true });
      const version = this.#db.prepare("PRAGMA user_version").get()?.user_version;
      const application = this.#db.prepare("PRAGMA application_id").get()?.application_id;
      const tables = this.#db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
      if (!(version === 0 && application === 0 && !tables.length || (version === 1 || version === 2 || version === 3) && application === 1396918606))
        throw new Error();
      if (options.readOnly === true) {
        if (version !== 3 || application !== 1396918606) throw new Error();
        this.#db.exec("PRAGMA busy_timeout=100;");
        return;
      }
      this.#db.exec(`PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; PRAGMA busy_timeout=100;
        BEGIN IMMEDIATE;
        CREATE TABLE IF NOT EXISTS installation_transactions(scope TEXT NOT NULL,request_id TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('prepared','committed','aborted')),plan TEXT NOT NULL,PRIMARY KEY(scope,request_id));
        CREATE TABLE IF NOT EXISTS installation_roots(scope TEXT PRIMARY KEY,plan TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS installed_packages(environment TEXT NOT NULL,package_id TEXT NOT NULL,version TEXT NOT NULL,sha256 TEXT NOT NULL,manifest TEXT NOT NULL,sources TEXT NOT NULL,attestation TEXT NOT NULL,PRIMARY KEY(environment,package_id,version));
        CREATE TABLE IF NOT EXISTS installation_references(scope TEXT NOT NULL,environment TEXT NOT NULL,package_id TEXT NOT NULL,version TEXT NOT NULL,sha256 TEXT NOT NULL,PRIMARY KEY(scope,package_id));
        CREATE TABLE IF NOT EXISTS package_leases(scope TEXT NOT NULL,task_id TEXT NOT NULL,request_id TEXT NOT NULL,status TEXT NOT NULL CHECK(status IN ('active','released')),plan TEXT NOT NULL,PRIMARY KEY(scope,task_id));
        CREATE TABLE IF NOT EXISTS installation_generations(scope TEXT PRIMARY KEY,generation INTEGER NOT NULL);
        INSERT OR IGNORE INTO installation_generations SELECT scope,1 FROM installation_roots;
        CREATE TABLE IF NOT EXISTS installation_operations(scope TEXT NOT NULL,request_id TEXT NOT NULL,operation TEXT NOT NULL CHECK(operation IN ('update','uninstall')),generation INTEGER NOT NULL,PRIMARY KEY(scope,request_id));
        PRAGMA user_version=3; PRAGMA application_id=0x5343494e; COMMIT;`);
    } catch {
      try {
        this.#db?.close();
      } catch {
      }
      throw new Error("Installation store unavailable.");
    }
  }
  #work(work, write = false) {
    if (this.#closed) return error2("UNAVAILABLE");
    if (write && this.#readOnly) return { ok: false, error: createCapabilityError("FORBIDDEN") };
    let transaction = false;
    try {
      this.#db.exec(write ? "BEGIN IMMEDIATE" : "BEGIN");
      transaction = true;
      const value2 = work();
      this.#db.exec("COMMIT");
      transaction = false;
      return { ok: true, value: freeze3(value2) };
    } catch (cause) {
      if (transaction)
        try {
          this.#db.exec("ROLLBACK");
        } catch {
        }
      return error2(cause instanceof InstallationError ? cause.code : "UNAVAILABLE");
    }
  }
  #transaction(requestId) {
    if (!identifier2(requestId)) fail3("INVALID_INPUT");
    const row = this.#db.prepare("SELECT status,plan FROM installation_transactions WHERE scope=? AND request_id=?").get(this.#scope, requestId);
    if (!row) fail3("FORBIDDEN");
    return {
      requestId,
      status: row.status,
      plan: JSON.parse(row.plan)
    };
  }
  prepare(requestId, roots, references, releases, trust, now = Date.now()) {
    return this.#prepare(requestId, roots, references, releases, trust, now, false);
  }
  prepareUpdate(requestId, roots, references, releases, trust, now = Date.now()) {
    return this.#prepare(requestId, roots, references, releases, trust, now, true);
  }
  #generation() {
    return Number(
      this.#db.prepare("SELECT generation FROM installation_generations WHERE scope=?").get(this.#scope)?.generation ?? 0
    );
  }
  #operation(requestId) {
    return this.#db.prepare(
      "SELECT operation,generation FROM installation_operations WHERE scope=? AND request_id=?"
    ).get(this.#scope, requestId);
  }
  #capacity() {
    if (Number(
      this.#db.prepare("SELECT COUNT(*) AS count FROM installation_transactions").get().count
    ) >= INSTALLATION_LIMITS.transactions)
      fail3("LIMIT_EXCEEDED");
  }
  #idle() {
    if (this.#db.prepare("SELECT task_id FROM package_leases WHERE scope=? AND status='active' LIMIT 1").get(this.#scope))
      fail3("CONFLICT");
  }
  #prepare(requestId, roots, references, releases, trust, now, update) {
    return this.#work(() => {
      if (!identifier2(requestId)) fail3("INVALID_INPUT");
      const { plan, packages } = checkedPlan(
        roots,
        references,
        this.#environment,
        releases,
        trust,
        now,
        this.#applicationId
      );
      const serialized = JSON.stringify(plan);
      const old = this.#db.prepare("SELECT plan FROM installation_transactions WHERE scope=? AND request_id=?").get(this.#scope, requestId);
      if (old) {
        if (old.plan !== serialized || (this.#operation(requestId)?.operation ?? "install") !== (update ? "update" : "install"))
          fail3("CONFLICT");
        return this.#transaction(requestId);
      }
      const installed = this.#db.prepare("SELECT scope FROM installation_roots WHERE scope=?").get(this.#scope);
      if (update ? !installed : installed) fail3("CONFLICT");
      if (update) {
        const previous = this.#db.prepare(
          "SELECT p.* FROM installed_packages p JOIN installation_references r ON p.environment=r.environment AND p.package_id=r.package_id AND p.version=r.version AND p.sha256=r.sha256 WHERE r.scope=?"
        ).all(this.#scope);
        const wasApplication = previous.some(
          (row) => this.#content(row).manifest.execution === "static-application-v1"
        );
        if (wasApplication && !packages.some((item) => item.package.manifest.execution === "static-application-v1"))
          fail3("FORBIDDEN");
      }
      this.#capacity();
      this.#db.prepare("INSERT INTO installation_transactions VALUES (?,?,'prepared',?)").run(this.#scope, requestId, serialized);
      if (update)
        this.#db.prepare("INSERT INTO installation_operations VALUES (?,?,'update',?)").run(this.#scope, requestId, this.#generation());
      return this.#transaction(requestId);
    }, true);
  }
  prepareUninstall(requestId) {
    return this.#work(() => {
      if (!identifier2(requestId)) fail3("INVALID_INPUT");
      const old = this.#db.prepare("SELECT request_id FROM installation_transactions WHERE scope=? AND request_id=?").get(this.#scope, requestId);
      if (old) {
        if (this.#operation(requestId)?.operation !== "uninstall") fail3("CONFLICT");
        return this.#transaction(requestId);
      }
      const root = this.#db.prepare("SELECT plan FROM installation_roots WHERE scope=?").get(this.#scope);
      if (!root) fail3("FORBIDDEN");
      this.#capacity();
      this.#db.prepare("INSERT INTO installation_transactions VALUES (?,?,'prepared',?)").run(this.#scope, requestId, root.plan);
      this.#db.prepare("INSERT INTO installation_operations VALUES (?,?,'uninstall',?)").run(this.#scope, requestId, this.#generation());
      return this.#transaction(requestId);
    }, true);
  }
  #removeRoot() {
    this.#db.prepare("DELETE FROM installation_references WHERE scope=?").run(this.#scope);
    this.#db.prepare("DELETE FROM installation_roots WHERE scope=?").run(this.#scope);
  }
  #advance() {
    this.#db.prepare(
      "INSERT INTO installation_generations VALUES (?,1) ON CONFLICT(scope) DO UPDATE SET generation=generation+1"
    ).run(this.#scope);
  }
  commitUninstall(requestId) {
    return this.#work(() => {
      const transaction = this.#transaction(requestId);
      const operation = this.#operation(requestId);
      if (operation?.operation !== "uninstall") fail3("CONFLICT");
      if (transaction.status === "committed") return transaction;
      if (transaction.status !== "prepared" || operation.generation !== this.#generation())
        fail3("CONFLICT");
      this.#idle();
      if (!this.#db.prepare("SELECT scope FROM installation_roots WHERE scope=?").get(this.#scope))
        fail3("CONFLICT");
      this.#removeRoot();
      this.#advance();
      this.#db.prepare(
        "UPDATE installation_transactions SET status='committed' WHERE scope=? AND request_id=?"
      ).run(this.#scope, requestId);
      return this.#transaction(requestId);
    }, true);
  }
  commit(requestId, releases, trust, now = Date.now()) {
    return this.#commit(requestId, releases, trust, now);
  }
  reviewUpdate(requestId, policy2, releases, trust, now = Date.now()) {
    return this.#work(() => this.#reviewUpdate(requestId, policy2, releases, trust, now));
  }
  #reviewUpdate(requestId, raw, releases, trust, now) {
    const policy2 = snapshot3(raw);
    if (!policy2 || Object.keys(policy2).length !== 2 || !Object.hasOwn(policy2, "entry") || !Object.hasOwn(policy2, "grants"))
      fail3("INVALID_INPUT");
    try {
      const broker = new CapabilityBroker();
      const session = broker.createSession({
        tenantId: "review",
        environment: this.#environment,
        installationId: "review",
        consumerAppId: "review",
        entry: policy2.entry,
        grants: policy2.grants,
        bindings: []
      });
      broker.revokeSession(session);
    } catch {
      fail3("INVALID_INPUT");
    }
    const transaction = this.#transaction(requestId);
    const operation = this.#operation(requestId);
    if (transaction.status !== "prepared" || operation?.operation !== "update" || operation.generation !== this.#generation())
      fail3("CONFLICT");
    const current = this.#loadInstalled(trust, now);
    const target = checkedPlan(
      transaction.plan.roots,
      transaction.plan.packages.map((item) => ({ ...item, environment: this.#environment })),
      this.#environment,
      releases,
      trust,
      now,
      this.#applicationId
    );
    if (JSON.stringify(target.plan) !== JSON.stringify(transaction.plan)) fail3("CONFLICT");
    const declarations = target.packages.flatMap((item) => item.package.manifest.capabilities);
    const required = [...new Set(declarations.flatMap((item) => item.permissions))].sort();
    const previous = new Set(
      current.packages.flatMap(
        (item) => item.package.manifest.capabilities.flatMap((cap) => cap.permissions)
      )
    );
    const review = {
      requestId,
      generation: this.#generation(),
      plan: target.plan,
      policy: { entry: policy2.entry, grants: [...policy2.grants].sort() },
      required,
      added: required.filter((item) => !previous.has(item)),
      removed: [...previous].filter((item) => !required.includes(item)).sort(),
      missing: required.filter((item) => !policy2.grants.includes(item)),
      unsupportedEntries: declarations.filter((item) => !item.allowedEntries.includes(policy2.entry)).map((item) => item.capabilityId).sort()
    };
    return {
      ...review,
      reviewSha256: createHash3("sha256").update(JSON.stringify(review)).digest("hex")
    };
  }
  /** Trusted host supplies reviewed grants; this does not mint or persist execution authorization. */
  commitAuthorizedUpdate(requestId, policy2, reviewSha256, releases, trust, now = Date.now()) {
    return this.#commit(requestId, releases, trust, now, { policy: policy2, reviewSha256 });
  }
  #commit(requestId, releases, trust, now, authorization) {
    return this.#work(() => {
      const transaction = this.#transaction(requestId);
      const operation = this.#operation(requestId);
      if (authorization && operation?.operation !== "update") fail3("CONFLICT");
      if (operation?.operation === "uninstall") fail3("CONFLICT");
      if (transaction.status === "committed") return transaction;
      if (transaction.status === "aborted") fail3("CONFLICT");
      if (authorization) {
        const review = this.#reviewUpdate(requestId, authorization.policy, releases, trust, now);
        if (review.reviewSha256 !== authorization.reviewSha256) fail3("CONFLICT");
        if (review.missing.length || review.unsupportedEntries.length) fail3("FORBIDDEN");
      }
      const installed = this.#db.prepare("SELECT scope FROM installation_roots WHERE scope=?").get(this.#scope);
      if (operation?.operation === "update") {
        if (!installed || operation.generation !== this.#generation()) fail3("CONFLICT");
        this.#idle();
      } else if (installed) fail3("CONFLICT");
      const references = transaction.plan.packages.map((item) => ({
        ...item,
        environment: this.#environment
      }));
      const checked2 = checkedPlan(
        transaction.plan.roots,
        references,
        this.#environment,
        releases,
        trust,
        now,
        this.#applicationId
      );
      if (JSON.stringify(checked2.plan) !== JSON.stringify(transaction.plan)) fail3("CONFLICT");
      if (!installed && Number(this.#db.prepare("SELECT COUNT(*) AS count FROM installation_roots").get().count) >= INSTALLATION_LIMITS.roots)
        fail3("LIMIT_EXCEEDED");
      const count = Number(
        this.#db.prepare("SELECT COUNT(*) AS count FROM installed_packages").get().count
      );
      const missing = checked2.packages.filter(
        (item) => !this.#db.prepare(
          "SELECT sha256 FROM installed_packages WHERE environment=? AND package_id=? AND version=?"
        ).get(this.#environment, item.package.manifest.packageId, item.package.manifest.version)
      );
      if (count + missing.length > INSTALLATION_LIMITS.packages) fail3("LIMIT_EXCEEDED");
      if (installed) this.#removeRoot();
      for (const item of checked2.packages) {
        const pkg = item.package;
        const row = this.#db.prepare(
          "SELECT * FROM installed_packages WHERE environment=? AND package_id=? AND version=?"
        ).get(this.#environment, pkg.manifest.packageId, pkg.manifest.version);
        if (row) {
          if (row.sha256 !== pkg.sha256) fail3("CONFLICT");
          const cached = this.#content(row);
          if (cached.sha256 !== pkg.sha256) fail3("INVALID_INPUT");
          this.#db.prepare(
            "UPDATE installed_packages SET attestation=? WHERE environment=? AND package_id=? AND version=?"
          ).run(
            JSON.stringify(item.attestation),
            this.#environment,
            pkg.manifest.packageId,
            pkg.manifest.version
          );
        } else
          this.#db.prepare("INSERT INTO installed_packages VALUES (?,?,?,?,?,?,?)").run(
            this.#environment,
            pkg.manifest.packageId,
            pkg.manifest.version,
            pkg.sha256,
            JSON.stringify(pkg.manifest),
            JSON.stringify(pkg.sources),
            JSON.stringify(item.attestation)
          );
        this.#db.prepare("INSERT INTO installation_references VALUES (?,?,?,?,?)").run(
          this.#scope,
          this.#environment,
          pkg.manifest.packageId,
          pkg.manifest.version,
          pkg.sha256
        );
      }
      this.#db.prepare("INSERT INTO installation_roots VALUES (?,?)").run(this.#scope, JSON.stringify(checked2.plan));
      this.#advance();
      this.#db.prepare(
        "UPDATE installation_transactions SET status='committed' WHERE scope=? AND request_id=?"
      ).run(this.#scope, requestId);
      return this.#transaction(requestId);
    }, true);
  }
  #content(row) {
    const sources = JSON.parse(row.sources);
    const pkg = unwrap(
      verifyCapabilityPackage(
        row.manifest,
        new Map(
          Object.entries(sources).map(([path2, source]) => [path2, Buffer.from(source, "utf8")])
        )
      )
    );
    if (pkg.sha256 !== row.sha256 || pkg.manifest.packageId !== row.package_id || pkg.manifest.version !== row.version)
      fail3("INVALID_INPUT");
    return pkg;
  }
  status(requestId) {
    return this.#work(() => this.#transaction(requestId));
  }
  abort(requestId) {
    return this.#work(() => {
      const transaction = this.#transaction(requestId);
      if (transaction.status === "committed") fail3("CONFLICT");
      this.#db.prepare(
        "UPDATE installation_transactions SET status='aborted' WHERE scope=? AND request_id=?"
      ).run(this.#scope, requestId);
      return this.#transaction(requestId);
    }, true);
  }
  pending() {
    return this.#work(
      () => this.#db.prepare(
        "SELECT request_id FROM installation_transactions WHERE scope=? AND status='prepared' ORDER BY request_id"
      ).all(this.#scope).map((row) => this.#transaction(row.request_id))
    );
  }
  load(trust, now = Date.now()) {
    return this.#work(() => this.#loadInstalled(trust, now));
  }
  #loadInstalled(trust, now) {
    const root = this.#db.prepare("SELECT plan FROM installation_roots WHERE scope=?").get(this.#scope);
    if (!root) fail3("FORBIDDEN");
    const plan = JSON.parse(root.plan);
    const refs = this.#db.prepare("SELECT * FROM installation_references WHERE scope=?").all(this.#scope);
    if (refs.length !== plan.packages.length) fail3("INVALID_INPUT");
    for (const item of plan.packages) {
      if (!refs.some(
        (ref) => ref.environment === this.#environment && ref.package_id === item.packageId && ref.version === item.version && ref.sha256 === item.sha256
      ))
        fail3("INVALID_INPUT");
    }
    return this.#hydratePlan(plan, trust, now);
  }
  #hydratePlan(plan, trust, now) {
    const packages = plan.packages.map((item) => {
      const row = this.#db.prepare(
        "SELECT * FROM installed_packages WHERE environment=? AND package_id=? AND version=? AND sha256=?"
      ).get(this.#environment, item.packageId, item.version, item.sha256);
      if (!row) fail3("INVALID_INPUT");
      const trusted2 = unwrap(
        trust.verify(this.#content(row), JSON.parse(row.attestation), now)
      );
      if (trusted2.attestation.environment !== this.#environment) fail3("FORBIDDEN");
      return trusted2;
    });
    const checked2 = unwrap(
      resolveCapabilityDependencies(
        plan.roots,
        packages.map((item) => item.package)
      )
    );
    if (JSON.stringify(checked2) !== JSON.stringify(plan)) fail3("INVALID_INPUT");
    checkApplicationRoot(checked2, packages, this.#applicationId);
    return { plan: checked2, packages };
  }
  #lease(taskId) {
    if (!identifier2(taskId)) fail3("INVALID_INPUT");
    const row = this.#db.prepare("SELECT * FROM package_leases WHERE scope=? AND task_id=?").get(this.#scope, taskId);
    if (!row) fail3("FORBIDDEN");
    if (!["active", "released"].includes(row.status)) fail3("INVALID_INPUT");
    return {
      taskId,
      requestId: row.request_id,
      status: row.status,
      plan: JSON.parse(row.plan)
    };
  }
  acquireLease(taskId, requestId, bindings, trust, now = Date.now()) {
    return this.#work(() => {
      if (!identifier2(taskId) || !identifier2(requestId)) fail3("INVALID_INPUT");
      const { plan } = this.#loadInstalled(trust, now);
      const requested = snapshot3(bindings);
      if (!Array.isArray(requested) || requested.length !== plan.bindings.length || requested.some(
        (item) => !item || Object.keys(item).length !== 4 || !plan.bindings.some(
          (binding2) => binding2.capabilityId === item.capabilityId && binding2.packageId === item.packageId && binding2.version === item.version && binding2.sha256 === item.sha256
        )
      ))
        fail3("CONFLICT");
      if (new Set(requested.map((item) => item.capabilityId)).size !== requested.length)
        fail3("CONFLICT");
      const old = this.#db.prepare("SELECT task_id FROM package_leases WHERE scope=? AND task_id=?").get(this.#scope, taskId);
      if (old) {
        const lease = this.#lease(taskId);
        if (lease.requestId !== requestId || lease.status !== "active" || JSON.stringify(lease.plan) !== JSON.stringify(plan))
          fail3("CONFLICT");
        return lease;
      }
      if (Number(this.#db.prepare("SELECT COUNT(*) AS count FROM package_leases").get().count) >= LEASE_LIMITS.records)
        fail3("LIMIT_EXCEEDED");
      this.#db.prepare("INSERT INTO package_leases VALUES (?,?,?,'active',?)").run(this.#scope, taskId, requestId, JSON.stringify(plan));
      return this.#lease(taskId);
    }, true);
  }
  getLease(taskId) {
    return this.#work(() => this.#lease(taskId));
  }
  activeLeases() {
    return this.#work(
      () => this.#db.prepare(
        "SELECT task_id FROM package_leases WHERE scope=? AND status='active' ORDER BY task_id"
      ).all(this.#scope).map((row) => this.#lease(row.task_id))
    );
  }
  releaseLease(taskId) {
    return this.#work(() => {
      const lease = this.#lease(taskId);
      if (lease.status === "released") return lease;
      this.#db.prepare("UPDATE package_leases SET status='released' WHERE scope=? AND task_id=?").run(this.#scope, taskId);
      return this.#lease(taskId);
    }, true);
  }
  loadLease(taskId, trust, now = Date.now()) {
    return this.#work(() => {
      const lease = this.#lease(taskId);
      if (lease.status !== "active") fail3("FORBIDDEN");
      return this.#hydratePlan(lease.plan, trust, now);
    });
  }
  leaseInventory() {
    return this.#work(() => {
      const active = this.#db.prepare("SELECT plan FROM package_leases WHERE status='active'").all();
      return {
        records: Number(
          this.#db.prepare("SELECT COUNT(*) AS count FROM package_leases").get().count
        ),
        active: active.length,
        references: active.reduce(
          (count, row) => count + JSON.parse(row.plan).packages.length,
          0
        )
      };
    });
  }
  /** Explicit global maintenance; preserve every root, active pin and prepared transaction. */
  collectUnused() {
    return this.#work(() => {
      const protectedPackages = /* @__PURE__ */ new Set();
      for (const row of this.#db.prepare("SELECT environment,package_id,version,sha256 FROM installation_references").all())
        protectedPackages.add(
          JSON.stringify([row.environment, row.package_id, row.version, row.sha256])
        );
      for (const row of this.#db.prepare(
        "SELECT scope,plan FROM installation_roots UNION ALL SELECT scope,plan FROM package_leases WHERE status='active' UNION ALL SELECT scope,plan FROM installation_transactions WHERE status='prepared'"
      ).all()) {
        const environment = JSON.parse(row.scope)[3];
        const plan = JSON.parse(row.plan);
        for (const item of plan.packages)
          protectedPackages.add(
            JSON.stringify([environment, item.packageId, item.version, item.sha256])
          );
      }
      const rows = this.#db.prepare("SELECT environment,package_id,version,sha256 FROM installed_packages").all();
      let removed = 0;
      for (const row of rows) {
        if (protectedPackages.has(
          JSON.stringify([row.environment, row.package_id, row.version, row.sha256])
        ))
          continue;
        this.#db.prepare(
          "DELETE FROM installed_packages WHERE environment=? AND package_id=? AND version=? AND sha256=?"
        ).run(
          row.environment,
          row.package_id,
          row.version,
          row.sha256
        );
        removed++;
      }
      return { removed, retained: rows.length - removed };
    }, true);
  }
  /** Administrative aggregate only; this class must not be exposed directly to applications. */
  inventory() {
    return this.#work(() => ({
      packages: Number(
        this.#db.prepare("SELECT COUNT(*) AS count FROM installed_packages").get().count
      ),
      roots: Number(
        this.#db.prepare("SELECT COUNT(*) AS count FROM installation_roots").get().count
      ),
      references: Number(
        this.#db.prepare("SELECT COUNT(*) AS count FROM installation_references").get().count
      ),
      transactions: Number(
        this.#db.prepare("SELECT COUNT(*) AS count FROM installation_transactions").get().count
      )
    }));
  }
  close() {
    if (!this.#closed) {
      this.#closed = true;
      this.#db.close();
    }
  }
};

// packages/capability-packages/src/migrations.ts
var DATA_MIGRATION_LIMITS = Object.freeze({
  roots: 128,
  records: 512,
  version: 2147483647,
  revision: 2147483647
});

// packages/capability-packages/src/authorizations.ts
import { DatabaseSync as DatabaseSync6 } from "node:sqlite";
var AUTHORIZATION_LIMITS = Object.freeze({
  scopes: 384,
  records: 1024,
  revision: 2147483647
});
var AuthorizationError = class extends Error {
  code;
  constructor(code) {
    super(code);
    this.code = code;
  }
};
function fail4(code) {
  throw new AuthorizationError(code);
}
function policy(raw) {
  if (!raw || Object.keys(raw).length !== 3 || !["entry", "grants", "bindings"].every((key) => Object.hasOwn(raw, key)))
    fail4("INVALID_INPUT");
  const broker = new CapabilityBroker();
  try {
    const session = broker.createSession({
      tenantId: "authorization",
      environment: "test",
      installationId: "authorization",
      consumerAppId: "authorization",
      ...raw
    });
    const caller = broker.getCaller(session);
    broker.revokeSession(session);
    if (!caller.ok) return fail4("INVALID_INPUT");
    return {
      entry: caller.value.entry,
      grants: [...caller.value.grants].sort(),
      bindings: caller.value.bindings.map((item) => ({
        capabilityId: item.capabilityId,
        packageId: item.packageId,
        version: item.version,
        sha256: item.sha256
      })).sort((a, b) => a.capabilityId.localeCompare(b.capabilityId))
    };
  } catch {
    return fail4("INVALID_INPUT");
  }
}
function freeze4(value2) {
  if (value2 && typeof value2 === "object") {
    Object.values(value2).forEach(freeze4);
    Object.freeze(value2);
  }
  return value2;
}
function revision(value2) {
  return Number.isInteger(value2) && value2 >= 0 && value2 <= AUTHORIZATION_LIMITS.revision;
}
var CapabilityAuthorizationStore = class {
  #db;
  #scope;
  #closed = false;
  #readOnly = false;
  constructor(path2, root, entry, options = {}) {
    this.#readOnly = options.readOnly === true;
    this.#scope = JSON.stringify([
      rootKey(root),
      policy({ entry, grants: [], bindings: [] }).entry
    ]);
    try {
      this.#db = new DatabaseSync6(path2, { readOnly: options.readOnly === true });
      const version = this.#db.prepare("PRAGMA user_version").get()?.user_version;
      const application = this.#db.prepare("PRAGMA application_id").get()?.application_id;
      const tables = this.#db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
      if (!(version === 0 && application === 0 && !tables.length || version === 1 && application === 1396916565))
        throw new Error();
      if (options.readOnly === true) {
        if (version !== 1 || application !== 1396916565) throw new Error();
        this.#db.exec("PRAGMA busy_timeout=100;");
        return;
      }
      this.#db.exec(`PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; PRAGMA busy_timeout=100;
        BEGIN IMMEDIATE;
        CREATE TABLE IF NOT EXISTS authorizations(scope TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS authorization_receipts(scope TEXT NOT NULL,request_id TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(scope,request_id));
        PRAGMA user_version=1; PRAGMA application_id=0x53434155; COMMIT;`);
    } catch {
      try {
        this.#db?.close();
      } catch {
      }
      throw new Error("Authorization store unavailable.");
    }
  }
  #work(work, write = false) {
    if (this.#closed) return { ok: false, error: createCapabilityError("UNAVAILABLE") };
    if (write && this.#readOnly) return { ok: false, error: createCapabilityError("FORBIDDEN") };
    let transaction = false;
    try {
      this.#db.exec(write ? "BEGIN IMMEDIATE" : "BEGIN");
      transaction = true;
      const value2 = work();
      this.#db.exec("COMMIT");
      transaction = false;
      return { ok: true, value: freeze4(value2) };
    } catch (cause) {
      if (transaction)
        try {
          this.#db.exec("ROLLBACK");
        } catch {
        }
      return {
        ok: false,
        error: createCapabilityError(
          cause instanceof AuthorizationError ? cause.code : "UNAVAILABLE"
        )
      };
    }
  }
  #checked(raw) {
    if (!raw || Object.keys(raw).length !== 3 || !revision(raw.revision) || raw.revision === 0 || !["active", "revoked"].includes(raw.status))
      fail4("INVALID_INPUT");
    const checked2 = policy(raw.policy);
    if (JSON.stringify([JSON.parse(this.#scope)[0], checked2.entry]) !== this.#scope || raw.status === "revoked" && checked2.grants.length)
      fail4("INVALID_INPUT");
    return { revision: raw.revision, status: raw.status, policy: checked2 };
  }
  #read() {
    const row = this.#db.prepare("SELECT value FROM authorizations WHERE scope=?").get(this.#scope);
    return row ? this.#checked(JSON.parse(row.value)) : null;
  }
  #receipt(id3) {
    if (typeof id3 !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9._/-]{0,127}(?![\s\S])/.test(id3))
      fail4("INVALID_INPUT");
    const row = this.#db.prepare("SELECT value FROM authorization_receipts WHERE scope=? AND request_id=?").get(this.#scope, id3);
    if (!row) return null;
    const raw = JSON.parse(row.value);
    if (Object.keys(raw).length !== 3 || raw.requestId !== id3 || !revision(raw.expectedRevision) || raw.authorization.revision !== raw.expectedRevision + 1)
      fail4("INVALID_INPUT");
    return {
      requestId: id3,
      expectedRevision: raw.expectedRevision,
      authorization: this.#checked(raw.authorization)
    };
  }
  read() {
    return this.#work(() => this.#read());
  }
  status(requestId) {
    return this.#work(() => this.#receipt(requestId));
  }
  set(requestId, expectedRevision, raw, status = "active") {
    return this.#work(() => {
      const checked2 = policy(raw);
      if (!revision(expectedRevision) || !["active", "revoked"].includes(status) || status === "revoked" && checked2.grants.length)
        fail4("INVALID_INPUT");
      if (JSON.stringify([JSON.parse(this.#scope)[0], checked2.entry]) !== this.#scope)
        fail4("INVALID_INPUT");
      const old = this.#receipt(requestId);
      if (old) {
        if (old.expectedRevision !== expectedRevision || old.authorization.status !== status || JSON.stringify(old.authorization.policy) !== JSON.stringify(checked2))
          fail4("CONFLICT");
        return old;
      }
      const current = this.#read();
      if ((current?.revision ?? 0) !== expectedRevision) fail4("CONFLICT");
      if (expectedRevision === AUTHORIZATION_LIMITS.revision || Number(
        this.#db.prepare("SELECT COUNT(*) AS count FROM authorization_receipts").get().count
      ) >= AUTHORIZATION_LIMITS.records || !current && Number(this.#db.prepare("SELECT COUNT(*) AS count FROM authorizations").get().count) >= AUTHORIZATION_LIMITS.scopes)
        fail4("LIMIT_EXCEEDED");
      const authorization = this.#checked({
        revision: expectedRevision + 1,
        status,
        policy: checked2
      });
      const receipt = { requestId, expectedRevision, authorization };
      this.#db.prepare(
        "INSERT INTO authorizations VALUES (?,?) ON CONFLICT(scope) DO UPDATE SET value=excluded.value"
      ).run(this.#scope, JSON.stringify(authorization));
      this.#db.prepare("INSERT INTO authorization_receipts VALUES (?,?,?)").run(this.#scope, requestId, JSON.stringify(receipt));
      return receipt;
    }, true);
  }
  close() {
    if (!this.#closed) {
      this.#closed = true;
      this.#db.close();
    }
  }
};

// packages/capability-packages/src/index.ts
var PACKAGE_LIMITS = Object.freeze({
  manifestBytes: 65536,
  files: 16,
  sourceBytes: 65536,
  packageBytes: 1048576,
  dependencies: 32,
  capabilities: 16,
  catalog: 128,
  searchStates: 2048
});
var id2 = /^[a-z][a-z0-9.-]{0,63}\/[a-z][a-z0-9.-]{0,63}(?![\s\S])/;
var hash2 = /^[a-f0-9]{64}(?![\s\S])/;
function fail5(code) {
  throw new PackageError(code);
}
var PackageError = class extends Error {
  code;
  constructor(code) {
    super(createCapabilityError(code).message);
    this.code = code;
  }
};
var digest2 = (bytes) => createHash4("sha256").update(bytes).digest("hex");
var compare = (a, b) => a < b ? -1 : a > b ? 1 : 0;
function freeze5(value2) {
  if (value2 && typeof value2 === "object") {
    Object.values(value2).forEach(freeze5);
    Object.freeze(value2);
  }
  return value2;
}
function exact3(value2, keys) {
  return !!value2 && typeof value2 === "object" && !Array.isArray(value2) && Object.keys(value2).length === keys.length && keys.every((key) => Object.hasOwn(value2, key));
}
function canonical2(value2) {
  if (Array.isArray(value2)) return "[" + value2.map(canonical2).join(",") + "]";
  if (value2 && typeof value2 === "object")
    return "{" + Object.keys(value2).sort().map(
      (key) => JSON.stringify(key) + ":" + canonical2(value2[key])
    ).join(",") + "}";
  return JSON.stringify(value2);
}
function pathValid(value2, application = false) {
  return typeof value2 === "string" && value2.length <= 192 && (application ? /\.(html|css|js|json)$/.test(value2) : value2.endsWith(".guest")) && value2.split("/").every(
    (part) => /^[a-zA-Z0-9_-][a-zA-Z0-9_.-]*(?![\s\S])/.test(part) && !/[.]$/.test(part) && !/^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(part)
  );
}
function requirements(raw) {
  const snapshot4 = parseCapabilityRequest({
    protocolVersion: 1,
    requestId: "019c7714-3b77-74d1-9866-e1f484aae2ab",
    capabilityId: "platform/package-validation",
    input: raw
  });
  if (!snapshot4.ok || !Array.isArray(snapshot4.value.input) || snapshot4.value.input.length > PACKAGE_LIMITS.dependencies)
    fail5("INVALID_INPUT");
  const result = snapshot4.value.input;
  const seen = /* @__PURE__ */ new Set();
  for (const item of result) {
    if (!exact3(item, ["packageId", "range"]) || typeof item.packageId !== "string" || !id2.test(item.packageId) || typeof item.range !== "string" || !item.range.trim() || item.range.length > 192 || !import_semver2.default.validRange(item.range) || seen.has(item.packageId))
      fail5("INVALID_INPUT");
    seen.add(item.packageId);
  }
  return result;
}
function validation2(work) {
  try {
    return { ok: true, value: work() };
  } catch (error3) {
    return {
      ok: false,
      error: createCapabilityError(error3 instanceof PackageError ? error3.code : "INVALID_INPUT")
    };
  }
}
function verifyCapabilityPackage(manifestJson, files) {
  return validation2(() => {
    if (typeof manifestJson !== "string" || Buffer.byteLength(manifestJson) > PACKAGE_LIMITS.manifestBytes)
      fail5("INVALID_INPUT");
    const snapshot4 = parseCapabilityRequest({
      protocolVersion: 1,
      requestId: "019c7714-3b77-74d1-9866-e1f484aae2ab",
      capabilityId: "platform/package-validation",
      input: JSON.parse(manifestJson)
    });
    if (!snapshot4.ok) fail5("INVALID_INPUT");
    const raw = snapshot4.value.input;
    const application = raw !== null && typeof raw === "object" && !Array.isArray(raw) && raw.execution === "static-application-v1";
    const service = raw !== null && typeof raw === "object" && !Array.isArray(raw) && raw.execution === "host-service-v1";
    if (!exact3(raw, [
      "formatVersion",
      "execution",
      "packageId",
      "version",
      "dependencies",
      "capabilities",
      "files",
      ...application ? ["application"] : []
    ]) || raw.formatVersion !== 1 || !application && !service && raw.execution !== "quickjs-function-v1" || typeof raw.packageId !== "string" || !id2.test(raw.packageId) || typeof raw.version !== "string" || import_semver2.default.valid(raw.version) !== raw.version)
      fail5("INVALID_INPUT");
    const manifest = raw;
    if (manifest.execution === "static-application-v1" && (!exact3(manifest.application, ["applicationId", "entry"]) || typeof manifest.application.applicationId !== "string" || manifest.application.applicationId.length > 128 || !/^[a-z][a-z0-9.-]+(?![\s\S])/.test(manifest.application.applicationId) || !manifest.application.applicationId.startsWith(manifest.packageId.split("/")[0] + ".") || !pathValid(manifest.application.entry, true) || !manifest.application.entry.endsWith(".html")))
      fail5("INVALID_INPUT");
    requirements(manifest.dependencies);
    if (manifest.dependencies.some((dep) => dep.packageId === manifest.packageId)) fail5("CONFLICT");
    if (!Array.isArray(manifest.files) || (service ? manifest.files.length !== 0 : !manifest.files.length) || manifest.files.length > PACKAGE_LIMITS.files || !(files instanceof Map) || files.size !== manifest.files.length || !Array.isArray(manifest.capabilities) || (application ? manifest.capabilities.length !== 0 : !manifest.capabilities.length) || manifest.capabilities.length > PACKAGE_LIMITS.capabilities)
      fail5("INVALID_INPUT");
    const paths = /* @__PURE__ */ new Set();
    const folded = /* @__PURE__ */ new Set();
    const sources = /* @__PURE__ */ Object.create(null);
    let bytes = 0;
    for (const file2 of manifest.files) {
      if (!exact3(file2, ["path", "bytes", "sha256"]) || !pathValid(file2.path, application) || file2.path === "capability-package.json" || !Number.isSafeInteger(file2.bytes) || file2.bytes < 1 || file2.bytes > PACKAGE_LIMITS.sourceBytes || !hash2.test(file2.sha256) || folded.has(file2.path.toLowerCase()))
        fail5("INVALID_INPUT");
      const contents = files.get(file2.path);
      if (!(contents instanceof Uint8Array) || contents.byteLength !== file2.bytes || digest2(contents) !== file2.sha256)
        fail5("INVALID_INPUT");
      bytes += contents.byteLength;
      if (bytes > PACKAGE_LIMITS.packageBytes) fail5("LIMIT_EXCEEDED");
      sources[file2.path] = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(
        contents
      );
      paths.add(file2.path);
      folded.add(file2.path.toLowerCase());
    }
    if (manifest.execution === "static-application-v1" && !paths.has(manifest.application.entry))
      fail5("INVALID_INPUT");
    const sha256 = digest2(canonical2(manifest));
    const broker = new CapabilityBroker();
    const bindings = [];
    const used = /* @__PURE__ */ new Set();
    for (const capability of manifest.capabilities) {
      if (!exact3(capability, [
        "capabilityId",
        ...service ? [] : ["source"],
        "interfaceVersion",
        "inputSchema",
        "outputSchema",
        "permissions",
        "allowedEntries",
        "delegates",
        "effects"
      ]) || typeof capability.capabilityId !== "string" || !id2.test(capability.capabilityId) || !service && (!("source" in capability) || typeof capability.source !== "string" || !paths.has(capability.source)))
        fail5("INVALID_INPUT");
      const { capabilityId: capabilityId2, ...contract } = capability;
      const { source, ...declaration } = { source: void 0, ...contract };
      const binding2 = {
        capabilityId: capabilityId2,
        packageId: manifest.packageId,
        version: manifest.version,
        sha256
      };
      broker.register({ ...declaration, binding: binding2 }, () => null);
      bindings.push(binding2);
      if (source) used.add(source);
    }
    if (!application && used.size !== paths.size) fail5("INVALID_INPUT");
    const result = freeze5({ manifest, sha256, sources, bindings });
    verifiedPackages.add(result);
    return result;
  });
}
function resolveCapabilityDependencies(roots, catalog) {
  return validation2(() => {
    const requested = requirements(roots);
    if (!requested.length || !Array.isArray(catalog) || catalog.length > PACKAGE_LIMITS.catalog)
      fail5("INVALID_INPUT");
    const versions = /* @__PURE__ */ new Map();
    for (const item of catalog) {
      if (!item || !verifiedPackages.has(item)) fail5("INVALID_INPUT");
      const list = versions.get(item.manifest.packageId) ?? [];
      const same = list.find((p) => p.manifest.version === item.manifest.version);
      if (same) {
        if (same.sha256 !== item.sha256) fail5("CONFLICT");
        continue;
      }
      list.push(item);
      versions.set(item.manifest.packageId, list);
    }
    for (const list of versions.values())
      list.sort(
        (a, b) => import_semver2.default.rcompare(a.manifest.version, b.manifest.version) || compare(a.manifest.version, b.manifest.version)
      );
    let states = 0;
    function order(selected) {
      const visiting = /* @__PURE__ */ new Set();
      const visited = /* @__PURE__ */ new Set();
      const sorted = [];
      function visit(packageId) {
        if (visiting.has(packageId)) return false;
        if (visited.has(packageId)) return true;
        visiting.add(packageId);
        const item = selected.get(packageId);
        for (const dep of [...item.manifest.dependencies].sort(
          (a, b) => compare(a.packageId, b.packageId)
        ))
          if (selected.get(dep.packageId).manifest.execution === "static-application-v1" || !visit(dep.packageId))
            return false;
        visiting.delete(packageId);
        visited.add(packageId);
        sorted.push(item);
        return true;
      }
      for (const name of [...selected.keys()].sort()) if (!visit(name)) return void 0;
      const ids = /* @__PURE__ */ new Set();
      for (const item of sorted)
        for (const binding2 of item.bindings) {
          if (ids.has(binding2.capabilityId)) return void 0;
          ids.add(binding2.capabilityId);
        }
      for (const item of sorted) {
        const allowed = /* @__PURE__ */ new Set();
        const seen = /* @__PURE__ */ new Set();
        const collect = (p) => {
          if (seen.has(p.manifest.packageId)) return;
          seen.add(p.manifest.packageId);
          p.bindings.forEach((b) => allowed.add(b.capabilityId));
          p.manifest.dependencies.forEach((d) => collect(selected.get(d.packageId)));
        };
        collect(item);
        if (item.manifest.capabilities.some((c) => c.delegates.some((d) => !allowed.has(d))))
          return void 0;
      }
      return sorted;
    }
    function search(selected, constraints) {
      if (++states > PACKAGE_LIMITS.searchStates) fail5("LIMIT_EXCEEDED");
      for (const [name2, item] of selected)
        if (!constraints.get(name2).every((range) => import_semver2.default.satisfies(item.manifest.version, range)))
          return void 0;
      const name = [...constraints.keys()].filter((key) => !selected.has(key)).sort()[0];
      if (!name) return order(selected);
      for (const item of versions.get(name) ?? []) {
        if (!constraints.get(name).every((range) => import_semver2.default.satisfies(item.manifest.version, range)))
          continue;
        const next = new Map(selected);
        next.set(name, item);
        const requirements2 = new Map([...constraints].map(([key, ranges]) => [key, [...ranges]]));
        for (const dep of item.manifest.dependencies)
          requirements2.set(dep.packageId, [...requirements2.get(dep.packageId) ?? [], dep.range]);
        const result = search(next, requirements2);
        if (result) return result;
      }
      return void 0;
    }
    const resolved = search(
      /* @__PURE__ */ new Map(),
      new Map(requested.map((root) => [root.packageId, [root.range]]))
    );
    if (!resolved) fail5("CONFLICT");
    return freeze5({
      formatVersion: 1,
      roots: requested,
      packages: resolved.map((item) => ({
        packageId: item.manifest.packageId,
        version: item.manifest.version,
        sha256: item.sha256
      })),
      bindings: resolved.flatMap((item) => item.bindings)
    });
  });
}

// packages/capability-tasks/src/shared-quota.ts
import { DatabaseSync as DatabaseSync7 } from "node:sqlite";

// packages/capability-tasks/src/index.ts
import { DatabaseSync as DatabaseSync9 } from "node:sqlite";

// packages/capability-tasks/src/views.ts
import { DatabaseSync as DatabaseSync8 } from "node:sqlite";
import path from "node:path";
var fail6 = (code) => ({
  ok: false,
  error: createCapabilityError(code)
});
var CapabilityTaskViews = class {
  #db;
  #scope;
  #closed = false;
  constructor(options) {
    if (!options.scope || Object.keys(options.scope).length !== 4)
      throw new Error("Invalid task view scope.");
    const broker = new CapabilityBroker();
    const session = broker.createSession({
      ...options.scope,
      entry: "application",
      grants: [],
      bindings: []
    });
    const caller = broker.getCaller(session);
    if (!caller.ok) throw new Error("Invalid task view scope.");
    const { tenantId, environment, installationId, consumerAppId } = caller.value;
    this.#scope = JSON.stringify([tenantId, environment, installationId, consumerAppId]);
    broker.revokeSession(session);
    this.#db = new DatabaseSync8(
      path.isAbsolute(options.path) ? path.toNamespacedPath(options.path) : options.path,
      { readOnly: true }
    );
    try {
      this.#db.exec("PRAGMA busy_timeout=100;");
      const versions = this.#db.prepare("SELECT version FROM metadata").all();
      if (versions.length !== 1 || ![1, 2].includes(Number(versions[0].version)))
        throw new Error("Unsupported task database version.");
      if (versions[0].version === 2) {
        const binding2 = this.#db.prepare("SELECT path,identity FROM task_quota_binding").all();
        if (binding2.length !== 1 || typeof binding2[0].path !== "string" || typeof binding2[0].identity !== "string" || !path.isAbsolute(binding2[0].path))
          throw new Error("Invalid shared quota task database.");
      }
      this.#db.prepare("SELECT id,scope,request_id,data FROM tasks LIMIT 0");
    } catch (error3) {
      this.#db.close();
      throw error3;
    }
  }
  #snapshot(row) {
    if (typeof row.data !== "string" || Buffer.byteLength(row.data) > 262144) throw new Error();
    const record = JSON.parse(row.data);
    const task = record.task;
    const request = parseCapabilityRequest(record.request);
    const reference = task && parseCapabilityTaskReference({
      taskId: task.taskId,
      requestId: task.requestId,
      capabilityId: task.capabilityId,
      status: task.status
    });
    if (record.scope !== this.#scope || !request.ok || !reference?.ok || task.taskId !== row.id || task.requestId !== row.request_id || request.value.requestId !== task.requestId || request.value.capabilityId !== task.capabilityId || !Number.isSafeInteger(task.revision) || task.revision < 1 || !Number.isFinite(Date.parse(task.createdAt)) || !Number.isFinite(Date.parse(task.updatedAt)))
      throw new Error();
    const broker = new CapabilityBroker();
    const session = broker.createSession({
      tenantId: "view",
      installationId: "view",
      consumerAppId: "view",
      environment: "development",
      entry: "application",
      grants: [],
      bindings: [task.binding]
    });
    broker.revokeSession(session);
    if (task.binding.capabilityId !== task.capabilityId) throw new Error();
    const result = task.result === void 0 ? void 0 : parseCapabilityResponse(task.result, request.value);
    if (result && !result.ok) throw new Error();
    const upstream = task.upstreamTask === void 0 ? void 0 : parseCapabilityTaskReference(task.upstreamTask);
    if (upstream && !upstream.ok) throw new Error();
    return {
      ...reference.value,
      binding: structuredClone(task.binding),
      revision: task.revision,
      createdAt: task.createdAt,
      updatedAt: task.updatedAt,
      ...result?.ok ? { result: result.value } : {},
      ...upstream?.ok ? { upstreamTask: upstream.value } : {}
    };
  }
  get(taskId) {
    if (this.#closed) return fail6("UNAVAILABLE");
    if (typeof taskId !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/.test(taskId))
      return fail6("INVALID_INPUT");
    try {
      const row = this.#db.prepare("SELECT id,request_id,data FROM tasks WHERE scope=? AND id=?").get(this.#scope, taskId);
      return row ? { ok: true, value: this.#snapshot(row) } : fail6("FORBIDDEN");
    } catch {
      return fail6("UNAVAILABLE");
    }
  }
  list(options = {}) {
    if (this.#closed) return fail6("UNAVAILABLE");
    const { limit = 50, offset = 0 } = options;
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100 || !Number.isSafeInteger(offset) || offset < 0)
      return fail6("INVALID_INPUT");
    try {
      return {
        ok: true,
        value: this.#db.prepare(
          "SELECT id,request_id,data FROM tasks WHERE scope=? ORDER BY rowid DESC LIMIT ? OFFSET ?"
        ).all(this.#scope, limit, offset).map((row) => this.#snapshot(row))
      };
    } catch {
      return fail6("UNAVAILABLE");
    }
  }
  close() {
    if (!this.#closed) {
      this.#closed = true;
      this.#db.close();
    }
  }
};

// packages/capability-tasks/src/index.ts
var DEFAULT_TASK_SCHEDULING_LIMITS = Object.freeze({
  maxConcurrent: 8,
  maxConcurrentPerTenant: 2,
  maxConcurrentPerAccount: 2,
  maxConcurrentPerScope: 1,
  maxPending: 64,
  maxPendingPerTenant: 16,
  maxPendingPerAccount: 16,
  maxPendingPerScope: 8,
  executionMs: 3e4
});

// packages/ecosystem-data/account-guard.mjs
import { existsSync as existsSync2 } from "node:fs";
import { join } from "node:path";
function assertAccountData(directory, tenant, account, environment) {
  const binding2 = digest(JSON.stringify([tenant, environment]));
  const policyDirectory = join(directory, "data-deletions", binding2);
  if (!existsSync2(policyDirectory)) return;
  const registry = join(policyDirectory, "registry.json");
  const owner = digest(JSON.stringify([tenant, account, environment]));
  if (readRegistry(registry, binding2).deleted.some((r) => r.owner === owner))
    throw new Error("OWNER_DATA_DELETED");
}

// packages/browser-host/process.mjs
import { spawn } from "node:child_process";
import { randomUUID as randomUUID4 } from "node:crypto";
import { join as join3 } from "node:path";

// packages/host-process/process-isolation.mjs
import { readFile } from "node:fs/promises";
import { createHash as createHash5 } from "node:crypto";
import { join as join2 } from "node:path";
async function isolatedCommand(directory, executable) {
  if (process.platform !== "win32" || process.arch !== "x64")
    throw new Error("PROCESS_ISOLATION_UNAVAILABLE");
  const manifest = JSON.parse(await readFile(join2(directory, "isolation-manifest.json"), "utf8"));
  if (manifest.version !== 1 || manifest.mode !== "windows-job-quickjs-v1" || manifest.file !== "sitoo-job.exe" || manifest.memoryMiB !== 512 || manifest.cpuPercent !== 25 || manifest.activeProcessLimit !== 1)
    throw new Error("PROCESS_ISOLATION_UNAVAILABLE");
  const launcher = join2(directory, "sitoo-job.exe");
  if (createHash5("sha256").update(await readFile(launcher)).digest("hex") !== manifest.sha256)
    throw new Error("PROCESS_ISOLATION_UNAVAILABLE");
  return { executable: launcher, args: ["512", "25", "--owner", String(process.pid), executable] };
}

// packages/browser-host/process.mjs
async function startBrowserExecution(runtimeDirectory, configuration) {
  const command = await isolatedCommand(runtimeDirectory, process.execPath);
  const environment = { ...process.env };
  for (const key of ["NODE_OPTIONS", "NODE_PATH", "ELECTRON_RUN_AS_NODE"]) delete environment[key];
  const child = spawn(
    command.executable,
    [...command.args, join3(runtimeDirectory, "browser-worker.mjs")],
    { cwd: runtimeDirectory, env: environment, stdio: ["pipe", "pipe", "pipe"], windowsHide: true }
  );
  const pending = /* @__PURE__ */ new Map();
  let buffer = "", dead = false;
  const unavailable = () => {
    dead = true;
    for (const item of pending.values()) {
      clearTimeout(item.timer);
      item.reject(Error("BROWSER_HOST_UNAVAILABLE"));
    }
    pending.clear();
  };
  child.on("error", unavailable);
  child.on("exit", unavailable);
  child.stdin.on("error", unavailable);
  child.stderr.resume();
  child.stdout.setEncoding("utf8");
  child.stdout.on("data", (chunk) => {
    buffer += chunk;
    if (Buffer.byteLength(buffer) > 4194304) {
      child.kill();
      unavailable();
      return;
    }
    let end;
    while ((end = buffer.indexOf("\n")) >= 0) {
      const line = buffer.slice(0, end);
      buffer = buffer.slice(end + 1);
      try {
        const message2 = JSON.parse(line), item = pending.get(message2.id);
        if (item) {
          pending.delete(message2.id);
          clearTimeout(item.timer);
          item.resolve(message2.result);
        }
      } catch {
        child.kill();
        unavailable();
        return;
      }
    }
  });
  const call = (operation, entry, input) => new Promise((resolve4, reject2) => {
    if (dead || pending.size >= 32) return reject2(Error("BROWSER_HOST_UNAVAILABLE"));
    const id3 = randomUUID4(), timer = setTimeout(() => {
      pending.delete(id3);
      reject2(Error("BROWSER_HOST_RESULT_UNKNOWN"));
    }, 3e4);
    pending.set(id3, { timer, resolve: resolve4, reject: reject2 });
    child.stdin.write(JSON.stringify({ id: id3, operation, entry, input }) + "\n", (error3) => {
      if (error3) unavailable();
    });
  });
  let ready;
  try {
    ready = await call("initialize", null, configuration);
  } catch (error3) {
    child.kill();
    throw error3;
  }
  if (!ready.ok) {
    child.kill();
    throw Error("BROWSER_HOST_UNAVAILABLE");
  }
  let closing;
  return {
    child,
    call,
    get dead() {
      return dead;
    },
    close: () => closing ??= new Promise((resolve4) => {
      if (dead) return resolve4();
      const timer = setTimeout(() => child.kill(), 5e3);
      child.once("exit", () => {
        clearTimeout(timer);
        resolve4();
      });
      child.stdin.end(JSON.stringify({ id: randomUUID4(), operation: "close" }) + "\n");
    })
  };
}

// packages/capability-dev-host/src/model-planner.ts
import { createHash as createHash6 } from "node:crypto";
function createLoopbackConversationPlanner(raw) {
  if (!raw || Object.keys(raw).length !== (raw.apiKey === void 0 ? 3 : 4) || raw.version !== 1 || typeof raw.endpoint !== "string" || typeof raw.model !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$/.test(raw.model) || raw.apiKey !== void 0 && (typeof raw.apiKey !== "string" || !/^[\x21-\x7e]{1,8192}$/.test(raw.apiKey)))
    throw new Error("Invalid local model config.");
  const endpoint = new URL(raw.endpoint);
  if (endpoint.protocol !== "http:" || endpoint.hostname !== "127.0.0.1" || endpoint.pathname !== "/v1/chat/completions" || endpoint.username || endpoint.password || endpoint.search || endpoint.hash)
    throw new Error("Invalid local model config.");
  const model = raw.model, apiKey = raw.apiKey;
  return async ({ text: text2, requestId, tools, signal }) => {
    try {
      if (!tools.length || tools.length > 64) throw new Error();
      const catalog = [...tools].sort(
        (a, b) => a.binding.capabilityId.localeCompare(b.binding.capabilityId)
      );
      const child = createHash6("sha256").update(requestId + ":model-child").digest("hex");
      const childRequestId = `${child.slice(0, 8)}-${child.slice(8, 12)}-4${child.slice(13, 16)}-a${child.slice(17, 20)}-${child.slice(20, 32)}`;
      const input = JSON.stringify({
        model,
        stream: false,
        tool_choice: "required",
        parallel_tool_calls: false,
        max_completion_tokens: 1024,
        messages: [
          {
            role: "system",
            content: "Propose exactly one provided function call. Never execute tools. Arguments must contain only input matching its schema. If input requires childRequestId, use " + childRequestId + ". Do not invent authority, results or credentials."
          },
          { role: "user", content: text2 }
        ],
        tools: catalog.map((tool2, index) => ({
          type: "function",
          function: {
            name: "tool_" + index,
            description: "Capability " + tool2.binding.capabilityId + " version " + tool2.binding.version,
            parameters: {
              type: "object",
              properties: { input: tool2.inputSchema },
              required: ["input"],
              additionalProperties: false
            }
          }
        }))
      });
      if (Buffer.byteLength(input) > PROTOCOL_LIMITS.requestBytes) throw new Error();
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          ...apiKey ? { authorization: "Bearer " + apiKey } : {}
        },
        body: input,
        redirect: "error",
        signal: AbortSignal.any([signal, AbortSignal.timeout(2e4)])
      });
      if (!response.ok || !response.body) {
        await response.body?.cancel();
        throw new Error();
      }
      const reader = response.body.getReader();
      const chunks = [];
      let size = 0;
      try {
        while (true) {
          const { value: value2, done } = await reader.read();
          if (done) break;
          size += value2.length;
          if (size > PROTOCOL_LIMITS.requestBytes) throw new Error();
          chunks.push(value2);
        }
      } finally {
        await reader.cancel().catch(() => {
        });
        reader.releaseLock();
      }
      const parsed = JSON.parse(
        new TextDecoder("utf-8", { fatal: true }).decode(Buffer.concat(chunks))
      );
      if (!Array.isArray(parsed.choices) || parsed.choices.length !== 1 || parsed.choices[0].finish_reason !== "tool_calls")
        throw new Error();
      const message2 = parsed.choices[0].message;
      if (message2?.role !== "assistant" || message2.refusal || !Array.isArray(message2.tool_calls) || message2.tool_calls.length !== 1)
        throw new Error();
      const call = message2.tool_calls[0];
      if (call.type !== "function" || typeof call.function?.name !== "string" || !/^tool_(0|[1-9][0-9]*)$/.test(call.function.name) || typeof call.function.arguments !== "string")
        throw new Error();
      const tool = catalog[Number(call.function.name.slice(5))];
      const args = JSON.parse(call.function.arguments);
      if (!tool || !args || typeof args !== "object" || Array.isArray(args) || Object.keys(args).length !== 1 || !Object.hasOwn(args, "input"))
        throw new Error();
      return { capabilityId: tool.binding.capabilityId, input: args.input };
    } catch {
      throw new Error("Local model planning unavailable.");
    }
  };
}

// packages/browser-host/controller.mjs
var digest3 = (value2) => createHash7("sha256").update(value2).digest("hex");
var ok = (value2) => ({ ok: true, value: value2 });
var value = (result) => {
  if (!result.ok) fail7(result.error.code, 409);
  return result.value;
};
function fail7(code, status = 400) {
  throw Object.assign(Error(code), { code, status, browserHostProblem: true });
}
var entries2 = ["application", "conversation", "service"];
var strict = (input, fields) => {
  if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).some((key) => !fields.includes(key)))
    fail7("INVALID_INPUT");
};
var read = (file2) => JSON.parse(readFileSync4(file2, "utf8"));
var atomic = (file2, object2) => {
  const temp = file2 + "." + randomUUID5();
  writeFileSync2(temp, JSON.stringify(object2), { flag: "wx", mode: 384 });
  renameSync2(temp, file2);
};
var safeDirectory = (directory) => {
  mkdirSync3(directory, { recursive: true });
  if (realpathSync2(directory) !== resolve(directory)) fail7("BROWSER_STORAGE_INVALID", 503);
  return directory;
};
function validateBrowserHost(config2, deployment) {
  if (!config2) return;
  const origin = new URL(deployment.origin);
  if (deployment.environment !== "production" || origin.protocol !== "https:" || !["127.0.0.1", "localhost"].includes(origin.hostname) || config2.profile !== "loopback-browser-rehearsal-v1" || !isAbsolute(config2.dataDirectory ?? "") || !isAbsolute(config2.runtimeDirectory ?? "") || process.platform !== "win32" || process.arch !== "x64")
    fail7("BROWSER_HOST_CONFIGURATION", 503);
  const manifest = read(join4(config2.runtimeDirectory, "isolation-manifest.json"));
  if (manifest.version !== 1 || manifest.file !== "sitoo-job.exe" || manifest.mode !== "windows-job-quickjs-v1" || manifest.memoryMiB !== 512 || manifest.cpuPercent !== 25 || manifest.activeProcessLimit !== 1 || digest3(readFileSync4(join4(config2.runtimeDirectory, "sitoo-job.exe"))) !== manifest.sha256)
    fail7("BROWSER_ISOLATION_REQUIRED", 503);
}
var BrowserHost = class {
  constructor(store, catalog, config2, origin) {
    if (!catalog || catalog.environment !== "production" || !store.dataPolicy)
      fail7("BROWSER_HOST_CONFIGURATION", 503);
    this.store = store;
    this.catalog = catalog;
    this.config = config2;
    this.origin = origin;
    this.tenant = digest3(JSON.stringify([origin, store.issuer]));
    this.directory = safeDirectory(resolve(config2.dataDirectory));
    this.previews = /* @__PURE__ */ new Map();
    this.contexts = /* @__PURE__ */ new Map();
    this.workers = /* @__PURE__ */ new Map();
    this.opening = /* @__PURE__ */ new Map();
    this.queues = /* @__PURE__ */ new Map();
    this.pending = /* @__PURE__ */ new Map();
    this.pendingTotal = 0;
    this.planner = config2.planningModel ? createLoopbackConversationPlanner(config2.planningModel) : null;
    store.transaction(
      () => store.db.exec(`
      CREATE TABLE IF NOT EXISTS browser_roots(scope TEXT PRIMARY KEY,actor TEXT NOT NULL,org TEXT,application TEXT NOT NULL,project TEXT NOT NULL,release TEXT NOT NULL,closure TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS browser_operations(id TEXT PRIMARY KEY,scope TEXT NOT NULL,actor TEXT NOT NULL,org TEXT,application TEXT NOT NULL,kind TEXT NOT NULL,payload TEXT NOT NULL,state TEXT NOT NULL,created INTEGER NOT NULL);
      INSERT OR IGNORE INTO schema_version VALUES(8);
    `)
    );
  }
  owner(session, write = false) {
    const s = this.store.sessionFromHash ? this.store.sessionFromHash(session.hash) : this.store.get(
      "SELECT * FROM sessions WHERE hash=? AND expires>?",
      session.hash,
      this.store.now()
    );
    if (!s || s.actor !== session.actor || s.org !== session.org) fail7("UNAUTHENTICATED", 401);
    this.store.assertDataOwner(s.actor);
    if (s.org) this.store.permission(s, s.org, write ? ["owner", "admin", "developer"] : void 0);
    const account = digest3(JSON.stringify([s.actor, s.org]));
    assertAccountData(this.directory, this.tenant, account, "production");
    const directory = safeDirectory(join4(this.directory, account));
    const ownerFile = join4(directory, "owner.json");
    if (!existsSync3(ownerFile))
      atomic(ownerFile, {
        tenant: this.tenant,
        account,
        actor: s.actor,
        org: s.org,
        environment: "production"
      });
    const membershipEpoch = this.store.get(
      "SELECT COALESCE(MAX(id),0) AS n FROM audit WHERE org IS ? AND ((target=? AND action LIKE 'member.%') OR (actor=? AND action LIKE '%accept%'))",
      s.org,
      s.actor,
      s.actor
    ).n;
    return {
      actor: s.actor,
      org: s.org,
      account,
      directory,
      sessionHash: session.hash,
      membershipEpoch
    };
  }
  root(owner, applicationId) {
    if (typeof applicationId !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9._/-]{0,127}$/.test(applicationId))
      fail7("INVALID_INPUT");
    return {
      tenantId: this.tenant,
      accountId: owner.account,
      applicationId,
      environment: "production"
    };
  }
  scope(root) {
    return JSON.stringify([root.tenantId, root.accountId, root.applicationId, root.environment]);
  }
  installation(owner, application) {
    return new CapabilityInstallationStore(
      join4(owner.directory, "installations.sqlite"),
      this.root(owner, application)
    );
  }
  trust(session, owner) {
    const policies = this.catalog.trustKeys(session).keys;
    atomic(join4(owner.directory, "trust.json"), policies);
    return new CapabilityPackageTrust(policies);
  }
  authorization(owner, application, entry) {
    if (!entries2.includes(entry)) fail7("INVALID_INPUT");
    return new CapabilityAuthorizationStore(
      join4(owner.directory, "authorizations.sqlite"),
      this.root(owner, application),
      entry
    );
  }
  bundle(session, project, release) {
    const bundle = this.catalog.download(session, project, release, "production");
    const root = bundle.packages.find((p) => p.manifest.packageId === bundle.root.packageId);
    if (!root || root.manifest.execution !== "static-application-v1")
      fail7("BROWSER_APPLICATION_UNSUPPORTED", 409);
    if (bundle.packages.some(
      (p) => !["static-application-v1", "quickjs-function-v1"].includes(p.manifest.execution)
    ))
      fail7("BROWSER_CAPABILITY_UNSUPPORTED", 409);
    return { bundle, application: root.manifest.application.applicationId };
  }
  snapshot(session, owner, application) {
    const store = this.installation(owner, application);
    try {
      return value(store.load(this.trust(session, owner)));
    } finally {
      store.close();
    }
  }
  permissions(snapshot4, entry) {
    return [
      ...new Set(
        snapshot4.packages.flatMap(
          (p) => p.package.manifest.capabilities.filter((c) => c.allowedEntries.includes(entry)).flatMap((c) => c.permissions)
        )
      )
    ].sort();
  }
  preview(session, input) {
    strict(input, ["kind", "project", "release", "application", "entry"]);
    const owner = this.owner(session, true), kind = input.kind;
    if (!["install", "update", "uninstall", "authorize", "revoke"].includes(kind))
      fail7("INVALID_INPUT");
    let application = input.application, payload2, review;
    if (kind === "install" || kind === "update") {
      const selected = this.bundle(session, input.project, input.release);
      application = selected.application;
      payload2 = {
        project: input.project,
        release: input.release,
        digest: digest3(JSON.stringify(selected.bundle)),
        ...kind === "update" ? { installationDigest: digest3(JSON.stringify(this.snapshot(session, owner, application).plan)) } : {}
      };
      review = {
        kind,
        application,
        version: selected.bundle.root.version,
        packages: selected.bundle.packages.map((p) => ({
          packageId: p.manifest.packageId,
          version: p.manifest.version,
          sha256: p.sha256
        })),
        grantsNotAutomatic: true
      };
    } else {
      const snapshot4 = this.snapshot(session, owner, application);
      payload2 = { installationDigest: digest3(JSON.stringify(snapshot4.plan)) };
      review = {
        kind,
        application,
        version: snapshot4.plan.packages.find(
          (p) => p.packageId === snapshot4.plan.roots[0].packageId
        )?.version
      };
      if (kind === "authorize" || kind === "revoke") {
        if (!entries2.includes(input.entry)) fail7("INVALID_INPUT");
        const authorization = this.authorization(owner, application, input.entry);
        try {
          payload2.entry = input.entry;
          payload2.revision = value(authorization.read())?.revision ?? 0;
        } finally {
          authorization.close();
        }
        payload2.grants = kind === "revoke" ? [] : this.permissions(snapshot4, input.entry);
        review = {
          ...review,
          entry: payload2.entry,
          permissions: payload2.grants,
          expectedRevision: payload2.revision
        };
      }
    }
    const root = this.root(owner, application), token = randomUUID5(), requestId = randomUUID5();
    for (const [id3, item] of this.previews) if (item.expires < Date.now()) this.previews.delete(id3);
    if (this.previews.size >= 128) fail7("LIMIT_EXCEEDED", 429);
    this.previews.set(token, {
      owner: owner.account,
      session: session.hash,
      root,
      kind,
      payload: payload2,
      review,
      requestId,
      expires: Date.now() + 3e5
    });
    return ok({ token, requestId, ...review });
  }
  async confirm(session, input) {
    strict(input, ["token", "confirmed"]);
    const owner = this.owner(session, true), preview = this.previews.get(input.token);
    if (input.confirmed !== true || !preview || preview.owner !== owner.account || preview.session !== session.hash || preview.expires < Date.now())
      fail7("BROWSER_PREVIEW_INVALID", 409);
    const row = this.store.get("SELECT * FROM browser_operations WHERE id=?", preview.requestId);
    if (!row)
      this.store.run(
        "INSERT INTO browser_operations VALUES(?,?,?,?,?,?,?,?,?)",
        preview.requestId,
        this.scope(preview.root),
        session.actor,
        session.org,
        preview.root.applicationId,
        preview.kind,
        JSON.stringify(preview.payload),
        "prepared",
        this.store.now()
      );
    const result = await this.resume(session, preview.requestId);
    this.previews.delete(input.token);
    return result;
  }
  async resume(session, id3) {
    const owner = this.owner(session, true), op = this.store.get(
      "SELECT * FROM browser_operations WHERE id=? AND actor=? AND org IS ?",
      id3,
      session.actor,
      session.org
    );
    if (!op) fail7("NOT_FOUND", 404);
    if (op.state === "committed") return ok({ requestId: op.id, state: op.state });
    if (op.state !== "prepared") fail7("CONFLICT", 409);
    const root = this.root(owner, op.application), data = JSON.parse(op.payload), trust = this.trust(session, owner);
    const releases = new CapabilityReleaseStore(join4(owner.directory, "releases.sqlite"));
    const store = this.installation(owner, op.application);
    try {
      if (op.kind === "install" || op.kind === "update") {
        const prior = store.status(op.id);
        if (op.kind === "update" && !prior.ok && digest3(JSON.stringify(value(store.load(trust)).plan)) !== data.installationDigest)
          fail7("BROWSER_PREVIEW_STALE", 409);
        const selected = this.bundle(session, data.project, data.release);
        if (selected.application !== op.application || digest3(JSON.stringify(selected.bundle)) !== data.digest)
          fail7("BROWSER_PREVIEW_STALE", 409);
        const references = selected.bundle.packages.map((p) => {
          const verified = value(
            verifyCapabilityPackage(
              JSON.stringify(p.manifest),
              new Map(
                Object.entries(p.sources).map(([name, source]) => [name, Buffer.from(source)])
              )
            )
          );
          return value(releases.publish(verified, p.attestation, trust));
        });
        const roots = [
          { packageId: selected.bundle.root.packageId, range: selected.bundle.root.version }
        ];
        const tx = value(
          op.kind === "install" ? store.prepare(op.id, roots, references, releases, trust) : store.prepareUpdate(op.id, roots, references, releases, trust)
        );
        if (tx.status !== "committed") {
          if (op.kind === "update") {
            const grants = [
              ...new Set(
                selected.bundle.packages.flatMap(
                  (p) => p.manifest.capabilities.flatMap((c) => c.permissions)
                )
              )
            ];
            const policy2 = { entry: "application", grants }, review = value(store.reviewUpdate(op.id, policy2, releases, trust));
            value(
              store.commitAuthorizedUpdate(op.id, policy2, review.reviewSha256, releases, trust)
            );
          } else value(store.commit(op.id, releases, trust));
        }
        const policies = this.catalog.trustKeys(session).keys;
        const closure = selected.bundle.packages.map((p) => {
          const project = this.store.get(
            "SELECT id FROM projects WHERE package_id=?",
            p.manifest.packageId
          );
          return {
            id: p.id,
            project: project.id,
            publicKey: policies.find((k) => k.keyId === p.attestation.keyId)?.publicKeyPem
          };
        });
        this.store.run(
          "INSERT INTO browser_roots VALUES(?,?,?,?,?,?,?) ON CONFLICT(scope) DO UPDATE SET project=excluded.project,release=excluded.release,closure=excluded.closure",
          this.scope(root),
          session.actor,
          session.org,
          op.application,
          data.project,
          data.release,
          JSON.stringify(closure)
        );
      } else {
        const previous = store.status(op.id);
        if (op.kind === "uninstall" && previous.ok && previous.value.status === "committed") {
          this.store.run("DELETE FROM browser_roots WHERE scope=?", this.scope(root));
          this.store.run("UPDATE browser_operations SET state='committed' WHERE id=?", op.id);
          return ok({ requestId: op.id, state: "committed", application: op.application });
        }
        const loaded = value(store.load(trust));
        if (digest3(JSON.stringify(loaded.plan)) !== data.installationDigest)
          fail7("BROWSER_PREVIEW_STALE", 409);
        if (op.kind === "uninstall") {
          value(store.prepareUninstall(op.id));
          value(store.commitUninstall(op.id));
          this.store.run("DELETE FROM browser_roots WHERE scope=?", this.scope(root));
        } else {
          const authorization = this.authorization(owner, op.application, data.entry);
          try {
            value(
              authorization.set(
                op.id,
                data.revision,
                { entry: data.entry, grants: data.grants, bindings: loaded.plan.bindings },
                op.kind === "revoke" ? "revoked" : "active"
              )
            );
          } finally {
            authorization.close();
          }
        }
      }
      this.store.run("UPDATE browser_operations SET state='committed' WHERE id=?", op.id);
      this.store.record(session.actor, session.org, "browser." + op.kind, op.application);
      return ok({ requestId: op.id, state: "committed", application: op.application });
    } finally {
      store.close();
      releases.close();
    }
  }
  list(session) {
    const owner = this.owner(session), installed = this.store.all(
      "SELECT application,project,release FROM browser_roots WHERE actor=? AND org IS ?",
      owner.actor,
      owner.org
    );
    const applications = installed.map((item) => {
      let snapshot4;
      try {
        snapshot4 = this.snapshot(session, owner, item.application);
      } catch {
        return { ...item, unavailable: true, entries: [] };
      }
      return {
        ...item,
        entries: entries2.map((entry) => {
          const auth = this.authorization(owner, item.application, entry);
          try {
            const state = value(auth.read());
            return {
              entry,
              status: state?.status ?? "missing",
              revision: state?.revision ?? 0,
              bindingsCurrent: state ? JSON.stringify(state.policy.bindings) === JSON.stringify(snapshot4.plan.bindings) : false
            };
          } finally {
            auth.close();
          }
        })
      };
    });
    return ok({
      applications,
      catalog: this.catalog.list(session, "production").filter((p) => p.type === "application"),
      operations: this.store.all(
        "SELECT id,application,kind,state,created FROM browser_operations WHERE actor=? AND org IS ? ORDER BY created DESC LIMIT 50",
        owner.actor,
        owner.org
      ),
      compatibility: {
        staticApplication: true,
        quickjs: true,
        moduleScripts: false,
        nativeServices: false,
        artifacts: false,
        appNativeBridge: false,
        modelPlanning: this.planner ? "configured-local-model" : "unavailable"
      }
    });
  }
  async worker(session, application, entry) {
    const owner = this.owner(session, true), root = this.root(owner, application), key = this.scope(root);
    const record = this.store.get("SELECT * FROM browser_roots WHERE scope=?", key);
    if (!record) fail7("BROWSER_NOT_INSTALLED", 404);
    for (const item of JSON.parse(record.closure)) {
      const project = this.store.get("SELECT * FROM projects WHERE id=?", item.project);
      if (!project || !this.catalog.visible(session, project)) fail7("FORBIDDEN", 403);
      this.catalog.published(item.id);
    }
    const snapshot4 = this.snapshot(session, owner, application);
    const consumers = [];
    for (const selectedEntry of entries2) {
      const auth = this.authorization(owner, application, selectedEntry);
      try {
        const state = value(auth.read());
        if (state?.status === "active" && JSON.stringify(state.policy.bindings) === JSON.stringify(snapshot4.plan.bindings))
          consumers.push({
            token: randomBytes2(32).toString("hex"),
            root,
            entry: selectedEntry,
            revision: state.revision
          });
      } finally {
        auth.close();
      }
    }
    if (!consumers.some((c) => c.entry === entry)) fail7("BROWSER_ENTRY_UNAUTHORIZED", 403);
    const fingerprint = digest3(
      JSON.stringify([
        owner.account,
        owner.membershipEpoch,
        snapshot4.plan,
        consumers.map((c) => [c.entry, c.revision]),
        record.release,
        record.closure
      ])
    );
    const entryDigest = digest3(
      JSON.stringify([
        owner.membershipEpoch,
        snapshot4.plan,
        entry,
        consumers.find((c) => c.entry === entry).revision
      ])
    );
    const existing = this.workers.get(key);
    if (existing && !existing.dead && existing.fingerprint === fingerprint)
      return { owner, root, worker: existing, entryDigest };
    if (this.opening.has(key)) {
      await this.opening.get(key);
      return this.worker(session, application, entry);
    }
    if (!existing && this.workers.size + this.opening.size >= 8) fail7("BROWSER_HOST_LIMIT", 429);
    const opening = (async () => {
      if (existing) {
        await existing.close();
        this.workers.delete(key);
      }
      const tasksDirectory = safeDirectory(join4(owner.directory, "tasks", digest3(application)));
      const worker = await startBrowserExecution(this.config.runtimeDirectory, {
        profile: this.config.profile,
        directory: owner.directory,
        root,
        identityDatabase: this.config.identityDatabase,
        session: { actor: session.actor, org: session.org },
        membershipEpoch: owner.membershipEpoch,
        invitedSubjects: this.store.allowedSubjects,
        dataPolicy: this.store.dataPolicy,
        releases: JSON.parse(record.closure),
        taskPath: join4(tasksDirectory, "tasks.sqlite"),
        quotaPath: join4(this.directory, "task-quota.sqlite"),
        config: {
          version: 3,
          installationPath: "installations.sqlite",
          authorizationPath: "authorizations.sqlite",
          trustPath: "trust.json",
          consumers: consumers.map(({ revision: revision2, ...consumer }) => consumer)
        }
      });
      try {
        this.owner(session, true);
      } catch (error3) {
        await worker.close();
        throw error3;
      }
      worker.fingerprint = fingerprint;
      this.workers.set(key, worker);
      return worker;
    })();
    this.opening.set(key, opening);
    try {
      return { owner, root, worker: await opening, entryDigest };
    } finally {
      this.opening.delete(key);
    }
  }
  async open(session, input) {
    strict(input, ["application", "entry"]);
    const execution = await this.worker(session, input.application, input.entry);
    for (const [id4, item] of this.contexts)
      if (item.created < Date.now() - 30 * 6e4) this.contexts.delete(id4);
    if (this.contexts.size >= 128) fail7("LIMIT_EXCEEDED", 429);
    const id3 = randomUUID5();
    this.contexts.set(id3, {
      owner: execution.owner.account,
      session: session.hash,
      application: input.application,
      entry: input.entry,
      entryDigest: execution.entryDigest,
      created: Date.now()
    });
    return ok({ context: id3, entry: input.entry, application: input.application });
  }
  async context(session, id3, action, input) {
    const owner = this.owner(session), context = this.contexts.get(id3);
    if (!context || context.owner !== owner.account || context.session !== session.hash || context.created < Date.now() - 30 * 6e4)
      fail7("BROWSER_CONTEXT_EXPIRED", 403);
    const { worker, entryDigest } = await this.worker(session, context.application, context.entry);
    if (entryDigest !== context.entryDigest) fail7("BROWSER_CONTEXT_EXPIRED", 403);
    if (["application", "tools", "list"].includes(action)) strict(input, []);
    if (["get", "cancel", "confirmation", "artifact"].includes(action)) strict(input, ["taskId"]);
    if (action === "prepare") strict(input, ["capabilityId", "input"]);
    if (action === "approve") {
      strict(input, ["taskId", "revision", "confirmed"]);
      if (input.confirmed !== true) fail7("BROWSER_CONFIRMATION_REQUIRED", 409);
    }
    if (action === "plan") {
      if (!this.planner) fail7("BROWSER_MODEL_UNAVAILABLE", 503);
      strict(input, ["prompt"]);
      if (typeof input.prompt !== "string" || input.prompt.length > 8192) fail7("INVALID_INPUT");
      const tools = value(await worker.call("tools", context.entry, {})).tools;
      const proposal = await this.planner({
        text: input.prompt,
        requestId: randomUUID5(),
        tools,
        signal: AbortSignal.timeout(2e4)
      });
      this.owner(session, true);
      strict(proposal, ["capabilityId", "input"]);
      const refreshed = await this.worker(session, context.application, context.entry);
      if (refreshed.entryDigest !== context.entryDigest) fail7("BROWSER_CONTEXT_EXPIRED", 403);
      return refreshed.worker.call("prepare", context.entry, proposal);
    }
    if (![
      "application",
      "tools",
      "prepare",
      "submit",
      "get",
      "list",
      "cancel",
      "confirmation",
      "approve",
      "artifact"
    ].includes(action))
      fail7("NOT_FOUND", 404);
    return worker.call(action, context.entry, input);
  }
  async history(session, input) {
    strict(input, ["application", "taskId"]);
    const owner = this.owner(session), root = this.root(owner, input.application), key = this.scope(root), live = this.workers.get(key);
    if (live && !live.dead) return live.call("history", null, input);
    const file2 = join4(owner.directory, "tasks", digest3(input.application), "tasks.sqlite");
    if (!existsSync3(file2)) {
      if (input.taskId) fail7("NOT_FOUND", 404);
      return ok([]);
    }
    const views = new CapabilityTaskViews({
      path: file2,
      scope: {
        tenantId: root.tenantId,
        environment: "production",
        installationId: digest3(this.scope(root)),
        consumerAppId: root.applicationId
      }
    });
    try {
      return input.taskId ? views.get(input.taskId) : views.list({ limit: 20, offset: 0 });
    } finally {
      views.close();
    }
  }
  async dispatch(session, action, input = {}) {
    const owner = this.owner(session), prior = this.queues.get(owner.account) ?? Promise.resolve();
    if (this.pendingTotal >= 32 || (this.pending.get(owner.account) ?? 0) >= 4)
      fail7("LIMIT_EXCEEDED", 429);
    this.pendingTotal++;
    this.pending.set(owner.account, (this.pending.get(owner.account) ?? 0) + 1);
    const operation = prior.catch(() => {
    }).then(() => {
      this.owner(session);
      if (action === "list") return this.list(session);
      if (action === "preview") return this.preview(session, input);
      if (action === "confirm") return this.confirm(session, input);
      if (action === "resume") {
        strict(input, ["requestId"]);
        return this.resume(session, input.requestId);
      }
      if (action === "open") return this.open(session, input);
      if (action === "history") return this.history(session, input);
      const match = /^contexts\/([a-f0-9-]{36})\/([a-z]+)$/.exec(action);
      if (match) return this.context(session, match[1], match[2], input);
      fail7("NOT_FOUND", 404);
    });
    this.queues.set(owner.account, operation);
    try {
      const result = await operation;
      this.owner(session);
      return result;
    } finally {
      this.pendingTotal--;
      this.pending.set(owner.account, this.pending.get(owner.account) - 1);
      if (this.queues.get(owner.account) === operation) this.queues.delete(owner.account);
    }
  }
  async close() {
    if (!this.closing) {
      this.closing = Promise.allSettled([...this.workers.values()].map((w) => w.close()));
      this.workers.clear();
      this.contexts.clear();
    }
    await this.closing;
  }
};

// server/src/support.mjs
import { randomUUID as randomUUID6 } from "node:crypto";
var safeText = (value2, max) => {
  const result = text(value2, max);
  requireValue(
    !/Bearer\s|sitoo_(?:pub_|catalog_)|-----BEGIN .*PRIVATE KEY-----/i.test(result),
    "SENSITIVE_CONTENT"
  );
  return result;
};
var Support = class {
  constructor(publishing) {
    this.publishing = publishing;
    this.store = publishing.store;
    this.store.transaction(() => {
      this.store.db.exec(`
        CREATE TABLE IF NOT EXISTS diagnostics(id TEXT PRIMARY KEY, at INTEGER NOT NULL, actor TEXT NOT NULL, org TEXT, project TEXT REFERENCES projects(id), release TEXT, stage TEXT NOT NULL, status INTEGER NOT NULL, code TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS diagnostics_project ON diagnostics(project,at);
        CREATE TABLE IF NOT EXISTS feedback(id TEXT PRIMARY KEY, project TEXT REFERENCES projects(id), creator TEXT NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL, release TEXT, request TEXT, state TEXT NOT NULL, revision INTEGER NOT NULL, created INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS feedback_events(id INTEGER PRIMARY KEY, ticket TEXT REFERENCES feedback(id), at INTEGER NOT NULL, actor TEXT NOT NULL, state TEXT NOT NULL, reply TEXT NOT NULL);
        INSERT OR IGNORE INTO schema_version VALUES(4);`);
    });
  }
  record(context, status, code) {
    if (!context.actor || !context.project) return;
    this.store.transaction(() => {
      this.store.run(
        "INSERT INTO diagnostics VALUES(?,?,?,?,?,?,?,?,?)",
        context.id,
        this.store.now(),
        context.actor,
        context.org,
        context.project,
        context.release ?? null,
        context.stage,
        status,
        code
      );
      this.store.run(
        "DELETE FROM diagnostics WHERE id IN (SELECT id FROM diagnostics ORDER BY at DESC,id DESC LIMIT -1 OFFSET 20000)"
      );
    });
  }
  diagnostics(session, project, filters = {}) {
    this.publishing.project(session, project);
    for (const value2 of [filters.requestId, filters.release])
      if (value2) requireValue(/^[a-f0-9-]{36}$/.test(value2), "INVALID_INPUT");
    const rows = this.store.all(
      "SELECT id,at,release,stage,status,code FROM diagnostics WHERE project=? AND (? IS NULL OR id=?) AND (? IS NULL OR release=?) ORDER BY at DESC,id DESC LIMIT 100",
      project,
      filters.requestId ?? null,
      filters.requestId ?? null,
      filters.release ?? null,
      filters.release ?? null
    );
    return { requests: rows };
  }
  ticket(session, project, id3) {
    this.publishing.project(session, project);
    const ticket = this.store.get("SELECT * FROM feedback WHERE id=? AND project=?", id3, project);
    requireValue(ticket, "NOT_FOUND", 404);
    return ticket;
  }
  list(session, project) {
    this.publishing.project(session, project);
    return {
      tickets: this.store.all(
        "SELECT id,title,state,revision,creator,release,request,created FROM feedback WHERE project=? ORDER BY created DESC LIMIT 100",
        project
      )
    };
  }
  detail(session, project, id3) {
    const ticket = this.ticket(session, project, id3);
    return {
      ...ticket,
      events: this.store.all(
        "SELECT at,actor,state,reply FROM feedback_events WHERE ticket=? ORDER BY id",
        id3
      )
    };
  }
  create(session, project, input) {
    const title = safeText(input.title, 160), description = safeText(input.description, 2e3);
    return this.store.transaction(() => {
      const p = this.publishing.project(session, project);
      if (input.release)
        requireValue(
          this.store.get(
            "SELECT id FROM submissions WHERE id=? AND project=?",
            input.release,
            project
          ),
          "NOT_FOUND",
          404
        );
      if (input.requestId)
        requireValue(
          this.store.get(
            "SELECT id FROM diagnostics WHERE id=? AND project=?",
            input.requestId,
            project
          ),
          "NOT_FOUND",
          404
        );
      const id3 = randomUUID6();
      this.store.run(
        "INSERT INTO feedback VALUES(?,?,?,?,?,?,?,?,?,?)",
        id3,
        project,
        session.actor,
        title,
        description,
        input.release ?? null,
        input.requestId ?? null,
        "open",
        0,
        this.store.now()
      );
      this.store.record(
        session.actor,
        p.kind === "organization" ? p.owner : null,
        "feedback.create",
        id3
      );
      return this.detail(session, project, id3);
    });
  }
  update(session, project, id3, input) {
    return this.store.transaction(() => {
      const ticket = this.ticket(session, project, id3), p = this.publishing.project(session, project);
      requireValue(
        Number.isSafeInteger(input.revision) && ticket.revision === input.revision,
        "TICKET_CONFLICT",
        409
      );
      const manager = p.kind === "personal" ? p.owner === session.actor : ["owner", "admin"].includes(
        this.store.get(
          "SELECT role FROM members WHERE org=? AND actor=?",
          p.owner,
          session.actor
        )?.role
      );
      if (input.state === "closed") {
        requireValue(manager || ticket.creator === session.actor, "FORBIDDEN", 403);
        requireValue(ticket.state === "answered", "TICKET_STATE_CONFLICT", 409);
      } else {
        requireValue(manager, "FORBIDDEN", 403);
        requireValue(
          ticket.state === "open" && input.state === "processing" || ["open", "processing"].includes(ticket.state) && input.state === "answered",
          "TICKET_STATE_CONFLICT",
          409
        );
      }
      const reply = input.state === "answered" ? safeText(input.reply, 2e3) : "";
      this.store.run("UPDATE feedback SET state=?,revision=revision+1 WHERE id=?", input.state, id3);
      this.store.run(
        "INSERT INTO feedback_events(ticket,at,actor,state,reply) VALUES(?,?,?,?,?)",
        id3,
        this.store.now(),
        session.actor,
        input.state,
        reply
      );
      this.store.record(
        session.actor,
        p.kind === "organization" ? p.owner : null,
        "feedback." + input.state,
        id3
      );
      return this.detail(session, project, id3);
    });
  }
};

// server/src/http.mjs
import { readFile as readFile2 } from "node:fs/promises";
import { resolve as resolve2 } from "node:path";

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/buffer_utils.js
var encoder = new TextEncoder();
var decoder = new TextDecoder();
var MAX_INT32 = 2 ** 32;
function concat(...buffers) {
  const size = buffers.reduce((acc, { length }) => acc + length, 0);
  const buf = new Uint8Array(size);
  let i = 0;
  for (const buffer of buffers) {
    buf.set(buffer, i);
    i += buffer.length;
  }
  return buf;
}

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/base64.js
function decodeBase64(encoded) {
  if (Uint8Array.fromBase64) {
    return Uint8Array.fromBase64(encoded);
  }
  const binary = atob(encoded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/util/base64url.js
function decode(input) {
  if (Uint8Array.fromBase64) {
    return Uint8Array.fromBase64(typeof input === "string" ? input : decoder.decode(input), {
      alphabet: "base64url"
    });
  }
  let encoded = input;
  if (encoded instanceof Uint8Array) {
    encoded = decoder.decode(encoded);
  }
  encoded = encoded.replace(/-/g, "+").replace(/_/g, "/").replace(/\s/g, "");
  try {
    return decodeBase64(encoded);
  } catch {
    throw new TypeError("The input to be decoded is not correctly encoded.");
  }
}

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/util/errors.js
var JOSEError = class extends Error {
  static code = "ERR_JOSE_GENERIC";
  code = "ERR_JOSE_GENERIC";
  constructor(message2, options) {
    super(message2, options);
    this.name = this.constructor.name;
    Error.captureStackTrace?.(this, this.constructor);
  }
};
var JWTClaimValidationFailed = class extends JOSEError {
  static code = "ERR_JWT_CLAIM_VALIDATION_FAILED";
  code = "ERR_JWT_CLAIM_VALIDATION_FAILED";
  claim;
  reason;
  payload;
  constructor(message2, payload2, claim = "unspecified", reason = "unspecified") {
    super(message2, { cause: { claim, reason, payload: payload2 } });
    this.claim = claim;
    this.reason = reason;
    this.payload = payload2;
  }
};
var JWTExpired = class extends JOSEError {
  static code = "ERR_JWT_EXPIRED";
  code = "ERR_JWT_EXPIRED";
  claim;
  reason;
  payload;
  constructor(message2, payload2, claim = "unspecified", reason = "unspecified") {
    super(message2, { cause: { claim, reason, payload: payload2 } });
    this.claim = claim;
    this.reason = reason;
    this.payload = payload2;
  }
};
var JOSEAlgNotAllowed = class extends JOSEError {
  static code = "ERR_JOSE_ALG_NOT_ALLOWED";
  code = "ERR_JOSE_ALG_NOT_ALLOWED";
};
var JOSENotSupported = class extends JOSEError {
  static code = "ERR_JOSE_NOT_SUPPORTED";
  code = "ERR_JOSE_NOT_SUPPORTED";
};
var JWSInvalid = class extends JOSEError {
  static code = "ERR_JWS_INVALID";
  code = "ERR_JWS_INVALID";
};
var JWTInvalid = class extends JOSEError {
  static code = "ERR_JWT_INVALID";
  code = "ERR_JWT_INVALID";
};
var JWKSInvalid = class extends JOSEError {
  static code = "ERR_JWKS_INVALID";
  code = "ERR_JWKS_INVALID";
};
var JWKSNoMatchingKey = class extends JOSEError {
  static code = "ERR_JWKS_NO_MATCHING_KEY";
  code = "ERR_JWKS_NO_MATCHING_KEY";
  constructor(message2 = "no applicable key found in the JSON Web Key Set", options) {
    super(message2, options);
  }
};
var JWKSMultipleMatchingKeys = class extends JOSEError {
  [Symbol.asyncIterator];
  static code = "ERR_JWKS_MULTIPLE_MATCHING_KEYS";
  code = "ERR_JWKS_MULTIPLE_MATCHING_KEYS";
  constructor(message2 = "multiple matching keys found in the JSON Web Key Set", options) {
    super(message2, options);
  }
};
var JWSSignatureVerificationFailed = class extends JOSEError {
  static code = "ERR_JWS_SIGNATURE_VERIFICATION_FAILED";
  code = "ERR_JWS_SIGNATURE_VERIFICATION_FAILED";
  constructor(message2 = "signature verification failed", options) {
    super(message2, options);
  }
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/crypto_key.js
function unusable(name, prop = "algorithm.name") {
  return new TypeError(`CryptoKey does not support this operation, its ${prop} must be ${name}`);
}
function isAlgorithm(algorithm, name) {
  return algorithm.name === name;
}
function getHashLength(hash3) {
  return parseInt(hash3.name.slice(4), 10);
}
function getNamedCurve(alg) {
  switch (alg) {
    case "ES256":
      return "P-256";
    case "ES384":
      return "P-384";
    case "ES512":
      return "P-521";
    default:
      throw new Error("unreachable");
  }
}
function checkUsage(key, usage) {
  if (usage && !key.usages.includes(usage)) {
    throw new TypeError(`CryptoKey does not support this operation, its usages must include ${usage}.`);
  }
}
function checkSigCryptoKey(key, alg, usage) {
  switch (alg) {
    case "HS256":
    case "HS384":
    case "HS512": {
      if (!isAlgorithm(key.algorithm, "HMAC"))
        throw unusable("HMAC");
      const expected = parseInt(alg.slice(2), 10);
      const actual = getHashLength(key.algorithm.hash);
      if (actual !== expected)
        throw unusable(`SHA-${expected}`, "algorithm.hash");
      break;
    }
    case "RS256":
    case "RS384":
    case "RS512": {
      if (!isAlgorithm(key.algorithm, "RSASSA-PKCS1-v1_5"))
        throw unusable("RSASSA-PKCS1-v1_5");
      const expected = parseInt(alg.slice(2), 10);
      const actual = getHashLength(key.algorithm.hash);
      if (actual !== expected)
        throw unusable(`SHA-${expected}`, "algorithm.hash");
      break;
    }
    case "PS256":
    case "PS384":
    case "PS512": {
      if (!isAlgorithm(key.algorithm, "RSA-PSS"))
        throw unusable("RSA-PSS");
      const expected = parseInt(alg.slice(2), 10);
      const actual = getHashLength(key.algorithm.hash);
      if (actual !== expected)
        throw unusable(`SHA-${expected}`, "algorithm.hash");
      break;
    }
    case "Ed25519":
    case "EdDSA": {
      if (!isAlgorithm(key.algorithm, "Ed25519"))
        throw unusable("Ed25519");
      break;
    }
    case "ML-DSA-44":
    case "ML-DSA-65":
    case "ML-DSA-87": {
      if (!isAlgorithm(key.algorithm, alg))
        throw unusable(alg);
      break;
    }
    case "ES256":
    case "ES384":
    case "ES512": {
      if (!isAlgorithm(key.algorithm, "ECDSA"))
        throw unusable("ECDSA");
      const expected = getNamedCurve(alg);
      const actual = key.algorithm.namedCurve;
      if (actual !== expected)
        throw unusable(expected, "algorithm.namedCurve");
      break;
    }
    default:
      throw new TypeError("CryptoKey does not support this operation");
  }
  checkUsage(key, usage);
}

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/invalid_key_input.js
function message(msg, actual, ...types) {
  types = types.filter(Boolean);
  if (types.length > 2) {
    const last = types.pop();
    msg += `one of type ${types.join(", ")}, or ${last}.`;
  } else if (types.length === 2) {
    msg += `one of type ${types[0]} or ${types[1]}.`;
  } else {
    msg += `of type ${types[0]}.`;
  }
  if (actual == null) {
    msg += ` Received ${actual}`;
  } else if (typeof actual === "function" && actual.name) {
    msg += ` Received function ${actual.name}`;
  } else if (typeof actual === "object" && actual != null) {
    if (actual.constructor?.name) {
      msg += ` Received an instance of ${actual.constructor.name}`;
    }
  }
  return msg;
}
var invalid_key_input_default = (actual, ...types) => {
  return message("Key must be ", actual, ...types);
};
function withAlg(alg, actual, ...types) {
  return message(`Key for the ${alg} algorithm must be `, actual, ...types);
}

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/is_key_like.js
function isCryptoKey(key) {
  return key?.[Symbol.toStringTag] === "CryptoKey";
}
function isKeyObject(key) {
  return key?.[Symbol.toStringTag] === "KeyObject";
}
var is_key_like_default = (key) => {
  return isCryptoKey(key) || isKeyObject(key);
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/is_disjoint.js
var is_disjoint_default = (...headers) => {
  const sources = headers.filter(Boolean);
  if (sources.length === 0 || sources.length === 1) {
    return true;
  }
  let acc;
  for (const header of sources) {
    const parameters = Object.keys(header);
    if (!acc || acc.size === 0) {
      acc = new Set(parameters);
      continue;
    }
    for (const parameter of parameters) {
      if (acc.has(parameter)) {
        return false;
      }
      acc.add(parameter);
    }
  }
  return true;
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/is_object.js
function isObjectLike(value2) {
  return typeof value2 === "object" && value2 !== null;
}
var is_object_default = (input) => {
  if (!isObjectLike(input) || Object.prototype.toString.call(input) !== "[object Object]") {
    return false;
  }
  if (Object.getPrototypeOf(input) === null) {
    return true;
  }
  let proto = input;
  while (Object.getPrototypeOf(proto) !== null) {
    proto = Object.getPrototypeOf(proto);
  }
  return Object.getPrototypeOf(input) === proto;
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/check_key_length.js
var check_key_length_default = (alg, key) => {
  if (alg.startsWith("RS") || alg.startsWith("PS")) {
    const { modulusLength } = key.algorithm;
    if (typeof modulusLength !== "number" || modulusLength < 2048) {
      throw new TypeError(`${alg} requires key modulusLength to be 2048 bits or larger`);
    }
  }
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/jwk_to_key.js
function subtleMapping(jwk) {
  let algorithm;
  let keyUsages;
  switch (jwk.kty) {
    case "AKP": {
      switch (jwk.alg) {
        case "ML-DSA-44":
        case "ML-DSA-65":
        case "ML-DSA-87":
          algorithm = { name: jwk.alg };
          keyUsages = jwk.priv ? ["sign"] : ["verify"];
          break;
        default:
          throw new JOSENotSupported('Invalid or unsupported JWK "alg" (Algorithm) Parameter value');
      }
      break;
    }
    case "RSA": {
      switch (jwk.alg) {
        case "PS256":
        case "PS384":
        case "PS512":
          algorithm = { name: "RSA-PSS", hash: `SHA-${jwk.alg.slice(-3)}` };
          keyUsages = jwk.d ? ["sign"] : ["verify"];
          break;
        case "RS256":
        case "RS384":
        case "RS512":
          algorithm = { name: "RSASSA-PKCS1-v1_5", hash: `SHA-${jwk.alg.slice(-3)}` };
          keyUsages = jwk.d ? ["sign"] : ["verify"];
          break;
        case "RSA-OAEP":
        case "RSA-OAEP-256":
        case "RSA-OAEP-384":
        case "RSA-OAEP-512":
          algorithm = {
            name: "RSA-OAEP",
            hash: `SHA-${parseInt(jwk.alg.slice(-3), 10) || 1}`
          };
          keyUsages = jwk.d ? ["decrypt", "unwrapKey"] : ["encrypt", "wrapKey"];
          break;
        default:
          throw new JOSENotSupported('Invalid or unsupported JWK "alg" (Algorithm) Parameter value');
      }
      break;
    }
    case "EC": {
      switch (jwk.alg) {
        case "ES256":
          algorithm = { name: "ECDSA", namedCurve: "P-256" };
          keyUsages = jwk.d ? ["sign"] : ["verify"];
          break;
        case "ES384":
          algorithm = { name: "ECDSA", namedCurve: "P-384" };
          keyUsages = jwk.d ? ["sign"] : ["verify"];
          break;
        case "ES512":
          algorithm = { name: "ECDSA", namedCurve: "P-521" };
          keyUsages = jwk.d ? ["sign"] : ["verify"];
          break;
        case "ECDH-ES":
        case "ECDH-ES+A128KW":
        case "ECDH-ES+A192KW":
        case "ECDH-ES+A256KW":
          algorithm = { name: "ECDH", namedCurve: jwk.crv };
          keyUsages = jwk.d ? ["deriveBits"] : [];
          break;
        default:
          throw new JOSENotSupported('Invalid or unsupported JWK "alg" (Algorithm) Parameter value');
      }
      break;
    }
    case "OKP": {
      switch (jwk.alg) {
        case "Ed25519":
        case "EdDSA":
          algorithm = { name: "Ed25519" };
          keyUsages = jwk.d ? ["sign"] : ["verify"];
          break;
        case "ECDH-ES":
        case "ECDH-ES+A128KW":
        case "ECDH-ES+A192KW":
        case "ECDH-ES+A256KW":
          algorithm = { name: jwk.crv };
          keyUsages = jwk.d ? ["deriveBits"] : [];
          break;
        default:
          throw new JOSENotSupported('Invalid or unsupported JWK "alg" (Algorithm) Parameter value');
      }
      break;
    }
    default:
      throw new JOSENotSupported('Invalid or unsupported JWK "kty" (Key Type) Parameter value');
  }
  return { algorithm, keyUsages };
}
var jwk_to_key_default = async (jwk) => {
  if (!jwk.alg) {
    throw new TypeError('"alg" argument is required when "jwk.alg" is not present');
  }
  const { algorithm, keyUsages } = subtleMapping(jwk);
  const keyData = { ...jwk };
  if (keyData.kty !== "AKP") {
    delete keyData.alg;
  }
  delete keyData.use;
  return crypto.subtle.importKey("jwk", keyData, algorithm, jwk.ext ?? (jwk.d || jwk.priv ? false : true), jwk.key_ops ?? keyUsages);
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/key/import.js
async function importJWK(jwk, alg, options) {
  if (!is_object_default(jwk)) {
    throw new TypeError("JWK must be an object");
  }
  let ext;
  alg ??= jwk.alg;
  ext ??= options?.extractable ?? jwk.ext;
  switch (jwk.kty) {
    case "oct":
      if (typeof jwk.k !== "string" || !jwk.k) {
        throw new TypeError('missing "k" (Key Value) Parameter value');
      }
      return decode(jwk.k);
    case "RSA":
      if ("oth" in jwk && jwk.oth !== void 0) {
        throw new JOSENotSupported('RSA JWK "oth" (Other Primes Info) Parameter value is not supported');
      }
      return jwk_to_key_default({ ...jwk, alg, ext });
    case "AKP": {
      if (typeof jwk.alg !== "string" || !jwk.alg) {
        throw new TypeError('missing "alg" (Algorithm) Parameter value');
      }
      if (alg !== void 0 && alg !== jwk.alg) {
        throw new TypeError("JWK alg and alg option value mismatch");
      }
      return jwk_to_key_default({ ...jwk, ext });
    }
    case "EC":
    case "OKP":
      return jwk_to_key_default({ ...jwk, alg, ext });
    default:
      throw new JOSENotSupported('Unsupported "kty" (Key Type) Parameter value');
  }
}

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/validate_crit.js
var validate_crit_default = (Err, recognizedDefault, recognizedOption, protectedHeader, joseHeader) => {
  if (joseHeader.crit !== void 0 && protectedHeader?.crit === void 0) {
    throw new Err('"crit" (Critical) Header Parameter MUST be integrity protected');
  }
  if (!protectedHeader || protectedHeader.crit === void 0) {
    return /* @__PURE__ */ new Set();
  }
  if (!Array.isArray(protectedHeader.crit) || protectedHeader.crit.length === 0 || protectedHeader.crit.some((input) => typeof input !== "string" || input.length === 0)) {
    throw new Err('"crit" (Critical) Header Parameter MUST be an array of non-empty strings when present');
  }
  let recognized;
  if (recognizedOption !== void 0) {
    recognized = new Map([...Object.entries(recognizedOption), ...recognizedDefault.entries()]);
  } else {
    recognized = recognizedDefault;
  }
  for (const parameter of protectedHeader.crit) {
    if (!recognized.has(parameter)) {
      throw new JOSENotSupported(`Extension Header Parameter "${parameter}" is not recognized`);
    }
    if (joseHeader[parameter] === void 0) {
      throw new Err(`Extension Header Parameter "${parameter}" is missing`);
    }
    if (recognized.get(parameter) && protectedHeader[parameter] === void 0) {
      throw new Err(`Extension Header Parameter "${parameter}" MUST be integrity protected`);
    }
  }
  return new Set(protectedHeader.crit);
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/validate_algorithms.js
var validate_algorithms_default = (option, algorithms) => {
  if (algorithms !== void 0 && (!Array.isArray(algorithms) || algorithms.some((s) => typeof s !== "string"))) {
    throw new TypeError(`"${option}" option must be an array of strings`);
  }
  if (!algorithms) {
    return void 0;
  }
  return new Set(algorithms);
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/is_jwk.js
function isJWK(key) {
  return is_object_default(key) && typeof key.kty === "string";
}
function isPrivateJWK(key) {
  return key.kty !== "oct" && (key.kty === "AKP" && typeof key.priv === "string" || typeof key.d === "string");
}
function isPublicJWK(key) {
  return key.kty !== "oct" && typeof key.d === "undefined" && typeof key.priv === "undefined";
}
function isSecretJWK(key) {
  return key.kty === "oct" && typeof key.k === "string";
}

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/normalize_key.js
var cache;
var handleJWK = async (key, jwk, alg, freeze6 = false) => {
  cache ||= /* @__PURE__ */ new WeakMap();
  let cached = cache.get(key);
  if (cached?.[alg]) {
    return cached[alg];
  }
  const cryptoKey = await jwk_to_key_default({ ...jwk, alg });
  if (freeze6)
    Object.freeze(key);
  if (!cached) {
    cache.set(key, { [alg]: cryptoKey });
  } else {
    cached[alg] = cryptoKey;
  }
  return cryptoKey;
};
var handleKeyObject = (keyObject, alg) => {
  cache ||= /* @__PURE__ */ new WeakMap();
  let cached = cache.get(keyObject);
  if (cached?.[alg]) {
    return cached[alg];
  }
  const isPublic = keyObject.type === "public";
  const extractable = isPublic ? true : false;
  let cryptoKey;
  if (keyObject.asymmetricKeyType === "x25519") {
    switch (alg) {
      case "ECDH-ES":
      case "ECDH-ES+A128KW":
      case "ECDH-ES+A192KW":
      case "ECDH-ES+A256KW":
        break;
      default:
        throw new TypeError("given KeyObject instance cannot be used for this algorithm");
    }
    cryptoKey = keyObject.toCryptoKey(keyObject.asymmetricKeyType, extractable, isPublic ? [] : ["deriveBits"]);
  }
  if (keyObject.asymmetricKeyType === "ed25519") {
    if (alg !== "EdDSA" && alg !== "Ed25519") {
      throw new TypeError("given KeyObject instance cannot be used for this algorithm");
    }
    cryptoKey = keyObject.toCryptoKey(keyObject.asymmetricKeyType, extractable, [
      isPublic ? "verify" : "sign"
    ]);
  }
  switch (keyObject.asymmetricKeyType) {
    case "ml-dsa-44":
    case "ml-dsa-65":
    case "ml-dsa-87": {
      if (alg !== keyObject.asymmetricKeyType.toUpperCase()) {
        throw new TypeError("given KeyObject instance cannot be used for this algorithm");
      }
      cryptoKey = keyObject.toCryptoKey(keyObject.asymmetricKeyType, extractable, [
        isPublic ? "verify" : "sign"
      ]);
    }
  }
  if (keyObject.asymmetricKeyType === "rsa") {
    let hash3;
    switch (alg) {
      case "RSA-OAEP":
        hash3 = "SHA-1";
        break;
      case "RS256":
      case "PS256":
      case "RSA-OAEP-256":
        hash3 = "SHA-256";
        break;
      case "RS384":
      case "PS384":
      case "RSA-OAEP-384":
        hash3 = "SHA-384";
        break;
      case "RS512":
      case "PS512":
      case "RSA-OAEP-512":
        hash3 = "SHA-512";
        break;
      default:
        throw new TypeError("given KeyObject instance cannot be used for this algorithm");
    }
    if (alg.startsWith("RSA-OAEP")) {
      return keyObject.toCryptoKey({
        name: "RSA-OAEP",
        hash: hash3
      }, extractable, isPublic ? ["encrypt"] : ["decrypt"]);
    }
    cryptoKey = keyObject.toCryptoKey({
      name: alg.startsWith("PS") ? "RSA-PSS" : "RSASSA-PKCS1-v1_5",
      hash: hash3
    }, extractable, [isPublic ? "verify" : "sign"]);
  }
  if (keyObject.asymmetricKeyType === "ec") {
    const nist = /* @__PURE__ */ new Map([
      ["prime256v1", "P-256"],
      ["secp384r1", "P-384"],
      ["secp521r1", "P-521"]
    ]);
    const namedCurve = nist.get(keyObject.asymmetricKeyDetails?.namedCurve);
    if (!namedCurve) {
      throw new TypeError("given KeyObject instance cannot be used for this algorithm");
    }
    if (alg === "ES256" && namedCurve === "P-256") {
      cryptoKey = keyObject.toCryptoKey({
        name: "ECDSA",
        namedCurve
      }, extractable, [isPublic ? "verify" : "sign"]);
    }
    if (alg === "ES384" && namedCurve === "P-384") {
      cryptoKey = keyObject.toCryptoKey({
        name: "ECDSA",
        namedCurve
      }, extractable, [isPublic ? "verify" : "sign"]);
    }
    if (alg === "ES512" && namedCurve === "P-521") {
      cryptoKey = keyObject.toCryptoKey({
        name: "ECDSA",
        namedCurve
      }, extractable, [isPublic ? "verify" : "sign"]);
    }
    if (alg.startsWith("ECDH-ES")) {
      cryptoKey = keyObject.toCryptoKey({
        name: "ECDH",
        namedCurve
      }, extractable, isPublic ? [] : ["deriveBits"]);
    }
  }
  if (!cryptoKey) {
    throw new TypeError("given KeyObject instance cannot be used for this algorithm");
  }
  if (!cached) {
    cache.set(keyObject, { [alg]: cryptoKey });
  } else {
    cached[alg] = cryptoKey;
  }
  return cryptoKey;
};
var normalize_key_default = async (key, alg) => {
  if (key instanceof Uint8Array) {
    return key;
  }
  if (isCryptoKey(key)) {
    return key;
  }
  if (isKeyObject(key)) {
    if (key.type === "secret") {
      return key.export();
    }
    if ("toCryptoKey" in key && typeof key.toCryptoKey === "function") {
      try {
        return handleKeyObject(key, alg);
      } catch (err) {
        if (err instanceof TypeError) {
          throw err;
        }
      }
    }
    let jwk = key.export({ format: "jwk" });
    return handleJWK(key, jwk, alg);
  }
  if (isJWK(key)) {
    if (key.k) {
      return decode(key.k);
    }
    return handleJWK(key, key, alg, true);
  }
  throw new Error("unreachable");
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/check_key_type.js
var tag = (key) => key?.[Symbol.toStringTag];
var jwkMatchesOp = (alg, key, usage) => {
  if (key.use !== void 0) {
    let expected;
    switch (usage) {
      case "sign":
      case "verify":
        expected = "sig";
        break;
      case "encrypt":
      case "decrypt":
        expected = "enc";
        break;
    }
    if (key.use !== expected) {
      throw new TypeError(`Invalid key for this operation, its "use" must be "${expected}" when present`);
    }
  }
  if (key.alg !== void 0 && key.alg !== alg) {
    throw new TypeError(`Invalid key for this operation, its "alg" must be "${alg}" when present`);
  }
  if (Array.isArray(key.key_ops)) {
    let expectedKeyOp;
    switch (true) {
      case (usage === "sign" || usage === "verify"):
      case alg === "dir":
      case alg.includes("CBC-HS"):
        expectedKeyOp = usage;
        break;
      case alg.startsWith("PBES2"):
        expectedKeyOp = "deriveBits";
        break;
      case /^A\d{3}(?:GCM)?(?:KW)?$/.test(alg):
        if (!alg.includes("GCM") && alg.endsWith("KW")) {
          expectedKeyOp = usage === "encrypt" ? "wrapKey" : "unwrapKey";
        } else {
          expectedKeyOp = usage;
        }
        break;
      case (usage === "encrypt" && alg.startsWith("RSA")):
        expectedKeyOp = "wrapKey";
        break;
      case usage === "decrypt":
        expectedKeyOp = alg.startsWith("RSA") ? "unwrapKey" : "deriveBits";
        break;
    }
    if (expectedKeyOp && key.key_ops?.includes?.(expectedKeyOp) === false) {
      throw new TypeError(`Invalid key for this operation, its "key_ops" must include "${expectedKeyOp}" when present`);
    }
  }
  return true;
};
var symmetricTypeCheck = (alg, key, usage) => {
  if (key instanceof Uint8Array)
    return;
  if (isJWK(key)) {
    if (isSecretJWK(key) && jwkMatchesOp(alg, key, usage))
      return;
    throw new TypeError(`JSON Web Key for symmetric algorithms must have JWK "kty" (Key Type) equal to "oct" and the JWK "k" (Key Value) present`);
  }
  if (!is_key_like_default(key)) {
    throw new TypeError(withAlg(alg, key, "CryptoKey", "KeyObject", "JSON Web Key", "Uint8Array"));
  }
  if (key.type !== "secret") {
    throw new TypeError(`${tag(key)} instances for symmetric algorithms must be of type "secret"`);
  }
};
var asymmetricTypeCheck = (alg, key, usage) => {
  if (isJWK(key)) {
    switch (usage) {
      case "decrypt":
      case "sign":
        if (isPrivateJWK(key) && jwkMatchesOp(alg, key, usage))
          return;
        throw new TypeError(`JSON Web Key for this operation be a private JWK`);
      case "encrypt":
      case "verify":
        if (isPublicJWK(key) && jwkMatchesOp(alg, key, usage))
          return;
        throw new TypeError(`JSON Web Key for this operation be a public JWK`);
    }
  }
  if (!is_key_like_default(key)) {
    throw new TypeError(withAlg(alg, key, "CryptoKey", "KeyObject", "JSON Web Key"));
  }
  if (key.type === "secret") {
    throw new TypeError(`${tag(key)} instances for asymmetric algorithms must not be of type "secret"`);
  }
  if (key.type === "public") {
    switch (usage) {
      case "sign":
        throw new TypeError(`${tag(key)} instances for asymmetric algorithm signing must be of type "private"`);
      case "decrypt":
        throw new TypeError(`${tag(key)} instances for asymmetric algorithm decryption must be of type "private"`);
      default:
        break;
    }
  }
  if (key.type === "private") {
    switch (usage) {
      case "verify":
        throw new TypeError(`${tag(key)} instances for asymmetric algorithm verifying must be of type "public"`);
      case "encrypt":
        throw new TypeError(`${tag(key)} instances for asymmetric algorithm encryption must be of type "public"`);
      default:
        break;
    }
  }
};
var check_key_type_default = (alg, key, usage) => {
  const symmetric = alg.startsWith("HS") || alg === "dir" || alg.startsWith("PBES2") || /^A(?:128|192|256)(?:GCM)?(?:KW)?$/.test(alg) || /^A(?:128|192|256)CBC-HS(?:256|384|512)$/.test(alg);
  if (symmetric) {
    symmetricTypeCheck(alg, key, usage);
  } else {
    asymmetricTypeCheck(alg, key, usage);
  }
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/subtle_dsa.js
var subtle_dsa_default = (alg, algorithm) => {
  const hash3 = `SHA-${alg.slice(-3)}`;
  switch (alg) {
    case "HS256":
    case "HS384":
    case "HS512":
      return { hash: hash3, name: "HMAC" };
    case "PS256":
    case "PS384":
    case "PS512":
      return { hash: hash3, name: "RSA-PSS", saltLength: parseInt(alg.slice(-3), 10) >> 3 };
    case "RS256":
    case "RS384":
    case "RS512":
      return { hash: hash3, name: "RSASSA-PKCS1-v1_5" };
    case "ES256":
    case "ES384":
    case "ES512":
      return { hash: hash3, name: "ECDSA", namedCurve: algorithm.namedCurve };
    case "Ed25519":
    case "EdDSA":
      return { name: "Ed25519" };
    case "ML-DSA-44":
    case "ML-DSA-65":
    case "ML-DSA-87":
      return { name: alg };
    default:
      throw new JOSENotSupported(`alg ${alg} is not supported either by JOSE or your javascript runtime`);
  }
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/get_sign_verify_key.js
var get_sign_verify_key_default = async (alg, key, usage) => {
  if (key instanceof Uint8Array) {
    if (!alg.startsWith("HS")) {
      throw new TypeError(invalid_key_input_default(key, "CryptoKey", "KeyObject", "JSON Web Key"));
    }
    return crypto.subtle.importKey("raw", key, { hash: `SHA-${alg.slice(-3)}`, name: "HMAC" }, false, [usage]);
  }
  checkSigCryptoKey(key, alg, usage);
  return key;
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/verify.js
var verify_default = async (alg, key, signature, data) => {
  const cryptoKey = await get_sign_verify_key_default(alg, key, "verify");
  check_key_length_default(alg, cryptoKey);
  const algorithm = subtle_dsa_default(alg, cryptoKey.algorithm);
  try {
    return await crypto.subtle.verify(algorithm, cryptoKey, signature, data);
  } catch {
    return false;
  }
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/jws/flattened/verify.js
async function flattenedVerify(jws, key, options) {
  if (!is_object_default(jws)) {
    throw new JWSInvalid("Flattened JWS must be an object");
  }
  if (jws.protected === void 0 && jws.header === void 0) {
    throw new JWSInvalid('Flattened JWS must have either of the "protected" or "header" members');
  }
  if (jws.protected !== void 0 && typeof jws.protected !== "string") {
    throw new JWSInvalid("JWS Protected Header incorrect type");
  }
  if (jws.payload === void 0) {
    throw new JWSInvalid("JWS Payload missing");
  }
  if (typeof jws.signature !== "string") {
    throw new JWSInvalid("JWS Signature missing or incorrect type");
  }
  if (jws.header !== void 0 && !is_object_default(jws.header)) {
    throw new JWSInvalid("JWS Unprotected Header incorrect type");
  }
  let parsedProt = {};
  if (jws.protected) {
    try {
      const protectedHeader = decode(jws.protected);
      parsedProt = JSON.parse(decoder.decode(protectedHeader));
    } catch {
      throw new JWSInvalid("JWS Protected Header is invalid");
    }
  }
  if (!is_disjoint_default(parsedProt, jws.header)) {
    throw new JWSInvalid("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
  }
  const joseHeader = {
    ...parsedProt,
    ...jws.header
  };
  const extensions = validate_crit_default(JWSInvalid, /* @__PURE__ */ new Map([["b64", true]]), options?.crit, parsedProt, joseHeader);
  let b64 = true;
  if (extensions.has("b64")) {
    b64 = parsedProt.b64;
    if (typeof b64 !== "boolean") {
      throw new JWSInvalid('The "b64" (base64url-encode payload) Header Parameter must be a boolean');
    }
  }
  const { alg } = joseHeader;
  if (typeof alg !== "string" || !alg) {
    throw new JWSInvalid('JWS "alg" (Algorithm) Header Parameter missing or invalid');
  }
  const algorithms = options && validate_algorithms_default("algorithms", options.algorithms);
  if (algorithms && !algorithms.has(alg)) {
    throw new JOSEAlgNotAllowed('"alg" (Algorithm) Header Parameter value not allowed');
  }
  if (b64) {
    if (typeof jws.payload !== "string") {
      throw new JWSInvalid("JWS Payload must be a string");
    }
  } else if (typeof jws.payload !== "string" && !(jws.payload instanceof Uint8Array)) {
    throw new JWSInvalid("JWS Payload must be a string or an Uint8Array instance");
  }
  let resolvedKey = false;
  if (typeof key === "function") {
    key = await key(parsedProt, jws);
    resolvedKey = true;
  }
  check_key_type_default(alg, key, "verify");
  const data = concat(encoder.encode(jws.protected ?? ""), encoder.encode("."), typeof jws.payload === "string" ? encoder.encode(jws.payload) : jws.payload);
  let signature;
  try {
    signature = decode(jws.signature);
  } catch {
    throw new JWSInvalid("Failed to base64url decode the signature");
  }
  const k = await normalize_key_default(key, alg);
  const verified = await verify_default(alg, k, signature, data);
  if (!verified) {
    throw new JWSSignatureVerificationFailed();
  }
  let payload2;
  if (b64) {
    try {
      payload2 = decode(jws.payload);
    } catch {
      throw new JWSInvalid("Failed to base64url decode the payload");
    }
  } else if (typeof jws.payload === "string") {
    payload2 = encoder.encode(jws.payload);
  } else {
    payload2 = jws.payload;
  }
  const result = { payload: payload2 };
  if (jws.protected !== void 0) {
    result.protectedHeader = parsedProt;
  }
  if (jws.header !== void 0) {
    result.unprotectedHeader = jws.header;
  }
  if (resolvedKey) {
    return { ...result, key: k };
  }
  return result;
}

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/jws/compact/verify.js
async function compactVerify(jws, key, options) {
  if (jws instanceof Uint8Array) {
    jws = decoder.decode(jws);
  }
  if (typeof jws !== "string") {
    throw new JWSInvalid("Compact JWS must be a string or Uint8Array");
  }
  const { 0: protectedHeader, 1: payload2, 2: signature, length } = jws.split(".");
  if (length !== 3) {
    throw new JWSInvalid("Invalid Compact JWS");
  }
  const verified = await flattenedVerify({ payload: payload2, protected: protectedHeader, signature }, key, options);
  const result = { payload: verified.payload, protectedHeader: verified.protectedHeader };
  if (typeof key === "function") {
    return { ...result, key: verified.key };
  }
  return result;
}

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/epoch.js
var epoch_default = (date) => Math.floor(date.getTime() / 1e3);

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/secs.js
var minute = 60;
var hour = minute * 60;
var day = hour * 24;
var week = day * 7;
var year = day * 365.25;
var REGEX = /^(\+|\-)? ?(\d+|\d+\.\d+) ?(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)(?: (ago|from now))?$/i;
var secs_default = (str) => {
  const matched = REGEX.exec(str);
  if (!matched || matched[4] && matched[1]) {
    throw new TypeError("Invalid time period format");
  }
  const value2 = parseFloat(matched[2]);
  const unit = matched[3].toLowerCase();
  let numericDate;
  switch (unit) {
    case "sec":
    case "secs":
    case "second":
    case "seconds":
    case "s":
      numericDate = Math.round(value2);
      break;
    case "minute":
    case "minutes":
    case "min":
    case "mins":
    case "m":
      numericDate = Math.round(value2 * minute);
      break;
    case "hour":
    case "hours":
    case "hr":
    case "hrs":
    case "h":
      numericDate = Math.round(value2 * hour);
      break;
    case "day":
    case "days":
    case "d":
      numericDate = Math.round(value2 * day);
      break;
    case "week":
    case "weeks":
    case "w":
      numericDate = Math.round(value2 * week);
      break;
    default:
      numericDate = Math.round(value2 * year);
      break;
  }
  if (matched[1] === "-" || matched[4] === "ago") {
    return -numericDate;
  }
  return numericDate;
};

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/lib/jwt_claims_set.js
var normalizeTyp = (value2) => {
  if (value2.includes("/")) {
    return value2.toLowerCase();
  }
  return `application/${value2.toLowerCase()}`;
};
var checkAudiencePresence = (audPayload, audOption) => {
  if (typeof audPayload === "string") {
    return audOption.includes(audPayload);
  }
  if (Array.isArray(audPayload)) {
    return audOption.some(Set.prototype.has.bind(new Set(audPayload)));
  }
  return false;
};
function validateClaimsSet(protectedHeader, encodedPayload, options = {}) {
  let payload2;
  try {
    payload2 = JSON.parse(decoder.decode(encodedPayload));
  } catch {
  }
  if (!is_object_default(payload2)) {
    throw new JWTInvalid("JWT Claims Set must be a top-level JSON object");
  }
  const { typ } = options;
  if (typ && (typeof protectedHeader.typ !== "string" || normalizeTyp(protectedHeader.typ) !== normalizeTyp(typ))) {
    throw new JWTClaimValidationFailed('unexpected "typ" JWT header value', payload2, "typ", "check_failed");
  }
  const { requiredClaims = [], issuer, subject, audience, maxTokenAge } = options;
  const presenceCheck = [...requiredClaims];
  if (maxTokenAge !== void 0)
    presenceCheck.push("iat");
  if (audience !== void 0)
    presenceCheck.push("aud");
  if (subject !== void 0)
    presenceCheck.push("sub");
  if (issuer !== void 0)
    presenceCheck.push("iss");
  for (const claim of new Set(presenceCheck.reverse())) {
    if (!(claim in payload2)) {
      throw new JWTClaimValidationFailed(`missing required "${claim}" claim`, payload2, claim, "missing");
    }
  }
  if (issuer && !(Array.isArray(issuer) ? issuer : [issuer]).includes(payload2.iss)) {
    throw new JWTClaimValidationFailed('unexpected "iss" claim value', payload2, "iss", "check_failed");
  }
  if (subject && payload2.sub !== subject) {
    throw new JWTClaimValidationFailed('unexpected "sub" claim value', payload2, "sub", "check_failed");
  }
  if (audience && !checkAudiencePresence(payload2.aud, typeof audience === "string" ? [audience] : audience)) {
    throw new JWTClaimValidationFailed('unexpected "aud" claim value', payload2, "aud", "check_failed");
  }
  let tolerance;
  switch (typeof options.clockTolerance) {
    case "string":
      tolerance = secs_default(options.clockTolerance);
      break;
    case "number":
      tolerance = options.clockTolerance;
      break;
    case "undefined":
      tolerance = 0;
      break;
    default:
      throw new TypeError("Invalid clockTolerance option type");
  }
  const { currentDate } = options;
  const now = epoch_default(currentDate || /* @__PURE__ */ new Date());
  if ((payload2.iat !== void 0 || maxTokenAge) && typeof payload2.iat !== "number") {
    throw new JWTClaimValidationFailed('"iat" claim must be a number', payload2, "iat", "invalid");
  }
  if (payload2.nbf !== void 0) {
    if (typeof payload2.nbf !== "number") {
      throw new JWTClaimValidationFailed('"nbf" claim must be a number', payload2, "nbf", "invalid");
    }
    if (payload2.nbf > now + tolerance) {
      throw new JWTClaimValidationFailed('"nbf" claim timestamp check failed', payload2, "nbf", "check_failed");
    }
  }
  if (payload2.exp !== void 0) {
    if (typeof payload2.exp !== "number") {
      throw new JWTClaimValidationFailed('"exp" claim must be a number', payload2, "exp", "invalid");
    }
    if (payload2.exp <= now - tolerance) {
      throw new JWTExpired('"exp" claim timestamp check failed', payload2, "exp", "check_failed");
    }
  }
  if (maxTokenAge) {
    const age = now - payload2.iat;
    const max = typeof maxTokenAge === "number" ? maxTokenAge : secs_default(maxTokenAge);
    if (age - tolerance > max) {
      throw new JWTExpired('"iat" claim timestamp check failed (too far in the past)', payload2, "iat", "check_failed");
    }
    if (age < 0 - tolerance) {
      throw new JWTClaimValidationFailed('"iat" claim timestamp check failed (it should be in the past)', payload2, "iat", "check_failed");
    }
  }
  return payload2;
}

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/jwt/verify.js
async function jwtVerify(jwt, key, options) {
  const verified = await compactVerify(jwt, key, options);
  if (verified.protectedHeader.crit?.includes("b64") && verified.protectedHeader.b64 === false) {
    throw new JWTInvalid("JWTs MUST NOT use unencoded payload");
  }
  const payload2 = validateClaimsSet(verified.protectedHeader, verified.payload, options);
  const result = { payload: payload2, protectedHeader: verified.protectedHeader };
  if (typeof key === "function") {
    return { ...result, key: verified.key };
  }
  return result;
}

// node_modules/.pnpm/jose@6.1.0/node_modules/jose/dist/webapi/jwks/local.js
function getKtyFromAlg(alg) {
  switch (typeof alg === "string" && alg.slice(0, 2)) {
    case "RS":
    case "PS":
      return "RSA";
    case "ES":
      return "EC";
    case "Ed":
      return "OKP";
    case "ML":
      return "AKP";
    default:
      throw new JOSENotSupported('Unsupported "alg" value for a JSON Web Key Set');
  }
}
function isJWKSLike(jwks) {
  return jwks && typeof jwks === "object" && Array.isArray(jwks.keys) && jwks.keys.every(isJWKLike);
}
function isJWKLike(key) {
  return is_object_default(key);
}
var LocalJWKSet = class {
  #jwks;
  #cached = /* @__PURE__ */ new WeakMap();
  constructor(jwks) {
    if (!isJWKSLike(jwks)) {
      throw new JWKSInvalid("JSON Web Key Set malformed");
    }
    this.#jwks = structuredClone(jwks);
  }
  jwks() {
    return this.#jwks;
  }
  async getKey(protectedHeader, token) {
    const { alg, kid } = { ...protectedHeader, ...token?.header };
    const kty = getKtyFromAlg(alg);
    const candidates = this.#jwks.keys.filter((jwk2) => {
      let candidate = kty === jwk2.kty;
      if (candidate && typeof kid === "string") {
        candidate = kid === jwk2.kid;
      }
      if (candidate && (typeof jwk2.alg === "string" || kty === "AKP")) {
        candidate = alg === jwk2.alg;
      }
      if (candidate && typeof jwk2.use === "string") {
        candidate = jwk2.use === "sig";
      }
      if (candidate && Array.isArray(jwk2.key_ops)) {
        candidate = jwk2.key_ops.includes("verify");
      }
      if (candidate) {
        switch (alg) {
          case "ES256":
            candidate = jwk2.crv === "P-256";
            break;
          case "ES384":
            candidate = jwk2.crv === "P-384";
            break;
          case "ES512":
            candidate = jwk2.crv === "P-521";
            break;
          case "Ed25519":
          case "EdDSA":
            candidate = jwk2.crv === "Ed25519";
            break;
        }
      }
      return candidate;
    });
    const { 0: jwk, length } = candidates;
    if (length === 0) {
      throw new JWKSNoMatchingKey();
    }
    if (length !== 1) {
      const error3 = new JWKSMultipleMatchingKeys();
      const _cached = this.#cached;
      error3[Symbol.asyncIterator] = async function* () {
        for (const jwk2 of candidates) {
          try {
            yield await importWithAlgCache(_cached, jwk2, alg);
          } catch {
          }
        }
      };
      throw error3;
    }
    return importWithAlgCache(this.#cached, jwk, alg);
  }
};
async function importWithAlgCache(cache2, jwk, alg) {
  const cached = cache2.get(jwk) || cache2.set(jwk, {}).get(jwk);
  if (cached[alg] === void 0) {
    const key = await importJWK({ ...jwk, ext: true }, alg);
    if (key instanceof Uint8Array || key.type !== "public") {
      throw new JWKSInvalid("JSON Web Key Set members must be public keys");
    }
    cached[alg] = key;
  }
  return cached[alg];
}
function createLocalJWKSet(jwks) {
  const set = new LocalJWKSet(jwks);
  const localJWKSet = async (protectedHeader, token) => set.getKey(protectedHeader, token);
  Object.defineProperties(localJWKSet, {
    jwks: {
      value: () => structuredClone(set.jwks()),
      enumerable: false,
      configurable: false,
      writable: false
    }
  });
  return localJWKSet;
}

// server/src/publishing.mjs
import { randomUUID as randomUUID7, createPrivateKey as createPrivateKey3, createPublicKey as createPublicKey4 } from "node:crypto";
import { readFileSync as readFileSync5 } from "node:fs";
var writeRoles = ["owner", "admin", "developer"];
var checked = (result) => {
  requireValue(result.ok, result.error?.code ?? "INVALID_INPUT");
  return result.value;
};
var Publishing = class {
  signingId(namespace2, keyId2 = this.config.keyId) {
    return this.config.namespacedSigning ? "center-" + hash(keyId2 + "\0" + namespace2).slice(0, 48) : this.config.keyId;
  }
  constructor(store, config2) {
    this.store = store;
    this.config = config2;
    this.environment = store.environment === "production" ? "production" : "test";
    const entries3 = this.environment === "production" ? productionSigningKeys(config2) : null;
    if (!entries3) {
      this.key = createPrivateKey3(readFileSync5(config2.privateKeyFile));
      requireValue(this.key.asymmetricKeyType === "ed25519", "SIGNING_CONFIGURATION", 503);
      this.publicKey = createPublicKey4(this.key).export({ type: "spki", format: "pem" });
      text(config2.keyId, 128);
      requireValue(
        /^[a-zA-Z0-9][a-zA-Z0-9._-]{0,127}$/.test(config2.keyId),
        "SIGNING_CONFIGURATION",
        503
      );
    }
    store.transaction(() => {
      store.db.exec(`
        CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, owner TEXT NOT NULL, kind TEXT NOT NULL, package_id TEXT UNIQUE NOT NULL, type TEXT NOT NULL, name TEXT NOT NULL, license TEXT NOT NULL, author TEXT NOT NULL, sdk TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS submissions(id TEXT PRIMARY KEY, project TEXT REFERENCES projects(id), version TEXT NOT NULL, digest TEXT NOT NULL, manifest TEXT NOT NULL, sources TEXT NOT NULL, submitter TEXT NOT NULL, submitted_at INTEGER NOT NULL, state TEXT NOT NULL, reviewer TEXT, reason TEXT, reviewed_at INTEGER, UNIQUE(project,version));
        CREATE TABLE IF NOT EXISTS published(id TEXT PRIMARY KEY REFERENCES submissions(id), envelope TEXT NOT NULL, publisher TEXT NOT NULL, published_at INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS publishing_credentials(id TEXT PRIMARY KEY, hash TEXT UNIQUE NOT NULL, actor TEXT NOT NULL, project TEXT REFERENCES projects(id), environment TEXT NOT NULL CHECK(environment='${this.environment}'), expires INTEGER NOT NULL, revoked INTEGER NOT NULL DEFAULT 0);
        INSERT OR IGNORE INTO schema_version VALUES(2);`);
      const policy2 = hash(
        JSON.stringify(
          Object.entries(config2.platformRoles ?? {}).sort().map(([sub, roles2]) => [sub, [...roles2].sort()])
        )
      );
      const previous = store.get("SELECT value FROM settings WHERE name='publishing_roles'");
      if (previous && previous.value !== policy2)
        store.run(
          "UPDATE submissions SET state='invalidated',reason='Platform authorization changed' WHERE state='approved'"
        );
      store.run(
        "INSERT INTO settings VALUES('publishing_roles',?) ON CONFLICT(name) DO UPDATE SET value=excluded.value",
        policy2
      );
    });
    if (entries3) {
      this.config.namespacedSigning = true;
      this.signingKeys = new SigningKeys(this, entries3);
    }
  }
  owner(session, write = false) {
    this.store.assertDataOwner(session.actor);
    if (session.org) this.store.permission(session, session.org, write ? writeRoles : void 0);
    return { id: session.org ?? session.actor, kind: session.org ? "organization" : "personal" };
  }
  project(session, id3, write = false) {
    const owner = this.owner(session, write);
    const p = this.store.get(
      "SELECT * FROM projects WHERE id=? AND owner=? AND kind=?",
      id3,
      owner.id,
      owner.kind
    );
    requireValue(p, "NOT_FOUND", 404);
    requireValue(!this.catalogAccess || this.catalogAccess(session, p), "NOT_FOUND", 404);
    return p;
  }
  list(session) {
    const owner = this.owner(session);
    return this.store.all(
      "SELECT * FROM projects WHERE owner=? AND kind=? ORDER BY package_id",
      owner.id,
      owner.kind
    ).filter((p) => !this.catalogAccess || this.catalogAccess(session, p));
  }
  create(session, input) {
    return this.store.transaction(() => {
      const owner = this.owner(session, true), packageId = text(input.packageId, 129);
      requireValue(
        /^[a-z][a-z0-9-]{2,39}\/[a-z][a-z0-9.-]{0,63}$/.test(packageId),
        "INVALID_INPUT"
      );
      requireValue(
        this.store.get(
          "SELECT 1 FROM namespaces WHERE name=? AND owner=? AND kind=?",
          packageId.split("/")[0],
          owner.id,
          owner.kind
        ),
        "NAMESPACE_FORBIDDEN",
        403
      );
      requireValue(["application", "capability"].includes(input.type), "INVALID_INPUT");
      requireValue(input.sdk === "0.0.11", "INCOMPATIBLE_SDK");
      requireValue(
        !this.store.get("SELECT 1 FROM projects WHERE package_id=?", packageId),
        "PROJECT_CONFLICT",
        409
      );
      const id3 = randomUUID7();
      this.store.run(
        "INSERT INTO projects VALUES(?,?,?,?,?,?,?,?,?)",
        id3,
        owner.id,
        owner.kind,
        packageId,
        input.type,
        text(input.name),
        text(input.license),
        text(input.author),
        input.sdk
      );
      this.store.record(session.actor, session.org, "project.create", id3);
      if (this.catalogAccess)
        this.store.run("INSERT INTO catalog_projects VALUES(?,'private')", id3);
      return this.project(session, id3);
    });
  }
  package(input) {
    requireValue(
      input.manifest && input.sources && typeof input.sources === "object" && !Array.isArray(input.sources),
      "INVALID_INPUT"
    );
    const entries3 = Object.entries(input.sources);
    requireValue(
      entries3.length <= 16 && entries3.every(([, v]) => typeof v === "string"),
      "INVALID_INPUT"
    );
    const pkg = checked(
      verifyCapabilityPackage(
        JSON.stringify(input.manifest),
        new Map(entries3.map(([p, v]) => [p, Buffer.from(v)]))
      )
    );
    requireValue(pkg.sha256 === input.sha256, "DIGEST_MISMATCH");
    requireValue(pkg.manifest.execution !== "host-service-v1", "UNSUPPORTED_EXECUTION");
    if (input.attestation) {
      requireValue(this.config.publisherKeys?.length, "UNTRUSTED_SIGNATURE");
      checked(new CapabilityPackageTrust(this.config.publisherKeys).verify(pkg, input.attestation));
    }
    return pkg;
  }
  stored(row) {
    return checked(
      verifyCapabilityPackage(
        row.manifest,
        new Map(Object.entries(JSON.parse(row.sources)).map(([p, v]) => [p, Buffer.from(v)]))
      )
    );
  }
  dependencies(session, pkg) {
    const owner = this.owner(session);
    const rows = this.store.all(
      "SELECT s.* FROM submissions s JOIN projects p ON p.id=s.project JOIN published r ON r.id=s.id WHERE p.owner=? AND p.kind=?",
      owner.id,
      owner.kind
    );
    requireValue(rows.length < 128, "LIMIT_EXCEEDED");
    const catalog = rows.filter(
      (r) => !this.catalogAccess || this.catalogAccess(
        session,
        this.store.get("SELECT * FROM projects WHERE id=?", r.project)
      )
    ).map((r) => this.stored(r));
    checked(
      resolveCapabilityDependencies(
        [{ packageId: pkg.manifest.packageId, range: pkg.manifest.version }],
        [
          ...catalog.filter(
            (p) => p.manifest.packageId !== pkg.manifest.packageId || p.manifest.version !== pkg.manifest.version
          ),
          pkg
        ]
      )
    );
  }
  submit(session, project, input, token = null) {
    const pkg = this.package(input);
    return this.store.transaction(() => {
      if (token) session = this.tokenSession(token, project, this.environment);
      const p = this.project(session, project, true);
      requireValue(
        pkg.manifest.packageId === p.package_id && p.type === "application" === (pkg.manifest.execution === "static-application-v1"),
        "PROJECT_PACKAGE_MISMATCH"
      );
      requireValue(
        pkg.manifest.capabilities.every(
          (c) => c.capabilityId.startsWith(p.package_id.split("/")[0] + "/")
        ),
        "NAMESPACE_FORBIDDEN",
        403
      );
      const old = this.store.get(
        "SELECT * FROM submissions WHERE project=? AND version=?",
        p.id,
        pkg.manifest.version
      );
      if (old) {
        requireValue(old.digest === pkg.sha256, "VERSION_IMMUTABLE", 409);
        return this.summary(old);
      }
      this.dependencies(session, pkg);
      const id3 = randomUUID7();
      this.store.run(
        "INSERT INTO submissions(id,project,version,digest,manifest,sources,submitter,submitted_at,state) VALUES(?,?,?,?,?,?,?,?,?)",
        id3,
        p.id,
        pkg.manifest.version,
        pkg.sha256,
        JSON.stringify(pkg.manifest),
        JSON.stringify(pkg.sources),
        session.actor,
        this.store.now(),
        "pending"
      );
      this.store.record(session.actor, session.org, "submission.create", id3);
      return this.summary(this.store.get("SELECT * FROM submissions WHERE id=?", id3));
    });
  }
  summary(row) {
    const safe = { ...row };
    delete safe.sources;
    return { ...safe, manifest: JSON.parse(row.manifest) };
  }
  submissions(session, project) {
    this.project(session, project);
    return this.store.all("SELECT * FROM submissions WHERE project=? ORDER BY submitted_at DESC", project).map((r) => this.summary(r));
  }
  platform(session, role) {
    const actor = this.store.get("SELECT sub FROM actors WHERE id=?", session.actor);
    requireValue(this.config.platformRoles?.[actor.sub]?.includes(role), "FORBIDDEN", 403);
  }
  queue(session) {
    this.platform(session, "reviewer");
    return this.store.all(
      "SELECT s.*,p.package_id,p.name,p.license,p.author FROM submissions s JOIN projects p ON p.id=s.project WHERE state='pending' ORDER BY submitted_at"
    ).map((r) => this.summary(r));
  }
  publicationQueue(session) {
    this.platform(session, "publisher");
    return this.store.all(
      this.environment === "production" ? "SELECT * FROM submissions WHERE state IN ('approved','published') ORDER BY reviewed_at" : "SELECT * FROM submissions WHERE state='approved' ORDER BY reviewed_at"
    ).map((r) => this.summary(r));
  }
  artifact(session, id3) {
    const row = this.store.get("SELECT * FROM submissions WHERE id=?", id3);
    requireValue(row, "NOT_FOUND", 404);
    const actor = this.store.get("SELECT sub FROM actors WHERE id=?", session.actor);
    if (!this.config.platformRoles?.[actor.sub]?.includes("reviewer"))
      this.project(session, row.project);
    return {
      manifest: JSON.parse(row.manifest),
      sources: JSON.parse(row.sources),
      sha256: row.digest
    };
  }
  credentials(session, project) {
    this.project(session, project, true);
    return this.store.all(
      "SELECT id,actor,project,environment,expires,revoked FROM publishing_credentials WHERE project=?",
      project
    );
  }
  review(session, id3, input) {
    return this.store.transaction(() => {
      this.platform(session, "reviewer");
      const row = this.store.get("SELECT * FROM submissions WHERE id=?", id3);
      requireValue(row, "NOT_FOUND", 404);
      requireValue(row.submitter !== session.actor, "SELF_REVIEW_FORBIDDEN", 403);
      requireValue(row.state === "pending" && row.digest === input.sha256, "REVIEW_CONFLICT", 409);
      requireValue(["approved", "rejected"].includes(input.decision), "INVALID_INPUT");
      const reason = text(input.reason, 1e3);
      this.store.run(
        "UPDATE submissions SET state=?,reviewer=?,reason=?,reviewed_at=? WHERE id=?",
        input.decision,
        session.actor,
        reason,
        this.store.now(),
        id3
      );
      const project = this.store.get("SELECT * FROM projects WHERE id=?", row.project);
      this.store.record(
        session.actor,
        project.kind === "organization" ? project.owner : null,
        "submission." + input.decision,
        id3
      );
      return this.summary(this.store.get("SELECT * FROM submissions WHERE id=?", id3));
    });
  }
  submitterSession(row) {
    const p = this.store.get("SELECT * FROM projects WHERE id=?", row.project);
    const session = { actor: row.submitter, org: p.kind === "organization" ? p.owner : null };
    requireValue(
      p.kind === "organization" || p.owner === row.submitter,
      "APPROVAL_INVALIDATED",
      409
    );
    this.project(session, p.id, true);
    return session;
  }
  publish(session, id3, input) {
    return this.store.transaction(() => {
      this.platform(session, "publisher");
      const row = this.store.get("SELECT * FROM submissions WHERE id=?", id3);
      requireValue(row, "NOT_FOUND", 404);
      requireValue(row.reviewer !== session.actor, "DUTY_SEPARATION", 403);
      requireValue(
        ["approved", "published"].includes(row.state) && row.digest === input.sha256,
        "REVIEW_CONFLICT",
        409
      );
      this.platform({ actor: row.reviewer }, "reviewer");
      const submitter = this.submitterSession(row), pkg = this.stored(row);
      requireValue(pkg.sha256 === row.digest, "DIGEST_MISMATCH");
      this.dependencies(submitter, pkg);
      const existing = this.store.get("SELECT * FROM published WHERE id=?", id3);
      if (existing)
        return { id: id3, environment: this.environment, attestation: JSON.parse(existing.envelope) };
      const active = this.signingKeys?.active();
      const now = this.store.now(), attestation = checked(
        signCapabilityPackage(pkg, active?.key ?? this.key, {
          keyId: this.signingId(
            pkg.manifest.packageId.split("/")[0],
            active?.key_id ?? this.config.keyId
          ),
          environment: this.environment,
          issuedAt: now,
          expiresAt: Math.min(now + 7 * 864e5, active?.not_after ?? Number.MAX_SAFE_INTEGER)
        })
      );
      this.store.run(
        "INSERT INTO published VALUES(?,?,?,?)",
        id3,
        JSON.stringify(attestation),
        session.actor,
        now
      );
      this.store.run("UPDATE submissions SET state='published' WHERE id=?", id3);
      this.store.record(session.actor, submitter.org, "release.publish", id3);
      return { id: id3, environment: this.environment, attestation };
    });
  }
  credential(session, project) {
    return this.store.transaction(() => {
      this.project(session, project, true);
      const id3 = randomUUID7(), token = "sitoo_pub_" + secret(), expires = this.store.now() + 7 * 864e5;
      this.store.run(
        "INSERT INTO publishing_credentials(id,hash,actor,project,environment,expires) VALUES(?,?,?,?,?,?)",
        id3,
        hash(token),
        session.actor,
        project,
        this.environment,
        expires
      );
      this.store.record(session.actor, session.org, "publishing-credential.create", id3);
      return {
        id: id3,
        token,
        project,
        environment: this.environment,
        expires,
        scopes: ["project:read", "submission:create"]
      };
    });
  }
  revokeCredential(session, project, id3) {
    return this.store.transaction(() => {
      const p = this.project(session, project, true), c = this.store.get(
        "SELECT * FROM publishing_credentials WHERE id=? AND project=?",
        id3,
        project
      );
      requireValue(c, "NOT_FOUND", 404);
      if (p.kind === "organization" && this.store.permission(session, p.owner) === "developer")
        requireValue(c.actor === session.actor, "FORBIDDEN", 403);
      this.store.run("UPDATE publishing_credentials SET revoked=1 WHERE id=?", id3);
      this.store.record(session.actor, session.org, "publishing-credential.revoke", id3);
      return { revoked: true };
    });
  }
  tokenSession(token, project, environment) {
    requireValue(environment === this.environment, "ENVIRONMENT_FORBIDDEN", 403);
    const c = this.store.get(
      "SELECT * FROM publishing_credentials WHERE hash=? AND revoked=0 AND expires>?",
      hash(token),
      this.store.now()
    );
    requireValue(c, "UNAUTHENTICATED", 401);
    requireValue(c.environment === environment, "ENVIRONMENT_FORBIDDEN", 403);
    requireValue(c.project === project, "FORBIDDEN", 403);
    const p = this.store.get("SELECT * FROM projects WHERE id=?", project), session = { actor: c.actor, org: p.kind === "organization" ? p.owner : null };
    this.project(session, project, true);
    return session;
  }
};

// server/src/catalog.mjs
import { randomUUID as randomUUID8 } from "node:crypto";
var Catalog = class {
  constructor(publishing) {
    this.publishing = publishing;
    this.publishing.config.namespacedSigning = true;
    this.store = publishing.store;
    this.environment = publishing.environment;
    this.channels = this.environment === "production" ? ["production"] : ["test", "stable"];
    const migrating = this.store.get("SELECT max(version) AS version FROM schema_version").version < 3;
    this.store.transaction(
      () => this.store.db.exec(`
      CREATE TABLE IF NOT EXISTS catalog_projects(project TEXT PRIMARY KEY REFERENCES projects(id),visibility TEXT NOT NULL CHECK(visibility IN ('private','organization','public')));
      CREATE TABLE IF NOT EXISTS catalog_channels(project TEXT REFERENCES projects(id),channel TEXT NOT NULL CHECK(channel IN (${this.channels.map((c) => "'" + c + "'").join(",")})),release TEXT REFERENCES submissions(id),previous TEXT,percentage INTEGER NOT NULL CHECK(percentage BETWEEN 0 AND 100),paused INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(project,channel));
      CREATE TABLE IF NOT EXISTS withdrawn(release TEXT PRIMARY KEY REFERENCES submissions(id),actor TEXT NOT NULL,reason TEXT NOT NULL,at INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS catalog_credentials(id TEXT PRIMARY KEY,hash TEXT UNIQUE NOT NULL,actor TEXT NOT NULL,org TEXT,expires INTEGER NOT NULL,revoked INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS catalog_optouts(actor TEXT NOT NULL,project TEXT NOT NULL,channel TEXT NOT NULL,PRIMARY KEY(actor,project,channel));
      ${migrating ? "INSERT OR IGNORE INTO catalog_projects SELECT id,CASE WHEN kind='organization' THEN 'organization' ELSE 'private' END FROM projects;" : ""}
      INSERT OR IGNORE INTO schema_version VALUES(3);`)
    );
    this.publishing.catalogAccess = (session, p) => this.visible(session, p);
  }
  visibility(project) {
    return this.store.get("SELECT visibility FROM catalog_projects WHERE project=?", project)?.visibility ?? "private";
  }
  visible(session, p) {
    if (this.visibility(p.id) === "public") return true;
    if (!session?.actor) return false;
    if (p.kind === "personal") return p.owner === session.actor;
    if (session.org !== p.owner) return false;
    const member = this.store.get(
      "SELECT role FROM members WHERE org=? AND actor=?",
      p.owner,
      session.actor
    );
    if (!member) return false;
    if (this.visibility(p.id) === "organization") return true;
    const creator = this.store.get(
      "SELECT actor FROM audit WHERE action='project.create' AND target=? ORDER BY id LIMIT 1",
      p.id
    );
    return ["owner", "admin"].includes(member.role) || creator?.actor === session.actor;
  }
  published(id3) {
    const row = this.store.get(
      "SELECT s.*,r.envelope FROM submissions s JOIN published r ON r.id=s.id LEFT JOIN withdrawn w ON w.release=s.id WHERE s.id=? AND w.release IS NULL",
      id3
    );
    requireValue(row, "NOT_FOUND", 404);
    const pkg = this.publishing.stored(row), envelope = JSON.parse(row.envelope);
    if (!this.publishing.signingKeys)
      requireValue(
        [
          this.publishing.config.keyId,
          this.publishing.signingId(pkg.manifest.packageId.split("/")[0])
        ].includes(envelope.keyId),
        "NOT_FOUND",
        404
      );
    const trust = new CapabilityPackageTrust(
      this.publishing.signingKeys?.policies(pkg.manifest.packageId.split("/")[0]) ?? [
        {
          keyId: envelope.keyId,
          namespace: pkg.manifest.packageId.split("/")[0],
          environments: ["test"],
          publicKeyPem: this.publishing.publicKey,
          notBefore: 0,
          notAfter: Number.MAX_SAFE_INTEGER,
          revoked: false
        }
      ]
    );
    requireValue(trust.verify(pkg, envelope, this.store.now()).ok, "NOT_FOUND", 404);
    return { row, pkg, envelope };
  }
  candidate(session, project, channel) {
    const state = this.store.get(
      "SELECT * FROM catalog_channels WHERE project=? AND channel=?",
      project,
      channel
    );
    requireValue(state, "NOT_FOUND", 404);
    const bucket = parseInt(hash((session?.actor ?? "public-visitor") + "\0" + project).slice(0, 8), 16) % 100;
    const optout = session?.actor && this.store.get(
      "SELECT 1 FROM catalog_optouts WHERE actor=? AND project=? AND channel=?",
      session.actor,
      project,
      channel
    );
    const selected = state.paused || optout || bucket >= state.percentage ? state.previous : state.release;
    requireValue(selected, "NOT_FOUND", 404);
    return this.published(selected);
  }
  closure(session, selected) {
    const projects = this.store.all("SELECT * FROM projects");
    const allowed = new Set(projects.filter((p) => this.visible(session, p)).map((p) => p.id));
    requireValue(allowed.has(selected.row.project), "NOT_FOUND", 404);
    const rows = this.store.all(
      "SELECT s.id,s.project FROM submissions s JOIN published r ON r.id=s.id LEFT JOIN withdrawn w ON w.release=s.id WHERE w.release IS NULL"
    );
    const packages = [];
    for (const r of rows)
      if (allowed.has(r.project)) {
        try {
          packages.push(this.published(r.id));
        } catch {
        }
      }
    requireValue(packages.length <= 128, "LIMIT_EXCEEDED");
    const planned = resolveCapabilityDependencies(
      [{ packageId: selected.pkg.manifest.packageId, range: selected.pkg.manifest.version }],
      packages.map((p) => p.pkg)
    );
    requireValue(planned.ok, "NOT_FOUND", 404);
    const keyNamespaces = /* @__PURE__ */ new Map();
    return planned.value.packages.map((ref) => {
      const p = packages.find(
        (p2) => p2.pkg.manifest.packageId === ref.packageId && p2.pkg.manifest.version === ref.version && p2.pkg.sha256 === ref.sha256
      );
      requireValue(p, "NOT_FOUND", 404);
      const namespace2 = p.pkg.manifest.packageId.split("/")[0], previous = keyNamespaces.get(p.envelope.keyId);
      requireValue(!previous || previous === namespace2, "NOT_FOUND", 404);
      keyNamespaces.set(p.envelope.keyId, namespace2);
      return p;
    });
  }
  list(session, channel = this.channels[0], query = "") {
    requireValue(
      this.channels.includes(channel) && typeof query === "string" && query.length <= 100,
      "INVALID_INPUT"
    );
    const result = [];
    for (const p of this.store.all("SELECT * FROM projects ORDER BY package_id")) {
      if (!this.visible(session, p) || !(p.name + " " + p.package_id).toLowerCase().includes(query.toLowerCase()))
        continue;
      try {
        const selected = this.candidate(session, p.id, channel);
        this.closure(session, selected);
        result.push({
          id: p.id,
          type: p.type,
          name: p.name,
          packageId: p.package_id,
          author: p.author,
          license: p.license,
          sdk: p.sdk,
          visibility: this.visibility(p.id),
          release: selected.row.id,
          version: selected.row.version,
          sha256: selected.row.digest,
          channel,
          environment: this.environment
        });
      } catch {
      }
    }
    return result;
  }
  download(session, project, id3, channel = this.channels[0]) {
    return this.store.transaction(() => {
      const visible = this.list(session, channel).find((p) => p.id === project && p.release === id3);
      requireValue(visible, "NOT_FOUND", 404);
      const selected = this.candidate(session, project, channel);
      return {
        root: visible,
        packages: this.closure(session, selected).map((p) => ({
          id: p.row.id,
          manifest: p.pkg.manifest,
          sources: p.pkg.sources,
          sha256: p.pkg.sha256,
          attestation: p.envelope
        }))
      };
    });
  }
  configureVisibility(session, project, visibility) {
    return this.store.transaction(() => {
      const p = this.publishing.project(session, project, true);
      requireValue(["private", "organization", "public"].includes(visibility), "INVALID_INPUT");
      requireValue(visibility !== "organization" || p.kind === "organization", "INVALID_INPUT");
      if (visibility === "public") {
        const releases = this.store.all(
          "SELECT s.id FROM submissions s JOIN published r ON r.id=s.id WHERE s.project=?",
          project
        );
        for (const r of releases) {
          const selected = this.published(r.id);
          for (const dep of selected.pkg.manifest.dependencies) {
            const dependency = this.store.get(
              "SELECT id FROM projects WHERE package_id=?",
              dep.packageId
            );
            requireValue(
              dependency && this.visibility(dependency.id) === "public",
              "DEPENDENCY_NOT_PUBLIC",
              409
            );
          }
        }
      }
      this.store.run(
        "INSERT INTO catalog_projects VALUES(?,?) ON CONFLICT(project) DO UPDATE SET visibility=excluded.visibility",
        project,
        visibility
      );
      this.store.record(session.actor, session.org, "catalog.visibility", project);
      return { visibility };
    });
  }
  promote(session, project, input) {
    return this.store.transaction(() => {
      if (this.environment === "production") this.publishing.platform(session, "publisher");
      else this.publishing.project(session, project, true);
      requireValue(
        this.channels.includes(input.channel) && Number.isInteger(input.percentage) && input.percentage >= 0 && input.percentage <= 100 && typeof input.paused === "boolean",
        "INVALID_INPUT"
      );
      const release = this.published(input.release);
      requireValue(release.row.project === project, "NOT_FOUND", 404);
      this.closure(
        this.environment === "production" ? this.publishing.submitterSession(release.row) : session,
        release
      );
      const old = this.store.get(
        "SELECT * FROM catalog_channels WHERE project=? AND channel=?",
        project,
        input.channel
      );
      if (input.channel === "stable")
        requireValue(
          this.store.get(
            "SELECT 1 FROM catalog_channels WHERE project=? AND channel='test' AND release=?",
            project,
            input.release
          ),
          "TEST_CHANNEL_REQUIRED",
          409
        );
      const previous = old?.release === input.release ? old.previous : old?.release ?? null;
      this.store.run(
        "INSERT INTO catalog_channels VALUES(?,?,?,?,?,?) ON CONFLICT(project,channel) DO UPDATE SET release=excluded.release,previous=excluded.previous,percentage=excluded.percentage,paused=excluded.paused",
        project,
        input.channel,
        input.release,
        previous,
        input.percentage,
        input.paused ? 1 : 0
      );
      this.store.record(
        session.actor,
        session.org,
        "catalog.promote." + input.channel,
        input.release
      );
      return {
        release: input.release,
        previous,
        channel: input.channel,
        sha256: release.row.digest,
        attestation: release.envelope
      };
    });
  }
  withdraw(session, project, id3, reason) {
    return this.store.transaction(() => {
      this.publishing.project(session, project, true);
      const row = this.store.get("SELECT project FROM submissions WHERE id=?", id3);
      requireValue(row?.project === project, "NOT_FOUND", 404);
      this.store.run(
        "INSERT OR IGNORE INTO withdrawn VALUES(?,?,?,?)",
        id3,
        session.actor,
        text(reason, 1e3),
        this.store.now()
      );
      this.store.record(session.actor, session.org, "release.withdraw", id3);
      return { withdrawn: true, existingInstallations: "preserved", originalTasks: "preserved" };
    });
  }
  optOut(session, project, channel, enabled) {
    return this.store.transaction(() => {
      requireValue(
        session?.actor && this.channels.includes(channel) && typeof enabled === "boolean",
        "INVALID_INPUT"
      );
      const p = this.store.get("SELECT * FROM projects WHERE id=?", project);
      requireValue(p && this.visible(session, p), "NOT_FOUND", 404);
      requireValue(
        this.list(session, channel).some((p2) => p2.id === project) || this.store.get(
          "SELECT 1 FROM catalog_optouts WHERE actor=? AND project=? AND channel=?",
          session.actor,
          project,
          channel
        ),
        "NOT_FOUND",
        404
      );
      if (enabled)
        this.store.run(
          "INSERT OR IGNORE INTO catalog_optouts VALUES(?,?,?)",
          session.actor,
          project,
          channel
        );
      else
        this.store.run(
          "DELETE FROM catalog_optouts WHERE actor=? AND project=? AND channel=?",
          session.actor,
          project,
          channel
        );
      this.store.record(
        session.actor,
        session.org,
        enabled ? "catalog.rollout.exit" : "catalog.rollout.resume",
        project
      );
      return { optedOut: enabled };
    });
  }
  credential(session) {
    return this.store.transaction(() => {
      if (session.org) this.store.permission(session, session.org);
      const id3 = randomUUID8(), token = "sitoo_catalog_" + secret(), expires = this.store.now() + 7 * 864e5;
      this.store.run(
        "INSERT INTO catalog_credentials(id,hash,actor,org,expires) VALUES(?,?,?,?,?)",
        id3,
        hash(token),
        session.actor,
        session.org,
        expires
      );
      this.store.record(session.actor, session.org, "catalog-credential.create", id3);
      return {
        id: id3,
        token,
        expires,
        environment: this.environment,
        scopes: ["catalog:read", "release:download"]
      };
    });
  }
  tokenSession(token) {
    const c = this.store.get(
      "SELECT * FROM catalog_credentials WHERE hash=? AND revoked=0 AND expires>?",
      hash(token),
      this.store.now()
    );
    requireValue(c, "UNAUTHENTICATED", 401);
    this.store.assertDataOwner(c.actor);
    if (c.org) this.store.permission(c, c.org);
    return c;
  }
  credentials(session) {
    if (session.org) this.store.permission(session, session.org);
    return this.store.all(
      "SELECT id,org,expires,revoked FROM catalog_credentials WHERE actor=? AND org IS ?",
      session.actor,
      session.org
    );
  }
  revoke(session, id3) {
    return this.store.transaction(() => {
      if (session.org) this.store.permission(session, session.org);
      const c = this.store.get(
        "SELECT * FROM catalog_credentials WHERE id=? AND actor=? AND org IS ?",
        id3,
        session.actor,
        session.org
      );
      requireValue(c, "NOT_FOUND", 404);
      this.store.run("UPDATE catalog_credentials SET revoked=1 WHERE id=?", id3);
      this.store.record(session.actor, session.org, "catalog-credential.revoke", id3);
      return { revoked: true };
    });
  }
  settings(session, project) {
    this.publishing.project(session, project);
    return {
      visibility: this.visibility(project),
      channels: this.store.all("SELECT * FROM catalog_channels WHERE project=?", project),
      withdrawals: this.store.all(
        "SELECT w.release,w.reason,w.at FROM withdrawn w JOIN submissions s ON s.id=w.release WHERE s.project=?",
        project
      )
    };
  }
  trustKeys(session) {
    const namespaces = [
      ...new Set(
        this.store.all("SELECT * FROM projects").filter((p) => this.visible(session, p)).map((p) => p.package_id.split("/")[0])
      )
    ];
    requireValue(namespaces.length <= 32, "LIMIT_EXCEEDED");
    if (this.publishing.signingKeys) {
      const keys2 = namespaces.flatMap((ns) => this.publishing.signingKeys.policies(ns));
      requireValue(keys2.length <= 32, "LIMIT_EXCEEDED");
      return { keys: keys2, environment: this.environment };
    }
    const policy2 = (namespace2) => ({
      keyId: this.publishing.signingId(namespace2),
      namespace: namespace2,
      environments: ["test"],
      publicKeyPem: this.publishing.publicKey,
      notBefore: 0,
      notAfter: Date.UTC(2030, 0, 1),
      revoked: false
    });
    const keys = namespaces.map(policy2);
    const legacy = [];
    for (const ns of namespaces)
      if (this.store.get(
        "SELECT 1 FROM published r JOIN submissions s ON s.id=r.id JOIN projects p ON p.id=s.project WHERE p.package_id LIKE ? AND json_extract(r.envelope,'$.keyId')=?",
        ns + "/%",
        this.publishing.config.keyId
      ))
        legacy.push(ns);
    if (legacy.length === 1)
      keys.push({ ...policy2(legacy[0]), keyId: this.publishing.config.keyId });
    requireValue(keys.length <= 32, "LIMIT_EXCEEDED");
    return {
      keys,
      environment: this.environment,
      trust: "Confirm from trusted platform; do not trust keys supplied inside an artifact"
    };
  }
};

// server/src/http.mjs
import { createHash as createHash8 } from "node:crypto";
function trusted(value2) {
  const u = new URL(value2);
  requireValue(
    !u.username && !u.password && (u.protocol === "https:" || u.protocol === "http:" && ["127.0.0.1", "localhost"].includes(u.hostname)),
    "UNSAFE_CONFIGURATION"
  );
  return u;
}
var jsonFetch = async (url2, init = {}, ca) => {
  if (ca)
    return new Promise((yes, no) => {
      const req = httpsRequest(
        url2,
        {
          method: init.method ?? "GET",
          headers: init.headers,
          ca,
          rejectUnauthorized: true,
          timeout: 1e4
        },
        (res) => {
          const chunks = [];
          let size = 0;
          res.on("data", (chunk) => {
            size += chunk.length;
            if (size > 1048576) res.destroy(new Problem("IDENTITY_UNAVAILABLE", 503));
            else chunks.push(chunk);
          });
          res.on("error", no);
          res.on("end", () => {
            try {
              requireValue(
                res.statusCode >= 200 && res.statusCode < 300,
                "IDENTITY_UNAVAILABLE",
                503
              );
              yes(JSON.parse(Buffer.concat(chunks).toString("utf8")));
            } catch (e) {
              no(e);
            }
          });
        }
      );
      req.on("error", no);
      req.on("timeout", () => req.destroy(new Problem("IDENTITY_UNAVAILABLE", 503)));
      req.end(init.body);
    });
  const response = await fetch(url2, {
    ...init,
    redirect: "error",
    signal: AbortSignal.timeout(1e4)
  });
  requireValue(response.ok, "IDENTITY_UNAVAILABLE", 503);
  return response.json();
};
var cookie = (req, name) => (req.headers.cookie ?? "").split(";").map((x) => x.trim()).find((x) => x.startsWith(name + "="))?.slice(name.length + 1);
async function body(req, limit = 16384) {
  const chunks = [];
  let bytes = 0;
  for await (const chunk of req) {
    bytes += chunk.length;
    requireValue(bytes <= limit, "BODY_TOO_LARGE", 413);
    chunks.push(chunk);
  }
  try {
    const data = new TextDecoder("utf-8", { fatal: true }).decode(Buffer.concat(chunks));
    const value2 = JSON.parse(data || "{}");
    requireValue(value2 && typeof value2 === "object" && !Array.isArray(value2), "INVALID_INPUT");
    return value2;
  } catch {
    throw new Problem("INVALID_INPUT");
  }
}
function createIdentityServer(config2) {
  const deployment = deploymentConfig(config2);
  validateBrowserHost(config2.browserHost, deployment);
  requireValue(!config2.browserHost || config2.dataManagement, "BROWSER_DATA_POLICY_REQUIRED", 503);
  const { origin, issuer, sessionCookie, loginCookie, loginPath } = deployment;
  const identityFetch = (url2, init) => jsonFetch(url2, init, deployment.identityCA);
  const store = new IdentityStore(config2.database, issuer, void 0, {
    ...deployment,
    invitedSubjects: config2.invitedSubjects,
    dataManagement: config2.dataManagement
  }), flows = /* @__PURE__ */ new Map();
  const publishing = config2.publishing ? new Publishing(store, { ...config2.publishing, platformRoles: config2.platformRoles }) : null;
  const catalog = publishing && config2.catalog ? new Catalog(publishing) : null;
  requireValue(
    deployment.environment === "production" || catalog || store.get("SELECT max(version) AS version FROM schema_version").version < 3,
    "CATALOG_CONFIGURATION_REQUIRED",
    503
  );
  requireValue(!config2.support || catalog, "SUPPORT_CONFIGURATION_REQUIRED", 503);
  const dataManagement = config2.dataManagement ? new DataManagement(store, config2.dataManagement) : null;
  const support = config2.support ? new Support(publishing) : null;
  const browserHost = config2.browserHost ? new BrowserHost(
    store,
    catalog,
    { ...config2.browserHost, identityDatabase: config2.database },
    deployment.origin
  ) : null;
  requireValue(
    deployment.environment === "production" || support || store.get("SELECT max(version) AS version FROM schema_version").version < 4,
    "SUPPORT_CONFIGURATION_REQUIRED",
    503
  );
  const callback = origin + "/auth/callback";
  function setSession(res, token) {
    res.setHeader(
      "set-cookie",
      `${sessionCookie}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=28800${origin.startsWith("https:") ? "; Secure" : ""}`
    );
  }
  const send = (res, data, status = 200) => {
    res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
    res.end(JSON.stringify(data));
  };
  const redirect = (res, location) => {
    res.writeHead(302, { location });
    res.end();
  };
  async function discovery() {
    const d = await identityFetch(issuer + "/.well-known/openid-configuration");
    requireValue(d.issuer === issuer, "IDENTITY_CONFIGURATION", 503);
    requireValue(
      !deployment.clientSecret || d.token_endpoint_auth_methods_supported?.includes("client_secret_post"),
      "IDENTITY_CONFIGURATION",
      503
    );
    for (const key of ["authorization_endpoint", "token_endpoint", "jwks_uri"])
      requireValue(
        trusted(d[key]).origin === new URL(issuer).origin,
        "IDENTITY_CONFIGURATION",
        503
      );
    return d;
  }
  const handler = async (req, res) => {
    const context = { id: randomUUID9(), stage: "request", code: "OK" };
    res.setHeader("x-request-id", context.id);
    const track = (session, project, stage, release) => {
      context.actor = session.actor;
      context.org = project.kind === "organization" ? project.owner : null;
      context.project = project.id;
      context.stage = stage;
      context.release = release ?? null;
    };
    res.on("finish", () => {
      try {
        support?.record(context, res.statusCode, context.code);
      } catch {
      }
    });
    res.setHeader("cache-control", "no-store");
    res.setHeader("x-content-type-options", "nosniff");
    res.setHeader("referrer-policy", "no-referrer");
    res.setHeader(
      "content-security-policy",
      "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
    );
    try {
      const url2 = new URL(req.url, origin), path2 = url2.pathname;
      requireValue(req.headers.host === new URL(origin).host, "HOST_MISMATCH", 400);
      if (browserHost && ["/browser", "/browser/", "/browser/client.mjs"].includes(path2) && req.method === "GET") {
        const scriptNonce = randomUUID9().replaceAll("-", "");
        res.setHeader(
          "content-security-policy",
          "default-src 'none'; script-src 'self' 'nonce-" + scriptNonce + "'; style-src 'unsafe-inline'; img-src data:; connect-src 'self'; frame-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'"
        );
        const javascript = path2.endsWith(".mjs");
        const contents = await readFile2(
          resolve2(
            config2.browserHost.runtimeDirectory,
            javascript ? "browser-client.mjs" : "browser.html"
          )
        );
        res.setHeader(
          "content-type",
          javascript ? "text/javascript; charset=utf-8" : "text/html; charset=utf-8"
        );
        res.end(
          javascript ? contents : contents.toString("utf8").replaceAll("__SCRIPT_NONCE__", scriptNonce)
        );
        return;
      }
      if (path2 === "/health" && req.method === "GET")
        return send(res, {
          status: "ok",
          version: "0.8.0",
          deploymentEnvironment: deployment.environment,
          documentationUrl: deployment.documentationUrl,
          schema: store.get("SELECT max(version) AS version FROM schema_version").version
        });
      if (path2 === "/auth/login" && req.method === "GET") {
        for (const [id3, f] of flows) if (f.expires < Date.now()) flows.delete(id3);
        requireValue(flows.size < 100, "LOGIN_LIMIT", 429);
        const d = await discovery(), state = secret(), verifier = secret(), nonce = secret(), binding2 = secret();
        flows.set(state, {
          verifier,
          nonce,
          binding: hash(binding2),
          expires: Date.now() + 3e5,
          d
        });
        res.setHeader(
          "set-cookie",
          `${loginCookie}=${binding2}; Path=${loginPath}; HttpOnly; SameSite=Lax; Max-Age=300${origin.startsWith("https:") ? "; Secure" : ""}`
        );
        const authorization = new URL(d.authorization_endpoint);
        authorization.search = new URLSearchParams({
          client_id: config2.clientId,
          redirect_uri: callback,
          response_type: "code",
          scope: "openid profile email",
          state,
          nonce,
          code_challenge: hashPkce(verifier),
          code_challenge_method: "S256",
          prompt: "login"
        }).toString();
        return redirect(res, authorization.href);
      }
      if (path2 === "/auth/callback" && req.method === "GET") {
        const state = url2.searchParams.get("state"), flow = flows.get(state), binding2 = cookie(req, loginCookie);
        requireValue(
          flow && binding2 && flow.binding === hash(binding2) && flow.expires > Date.now() && url2.searchParams.getAll("state").length === 1 && url2.searchParams.getAll("code").length === 1 && !url2.searchParams.has("error"),
          "LOGIN_STATE",
          401
        );
        flows.delete(state);
        const tokens = await identityFetch(flow.d.token_endpoint, {
          method: "POST",
          headers: { "content-type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({
            grant_type: "authorization_code",
            client_id: config2.clientId,
            redirect_uri: callback,
            code: url2.searchParams.get("code"),
            code_verifier: flow.verifier,
            ...deployment.clientSecret ? { client_secret: deployment.clientSecret } : {}
          }).toString()
        });
        const jwks = await identityFetch(flow.d.jwks_uri);
        let payload2;
        try {
          ({ payload: payload2 } = await jwtVerify(tokens.id_token, createLocalJWKSet(jwks), {
            issuer,
            audience: config2.clientId,
            algorithms: ["RS256"],
            requiredClaims: ["sub", "exp", "iat", "nonce"],
            clockTolerance: 5
          }));
        } catch {
          throw new Problem("LOGIN_TOKEN_INVALID", 401);
        }
        requireValue(
          payload2.nonce === flow.nonce && typeof payload2.sub === "string" && payload2.sub.length <= 200 && (!Array.isArray(payload2.aud) || payload2.aud.length === 1 || payload2.azp === config2.clientId),
          "IDENTITY_MISMATCH",
          401
        );
        requireValue(config2.invitedSubjects.includes(payload2.sub), "DEVELOPER_NOT_INVITED", 403);
        const result = store.login(
          payload2.sub,
          text(payload2.name ?? payload2.sub),
          cookie(req, sessionCookie)
        );
        setSession(res, result.token);
        return redirect(res, "/");
      }
      if (path2.startsWith("/v1/")) {
        const directory = path2.match(/^\/v1\/catalog(?:\/([a-f0-9-]+)\/releases\/([a-f0-9-]+))?$/);
        if (catalog && (directory || path2 === "/v1/catalog-trust") && req.method === "GET") {
          let viewer = null;
          if (req.headers.authorization) {
            requireValue(
              req.headers.authorization.startsWith("Bearer ") && req.headers.authorization.length < 200,
              "UNAUTHENTICATED",
              401
            );
            viewer = catalog.tokenSession(req.headers.authorization.slice(7));
          } else if (cookie(req, sessionCookie)) viewer = store.session(cookie(req, sessionCookie));
          if (path2 === "/v1/catalog-trust") return send(res, catalog.trustKeys(viewer));
          const channel = url2.searchParams.get("channel") ?? catalog.channels[0];
          if (directory[1])
            return send(res, catalog.download(viewer, directory[1], directory[2], channel));
          return send(res, {
            items: catalog.list(viewer, channel, url2.searchParams.get("q") ?? "")
          });
        }
        const publishingToken = path2.match(
          /^\/v1\/environments\/(development|test|production)\/projects\/([a-f0-9-]+)\/(submissions)$/
        );
        if (publishing && publishingToken) {
          requireValue(["GET", "POST"].includes(req.method), "NOT_FOUND", 404);
          requireValue(
            req.headers.authorization?.startsWith("Bearer ") && req.headers.authorization.length < 200,
            "UNAUTHENTICATED",
            401
          );
          const s2 = publishing.tokenSession(
            req.headers.authorization.slice(7),
            publishingToken[2],
            publishingToken[1]
          );
          track(
            s2,
            publishing.project(s2, publishingToken[2]),
            req.method === "GET" ? "submission.status" : "submission.validation"
          );
          if (req.method === "GET")
            return send(res, { submissions: publishing.submissions(s2, publishingToken[2]) });
          requireValue(
            req.headers["content-type"]?.startsWith("application/json"),
            "INVALID_INPUT"
          );
          const input2 = await body(req, 2 * 1048576);
          return send(
            res,
            (() => {
              const row = publishing.submit(
                s2,
                publishingToken[2],
                input2,
                req.headers.authorization.slice(7)
              );
              context.release = row.id;
              context.stage = "submission.accepted";
              return row;
            })(),
            201
          );
        }
        if (req.method !== "GET") {
          requireValue(
            req.headers.origin === origin && req.headers["content-type"]?.startsWith("application/json"),
            "CSRF_REJECTED",
            403
          );
        }
        const input = req.method === "GET" ? {} : await body(
          req,
          path2.endsWith("/submissions") ? 2 * 1048576 : path2.startsWith("/v1/browser/") ? 65536 : 16384
        );
        const tokenMatch = path2.match(
          /^\/v1\/environments\/(development|test|production)\/namespaces$/
        );
        if (tokenMatch && req.method === "GET") {
          const authorization = req.headers.authorization;
          requireValue(
            authorization?.startsWith("Bearer ") && authorization.length < 200,
            "UNAUTHENTICATED",
            401
          );
          return send(res, {
            namespaces: store.tokenNamespaces(authorization.slice(7), tokenMatch[1])
          });
        }
        const s = store.session(cookie(req, sessionCookie));
        if (browserHost && path2.startsWith("/v1/browser/")) {
          requireValue(
            (req.headers.origin === origin || !req.headers.origin && req.headers["sec-fetch-site"] === "same-origin") && req.headers["x-csrf-token"] === s.csrf,
            "CSRF_REJECTED",
            403
          );
          const action = path2.slice("/v1/browser/".length);
          requireValue(req.method === (action === "list" ? "GET" : "POST"), "NOT_FOUND", 404);
          return send(res, await browserHost.dispatch(s, action, input));
        }
        if (req.method !== "GET")
          requireValue(input && req.headers["x-csrf-token"] === s.csrf, "CSRF_REJECTED", 403);
        if (dataManagement && path2 === "/v1/data/export" && req.method === "GET")
          return send(res, dataManagement.export(s));
        if (dataManagement && path2 === "/v1/data/deletion-preview" && req.method === "POST")
          return send(res, dataManagement.preview(s));
        if (dataManagement && path2 === "/v1/data/delete" && req.method === "POST")
          return send(res, dataManagement.apply(s, input));
        if (path2 === "/v1/session" && req.method === "GET")
          return send(res, {
            ...store.snapshot(s),
            deploymentEnvironment: deployment.environment,
            publishing: Boolean(publishing),
            catalog: Boolean(catalog),
            support: Boolean(support),
            dataManagement: Boolean(dataManagement),
            browserHost: Boolean(browserHost),
            platformRoles: config2.platformRoles?.[store.snapshot(s).actor.sub] ?? []
          });
        if (support) {
          const route2 = path2.match(
            /^\/v1\/projects\/([a-f0-9-]+)\/(diagnostics|feedback)(?:\/([a-f0-9-]+))?$/
          );
          if (route2) {
            const [, project, kind, id3] = route2;
            track(s, publishing.project(s, project), "support." + kind);
            if (kind === "diagnostics" && req.method === "GET" && !id3)
              return send(
                res,
                support.diagnostics(s, project, {
                  requestId: url2.searchParams.get("requestId"),
                  release: url2.searchParams.get("release")
                })
              );
            if (kind === "feedback") {
              if (req.method === "GET")
                return send(res, id3 ? support.detail(s, project, id3) : support.list(s, project));
              if (req.method === "POST" && !id3)
                return send(res, support.create(s, project, input), 201);
              if (req.method === "PATCH" && id3)
                return send(res, support.update(s, project, id3, input));
            }
          }
        }
        if (catalog) {
          if (path2 === "/v1/catalog-trust" && req.method === "GET")
            return send(res, catalog.trustKeys(s));
          if (path2 === "/v1/catalog-credentials" && req.method === "GET")
            return send(res, { credentials: catalog.credentials(s) });
          const revoke = path2.match(/^\/v1\/catalog-credentials\/([a-f0-9-]+)$/);
          if (revoke && req.method === "DELETE") return send(res, catalog.revoke(s, revoke[1]));
          if (path2 === "/v1/catalog-credentials" && req.method === "POST")
            return send(res, catalog.credential(s), 201);
          const settings = path2.match(/^\/v1\/projects\/([a-f0-9-]+)\/catalog-settings$/);
          if (settings && req.method === "GET") return send(res, catalog.settings(s, settings[1]));
          const projectCatalog = path2.match(
            /^\/v1\/projects\/([a-f0-9-]+)\/(visibility|channels|withdraw|rollout)$/
          );
          if (projectCatalog && req.method === "POST") {
            const [, project, action] = projectCatalog;
            if (action === "visibility")
              return send(res, catalog.configureVisibility(s, project, input.visibility));
            if (action === "channels") return send(res, catalog.promote(s, project, input));
            if (action === "withdraw")
              return send(res, catalog.withdraw(s, project, input.release, input.reason));
            if (action === "rollout")
              return send(res, catalog.optOut(s, project, input.channel, input.enabled));
          }
        }
        if (publishing?.signingKeys && path2 === "/v1/signing-keys") {
          publishing.platform(s, "key-manager");
          if (req.method === "GET")
            return send(res, {
              keys: publishing.signingKeys.list(),
              audit: store.all(
                "SELECT at,actor,action,target FROM audit WHERE action LIKE 'signing-key.%' ORDER BY id DESC LIMIT 100"
              )
            });
        }
        const signingAction = path2.match(/^\/v1\/signing-keys\/([a-zA-Z0-9._-]+)$/);
        if (publishing?.signingKeys && signingAction && req.method === "POST")
          return send(res, publishing.signingKeys.change(s, signingAction[1], input));
        if (publishing) {
          if (path2 === "/v1/projects") {
            if (req.method === "GET") return send(res, { projects: publishing.list(s) });
            if (req.method === "POST") return send(res, publishing.create(s, input), 201);
          }
          const projectRoute = path2.match(
            /^\/v1\/projects\/([a-f0-9-]+)\/(submissions|publishing-credentials)(?:\/([a-f0-9-]+))?$/
          );
          if (projectRoute) {
            const [, id3, kind, credential] = projectRoute;
            track(
              s,
              publishing.project(s, id3),
              kind === "submissions" ? "submission.validation" : "credential.operation"
            );
            if (kind === "publishing-credentials" && req.method === "GET" && !credential)
              return send(res, { credentials: publishing.credentials(s, id3) });
            if (kind === "submissions" && req.method === "GET")
              return send(res, { submissions: publishing.submissions(s, id3) });
            if (kind === "submissions" && req.method === "POST")
              return send(
                res,
                (() => {
                  const row = publishing.submit(s, id3, input);
                  context.release = row.id;
                  context.stage = "submission.accepted";
                  return row;
                })(),
                201
              );
            if (kind === "publishing-credentials" && req.method === "POST" && !credential)
              return send(res, publishing.credential(s, id3), 201);
            if (kind === "publishing-credentials" && req.method === "DELETE" && credential)
              return send(res, publishing.revokeCredential(s, id3, credential));
          }
          if (path2 === "/v1/review-queue" && req.method === "GET")
            return send(res, { submissions: publishing.queue(s) });
          if (path2 === "/v1/publication-queue" && req.method === "GET")
            return send(res, { submissions: publishing.publicationQueue(s) });
          const artifact = path2.match(/^\/v1\/submissions\/([a-f0-9-]+)\/artifact$/);
          if (artifact && req.method === "GET")
            return send(res, publishing.artifact(s, artifact[1]));
          const action = path2.match(/^\/v1\/submissions\/([a-f0-9-]+)\/(review|publish)$/);
          if (action && req.method === "POST") {
            publishing.platform(s, action[2] === "review" ? "reviewer" : "publisher");
            const row = store.get("SELECT * FROM submissions WHERE id=?", action[1]);
            if (row)
              track(
                s,
                store.get("SELECT * FROM projects WHERE id=?", row.project),
                "submission." + action[2],
                row.id
              );
            return send(
              res,
              action[2] === "review" ? publishing.review(s, action[1], input) : publishing.publish(s, action[1], input)
            );
          }
        }
        if (path2 === "/v1/logout" && req.method === "POST") {
          store.logout(s);
          setSession(res, "");
          return send(res, { signedOut: true });
        }
        if (path2 === "/v1/scope" && req.method === "POST") {
          const result = store.switchScope(s, input.organization ?? null);
          setSession(res, result.token);
          return send(res, { csrf: result.csrf });
        }
        if (path2 === "/v1/organizations" && req.method === "POST") {
          const result = store.createOrganization(s, input.name);
          setSession(res, result.token);
          return send(res, { id: result.id, csrf: result.csrf }, 201);
        }
        if (path2 === "/v1/namespaces") {
          if (req.method === "GET") return send(res, { namespaces: store.namespaces(s) });
          if (req.method === "POST") return send(res, store.createNamespace(s, input.name), 201);
        }
        const accept = path2.match(/^\/v1\/invitations\/([a-f0-9-]+)\/accept$/);
        if (accept && req.method === "POST") return send(res, store.accept(s, accept[1]));
        const route = path2.match(
          /^\/v1\/organizations\/([a-f0-9-]+)\/(members|invitations|credentials|audit)(?:\/([a-f0-9-]+))?$/
        );
        if (route) {
          const [, org, kind, id3] = route;
          if (kind === "members" && req.method === "GET" && !id3)
            return send(res, { members: store.listMembers(s, org) });
          if (kind === "members" && id3 && req.method === "PATCH")
            return send(res, store.changeMember(s, org, id3, input.role));
          if (kind === "members" && id3 && req.method === "DELETE")
            return send(res, store.changeMember(s, org, id3, null));
          if (kind === "invitations" && req.method === "POST" && !id3)
            return send(
              res,
              store.invite(s, org, input.target, input.role, input.hours ?? 24),
              201
            );
          if (kind === "credentials" && req.method === "GET" && !id3)
            return send(res, { credentials: store.credentials(s, org) });
          if (kind === "credentials" && req.method === "POST" && !id3)
            return send(res, store.createCredential(s, org, input.name, input.environment), 201);
          if (kind === "credentials" && req.method === "DELETE" && id3)
            return send(res, store.revokeCredential(s, org, id3));
          if (kind === "audit" && req.method === "GET")
            return send(res, { audit: store.audit(s, org) });
        }
        throw new Problem("NOT_FOUND", 404);
      }
      requireValue(req.method === "GET", "NOT_FOUND", 404);
      const files = { "/": "index.html", "/app.js": "app.js", "/app.css": "app.css" };
      requireValue(files[path2], "NOT_FOUND", 404);
      const content = await readFile2(resolve2(config2.webRoot, files[path2]));
      res.writeHead(200, {
        "content-type": path2.endsWith(".js") ? "text/javascript" : path2.endsWith(".css") ? "text/css" : "text/html; charset=utf-8"
      });
      res.end(content);
    } catch (error3) {
      const problem = error3 instanceof Problem ? error3 : error3.browserHostProblem ? new Problem(error3.code, error3.status) : new Problem("SERVICE_UNAVAILABLE", 503);
      context.code = problem.code;
      if (!res.headersSent)
        send(res, { error: { code: problem.code, requestId: context.id } }, problem.status);
      else res.end();
    }
  };
  const server2 = deployment.tls ? createHttpsServer(deployment.tls, handler) : createServer(handler);
  server2.on("close", () => {
    void browserHost?.close();
    store.close();
  });
  return {
    server: server2,
    store,
    dataManagement,
    browserHost,
    close: async () => {
      await new Promise((yes) => server2.close(yes));
      await browserHost?.close();
    }
  };
}
function hashPkce(value2) {
  return createHash8("sha256").update(value2).digest("base64url");
}

// server/src/main.mjs
var file = process.env.SITOO_CENTER_CONFIG;
if (!file) throw Error("\u8BF7\u8BBE\u7F6ESITOO_CENTER_CONFIG\uFF0C\u4F7F\u7528\u5DF2\u767B\u8BB0\u7684OIDC\u5BA2\u6237\u7AEF\u4E0E\u9080\u8BF7\u540D\u5355");
var config = JSON.parse(await readFile3(file, "utf8"));
config.database = resolve3(config.database);
config.webRoot = resolve3(config.webRoot ?? "apps/admin-web/dist");
var { server } = createIdentityServer(config);
var url = new URL(config.origin);
server.listen(
  Number(url.port || 443),
  "127.0.0.1",
  () => console.log(`OpenSitoo\u5F00\u53D1\u8005\u4E2D\u5FC3 ${url.origin}`)
);
for (const signal of ["SIGTERM", "SIGINT"]) process.on(signal, () => server.close());
