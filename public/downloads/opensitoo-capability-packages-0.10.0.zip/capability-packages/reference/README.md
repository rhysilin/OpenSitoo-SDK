# 三个独立发布者的目录包样例

用于 E2-01 包格式与解析验收，非正式签名分发/可安装应用。alice 发布文本能力，bob/carol 发布无 UI 的消费能力包，共享 alice/text。调用时 grants 与精确绑定仍由可信宿主设置。

构建 `node scripts/capability-packages.mjs` 后，可复制整个样例目录和工具目录到仓库外，在 Node 24 下执行：

```powershell
node C:/dev/tool/capability-packages.mjs plan C:/dev/reference/requirements.json C:/dev/reference/alice-text C:/dev/reference/bob-consumer C:/dev/reference/carol-consumer
```

文件格式、预算、摘要和后续边界见[包手册](../README.md)。编辑源码须同步文件 bytes/sha256，再重新解析；不能直接覆盖生产绑定或重提已有任务。消费包函数体需要 input.text 与 input.childRequestId，Guest 不接宿主身份或凭据。
