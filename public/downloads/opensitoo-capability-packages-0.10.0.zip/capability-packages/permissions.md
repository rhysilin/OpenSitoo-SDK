# 能力更新权限预检

日期：2026-10-08。维护中，适用 capability-packages / 包工具 0.8.0；安装库仍是 schema 3。E2-05 第二批的可信 Node 管理辅助接口，不是消费应用 API、签名批准票据或完整授权管理服务。证据见E2-05 权限预检。

## 流程与职责

在[生命周期](./lifecycle.md)的 update-prepare 之后，可信宿主用当前安装根、原请求 ID、选定入口和经过宿主审批的 grants 发起 reviewUpdate。预检对完整依赖闭包汇总权限，输出 required / added / removed / missing，并列出不支持该入口的所有能力。不同能力重复权限去重并排序；检查是保守的整闭包检查，不只检查应用直接调用的能力。根代数、精确计划、可信来源和当前权限/入口策略共同绑定至 reviewSha256。

缺少权限或入口不兼容时，review 仍成功返回可展示的结果，但 commitAuthorizedUpdate 返回 FORBIDDEN。改动策略或提交与 review 不一致的指纹返回 CONFLICT；原根和 prepared 请求保留。正确提交也必须通过原生命周期的配额、内容、当前签名、根代数和活动租约检查。预检不执行代码，不收费，不发起模型调用。

reviewSha256 只是内容一致性指纹，不能当作发布者签名、用户同意或授权凭据。消费应用不能提供管理 policy；它只能通过宿主原有确认流程申请权限。当前开发宿主 v1/v2 的执行授权仍由可信配置签发；v3 从[持久授权账本](./authorizations.md)读取，预检/提交不会自动写入配置、创建 session、扩大 grants 或改变运行中会话。独立账本与 v3 运行前撤销门禁已实现；产品内授权确认、生产授权服务与自动授权迁移仍待后续，不能把本接口当作已经实现的产品流程。

原 commit 保持可信存储层兼容，不新增隐式授权规则；宿主选择带检查的 commitAuthorizedUpdate 时才执行本批授权前置检查。必须将这两层职责区分，不应暴露原 commit 给消费应用。代码版本升级不等于新增权限获批。包声明的 billable/externalWrite、委托关系及每次任务的审批继续由 Broker/任务服务处理；本接口只检查权限字符串和入口，不审核这些副作用或任意业务行为。

## 方法与字段

```ts
type CapabilityUpdatePolicy = Pick<CapabilityCallerPolicy, 'entry' | 'grants'>;
reviewUpdate(requestId, policy, releases, trust, (now = Date.now()));
commitAuthorizedUpdate(requestId, policy, reviewSha256, releases, trust, (now = Date.now()));
```

reviewUpdate 返回 `ProtocolValidation<CapabilityUpdateReview>`；commitAuthorizedUpdate 返回 `ProtocolValidation<CapabilityInstallationTransaction>`。policy 严格只有 entry/grants，沿用 Broker 的实际入口与权限校验、64 项 grants 上限、禁止重复和非法通配字符串；不接受调用者身份或 bindings。返回结果冻结，不传送源码、配置或密钥。

| review 字段                | 含义                                                                    |
| -------------------------- | ----------------------------------------------------------------------- |
| requestId / generation     | 根内原请求及当前代数，只接受 prepared update                            |
| plan                       | 完整精确目标闭包，与原 prepared 计划一致                                |
| policy                     | 原入口与排序后 grants，排序变化不影响指纹                               |
| required / added / removed | 目标权限集合及相对当前根声明的新增/移除，不是相对账号全部已有授权的变化 |
| missing                    | 目标 required 中没有被提供 grants 覆盖的权限                            |
| unsupportedEntries         | 目标闭包中不支持该 entry 的 capabilityId                                |
| reviewSha256               | 绑定以上所有字段的 SHA-256 一致性指纹                                   |

review 和带检查 commit 都重新验证旧安装根与新完整发布引用的当前信任；旧代码撤销/过期也会拒绝此预检。它不能作为从失信根升级的恢复旁路，此类管理恢复需另按可信存储与安全恢复流程处理。其他账号/根无法查原请求。aborted、初装、卸载、代数变化或已提交请求不能重新 review；用原 status 查询已提交收据。

commitAuthorizedUpdate 在同一个安装库写事务内重新 review、比较指纹并切换根，没有“先检查后另外写入”的竞争窗口。已有 committed 更新重试仅返回历史收据，不再次执行授权检查或切换；收据不表示当前授权有效。未知任务/活动租约仍阻止提交，不因持有 reviewSha256 而释放。

## 可搬运 CLI

```text
update-review <installation.sqlite> <root.json> <requestId> <policy.json> <releases.sqlite> <trust.json>
update-commit-authorized <installation.sqlite> <root.json> <requestId> <approval.json> <releases.sqlite> <trust.json>
```

使用 node capability-packages.mjs 执行。两库文件必须存在，root、信任、输入文件预算与原 CLI 相同。policy.json 是严格的 `{ "entry": "conversation", "grants": ["text:read"] }`；approval.json 严格包含 policy 和 reviewSha256 两字段。后者是可信操作者提交已审查策略的输入文件，不是供消费应用自行生成的同意票据。修改 grants 后必须重新 review，不能沿用旧指纹。

按生命周期先停止旧宿主，在提交后显式修改可信配置（v2）或精确 bindings 的授权记录（v3），并重新启动，运行权限仍按 Broker 校验。新代码需要 text:read、配置仍是空 grants 时，真实运行仍被拒绝；通过操作者配置该授权后才可执行。没有自动配置更新或运行中热授权切换。

此版本未改变安装 schema、协议、SDK、Desktop 或任务库格式；0.5.0 旧工具仍能读取 schema 3，但没有新预检方法。工具回退不提供这些前置检查，不能暗示旧工具具备相同门禁。0.7.0 已提供[独立 JSON 数据迁移/回退](./data.md)，与本预检及原存储 commit 分开管理；产品数据迁移仍未接入。

[生命周期手册](./lifecycle.md) · [执行与租约](./execution.md) · API 参考 · E2-05 权限预检证据

返回文档总目录 · 当前状态

[持久授权与运行门禁](./authorizations.md)（包工具 0.8.0、开发宿主 0.4.0；可信管理与 opt-in v3）。
