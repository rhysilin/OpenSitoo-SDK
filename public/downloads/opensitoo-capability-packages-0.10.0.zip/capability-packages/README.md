# 独立能力包与依赖规划

0.12.0新增host-service-v1签名宿主服务声明包，规则见服务手册，验证见第二十三批。原quickjs/static格式和数据库schema不变；旧版解析器拒绝新execution，不自动升级。

维护日期：2026-10-09。`@sitoo/capability-packages@0.12.0` 为 private Node 24 工作区模块，工具可搬运到仓库外。没有 Pi、Desktop、Electron 或应用专用接线；不是原静态应用包格式，也不是浏览器 SDK 或正式公共 REST。

## 本批范围与兼容

E2-01 定义目录包格式 1 与可重复解析计划。不修改 SDK 0.0.8、Desktop 0.0.8、设计工作室 0.4.4 或用户数据。原 static-platform 分发继续使用原格式，不能直接安装新能力包。本页介绍内容校验与 unsigned 开发规划；0.2.0 新增[独立署名、可信来源与离线发布](./signatures.md)。0.3.0 新增[安装事务、恢复与安装根引用](./installations.md)。联网目录、产品授权接入、自动更新健康批准、现有产品数据迁移或生产执行开放仍未实现；0.4.0 新增的[已安装运行与任务租约](./execution.md)已提供独立宿主编译门禁和持久版本保护。

摘要与来源信任分别处理：文件摘要验证原字节；包摘要为规范化 manifest（对象 key 按字符序排序，数组顺序保留）的 UTF-8 SHA-256，覆盖全部声明及文件摘要。空白或对象 key 顺序不改变身份，声明/文件变化改变身份。摘要不是签名、命名空间归属或内容安全证明。可信署名封装已可验证该精确身份；生产根密钥及安全分发仍待验收，不应信任开发目录包自行声明的身份。

## 目录包格式

根文件 `capability-package.json` 在 quickjs-function-v1 能力类型只允许以下字段；0.9.0 新增独立应用类型及 application 字段，完整规则见[应用发布物手册](./applications.md)。两类分别发布，内容校验/签名/安装方法相同。

| 字段                | 值与约束                                                                                                                                                              |
| ------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| formatVersion       | 1                                                                                                                                                                     |
| execution           | quickjs-function-v1；只有函数体，无任意 Node、native 或网络入口                                                                                                       |
| packageId / version | namespace/name；精确规范 semver，不能用 v 前缀、范围或最新版                                                                                                          |
| dependencies        | `{packageId,range}[]`；非空有效 semver range，同包不可重复或自依赖                                                                                                    |
| capabilities        | `{capabilityId,source,interfaceVersion,inputSchema,outputSchema,permissions,allowedEntries,delegates,effects}[]`；使用 Broker 当前真实声明，去掉 binding，增加 source |
| files               | `{path,bytes,sha256}[]`；每个原始 UTF-8 源文件的长度与小写 SHA-256                                                                                                    |

能力 ID 与包同 namespace。所有源文件必须被声明使用，不允许额外 payload、重复能力、不同大小写别名、路径穿越、绝对路径、Windows 设备名或非 `.guest` 文件。source 为异步函数体，仍由现有受限 Runtime 执行；只检查 Broker 声明，不执行源码。UTF-8 BOM 保留用于原字节摘要，非法 UTF-8 拒绝。

预算：manifest 65536 字节（还受协议 JSON 深度 32/节点 8192/请求 envelope 64 KiB 约束）；1–16 个源文件，每个 1–65536 字节，总计最多 1 MiB；1–16 个能力、最多 32 个依赖。目录读入最多遍历 64 个条目/16 层，不读设备文件、不允许链接，未声明文件拒绝。读取前后尺寸受限，但不是抵御恶意并发修改文件系统的 OS 沙盒；安装时须从已验签的不可变暂存区重新核验。schema 编译沿用可信 Broker/Ajv，恶意 schema 的 CPU/正则隔离和生产审核待专项门禁。

## 真实宿主接口

| 方法                                                                                       | 返回                                                                                                                         |
| ------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------- |
| verifyCapabilityPackage(manifestJson:string, files:ReadonlyMap<string,Uint8Array>)         | 同步 `ProtocolValidation<VerifiedCapabilityPackage>`；运行时要求 Map，校验后保存冻结的 manifest/sources/bindings/sha256 快照 |
| readCapabilityPackage(directory:string)                                                    | 异步相同结果；读取目录并调用内容校验，错误不返回本机路径或原异常                                                             |
| resolveCapabilityDependencies(roots:unknown, catalog:readonly VerifiedCapabilityPackage[]) | 同步 `ProtocolValidation<CapabilityDependencyPlan>`；仅接本模块实例签发的已校验对象，不能把反序列化对象当可信 catalog        |

PackageRequirement 为 `{packageId:string,range:string}`。roots 为 1–32 个不重复需求；catalog 最多 128 个版本。包内同 packageId/version 不允许多个内容摘要，完全相同项合并。注册前宿主还须核验签名和来源、再建立 session；Verified 对象不是授权凭证。

解析采用确定的包名顺序及版本优先顺序，优先满足条件的高版本，约束冲突时回溯；预发布遵循 semver 的显式范围规则。全部传递依赖满足后输出依赖先于消费者的 packages，及对应精确 bindings。循环、缺包、无可满足版本、能力 ID 多重所有者或 delegate 不在本包/声明依赖闭包中拒绝。最多探索 2048 个状态，超额 LIMIT_EXCEEDED，绝不返回半份计划。

计划为 `{formatVersion:1,roots,packages:[{packageId,version,sha256}],bindings}`，冻结快照可保存为 JSON。此批没有已持久锁的加载/重验接口；不能把保存 JSON 直接作为新的 Verified catalog。单个安装计划一个包/能力只选一版；不同应用可以使用独立计划保留不同版本，真正并存安装与在途任务绑定由后续实现。解析不使用调用者 grants，也不自动扩大权限。

失败为 `{ok:false,error:{code,message}}`：格式/源码/schema/伪造校验对象 INVALID_INPUT，依赖不可满足/循环/同版本不同摘要 CONFLICT，目录/搜索超额 LIMIT_EXCEEDED。缺包属于不可满足约束。合法计划不承诺对应能力已经安装或能够调用。

## 可搬运工具

[三发布者样例](./reference/README.md)随工具放入 reference/，包含 alice/text 与 bob/carol 两个无 UI 消费包；这是协议参考，不是已经接入 Desktop 的独立 UI 应用。模块测试实际通过 WASM 执行两条委托链并保持各自身份。

仓库内 `node scripts/capability-packages.mjs` 构建 `release/capability-packages/`，包含自足 CLI、文档和依赖许可证；复制整个目录到仓库外，在 Node 24 下使用：

```powershell
node capability-packages.mjs inspect C:/dev/text-package
node capability-packages.mjs plan C:/dev/requirements.json C:/dev/text-package C:/dev/poster-package
```

requirements.json 示例：`[{"packageId":"bob/app","range":"^1.0.0"}]`。inspect 只输出身份、依赖和绑定，不输出源码；plan 输出完整精确计划，不安装或改配置。退出码 0 表示校验/解析成功，1 表示失败。`node scripts/verify-capability-packages.mjs` 在系统临时目录实际运行工具及三个发布者的目录包，不借用平台源码、NODE_PATH 或 node_modules。

交付与后续门禁见 E2-01（记录维护在平台文档站）。

返回文档总目录 · 当前状态 · 对应交付记录

[更新、卸载与代码回收](./lifecycle.md)：安装库当前 schema 3；维护流程、活动任务限制及迁移兼容性见此页。

0.7.0 新增[独立 JSON 数据迁移与回退](./data.md)，不自动转换既有 SDK/产品数据。

[持久授权与运行门禁](./authorizations.md)（包工具 0.8.0、开发宿主 0.4.0；可信管理与 opt-in v3）。
