// packages/app-sdk/src/client-contract.ts
var AppSdkError = class extends Error {
  code;
  retryable;
  action;
  constructor(details) {
    super(details.message);
    this.name = "AppSdkError";
    this.code = details.code;
    this.retryable = details.retryable;
    this.action = details.action;
  }
};
function appErrorDetails(error) {
  const code = error && typeof error === "object" && "code" in error ? String(error.code) : "";
  const known = {
    STALE_CONFIGURATION: {
      code,
      message: "\u914D\u7F6E\u5DF2\u66F4\u65B0\uFF0C\u8BF7\u91CD\u65B0\u8BFB\u53D6\u540E\u5408\u5E76\u4FEE\u6539\u3002",
      retryable: false,
      action: "resolve-conflict"
    },
    SESSION_CHANGED: {
      code,
      message: "\u5E94\u7528\u4F1A\u8BDD\u5DF2\u5931\u6548\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u5E94\u7528\u3002",
      retryable: false,
      action: "reload"
    },
    LOGIN_REQUIRED: { code, message: "\u8BF7\u5148\u767B\u5F55\u8D26\u6237\u3002", retryable: false, action: "login" },
    REVISION_CONFLICT: {
      code,
      message: "\u6570\u636E\u5DF2\u66F4\u65B0\uFF0C\u8BF7\u91CD\u65B0\u8BFB\u53D6\u540E\u5408\u5E76\u4FEE\u6539\u3002",
      retryable: false,
      action: "resolve-conflict"
    },
    INVALID_DATA: {
      code,
      message: "\u6570\u636E\u53C2\u6570\u3001\u7248\u672C\u6216\u5C3A\u5BF8\u4E0D\u5408\u89C4\u3002",
      retryable: false,
      action: "none"
    },
    STORAGE_LIMIT: { code, message: "\u5E94\u7528\u5B58\u50A8\u5DF2\u8FBE\u5230\u5BB9\u91CF\u4E0A\u9650\u3002", retryable: false, action: "none" },
    STORAGE_FAILED: {
      code,
      message: "\u5E94\u7528\u6570\u636E\u8BFB\u53D6\u6216\u4FDD\u5B58\u5931\u8D25\uFF0C\u8BF7\u4FDD\u7559\u5F53\u524D\u8349\u7A3F\u3002",
      retryable: false,
      action: "none"
    },
    DISPOSED: { code, message: "\u5E94\u7528\u5BA2\u6237\u7AEF\u5DF2\u5173\u95ED\u3002", retryable: false, action: "reload" },
    TIMEOUT: {
      code,
      message: "\u8C03\u7528\u8D85\u65F6\uFF0C\u7ED3\u679C\u53EF\u80FD\u4E0D\u786E\u5B9A\uFF1B\u8BF7\u67E5\u8BE2\u539F\u4EFB\u52A1\uFF0C\u4E0D\u8981\u81EA\u52A8\u91CD\u65B0\u63D0\u4EA4\u4ED8\u8D39\u64CD\u4F5C\u3002",
      retryable: false,
      action: "query-task"
    },
    BUSY: { code, message: "\u5E76\u53D1\u8C03\u7528\u8FC7\u591A\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5\u67E5\u8BE2\u3002", retryable: true, action: "none" },
    APP_TASKS_ACTIVE: {
      code,
      message: "\u5E94\u7528\u4ECD\u6709\u672A\u5B8C\u6210\u7684\u5E73\u53F0\u8C03\u7528\u6216\u4EFB\u52A1\uFF0C\u8BF7\u7B49\u5F85\u7ED3\u675F\u540E\u518D\u5347\u7EA7\u6216\u5378\u8F7D\u3002",
      retryable: true,
      action: "query-task"
    },
    MODEL_UNAVAILABLE: {
      code,
      message: "\u6240\u9009\u5E73\u53F0\u6A21\u578B\u672A\u542F\u7528\u6216\u4E0D\u53EF\u7528\uFF0C\u8BF7\u5728\u8BBE\u7F6E\u4E2D\u68C0\u67E5\u540E\u91CD\u65B0\u9009\u62E9\u3002",
      retryable: false,
      action: "none"
    },
    REQUEST_CONFLICT: {
      code,
      message: "\u8BF7\u6C42 ID \u5BF9\u5E94\u7684\u53C2\u6570\u6216\u5E94\u7528\u7248\u672C\u5DF2\u53D8\u5316\uFF0C\u8BF7\u67E5\u8BE2\u539F\u4EFB\u52A1\uFF1B\u65B0\u4EFB\u52A1\u9700\u8981\u65B0\u7684\u8BF7\u6C42 ID\u3002",
      retryable: false,
      action: "query-task"
    },
    CANCELLED: {
      code,
      message: "\u5DF2\u53D6\u6D88\u672C\u6B21\u670D\u52A1\u8C03\u7528\u3002",
      retryable: false,
      action: "none"
    },
    RESULT_UNKNOWN: {
      code,
      message: "\u539F\u8BF7\u6C42\u7ED3\u679C\u5C1A\u65E0\u6CD5\u786E\u8BA4\uFF0C\u8BF7\u67E5\u8BE2\u539F\u4EFB\u52A1\uFF0C\u4E0D\u8981\u91CD\u65B0\u63D0\u4EA4\u4ED8\u8D39\u64CD\u4F5C\u3002",
      retryable: false,
      action: "query-task"
    },
    FORBIDDEN: { code, message: "\u5E94\u7528\u6CA1\u6709\u8C03\u7528\u6B64\u80FD\u529B\u7684\u6743\u9650\u3002", retryable: false, action: "none" },
    UNSUPPORTED_OPERATION: {
      code,
      message: "\u5F53\u524D\u5BBF\u4E3B\u4E0D\u652F\u6301\u6B64\u64CD\u4F5C\u3002",
      retryable: false,
      action: "none"
    }
  };
  return (Object.hasOwn(known, code) ? known[code] : void 0) ?? {
    code: /^[A-Z][A-Z0-9_]{0,63}$/.test(code) ? code : "OPERATION_FAILED",
    message: "\u64CD\u4F5C\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u5E73\u53F0\u72B6\u6001\uFF1B\u4ED8\u8D39\u8BF7\u6C42\u5E94\u5148\u67E5\u8BE2\u539F\u4EFB\u52A1\u3002",
    retryable: false,
    action: "query-task"
  };
}

// packages/app-sdk/src/ui.ts
function createAppClient() {
  let disposed = false;
  const watchers = /* @__PURE__ */ new Set();
  const pending = /* @__PURE__ */ new Map();
  const listener = (event) => {
    if (event.source !== window.parent || event.data?.protocol !== "sitoo-app-v1") return;
    const item = pending.get(event.data.id);
    if (!item) return;
    clearTimeout(item.timer);
    pending.delete(event.data.id);
    if (event.data.ok) item.resolve(event.data.value);
    else {
      const details = appErrorDetails(event.data.error);
      item.reject(new AppSdkError(details));
    }
  };
  window.addEventListener("message", listener);
  const request = (method, fields) => {
    if (disposed) return Promise.reject(new AppSdkError(appErrorDetails({ code: "DISPOSED" })));
    const id = crypto.randomUUID();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new AppSdkError(appErrorDetails({ code: "TIMEOUT" })));
      }, 12e4);
      pending.set(id, { resolve: (value) => resolve(value), reject, timer });
      try {
        window.parent.postMessage({ protocol: "sitoo-app-v1", id, method, ...fields }, "*");
      } catch {
        clearTimeout(timer);
        pending.delete(id);
        reject(new AppSdkError(appErrorDetails({ code: "INVALID_DATA" })));
      }
    });
  };
  return {
    platform: {
      getCapabilities: () => request(
        "platform-capabilities",
        {}
      )
    },
    storage: {
      get: (id) => request("storage-get", {
        recordId: id
      }),
      list: (query = {}) => request("storage-list", { query }),
      put: (write) => request("storage-put", { write }),
      delete: (id, revision) => request("storage-delete", {
        recordId: id,
        revision
      })
    },
    invoke(capability, parameters, requestId = crypto.randomUUID()) {
      return request("invoke", { capability, parameters, requestId });
    },
    attachments: {
      uploadImages: (images) => request("attachment-upload", { images }),
      importImages: () => request("attachment-import", {}),
      get: (attachmentId) => request("attachment-get", { attachmentId })
    },
    agent: {
      dictation: {
        getState: () => request("agent-dictation-state", {}),
        start: () => request("agent-dictation-start", {}),
        stop: () => request("agent-dictation-stop", {})
      },
      open: (configuration) => request("agent-open", { input: configuration }),
      getState: () => request("agent-state", {}),
      send: (input) => request("agent-send", { input }),
      stop: () => request("agent-stop", {}),
      reset: () => request("agent-reset", {})
    },
    text: {
      listModels: () => request("text-models", {}),
      getTask: (taskId) => request("text-task", { taskId }),
      listTasks: () => request("text-tasks", {})
    },
    images: {
      listTasks: () => request("image-tasks", {}),
      getCapabilities: () => request("image-capabilities", {}),
      getTask: (taskId) => request("image-task", { taskId }),
      getArtifact: (taskId) => request("image-artifact", { taskId }),
      /** Polls one durable task; never generates or resubmits an image. */
      watchTask(taskId, onTask, onError) {
        let active = true;
        let timer;
        const deadline = Date.now() + 6e5;
        const cancel = () => {
          active = false;
          clearTimeout(timer);
          watchers.delete(cancel);
        };
        const poll = async () => {
          try {
            const task = await request("image-task", {
              taskId
            });
            if (!active) return;
            onTask(task);
            if (["completed", "failed", "cancelled"].includes(task.status) || task.status === "unknown" && !task.gatewayTaskId) {
              cancel();
              return;
            }
            if (Date.now() >= deadline)
              throw new Error("\u7B49\u5F85\u8D85\u65F6\uFF0C\u540E\u53F0\u4EFB\u52A1\u53EF\u80FD\u4ECD\u5728\u8FD0\u884C\uFF0C\u8BF7\u67E5\u8BE2\u539F\u4EFB\u52A1\u3002");
            timer = setTimeout(poll, 2e3);
          } catch (error) {
            if (active) {
              cancel();
              onError?.(error instanceof Error ? error : new Error("\u67E5\u8BE2\u5931\u8D25\u3002"));
            }
          }
        };
        watchers.add(cancel);
        void poll();
        return cancel;
      }
    },
    resources: {
      list: () => request("resource-packs", {}),
      read: (packId, resourceId) => request(
        "resource-read",
        { packId, resourceId }
      )
    },
    configuration: {
      get: () => request("configuration-get", {}),
      save: (revision, values) => request("configuration-save", { revision, values })
    },
    dispose() {
      disposed = true;
      for (const cancel of watchers) cancel();
      window.removeEventListener("message", listener);
      for (const item of pending.values()) {
        clearTimeout(item.timer);
        item.reject(new Error("\u5E94\u7528\u5DF2\u5173\u95ED\u3002"));
      }
      pending.clear();
    }
  };
}
export {
  AppSdkError,
  appErrorDetails,
  createAppClient
};
