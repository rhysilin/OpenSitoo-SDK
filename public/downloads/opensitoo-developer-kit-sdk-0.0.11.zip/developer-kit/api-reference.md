# Sitoo API 参考手册

E3-R06公开分发与独立多应用验证；SDK0.0.11及现有API契约保持，本轮新增开发工具分发与CI，不新增应用管理权限。

E3-R04新增独立开发宿主GET `/v1/tasks/<taskId>/artifact`，消费Bearer和已有页面/对话pin，已完成原platform/generate-image任务及当前resource:read/安装授权验证前后复核；成功ProtocolValidation<{mimeType:image/png,dataUrl}>，最大16MiB图片，失败脱敏。它是本机开发服务端口，不是生产REST。SDK0.0.10可选artifact(taskId)读取同一端口，原四方法保持；可信taskArtifact、createImageService、imageCapabilityDeclaration不是应用公共管理API。私有issue-reference kind增加image，使用当前已明确开启的图片配置，不接受app配置。SitooImageService.generate第四trusted approved参数复用原明确批准并在转发前authorize，原AppImages接口不变。详见服务、[SDK](./capability-sdk.md)、交付。

E3-R03新增 **私有主窗口IPC** `shared-apps:service-models()`、`service-references(applicationId)`、`issue-reference(applicationId,kind,value)`、`revoke-reference(applicationId,referenceId)`、`service-task(applicationId,entry,taskId,action)`；preload对应serviceModels/serviceReferences/issueReference/revokeReference/serviceTask，返回AuthReply。kind为text/model，action为approve/reconcile；账户来自登录owner，路径/凭据/身份不接受输入。approve必须再次可信确认，reconcile只查原任务；业务窗口/iframe没有这些管理方法。它们不是公开App SDK或REST。可信AppTextService内部generate新增可选第五参数authorize，实际转发前调用；SDK接口不变。references0.5.0的list(scope)是可信Node枚举。见服务手册、引用手册和交付。

E3第二十三批新增包模块0.12.0的HostServicePackageManifest（host-service-v1；files为空，能力声明无source），格式1/schema保持，旧格式兼容；CLI0.10.0沿用inspect/sign/publish/install命令。references0.3.0新增createCapabilities({text,model})返回可信{declaration,execute}描述器，registerCapabilities保持。dev-host0.14.0的prepareInstalledHost(rootDirectory,config,broker,runtime,services=[])/InstalledHostService与startDevelopmentHost可选installedServices、taskQuery、confirmationToken只接可信Node参数，不读应用/包JSON。服务必须匹配签名计划的完整声明和精确绑定；query前后复核授权/当前信任/绑定。确认沿用原消费Bearer和独立X-Fixture-Confirmation路由；prepare只查看副作用计划、不执行。详见服务手册、包手册及交付。没有新增SDK/IPC或生产认证。

E3第二十二批新增可信references0.2.0的ModelProvider、ModelQuery、issueModelProvider(scope,provider,id?)和queryModel(scope,request,signal?)，以及dev-host0.13.0/services的createModelTaskQuery(references):TaskQuery。详见服务手册、引用与确认及交付证据。低层查询不替代任务授权和输出校验；缺失/撤销/不可用时抛脱敏错误，保留unknown且不重跑。新增便携service-host.mjs仅供可信Node宿主，不新增SDK/HTTP/IPC。

第二十一批生态项目创建新增公开开发工具命令`node sitoo-project.mjs create <new-directory>`；用法与模板契约。这是项目生成CLI，不是SDK、HTTP/IPC、安装或授权接口。

E3第二十批业务契约与证据：design/validate-plan包内接口1见手册，不是新增平台HTTP/SDK/IPC；返回快照策略结果，不授予生图权限。

维护日期：2026-10-09。对应当前源码；App SDK 0.0.9，原能力/任务契约 1；新增独立 capability-protocol 0.1.0、wire 版本 1，分别版本化。本文描述现有接口，不代表已发布公共 REST API。

SDK 正式包名为 `@sitoo/sdk`，原 `@pi-market/sdk` 为历史名称。迁移须更新依赖与导入后重新安装；接口语义、协议及能力契约保持不变，详见开发者手册和 SDK 更新记录。

## 1. 接口边界与入口

E2-04 新增 capability-packages 0.4.0 的 CapabilityPackageLease、LEASE_LIMITS，以及 CapabilityInstallationStore.acquireLease/getLease/activeLeases/releaseLease/loadLease/leaseInventory；安装 schema 1→2 原地迁移，任务 schema 1 不变。capability-runtime 0.2.0 新增异步 checkSource；capability-tasks 0.3.0 构造新增可选 packageLeases:TaskPackageLeases；capability-dev-host 0.3.0 新增 InstalledDevelopmentHostConfig version 2，startDevelopmentHost/serve 和参考 HTTP 路由不变。CLI 新增 lease-*。均为可信 Node 开发辅助接口，不是 REST/IPC/浏览器契约。参数、租约保护/释放、编译限额、失败与回退见执行与租约参考。

E2-03 新增 capability-packages 当前 0.8.0 的 CapabilityInstallationStore(path,root)：prepare(requestId,roots,references,releases,trust,now?)、commit(requestId,releases,trust,now?)、status(requestId)、pending()、abort(requestId)、load(trust,now?)、inventory()、close()；新增 CapabilityInstallationRoot、CapabilityReleaseReference、CapabilityInstallationTransaction、INSTALLATION_LIMITS。同步方法返回 ProtocolValidation（close 除外），可信宿主根身份和整库统计不可直接暴露给应用；CLI 新增 install-prepare/commit/status/pending/abort/load/inventory。仅离线原子安装、查询/恢复及共享代码/独立根引用，不授予权限或执行源码，非 REST/IPC/浏览器接口。参数、限额、原请求幂等、失效/撤销与失败语义见安装参考。

E2-02 在独立包模块新增 signCapabilityPackage(pkg,privateKey,metadata)、CapabilityPackageTrust(keys).verify(pkg,attestation,now?)、CapabilityReleaseStore(path) 的 publish/get/close，以及 PackageSigningMetadata、PackageAttestation、TrustedPackageKey、TrustedCapabilityPackage、SIGNATURE_LIMITS。CLI 新增 sign/verify-signed/publish/fetch。均为可信 Node 辅助入口，没有 HTTP/IPC/浏览器接口；当前是离线精确分发，不是生产认证或应用安装。签名格式、来源/环境/有效期/撤销、存储身份、上限、参数和失败语义见署名与发布参考。

E2-01 新增 private Node 模块 `@sitoo/capability-packages@0.8.0`：verifyCapabilityPackage(manifestJson,files)、异步 readCapabilityPackage(directory)、resolveCapabilityDependencies(roots,catalog)，返回 ProtocolValidation 的内容快照或精确计划；PackageRequirement、CapabilityPackageManifest、PackageCapability、VerifiedCapabilityPackage、CapabilityDependencyPlan、PACKAGE_LIMITS 为当前导出。可搬运 CLI inspect/plan 仅校验/规划，不是浏览器 SDK、REST、安装器或签名认证。格式、参数、预算、失败与兼容见能力包参考。

E1-05 新增 `@sitoo/capability-dev-host@0.3.0` 的可信开发辅助接口 `startDevelopmentHost({configPath,dataDirectory}):Promise<{url,close():Promise<void>}>`、DevelopmentHostConfig，以及工具包 init/serve 和参考任务 GET/POST/cancel 传输。HTTP 只绑定开发消费凭据，不接受 policy；仅 loopback、拒绝 Origin/外部 Host、请求体 64 KiB、连接 32、header/request timeout 5000ms。返回 ProtocolValidation，身份/错误/持久任务规则沿用独立模块；详细路由、状态码与构造字段见开发工具包手册。这是本机参考传输，不是正式公共 REST/IPC，不接生产认证、真实收费或 Desktop。0.2.0 新增 init-fixtures/plan/confirm、POST /v1/tasks/:taskId/reconcile 与 GET/POST /v1/confirmations/:taskId；确认路由另需 X-Fixture-Confirmation，POST 仅 {revision}，仅启用本地模拟服务。详见确认与引用参考。

E1-01 新增 `@sitoo/capability-protocol` 工作区模块：parseCapabilityRequest、parseCapabilityResponse、parseCapabilityTaskReference、createCapabilityError，以及固定结构 schema、状态/错误/上限常量和公开类型。`/host` 仅含可信上下文类型，公共入口不接受调用者身份。参数与预算见协议参考。模块仅结构校验，无 HTTP/IPC 路由或浏览器 SDK 接入，未发布公共 npm；可信代理与受限执行由下述模块承担，生产认证仍待接入。

E1-02 的 `@sitoo/capability-broker` 当前为 0.2.0：CapabilityBroker 的 register、createSession、revokeSession、invoke；声明/绑定/政策/执行器/诊断类型与注册错误。0.1.1 新增可选 `{signal?:AbortSignal}`，原方式兼容；0.1.2 新增 getCaller、prepare、validateResult 三个可信同步校验端口，不执行能力。方法、失败分支与限制见代理参考。这是宿主管理接口，不向第三方浏览器暴露，不提供登录、签名或跨进程 token 认证。

E1-03 新增 `@sitoo/capability-runtime@0.2.0`：CapabilityRuntime 构造选项、createExecutor({source,sourceSha256})、activeRuns、DEFAULT_RUNTIME_LIMITS，以及 RuntimeLimits/RuntimeEvent。每次 Worker/QuickJS VM 只接业务 JSON，Guest 的异步 invoke 继续由代理授权；CPU/总时限、allocator/并发/桥限额和取消清理已实现。字段、默认预算、状态、错误及 RESULT_UNKNOWN 语义见执行器参考。没有新的 REST/IPC 或浏览器调用方法。

E1-04 新增 `@sitoo/capability-tasks@0.3.0`：CapabilityTasks({path,broker,query?,maxTasks?,allowEffects?})、broker 属性、submit/get/list/cancel/reconcile/close；DurableTask、TaskQuery，以及 LegacyTaskViews({broker,readers,map}) 的 get/list 和 LegacyTaskView/LegacyTaskReaders/LegacyScopeMap 类型。同步操作返回 ProtocolValidation，reconcile 和旧视图异步返回；构造/存储失败可抛出。SQLite 单宿主先持久化再执行，原 ID 去重，重启 unknown 不自动重跑；query-only 恢复及旧收费任务只读映射默认不开放收费执行；显式 allowEffects 先持久化 needs-approval。新增 getConfirmation(session,id)、approve(session,id,revision) 和 TaskQuery 第三参数 {request,caller}。范围、参数、状态、预算与失败语义见任务参考，非公共 REST/IPC/浏览器方法，尚未接产品。

E1 收口新增可信 `@sitoo/capability-references@0.1.0`：CapabilityReferences 的 issueText(scope,text,referenceId?)、issueModel(scope,infer,referenceId?)、revoke(id)、registerCapabilities(broker,{text,model})，注册 platform/read-text 与 platform/infer。引用为 UUID、按四维身份隔离、1024 个生命周期 ID、文本 32 KiB。Broker 0.2.0 新增 issueApproval(session,request,ttlMs?)、CapabilityApproval 和 execution options.approval；prepare 增加 {inspectEffects?} 与返回 effects，validateResult 不执行副作用。宿主方法不暴露给 Guest/浏览器 SDK，参数/失败/预算见确认与引用参考。

认证服务返回 HTTP 429 时，Desktop IPC 错误码为 RATE_LIMITED；错误信息区分限流与会话失效，有有效 Retry-After 时显示保守等待秒数，不自动重试。登录失败的 signed-out 事件保留 message，账户已连接时的限流不会作为 401 自动退出。New API 身份认证、刷新、OAuth 和凭据读取可能共享按 IP 的关键操作限流，外部身份页面登录成功不代表所有网关步骤已完成。

分组凭据已创建但读取失败时，后续主动重试复用尚未过期的记录，只重新读取凭据，不反复删除和新建。会话结束仍清理该记录；服务器实际限流策略由 New API 管理。

| 类型             | 入口                                                 | 调用方与状态                                                           |
| ---------------- | ---------------------------------------------------- | ---------------------------------------------------------------------- |
| App SDK          | @sitoo/sdk、/host、/mcp                              | 应用声明与可信服务端；详见 [开发者手册](./sdk-guide.md) |
| Desktop IPC      | window.piMarket                                      | 当前 Desktop 主窗口 renderer；不向第三方应用直接开放完整桥             |
| 应用 MCP         | POST http://127.0.0.1:<动态端口>/mcp                 | 平台绑定的可信 MCP 客户端，账户 token 鉴权                             |
| 生图私有 HTTP 桥 | POST http://127.0.0.1:<动态端口>/tool                | Runtime 扩展，不是公开生图 API                                         |
| 模型私有代理     | POST http://127.0.0.1:<动态端口>/v1/chat/completions | Runtime，真实模型凭据留在 Desktop                                      |
| 更新测试服务器   | GET/HEAD latest.yml、安装包、packages/catalog.json   | 本地验收用下载服务，不是专业应用发布管理 API                           |

`server/` 当前仅占位。登录、账单、模型调度使用外部 New API；其 /api 与 /v1 接口不是本仓库实现。没有现成的 /api/apps/install、资源包安装或 spkg REST 接口，不应据设计文档调用这些路径。

## 2. Desktop 约定

权威定义：preload.ts，执行处理：main.ts。DesktopApi 类型通过 `typeof desktopApi` 导出；返回数据类型以该文件引用的实际类型为准。

JS 调用形式为 `await window.piMarket.<模块>.<方法>(参数)`，不是 HTTP。下表省略 Promise：除事件订阅和 applications.images 外，方法均异步。? 表示可选参数；字符串方法名和大小写不能修改。

底层 IPC 响应为 `{ok:true,value:T}` 或 `{ok:false,error:{code,message}}`。preload 返回 value，失败保留 error.code。应用 apps:* 错误额外包含 retryable/action，preload 抛 AppSdkError，转发到隔离浏览器客户端时保留安全分类信息；不转发堆栈与原始宿主路径。不要解析中文错误文字作为稳定协议。void 成功可能是 undefined。

主进程只允许当前 mainWindow 的主 frame 调用，其他发送方返回 FORBIDDEN。此处保护可信 Desktop，不能当作第三方应用的身份沙盒。账户要求和参数校验由具体处理器执行。用户取消系统目录选择时部分接口正常返回 undefined，不是异常。

## 3. 应用与配置 API

| 方法                       | 参数                                                                                            | 返回                                    |
| -------------------------- | ----------------------------------------------------------------------------------------------- | --------------------------------------- |
| applications.list          | 无                                                                                              | RegisteredApp[]                         |
| applications.tasks         | appId:string                                                                                    | AppTask[]                               |
| applications.task          | appId:string,id:string                                                                          | AppTask                                 |
| applications.configuration | appId:string                                                                                    | AppConfigState                          |
| applications.configure     | `appId:string,revision:number,values:Record<string,unknown>,credentials?:Record<string,string>` | AppConfigState                          |
| applications.images        | appId:string                                                                                    | AppImages（同步绑定对象，内部方法异步） |

applications.images 的 getCapabilities、generate(request)、getTask(id)、listTasks、getArtifact(id) 分别返回 SitooImageCapabilities、SitooImageTask、SitooImageTask、SitooImageTask[]、`{mimeType:'image/png',dataUrl:string}`。需要应用声明 sitoo_image:generate；账户切换后旧绑定失效。当前可信窗口可传 appId，这不是不可信 UI 能自报身份的第三方授权方案。

静态应用新增以下受控桥。完整 window.piMarket 仅可信主窗口可用；应用 iframe 只能使用 SDK /ui 的窄接口，身份由主进程签发的随机会话绑定，不能自报 appId。

应用 iframe 使用 sandbox 的 allow-scripts、allow-forms、allow-downloads；不开放同源宿主访问、Node 或 preload。allow-downloads 用于下载 SDK 返回的作品副本，不授予任意本机文件读写权限。独立应用的生图审批由共享能力初始化审批服务，无需先打开对话页面。

Desktop 每秒检查已加载独立应用的页面进程。进程消失且对应 iframe 仍存在时，内部事件 `apps:ui-process-gone` 发送 `{token}`；可信主窗口通过 `applications.onUiProcessGone(listener)` 订阅，返回取消订阅函数。正常关闭 iframe 不提示故障。市场显示恢复入口，用户点击仅重新挂载同一会话的 iframe，不重发执行或模型请求；已保存草稿与宿主 Agent 会话保留，页面内未保存输入不保证恢复。该事件不是 App SDK 公共事件，不开放给第三方应用。

原生崩溃报告仅保存到当前用户数据目录的 Crashpad 目录，`uploadToServer:false`，不上传。`logs/process.log` 记录进程退出分类和退出码，以及独立页面进程消失；不记录输入文本、应用会话 token 或凭据。检测到进程消失不能单独证明输入法、显卡或内存是故障原因。

每个 iframe 会话的桥最多执行 4 个请求，另允许 32 个请求按先后顺序等待；正常批量初始化不会仅因同时读取六项状态而失败。等待队列满时返回 BUSY；页面关闭丢弃尚未执行的请求，已执行操作不会自动重试或撤销。此限制与文本生成任务的每账户并发上限分别生效。

SDK 0.0.5 文本任务新增安全 errorCode、stopReason、maxTokens，失败可返回收到的 text/usage；仅 completed 且结构通过才有 value。模型记录可声明 outputTokenLimit/outputLimitSource；当前目录仅有 32768 平台预算，实际模型限制由上游校验。maxTokens 范围 128–32768，默认 8192；不会自动续写或重试，旧任务不补造结束原因。

图片自动保存兼容 CDN 的 application/octet-stream 或缺失 Content-Type：核验 PNG/JPEG/WebP 文件签名后仍须经宿主真实解码，保持下载大小、像素及输出大小限制，不接受 HTML/SVG 伪装。已生成任务仅重试下载与保存，不重新生图；保存提示区分安全的 HTTP、类型及解码错误。

| 方法                              | 参数                                  | 返回及边界                                                                                                                                             |
| --------------------------------- | ------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| applications.market               | 无                                    | AppMarketState，签名目录、当前账户安装项、离线 warning                                                                                                 |
| applications.install              | id,digest,permissions:string[]        | InstalledApplication；重新核验市场摘要与用户确认的权限，再原子激活                                                                                     |
| applications.uninstall            | id                                    | void；阻止活跃任务，撤销会话，保留数据                                                                                                                 |
| applications.rollback             | id                                    | InstalledApplication；只切回上一已校验缓存包，无数据迁移                                                                                               |
| applications.open                 | id                                    | {token,url}；仅已安装应用，可撤销的账户绑定会话                                                                                                        |
| applications.close                | token                                 | void；关闭桥，不取消上游任务                                                                                                                           |
| applications.invoke               | token,capability,parameters,requestId | 绑定能力结果；schema 与身份校验，付费请求冻结参数并沿用幂等 ID                                                                                         |
| applications.imageOperation       | token,operation,taskId?               | operation 为 image-capabilities/image-tasks/image-task/image-artifact；只有生图权限可调用，仅本应用任务                                                |
| applications.platformCapabilities | token                                 | AppPlatformCapabilities；已安装包绑定的身份、SDK 版本、实际支持能力和配额                                                                              |
| applications.storage              | token,operation,input                 | AppDataRecord/null 或 AppDataPage；storage-get 接收 id，storage-list 接收分页对象，storage-put 接收 AppDataWrite，storage-delete 接收 id/revision 对象 |
| applications.resources            | token,packId?,resourceId?             | 本应用随包资源声明，或已校验文本和 snapshot；无任意文件路径访问                                                                                        |
| applications.sessionConfiguration | token,revision?,values?               | AppConfigState；本应用普通配置，revision 防陈旧覆盖，无凭据写入                                                                                        |
| applications.importDevelopment    | 无                                    | DevelopmentPackagePreview或undefined；只选取和校验文件，尚未安装；正式客户端禁止                                                                       |
| applications.installDevelopment   | token,permissions:string[]            | InstalledApplication；五分钟、账户绑定的一次性确认，权限须与已选择文件一致                                                                             |

明确 @ 命令仍走 workbench.send；已安装静态应用可以帮助和明确调用，自然语言 MCP 接入尚需通用应用路由。Host 的 approve/executeApproved 不暴露给第三方 UI。

服务器新增 GET/HEAD apps/metadata/{root,targets,snapshot,timestamp}.json、版本 root 元数据和 apps/targets/{catalog.json,sha256.spkg} 的固定安全路径。服务仅托管文件，不持有私钥。部署配置 appRepository.url/trustedRoot 由维护方提供，客户端禁止从远程自动建立初始信任。

AppTask 字段及状态、AppConfigState、参数转换、凭据和审批见 [SDK 手册](./sdk-guide.md)。配置使用当前 revision 保存；credentials 省略保留、空字符串删除，响应只返回凭据是否配置。不能把密钥写入普通 values。

```ts
const api = window.piMarket;
const state = await api.applications.configuration('sitoo.materials');
await api.applications.configure(state.appId, state.revision, {
  ...state.values,
  prefix: '项目A_',
});
const tasks = await api.applications.tasks('sitoo.materials');
```

此示例在已登录 Desktop renderer 使用，不在普通浏览器/Node 使用。遇到并发配置错误先刷新，禁止静默覆盖。

## 4. 图像与作品 API

| 方法                 | 参数                                  | 返回                                        |
| -------------------- | ------------------------------------- | ------------------------------------------- |
| images.configuration | 无                                    | SitooImageConfiguration                     |
| images.configure     | value:SitooImageConfiguration         | SitooImageConfiguration                     |
| images.capabilities  | 无                                    | SitooImageCapabilities                      |
| images.models        | group?:string                         | {groups:{id,description}[],models:string[]} |
| images.generate      | request:SitooImageRequest             | SitooImageTask                              |
| images.tasks         | 无                                    | SitooImageTask[]                            |
| images.task          | id:string                             | SitooImageTask                              |
| images.artifact      | id:string                             | {mimeType:'image/png',dataUrl:string}       |
| works.configuration  | 无                                    | WorksConfiguration                          |
| works.pickDirectory  | revision:number                       | WorksConfiguration                          |
| works.list           | 无                                    | WorkItem[]                                  |
| works.pending        | 无                                    | SitooImageTask[]                            |
| works.preview        | id:string,full?:boolean（默认 false） | string（图像预览数据）                      |
| works.reveal         | id:string                             | void                                        |

SitooImageRequest：prompt 必填，可选 aspectRatio、resolution（1K/2K/4K）、references:string[]。数量/比例等实际能力先查询 capabilities；模型、分组和凭据通过平台配置，不放在 generate 参数中。generate 会审批、提交并返回任务，不承诺立即得到图片，也不能当作免费试用。

images.tasks 当前合并 desktop/chat 来源、按创建时间降序、最多 50 条；不是所有应用的全局任务列表。应用来源用 applications.images(appId)。images.artifact 的 id 当前是任务 ID，具体实现核对任务归属后读取产物，不传作品文件路径。

生成成功不等于保存成功。未知结果先查询原任务，禁止自动重提付费操作。无取消上游接口。作品只登记成功保存产物，失败任务不作为作品。

works.list 除当前账户内部索引外，会从已配置保存目录的 `图片/` 恢复本产品生成的 `.png.json` 元数据：校验文件类型、尺寸、PNG 标识、摘要和时间后补建索引。使用目录中实际文件位置，不信任元数据中的绝对路径；损坏、摘要不匹配或链接文件不导入。不扫描未配置目录，不搬迁或改写原图片。用户主动选择已有作品目录时，该目录中有效作品可在当前账户中重新展示。

WorksConfiguration 为 revision/directory。WorkItem 含 id/kind/filename/prompt/generatedAt/savedAt/model/group/referenceCount/caller/bytes/sha256，可选 resolution/aspectRatio/width/height/gatewayTaskId，见 works.ts。保存位置改变只影响后续保存，不自动搬迁旧作品；pickDirectory 由系统选择器授权。

## 5. 资料应用领域 API

| 方法              | 参数                                                                          | 返回                            |
| ----------------- | ----------------------------------------------------------------------------- | ------------------------------- |
| materials.list    | 无                                                                            | MaterialsRun[]                  |
| materials.create  | rules:MaterialsRules                                                          | MaterialsRun或undefined（取消） |
| materials.get     | id:string                                                                     | MaterialsRun                    |
| materials.scan    | id:string                                                                     | MaterialsRun                    |
| materials.update  | id:string,revision:number,rules?:MaterialsRules,edits?:{id,target,included}[] | MaterialsRun                    |
| materials.cancel  | id:string                                                                     | MaterialsRun                    |
| materials.preview | id:string,file:string                                                         | string                          |
| materials.deliver | id:string,revision:number                                                     | MaterialsRun或undefined（取消） |
| materials.open    | id:string                                                                     | void                            |

create 不接受目录路径，使用系统选择器。deliver 选输出目录并显示真实确认，再由主进程签票执行；不是无交互交付。scan 为异步任务，get 查询真实状态。领域 status 为 draft/scanning/review/delivering/completed/failed/cancelled，与通用 AppTask 分开。

MaterialsRules 必填 title（1–80）、groupBy（type/original）、deduplicate:boolean、prefix（<=40，字母数字下划线连字符）、requiredExtensions:string[]（最多20，格式如 .pdf）。更新 edits 最多500，revision 必须最新。MaterialsRun/MaterialsFile 完整字段见 service.ts；预览、交付与打开均经过业务权限检查。

## 6. 对话工作台 API

| 方法                         | 参数                                                                            | 返回                 |
| ---------------------------- | ------------------------------------------------------------------------------- | -------------------- |
| workbench.getState           | 无                                                                              | WorkbenchState       |
| workbench.newSession         | 无                                                                              | void                 |
| workbench.openSession        | id:string                                                                       | void                 |
| workbench.updateSession      | id:string,action:rename/archive/unarchive/delete,name?:string                   | void                 |
| workbench.send               | text:string,images?:WorkbenchImage[],application?:{appId,command,hasExtraInput} | void                 |
| workbench.resend             | id:string,text?:string,images?:WorkbenchImage[]                                 | void                 |
| workbench.abort              | 无                                                                              | void                 |
| workbench.selectModel        | id:string                                                                       | void                 |
| workbench.setReasoningEffort | effort:ReasoningEffort                                                          | void                 |
| workbench.setApprovalMode    | mode:manual/auto/full                                                           | void                 |
| workbench.answerDialog       | id:string,response:{cancelled?,confirmed?,value?}                               | void                 |
| workbench.selectProject      | 无                                                                              | void                 |
| workbench.projectChanges     | 无                                                                              | ProjectReview        |
| workbench.projectDiff        | filename:string                                                                 | ProjectDiff          |
| workbench.runTest            | command:string                                                                  | void                 |
| workbench.onEvent            | listener:(WorkbenchEvent)=>void                                                 | 取消订阅函数（同步） |

send/resend/runTest 的 void 表示请求已交给处理器，不表示模型回复、测试或外部任务完成。用 getState/onEvent 查看实际状态。runTest 会执行命令，不能拿任意字符串作无副作用示例。忙碌/待审批时切换模式受限制。abort 不保证上游付费任务取消。

应用明确命令示例：

```ts
await window.piMarket.workbench.send('', undefined, {
  appId: 'sitoo.materials',
  command: 'help',
  hasExtraInput: false,
});
const unsubscribe = window.piMarket.workbench.onEvent((event) => console.log(event));
// 组件卸载时调用 unsubscribe()，避免重复事件处理。
```

事件和消息类型以 workbench-types.ts 的实际联合类型为准，按 type 分支处理，不将原始事件日志直接作为用户交付内容。

## 7. Runtime 设置与扩展市场

| 方法                            | 参数                                    | 返回               |
| ------------------------------- | --------------------------------------- | ------------------ |
| capabilities.getState           | 无                                      | CapabilityState    |
| capabilities.update             | key:CapabilityKey,enabled:boolean       | CapabilityState    |
| capabilities.apply              | 无                                      | CapabilityState    |
| capabilities.configure          | configuration:RuntimeConfiguration      | CapabilityState    |
| capabilities.mcpAuthentication  | action:login/logout/cancel,name?:string | void               |
| capabilities.pickPath           | kind:shell/skill/prompt                 | string或undefined  |
| packages.getState/refresh/apply | 无                                      | PackageMarketState |
| packages.install/remove         | id:string                               | PackageMarketState |
| packages.setEnabled             | id:string,enabled:boolean               | PackageMarketState |

packages 是 Pi Runtime 扩展市场，不是专业应用 spkg 安装 API。配置保存与实际应用状态分别检查；apply 可能重连运行时，不能把保存成功等同当前会话已启用。类型见 capability-settings.ts、package-market.ts。

## 8. 账户、模型、更新与桌面

| 方法                                    | 参数                                         | 返回                                                                               |
| --------------------------------------- | -------------------------------------------- | ---------------------------------------------------------------------------------- |
| auth.getState/login/logout/refresh      | 无                                           | AuthState                                                                          |
| auth.credentials                        | 无                                           | ModelCredentialSummary[]：group,name,status,expiresAt；无密钥                      |
| auth.connectCredentials                 | groups:string[]                              | void；1–100 个不重复分组，空字符串表示默认通道；已有有效凭据直接复用，其余批量获取 |
| auth.clearCredentials                   | groups:string[]                              | void；只清除本地副本并保留清除标记，取消所选分组请求，不撤销服务端令牌             |
| auth.checkConnection                    | 无                                           | void                                                                               |
| auth.onChange                           | listener:(AuthState)=>void                   | 取消订阅函数                                                                       |
| platform.list                           | 无                                           | PlatformGroup[]                                                                    |
| platform.update                         | group:string,enabled:boolean,models:string[] | void                                                                               |
| providers.list                          | 无                                           | ProviderInfo[]                                                                     |
| providers.login                         | id:string,method:oauth/api_key               | void                                                                               |
| providers.answer                        | id:string,value:string                       | void                                                                               |
| providers.cancel/openBrowser            | 无                                           | void                                                                               |
| providers.remove                        | id:string                                    | void                                                                               |
| providers.addCustom                     | input:CustomProviderInput                    | void                                                                               |
| providers.onEvent                       | listener:(ProviderAuthEvent)=>void           | 取消订阅函数                                                                       |
| updates.getState/check/download/install | 无                                           | UpdateState                                                                        |
| updates.onChange                        | listener:(UpdateState)=>void                 | 取消订阅函数                                                                       |
| desktop.getConfiguration                | 无                                           | desktopConfiguration                                                               |
| desktop.downloadImage                   | source:string                                | boolean                                                                            |
| desktop.showMenu                        | name:string,x:number,y:number                | void                                                                               |
| desktop.setTitleTheme                   | theme:string                                 | void                                                                               |
| desktop.onCommand                       | listener:(string)=>void                      | 取消订阅函数                                                                       |

平台凭据与登录会话分别管理。login 只完成身份认证，不读取模型 Key；refresh 只更新账户。logout 不撤销用户令牌，本地加密副本保留。connectCredentials 优先复用账户已有令牌，必要时创建长期有效、受账户余额约束的令牌；不修改已有令牌配置。凭据查询仅在主窗口可用，第三方应用没有访问权限，不属于 App SDK 公共契约。

凭据状态为 saved/pending/cleared/invalid/expired；saved 仅表示本地已保存，不证明实时网关可用。expiresAt=-1 表示无自动过期。首次缺失可按需获取，cleared/invalid/expired 必须明确 connectCredentials；清除后不会自动下载回来。模型网关 HTTP 401 将对应凭据标记 invalid，保留账户登录且不自动重放；429、网络错误、5xx、额度/权限类失败不删除密钥。批量创建结果不确定时返回 CREDENTIAL_PENDING，先核对 New API；确认后可清除本地标记并重新连接。存储异常 CREDENTIAL_STORAGE_FAILED 不降级为明文。官方批量接口 /api/token/batch/keys 是第三方 New API 接口，本仓库不新增公共 HTTP 服务。

AuthState 为 signed-out/signing-in/authenticated，authenticated 含 AccountSummary，不返回登录 token。providers 受编译版本限制，平台版不能靠调用 API 开启扩展版权限。updates.install 会进入实际更新流程，不作示例调用。

事件订阅立即返回解除函数，React effect 清理时调用。账户/更新数据详见 auth-types.ts、update-types.ts，Provider 类型见 provider-types.ts。

## 9. 应用 MCP HTTP 协议

资料服务来自 host.ts，动态 loopback 地址与 token 由平台 getBinding 获取，不固定端口或给普通网页暴露。`Authorization: Bearer <token>`，Content-Type: application/json，客户端按官方 Streamable HTTP 协商 Accept，调用 initialize 后再 list/call 工具。

当前是无服务端 session ID 的 Streamable HTTP，POST /mcp；不存在专用 GET /tasks REST。未认证/账户不匹配 401；路径/Host/Origin 不符 403；认证通过但非 POST 405；传输内部失败可能 500。拒绝带 Origin 的浏览器请求，不能直接从网页 fetch。

通用工具 get_capabilities({id?})、invoke_capability({id,parameters})；parameters 序列化长度上限10000。调用示例（初始化后的官方 MCP client）：

```ts
await client.callTool({ name: 'get_capabilities', arguments: { id: 'scan' } });
await client.callTool({
  name: 'invoke_capability',
  arguments: { id: 'scan', parameters: { task: existingTaskId } },
});
```

资料领域工具：

| 工具             | 参数                                | 行为                                   |
| ---------------- | ----------------------------------- | -------------------------------------- |
| list_tasks       | {}                                  | 当前账户任务摘要，最多30               |
| get_task         | id:UUID,offset?:整数>=0,limit?:1–30 | 默认 offset=0/limit=20，返回文件分页   |
| scan_task        | id:UUID                             | 异步扫描已授权目录                     |
| update_plan      | id,revision:正整数,rules?,edits?    | 修改方案，最多500 edits                |
| request_delivery | id,revision                         | 返回 requiresUserApproval，不批准/执行 |
| cancel_task      | id                                  | 请求停止，保留原文件和已有输出         |

MCP 调用结果 content 包含 text，通用 invoke 还有 structuredContent；工具错误查看 isError，不能只判断 HTTP 200。HTTP 错误与业务工具错误不是同一层。MCP 不提供创建目录授权或签票工具。

## 10. 私有 Runtime HTTP 桥

这些接口只记录给平台维护者排查，第三方应用使用 SDK 能力，不依赖动态 token 或桥实现。

生图 /tool：动态地址、账户 Bearer token、准确 Host、拒绝 Origin；仅 POST，正文最多800 KiB。操作为 capabilities、generate（requestId:string，<=300；request:SitooImageRequest）、status（id:string）。requestId 用于原任务幂等，不为同一逻辑动作随意更换。

成功200返回能力或任务对象；鉴权失败401；方法/路径/Host/Origin 不合规403；超限413；解析/业务调用失败400，正文 `{error:消息}`。wait 是 Runtime 扩展对 status 的等待逻辑，不是该 HTTP 桥的 operation。

模型代理：Bearer 代理会话 token（不同于持久化的 New API Key）、无 Origin、只 POST；路径 /v1/chat/completions 或 /v1/desktop-newapi-<24位小写hex>/chat/completions。正文上限16 MiB，转发上游流式响应；它不是任意 URL 代理。完整错误行为见 model-proxy.ts，生图见 sitoo-image-host.ts。

## 11. 本地更新与目录下载

serve-desktop-updates.mjs 只用于本地更新验收，默认 loopback 18680（可指定）。无认证，不作为生产发布管理后端。

| 路径                                                 | 方法     | 响应                                           |
| ---------------------------------------------------- | -------- | ---------------------------------------------- |
| /latest.yml                                          | GET/HEAD | electron-updater 版本清单                      |
| /Pi-Market[-Extended]-x.y.z-x64-setup.exe[.blockmap] | GET/HEAD | 允许名称的文件，支持单个 bytes=start-end Range |
| /packages/catalog.json                               | GET/HEAD | Runtime 扩展目录，文件缺失404                  |
| /__stats                                             | GET      | 验收下载统计，非生产监控 API                   |

未知文件404、不支持方法405、非法Range416；目录与清单 no-store，安装文件缓存一小时。没有 POST 上传、审核或专业应用目录接口。目录部署配置见 扩展市场 与 更新配置。

## 12. 版本、维护与验证

### 浏览器 SDK 0.0.3 与宿主私有桥

应用公开接口为 `createAppClient()`，详见[浏览器 SDK](./browser-sdk.md)。platform.getCapabilities、storage.get/list/put/delete、images.listTasks 均已接入；文本推理已开放，详见浏览器参考中的文本任务章节。内部查询 IPC 为 apps:text-operation(token,operation,id?)，operation 为 text-models/text-task/text-tasks；生成经 apps:invoke 调用 text.generate binding，不是公共 REST 路由。内部对应 IPC `apps:platform-capabilities(token)` 和 `apps:storage(token,operation,input)`，token 由主进程创建并绑定当前账户、已安装应用与包摘要，应用不能自行传入 appId 或 scope。浏览器只传数据，可信父页面持有 token 并调用私有 IPC。

存储输入使用 JSON；get 输入 id，list 输入 cursor/limit，put 输入 id/revision/version/value，delete 输入 id/revision。revision 乐观并发检查、原子保存、删除墓碑及配额在宿主执行。单写 16 KiB、单应用单账户 8 MiB/1000 记录、分页最多 100；卸载保留，普通业务存储不加密，不接受路径或凭据槽位。

浏览器错误为 AppSdkError(code,message,retryable,action)，消息不暴露原始路径/堆栈；TIMEOUT 表示提交结果可能未知，不能自动重提付费请求。Account 变化或关闭会话后拒绝调用；已提交的写入须重开查询确认。没有新增公开 HTTP API。

SDK API 按 SDK/契约版本管理；Desktop IPC 和私有桥目前是同客户端内部契约，不承诺不同客户端版本间稳定。未来公共 HTTP API 实现后增加独立版本、OpenAPI/schema、认证、限流与兼容策略，当前不生成虚构 OpenAPI。

公开方法/路由/参数/鉴权/状态改变时，同批更新本手册；API 原因引发 SDK 变化还须同步 SDK 手册和 CHANGELOG。维护入口见根 AGENTS。新接口说明权限、返回时机、取消、幂等、副作用和失败，不把网络200写成任务完成。

文档验证核对源码入口、方法清单、链接及示例；行为变更运行相关 SDK、桌面、MCP 和桥测试。不要为验证手册实际发送付费生图、执行任意 shell 或发起更新安装。本次文档编写不是所有接口端到端验收。

升级/卸载遇到实际平台调用、running 文本任务或未结束的生图任务时返回 APP_TASKS_ACTIVE。无 gatewayTaskId 的 unknown 生图记录不再永久阻止卸载或升级；仍保留历史记录和配置/作品，不表示远程任务被取消或未计费。有上游 ID 的 unknown 任务仍受保护，须先核对终态。

### 图片附件与多模态绑定（SDK 0.0.6）

公开浏览器方法是 attachments.importImages() / get(id)，返回 AppAttachment[] / AppAttachment。内部 IPC 为 apps:attachment-operation(token,operation,id?)，operation 为 attachment-import / attachment-get；可信父页面持会话 token，应用不得自行指定 appId/scope/path。导入打开宿主选择器，取消返回 []；PNG/JPEG/WebP 原图 <=12 MiB、<=2400 万像素，标准化 PNG 副本 <=1 MiB、最长边 <=1024，必要时 <=512。每次最多 8 张、每应用每账户 200 张。账户切换后复验会话，拒绝跨账户返回。文件不加密、卸载保留，无公开删除 API。

text.generate / sitoImage.generate 绑定新增可选 attachments: AppImageReference[]，每项 id 和 description（最多 500 字符）必填，最多 8。能力 schema 须声明字段。宿主读取附件，文本经 Pi 发送像素与说明；生图将附件转为 references 并按附件顺序追加说明。生图引用总数 <=8，编码参数上限 12 MiB；Runtime 生图私有 /tool 仍限 800 KiB，不供应用传输附件。上传不调用模型，不开放任意路径或第三方上传 HTTP 路由；费用和审批沿用实际生成能力。平台对视觉支持没有可靠目录标记，不自动改用其他模型。

## 应用 Agent 会话（SDK 0.0.7）

公开浏览器入口为 `createAppClient().agent`，通过隔离 iframe 的 `sitoo-app-v1` 协议调用宿主，不是 REST API。应用须声明 `text:generate`，先检查 `platform.getCapabilities().features.agentConversations`。模型 ID 使用 `text.listModels()` 返回的 ID。

| 方法                        | 参数                                                                                        | 返回                               |
| --------------------------- | ------------------------------------------------------------------------------------------- | ---------------------------------- |
| `agent.open(configuration)` | `{model, instructions, reasoningEffort?}`；强度自 0.0.8 起可选，instructions 最多 8000 字符 | `AppAgentState`                    |
| `agent.getState()`          | 无                                                                                          | 当前会话快照                       |
| `agent.send(input)`         | `{requestId, text, context?, attachments?}`                                                 | 接受消息后的快照，不保证回复已完成 |
| `agent.stop()`              | 无                                                                                          | 停止当前文本回复后的快照           |
| `agent.reset()`             | 无；只能在空闲时调用                                                                        | 新会话快照，旧历史保留在 Pi        |

状态为 `closed/ready/running/error`，含 sessionId、messages 和可选 error。消息只含 id、role（user/assistant）、text、可选 error/stopped，不暴露 Pi 路径、模型密钥或原始 RPC。运行时可以串行查询快照获得增量文本；没有新增公共推送事件。text 最多 8000 字符，context 最多 16000 字符（含宿主补充的参考图说明），attachments 最多 8 张，使用现有账户/应用隔离附件 ID。

参考图发送前，Desktop 使用与 Pi 模型配置一致的输入能力：优先使用平台显式声明的 `input`，缺省时查询当前 Pi 分发版的离线模型目录；未知模型默认只支持文本。该检查发生在模型请求之前，不通过模型名称猜测图片支持，也不自动重发被拒绝的消息。

每个账户每个应用有独立官方 Pi 会话，打开时恢复最近会话。修改模型或 instructions 会重连并恢复历史；运行中拒绝修改。会话不加载文件、命令、MCP、生图、第三方扩展、资源包或上下文文件工具，自动重试关闭。对话可能产生文本模型费用；SDK 不执行表单回填或生图，这两者由应用明确的用户操作触发。

requestId 须为 UUID；同一 ID 与请求内容、会话配置、包摘要绑定。宿主在提交前记录 ID，重复请求只查询当前状态，内容变化返回 REQUEST_CONFLICT；跨 reset 重用 ID 也不会重新发送。中断或不确定结果不会自动重放，可能出现只有请求记录而没有回复的情况，应查询原会话。注销/切换账户撤销桥接并停止进程。并发启动最多 4 个应用会话；目前没有公开会话列表、删除或闲置回收接口。

内部 Desktop IPC 为 `applications.agentOperation(token, operation, input?)` / `apps:agent-operation`，operation 对应 agent-open/state/send/stop/reset。token 由宿主发放并绑定账户、应用和包摘要；应用不能指定 caller 或账户。这个 IPC 不向第三方应用开放，应用使用上面的 SDK 方法。

## 应用输入附件与语音（SDK 0.0.8）

公开方法 `attachments.uploadImages(images: AppImageUpload[])` 返回 `AppAttachment[]`，要求可选能力 `features.attachmentUpload`。每批 1..8 项，name 长度 1..200，dataUrl 仅 PNG base64；每张解码 <=1 MiB、最长边 <=1024，宿主重新解码编码，沿用每应用每账户 200 张配额和账户复验。无公开删除或第三方上传 API。内部 `apps:attachment-operation(token,operation,id?,images?)` 新增 `attachment-upload`；可信 iframe 桥该请求编码上限 12,000,000 字符。

`agent.open` 新增可选 reasoningEffort（off/minimal/low/medium/high/xhigh/max），以实际返回的 reasoningLevels 为准；状态可含 reasoningEffort、reasoningLevels、contextUsage `{tokens:number|null,contextWindow:number}`。改变强度保留会话，未知枚举拒绝为 INVALID_DATA，实际 Pi 校验模型支持。无新增执行工具。

| 公开浏览器方法               | 输入 | 返回                |
| ---------------------------- | ---- | ------------------- |
| `agent.dictation.getState()` | 无   | `AppDictationState` |
| `agent.dictation.start()`    | 无   | 新语音状态          |
| `agent.dictation.stop()`     | 无   | 停止后的文字及状态  |

`AppDictationState` 是 `{status:'idle'|'starting'|'running'|'ended',text,error?}`，文字最多 8000 字符。先检查可选 `features.agentDictation`。桥方法为 agent-dictation-state/start/stop，由可信父页面处理，前后通过内部 agent-state 复验 token 与 text:generate 权限；不新增主进程 dictation IPC、公共 REST 路由或推送事件。每个打开应用只允许一个语音会话，最多两分钟，离开市场或关闭应用自动取消。识别结果不自动发送；宿主使用 Web Speech，iframe 不获得麦克风或执行权限。系统识别失败应显示错误，不重试发送。

## 独立开发页面与任务桥（宿主 0.7.0）

新增无令牌固定 GET `/development`、`/development/client.mjs`，只提供可信容器与脚本，不返回配置；页面通过原 GET /v1/application 加载签名资源，在不透明 iframe 使用实验性 `window.sitooDevelopmentTasks.submit(request)/get(taskId)/cancel(taskId)/list()`，返回 Promise 的原 ProtocolValidation 任务结果。v3 消费路由允许精确宿主 Origin；有 Origin 的任务请求必须有有效 `X-Sitoo-Application` 清单摘要，有摘要的调用始终复核当前完整应用计划和授权。null/外部 Origin、外部 Host 拒绝，旧无 Origin CLI 兼容。完整加载/消息/预算/错误与关闭规则见页面手册，真实浏览器证据见E3 第二批。不是 app-sdk 或 Desktop 公共方法，不提供生产登录、权限自批或直接网络。

## 独立开发应用资源读取（0.6.0 引入，0.7.0 保留）

新增开发 HTTP `GET /v1/application`：无参数，现有 bearer 身份，仅 v3 持久授权 application 入口读取自己的已安装静态应用。200 响应 `{ok:true,value:{applicationId,packageId,version,sha256,entry,files:[{path,bytes,sha256,source}]}}`；源文件为 UTF-8 JSON 数据。401 未认证，403 入口/授权/安装/信任不满足，503 宿主异常；不匹配的查询/方法为 404。每次复核完整计划、签名内容与授权快照；无消费者切换参数、CORS 或页面执行权限。完整约束以应用手册为权威，证据见E3 第一批。SDK、Desktop IPC 和产品 static-platform/spkg 不变。

## 独立安装生命周期（可信 Node，0.5.0）

`CapabilityInstallationStore.prepareUpdate(requestId, roots, references, releases, trust, now?)` 与 `prepareUninstall(requestId)` 返回 `ProtocolValidation<CapabilityInstallationTransaction>`；原 `commit(requestId, releases, trust, now?)` 同时提交更新。`commitUninstall(requestId)` 提交卸载。`collectUnused()` 返回 `ProtocolValidation<{ removed: number; retained: number }>`，是显式全库管理操作。原事务查询、abort 和 pending 共用请求空间。根代数防竞争与 ABA；active 租约阻止更新/卸载；schema 1/2→3 保留原记录。接口不提供应用权限、HTTP 或 SDK 方法，不执行用户数据迁移；实际契约及命令见生命周期手册，验证见E2-05 第一批。

## 更新权限预检（可信 Node，0.6.0）

`CapabilityUpdatePolicy` 严格包含 entry/grants。`CapabilityInstallationStore.reviewUpdate(requestId, policy, releases, trust, now?)` 返回 `ProtocolValidation<CapabilityUpdateReview>`（requestId/generation/plan/policy/required/added/removed/missing/unsupportedEntries/reviewSha256）；`commitAuthorizedUpdate(requestId, policy, reviewSha256, releases, trust, now?)` 返回 `ProtocolValidation<CapabilityInstallationTransaction>`，同一写事务重查原策略指纹、信任、根代数和租约。缺少授权或入口不匹配为 FORBIDDEN，指纹或代数冲突为 CONFLICT；原 commit 仍保持存储兼容，预检不写配置或创建执行授权。CLI 新增 update-review / update-commit-authorized，非公共 HTTP/IPC/浏览器 SDK。参数、预算和职责见预检手册，实际验证见第二批证据。

## 独立 JSON 数据迁移（可信 Node，0.7.0）

`CapabilityDataMigrationStore(path, root)`：initialize(dataVersion,value)、read()、write(expectedRevision,expectedDataVersion,value)、prepare(requestId,expectedRevision,targetVersion,value)、status(requestId)、pending()、commit(requestId)、abort(requestId)、rollback(requestId)、close()。close 除外返回 ProtocolValidation；读写返回 CapabilityDataSnapshot（dataVersion/revision/value），迁移返回 CapabilityDataMigration（requestId/status/before/after），pending 返回本根数组。DATA_MIGRATION_LIMITS 限制全库根/记录和版本/修订上限。data-* CLI 使用独立数据 SQLite schema 1，不接 SDK Storage/HTTP/IPC、不自动转换现有产品数据。参数、预算、身份及安全回退见手册，验证见第三批证据。

## 独立持久授权管理（E2-05 第四批）

capability-packages 0.8.0 新增可信 Node `CapabilityAuthorizationStore(path,root,entry)`、`read/status/set/close`，授权策略/状态/收据与 AUTHORIZATION_LIMITS；开发宿主 0.4.0 新增 AuthorizedDevelopmentHostConfig v3/authorizationPath。参数、CAS、精确 bindings、错误、预算、CLI 与兼容边界以授权手册为权威，证据见第四批记录。不是新增消费 HTTP 管理 API、浏览器 SDK 或 Desktop IPC；既有任务路由不新增，v3 的 POST /v1/tasks 在授权修订失效时返回 403/FORBIDDEN，原身份查询保留，不执行原任务。

## 独立业务健康检查（E2-05 第五批）

开发宿主/工具包 0.5.0 新增可信 Node `checkInstalledCapabilities({configPath,casesPath,dataDirectory})`，返回 `Promise<ProtocolValidation<CapabilityHealthReport>>`；新增 CapabilityHealthCase/Check/Report 与 HEALTH_CHECK_LIMITS，以及 health CLI。仅 v2/v3 已安装开发配置，独立 health-tasks.sqlite 与报告文件；不是消费 HTTP、SDK 或 Desktop IPC。输入、结果/错误、预算、去重/中断恢复与范围以健康手册为权威，证据见第五批记录。

## 独立应用发布物（E2，包模块/工具 0.9.0）

可信 Node 包模块新增 StaticApplicationPackageManifest/InstallablePackageManifest，`VerifiedCapabilityPackage.manifest` 扩展为能力/应用联合类型；verifyCapabilityPackage/readCapabilityPackage、署名发布、解析、安装与租约方法签名不变。新增 execution=static-application-v1 与 application={applicationId,entry}，capabilities 必须为空；应用只能为唯一安装根，身份绑定且不能成为依赖。范围与约束以应用发布物手册为权威，证据见本批交付。这是开发存储契约，不新增页面服务、HTTP、SDK 或 Desktop IPC；已有 static-platform/spkg 不变，旧工具拒绝新类型。

## 独立开发对话规划（宿主 0.8.0）

内部 loopback 开发 HTTP，非 SDK 或生产 API。`GET /v1/conversation/tools` 发现原能力声明，`POST /v1/conversation/plan` 接受 `{requestId,text}` 返回 `{request,binding,planSha256}` 提案；仅已安装 v3 conversation 持久授权身份、无收费/写入能力，模型无执行或批准权。标准任务提交可附 `X-Sitoo-Conversation` 完整计划摘要，读体后复核。原任务查询、请求去重和租约不变；同安装两入口可查询原任务。无/未知 bearer 401，授权或旧计划 403，非法输入 400，模型未启用/异常/五秒超时 503；禁止外部或 null Origin；0.9.0 浏览器对话约束见下方。

真实契约见对话手册，验证与限制见第三批交付。

## 开发浏览器对话（宿主 0.9.0）

固定 GET `/development/conversation` 和 `/development/conversation.mjs` 返回可信界面/脚本，无令牌、no-store、CSP frame-ancestors none。v3 精确同源 Origin 开放工具/规划路由；身份仍由独立 bearer 绑定。application 浏览器任务保留原摘要，conversation POST /v1/tasks 必须带 X-Sitoo-Conversation 并读体后复核，service 浏览器任务拒绝。conversation 原任务 GET/list 无需当前计划摘要，撤权/卸载只关闭新执行；未知 bearer 401，外部/null Origin 或错误摘要 403，无 CORS。配置、任务 wire 和 SDK 契约不变。

权威对话手册 · 第四批验收。

## 开发模型与手动提案（宿主 0.10.0）

内部 loopback 开发 HTTP。新增 `POST /v1/conversation/prepare` 接收标准 protocolVersion 1 能力请求，原 schema 校验后返回 `{request,binding,planSha256}`，不调用模型/创建任务。仅当前 v3 conversation 授权身份；精确同源 Origin，非 conversation 或失效授权 403、非法 schema 400。无 Origin CLI 兼容，执行与原请求去重仍走 /v1/tasks。

可信 Node 新增 `createLoopbackConversationPlanner` 与可选 `conversationPlanningTimeoutMs`（整数 5000–30000，默认 5000）；serve-conversation-model 使用 30000。传输失败、无工具提案、超预算或超时统一规划 503，无自动重试。模型凭据不是消费 API 参数，不返回上游错误正文。配置与成本边界见权威对话手册，第五批证据；不是 SDK 公共方法或生产网关。

## 公开能力 SDK 与 Desktop 开发入口（0.0.9）

`@sitoo/sdk/capabilities` 导出 createCapabilityClient(AppCapabilityTransport)，方法 submit(CapabilityRequest)、get/cancel(taskId)、list() 和 dispose()；异步返回原 ProtocolValidation 任务/列表，不生成 ID、不自动重试/确认。原请求 JSON 快照、32并发、10秒等待；未确认提交 RESULT_UNKNOWN，查询/取消未确认 UNAVAILABLE；dispose 仅终止客户端等待。原 /ui 与产品 IPC 没有新增任务方法。

Desktop 参数 `--capability-development-url=<loopback-origin>` 仅未打包且精确本机地址，开发窗口不加载产品 preload/IPC。完整真实契约见[SDK 手册](./capability-sdk.md)，第六批记录。

## 产品账户共享安装状态（私有 IPC）

Desktop 0.0.10 的 piMarket.sharedApplications.inspect() 对应 shared-apps:inspect，无参数；只允许产品窗口主 frame，额外参数 INVALID_INPUT，未登录 LOGIN_REQUIRED，异步期间账户撤销 SESSION_CHANGED，配置/签名/数据库错误 SHARED_INSTALLATIONS_UNAVAILABLE。返回 {environment:'development', applications:[{applicationId,packageId,version,sha256,dependencies:[{packageId,version,sha256}],entries:[{entry:'application'|'conversation',status:'active'|'revoked'|'missing'|'stale',revision?}]}]}。无应用 SDK/HTTP 公共入口、安装、权限管理或执行。当前账户和实路径/信任/完整计划每次复核；缺账户为空，部分配置失败。手册与证据见[SDK/Desktop 接入](./capability-sdk.md)及第七批交付。

能力包 0.10.0 的 CapabilityInstallationStore(path,root,{readOnly:true}) 与 CapabilityAuthorizationStore(path,root,entry,{readOnly:true}) 使用 SQLite 只读连接，分别要求既有 schema 3/1；不创建或迁移，写方法 FORBIDDEN。默认构造器保持旧行为；详见安装手册和授权手册。

此新增私有 preload 方法返回原 AuthReply 数据：成功 {ok:true,value:SharedInstallationState}，失败 {ok:false,error:{code,message}}。不跨 contextBridge 抛出附带 code 的 Error，以免错误码被 Electron 序列化丢弃；消费页面应检查 ok。原有 IPC 方法不变。

## 产品共享应用管理（私有 IPC，Desktop 0.0.11）

见[产品接入手册](./capability-sdk.md)和第八批交付。均要求产品主窗口/主 frame；管理只在未打包 Desktop，账户身份和文件目录不从调用者接收。preload 方法均返回 AuthReply，原 inspect 不变。

| 私有方法                                         | IPC 与参数                                                                              | 成功 value                                                                   |
| ------------------------------------------------ | --------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| catalog()                                        | shared-apps:catalog，无参数                                                             | {enabled,configured,applications:[{applicationId,packageId,version,sha256}]} |
| prepareInstall(packageId,version,sha256)         | shared-apps:prepare-install，3 参数                                                     | SharedApplicationReview                                                      |
| prepareAuthorization(applicationId,entry,revoke) | shared-apps:prepare-authorization，entry 为 application/conversation，revoke 为 boolean | SharedApplicationReview                                                      |
| confirm(token)                                   | shared-apps:confirm，仅 token                                                           | {requestId,status} 原操作收据                                                |
| discard(token)                                   | shared-apps:discard，仅 token                                                           | void，无持久副作用                                                           |
| abort(applicationId,requestId)                   | shared-apps:abort，2 参数                                                               | {requestId,status:aborted}；committed 为 CONFLICT                            |
| status(applicationId,requestId,entry?)           | shared-apps:status，第三参数 undefined 为安装，入口为授权                               | {requestId,status} 原持久收据；授权无记录为 not-found                        |

SharedApplicationReview 为 {token,requestId,operation:'install'|'authorize'|'revoke',applicationId,version,packages:[{packageId,version,sha256}],permissions:string[],entry?}。5 分钟/最多 32 个、账户撤销代数与信任摘要绑定。confirm 重验完整计划和授权 CAS，原请求复用；不接受任意授权。INVALID_INPUT/FORBIDDEN/CONFLICT/SESSION_CHANGED/SHARED_MANAGEMENT_UNAVAILABLE 及底层协议 UNAVAILABLE 等均为安全结构化码。目录缺整个账户时未配置，缺文件/签名异常整次失败。未开放任务执行、模型、生产 HTTP 或公开 App SDK 管理 API。

能力包 0.11.0 增加 CapabilityReleaseStore(path,{readOnly:true})，schema 1 现有库，只读 get，publish FORBIDDEN；默认构造保持兼容。证据见第八批。

### 产品共享业务页面私有入口（Desktop 0.0.12）

第九批交付 · [SDK/Desktop 手册](./capability-sdk.md)。可信产品主 frame 的 `piMarket.sharedApplications.open(applicationId)` / `shared-apps:open` 仅接收一个应用编号，返回 `AuthReply<{opened:true}>`。可信账户身份由 DesktopAuth 提供，需 application 持久授权与当前签名安装；正式包 FORBIDDEN，未登录 LOGIN_REQUIRED，账户切换 SESSION_CHANGED，无权限 FORBIDDEN，运行失败 SHARED_RUNTIME_UNAVAILABLE。没有公开 HTTP、App SDK 或应用管理权限扩展。

启动原独立开发宿主的 v3 任务/应用读取协议保持不变，业务调用经原不透明 iframe 和浏览器 SDK。关闭页面保留原任务；账户退出停止所属宿主但不删账本/unknown pin。开发令牌、路径与身份不经该 IPC 返回。

开发宿主 0.11.0 兼容增量：已安装 application 浏览器 GET 原任务/列表用启动时精确页面摘要与原身份 scope 只读，不要求当前执行授权；提交/取消及页面读取仍复核当前授权，错误摘要/Origin/跨 scope 拒绝。参见页面手册与第九批。

### 产品对话工具私有入口（Desktop 0.0.13）

第十批交付 · [SDK/Desktop 手册](./capability-sdk.md)。可信产品主 frame 的 piMarket.sharedApplications.openConversation(applicationId) / shared-apps:open-conversation 只接收一个应用编号，返回 AuthReply<{opened:true}>；DesktopAuth 提供当前账户，要求 conversation 持久授权和当前签名安装。错误沿用 LOGIN_REQUIRED、SESSION_CHANGED、FORBIDDEN、INVALID_INPUT、CONFLICT、SHARED_RUNTIME_UNAVAILABLE；正式包拒绝。不接收身份、路径、令牌、grants 或 bindings，不返回宿主 URL。业务 frame 无该管理桥。

页面与对话复用同应用宿主/原任务，分别校验入口授权；预览不派发，明确提交走原任务契约。跨应用、跨账户仍隔离。宿主 0.11.0、App SDK 0.0.9 和公开 HTTP/数据库契约不变；自然语言与 Pi 通用工具未接入。

### Pi 共享工具私有适配（Desktop 0.0.14）

第十一批交付 · [SDK/Desktop 手册](./capability-sdk.md)。可信主进程的本机私有桥向官方 Pi 产品扩展提供当前账户的 applications/tools/prepare/submit/tasks/get；模型只看到 sitoo_shared 的 applications/tools/execute/tasks/get。execute 先用原 conversation prepare 校验，再通过官方 extension_ui confirm 请求桌面明确确认，然后凭一次性提案提交原任务。原请求编号由 Pi 会话/工具调用编号稳定派生，提案绑定账户、应用和计划摘要，120 秒有效且只消费一次；确认不会绕过当前授权校验。

URL/随机桥令牌只传给可信 Pi 进程，不向 renderer、业务 frame 或模型工具结果返回。Origin/错误 bearer、身份与路径注入、过期/已消费提案、账户切换拒绝。退出账户撤销桥令牌与提案，关闭所属共享宿主。get/tasks 只查询原应用 scope，不恢复执行授权。提交响应未确认返回原 requestId/unknown，禁止自动重新提交。此桥不是公开 HTTP 或 App SDK，不修改原 SDK/任务 schema；正式包不启用。

### 共享应用生命周期私有 IPC（Desktop 0.0.15）

第十二批交付 · [SDK/Desktop 手册](./capability-sdk.md)。仅可信主窗口 preload 的 piMarket.sharedApplications 新增四个方法；不是业务 frame、App SDK 或公开 HTTP。沿用 AuthReply 成功/安全错误结构，可信主进程派生登录账户、租户、development 根、存储与信任，不接受调用者注入这些字段。

| 方法             | 严格参数                   | 成功 value                                                                                         |
| ---------------- | -------------------------- | -------------------------------------------------------------------------------------------------- |
| pending          | 无                         | 当前账户 prepared 原事务列表，每项 applicationId/requestId/operation（install/update/uninstall）   |
| prepareUpdate    | packageId, version, sha256 | SharedApplicationReview：原 requestId、短期 token、精确版本/依赖、operation=update、permissions=[] |
| prepareUninstall | applicationId              | 同一 review，operation=uninstall，原完整计划，permissions=[]                                       |
| prepareRecovery  | applicationId, requestId   | 同一 review，复用 prepared 原 requestId 与原 operation/plan                                        |

四个方法只读，不提交、不授予权限；确认仍调用既有 confirm(token)，查询/放弃原操作调用既有 status(applicationId,requestId)/abort(applicationId,requestId)，discard(token) 仅释放预览。确认安装/更新/卸载复用原 prepare/prepareUpdate/prepareUninstall 与 commit/commitUninstall；恢复直接提交原 prepared，无新事务。已完成原请求幂等返回原状态。LOGIN_REQUIRED、SESSION_CHANGED、FORBIDDEN、CONFLICT、INVALID_INPUT、LIMIT_EXCEEDED、UNAVAILABLE、SHARED_MANAGEMENT_UNAVAILABLE 等沿用安全错误；原代数/计划变化、租约 pin 或信任变化不绕过。pending 上限512，全库越界拒绝；不返回其他账户标识、路径、grants。

### 原任务历史私有 IPC 与可信只读库（E3 第十四批）

交付记录 · [SDK/Desktop 手册](./capability-sdk.md) · 任务手册。Desktop 0.0.16 新增可信主窗口私有 `shared-apps:history`；preload 方法 `piMarket.sharedApplications.history(applicationId,taskId?,offset=0)` 固定三个参数。applicationId 为原小写应用编号（1–128字符，首字符字母），taskId 可省略或原 ASCII 标识（1–128字符），offset 非负安全整数；不能额外注入账户/目录/token。成功 AuthReply.value 为 `{source:'live'|'stored',tasks:DurableTask[]}`，单查也返回数组，列表固定20条。错误为 LOGIN_REQUIRED、SESSION_CHANGED、INVALID_INPUT、FORBIDDEN、SHARED_HISTORY_UNAVAILABLE；正式包禁用，子 frame 无桥。可信登录账户派生原 scope；异步查询后重新复核账户代数。

活宿主通过原 GET /v1/tasks 或 /v1/tasks/:taskId 读取；否则只读原库，不恢复执行授权、不启动宿主、不更新状态/租约。撤权与卸载不删除原记录；不存在/外 scope 单查统一 FORBIDDEN。EXCLUSIVE 锁或损坏库安全失败，不用新库替代。

任务模块 0.4.0 新增可信 Node `CapabilityTaskViews({path,scope})`、`CapabilityTaskViewScope` 和 get/list/close；返回 ProtocolValidation，构造可能抛出。完整参数、分页50/1–100（产品适配为20）、schema与错误见任务手册。不是公开 REST、业务 SDK 或模型工具；原 CapabilityTasks、SDK 0.0.9、HTTP 与 schema 1 不变。

### Pi不可用与受限共享会话（Desktop 0.0.17）

第十五批证据 · [SDK/Desktop手册](./capability-sdk.md)。可信 Node PiWorkbench 的既有 conversationInstructions/sharedTool 组合允许加载产品所有的原共享工具扩展，官方CLI仅启用sitoo_shared，关闭内置文件/命令及通用审批扩展；仅可信宿主配置，无新增App SDK/HTTP/IPC字段。没有桥的应用会话维持无工具；普通工作台维持原审批兼容检查。

connect加载Pi资源失败返回既有PI_START_FAILED，并发布WorkbenchState.status=error及固定安全指引；异常退出清空对话，明确connect可重新打开原会话，不重新提交工具调用。内部PiRpcTransport在spawn错误/无效帧/退出时拒绝未完成请求，后续request立即PI_NOT_RUNNING；不输出stderr/路径/凭据。共享原任务不受Pi生命周期清理，不取消、不释放pin。第十五批完整1.1.0候选返回APPROVAL_INCOMPATIBLE；第十六批登记精确兼容后已通过完整审批，产品Pi仍固定1.0.0。

### 审批发行物精确兼容（E3第十六批）

交付记录 · [SDK/Desktop手册](./capability-sdk.md)。可信审批runtime.json新增compatiblePiVersions=["1.0.0","1.1.0"]，packages继续列精确扩展版本。内部prepareApproval先检查已验Pi、完整精确列表与唯一扩展版本39.0.3/0.5.2；非法组合返回APPROVAL_INCOMPATIBLE，不加载扩展或写新审批配置。旧单版本manifest仍按原version匹配，但未登记Pi拒绝。无新公开SDK、HTTP、IPC或账户字段。

stage-runtime构建审批包同样检查Pi与源扩展版本。此登记来自真实官方进程的完整模式及升级回退验收，不推断其他版本兼容，不改变共享任务、授权、确认、pin或数据库schema。产品Pi1.0.0不变。

## E3第十七批原任务恢复验证

未增加 SDK、HTTP 或 IPC。原 POST /v1/tasks/:id/reconcile 的查询失败保持原 unknown；已完成结果持久化后重复核对不重新执行。Desktop sharedApplications.history 仍只读；QuickJS 无原上游适配器时不能核对成成功。门禁与边界见第十七批交付。

## 开发宿主0.12.0父进程生命期

可信本机CLI的serve/serve-conversation-fixture新增可选第三参数 --parent-pipe；HTTP/SDK/IPC没有新增路由或字段。stdin EOF/错误触发原宿主close，正常close保存queued/running为unknown、保护pin保留并退出；若整进程强退未写回，原只读记录保持running/queued，显式重开原宿主恢复unknown；启动期间断开不输出ready。stdin数据无命令语义，默认独立serve不随stdin关闭而退出，serve-conversation-model未启用此参数。产品主进程以pipe启动并保持通道。验收见第十八批交付。

## E3第十九批CI编排边界

新增仓库命令capability:ci及固定可信脚本编排，不新增公共SDK/HTTP/IPC。报告是CI证据，不能作为业务执行授权、生产身份或自动安装批准；本地与托管运行区分，详见CI手册与第十九批交付。

## 开发任务操作者页面

宿主0.15.0提供GET /development/operator（HTML）和GET /development/operator.mjs（固定模块），沿用loopback精确Host、CSP/no-store与无跨域访问。v3同源确认路由接纳浏览器Origin，但仍须消费Bearer和独立X-Fixture-Confirmation，错误认证/跨身份/旧修订沿用原拒绝。应用/对话浏览器任务继续使用原摘要pin，无新SDK、生产REST或Desktop IPC。操作流程见服务手册，证据见第二十四批。

## 持久受控引用（E3-R01）

references0.4.0新增CapabilityReferenceStore(filename)、issue(scope,id,payload)、read(scope,id)、has(id)、revoke(scope,id)、close()；payload仅text快照或model Provider标识/正整数修订，scope四元组保持，签发revision1、撤销revision2墓碑，最多1024条，ID不可替换/复用。CapabilityReferences新增可选{store}构造参数和issuePersistentText、issuePersistentModel、bindPersistentModelProvider、revokePersistent。具体参数、返回值、错误与旧内存API兼容见引用手册；R01交付。这些都是可信Node端口，非App SDK/HTTP/Desktop IPC。service-host.mjs同步导出库类；现有Broker声明和确认协议保持。

## 持久原请求账本（E3-R02）

开发宿主0.17.0的可信Node子入口@sitoo/capability-dev-host/services及便携service-host.mjs新增ModelRequestLedger(filename)、reserve(identity)、read(scope,requestId)、complete(identity,result)、close()与createDurableModelProvider(options)。独立schema1保存四维owner、入口、原requestId、referenceId、Provider标识/修订、prompt及输入SHA256、精确binding和上游UUID；派发记录及首次完成结果不可替换。方法参数、预算、错误、查询与授权职责见服务手册，验证见R02交付。仅可信Node调用，不是App SDK、HTTP或Desktop IPC；现有任务确认与reconcile路由保持。

## E3-R05 结构化请求服务

SDK0.0.11静态应用包显式bindings值capabilities.text-request/image-request/call；旧值保持。详情见[SDK手册](./sdk-guide.md)与本轮记录。这些是公共包契约，不是新增Desktop IPC管理权限。

独立宿主services导出createRequestService、requestCapabilityDeclaration；声明platform/text-request或platform/image-request接口1、权限model:infer与resource:read、billable=true、externalWrite=false、无委托。输入为{referenceId,parameters}，引用须为本应用/安装/账户/环境的有效模型或图片配置引用；参数不接受模型配置、凭据、Base64图片或批准令牌。公开完整JSON Schema由requestCapabilityDeclaration(binding)生成，承接原文本prompt8000/instructions8000/maxTokens128–32768/responseSchema/附件ID和图片prompt8000/画幅/分辨率/HTTPS链接/附件ID/resourcePackId。其余字段拒绝；最终请求仍受64KiB协议预算和原生执行器校验。

账本schema1的prompt字段保存结构化参数JSON，32768字符上限，原短接口仍2000；原Provider和不可变关联不换绑。结果只{taskId}原生关联元数据；原任务result仍包含协议封套。`GET /v1/tasks/<id>/artifact`同时接受已完成platform/image-request及原platform/generate-image，当前resource:read、调用者、完整绑定和原账本结果须匹配；不会新生成。原生taskId不能跨应用读取。

createRequestService可信Node upstream端口复用原DurableModelUpstream；执行先持久reserve，query只查原关联。不向Guest、浏览器或普通SDK暴露函数/路径/bearer/确认端口。旧生产费用和原生按钮实际操作仍须单独验收，本轮无费用集成证据不代表生产通过。

SDK错误提示新增 `CANCELLED`（已取消，action=none）与 `RESULT_UNKNOWN`（查询原任务，action=query-task），不会暴露主进程原始异常。Desktop私有preload `applications.invokeReply(token,capability,parameters,requestId)` 返回原 `apps:invoke` 的脱敏 `AuthReply<unknown>`，供可信renderer桥保留错误码；原 `applications.invoke` 和业务页面 `client.invoke` 契约保持。该方法不是公共App SDK，也不向应用iframe暴露账户、管理或批准端口。
