# 项目与测试发布

返回文档目录 · 当前实现 · 身份与凭据 · API参考 · E4路线 · R02交付

开发者中心测试发布服务0.4.0，发布工具0.2.0，Node24、SDK0.0.11。本地服务须显式配置平台Ed25519签名私钥文件、keyId、受邀身份以及独立审核/发布职责。私钥由平台保管，不能放在项目、工具包、网页或凭据文件中；生产信任轮换和正式部署尚未支持。

先登录中心，在个人或组织范围申请命名空间，再创建应用或能力项目。填写包标识`your-team/application`、类型、名称、署名、许可与SDK版本。只能使用当前范围拥有的命名空间；个人与组织范围分开。项目及其版本列表不向其他组织泄露。

包复用`capability-package.json`目录格式：受限QuickJS函数或静态应用；不接收任意Node安装脚本、ZIP解压路径或新宿主服务实现。构建仍使用已发布开发工具。包内依赖必须能由当前范围已经签名发布的能力版本解析，静态应用不能成为依赖。包内兼容契约、文件路径、内容长度、摘要和精确绑定由既有公共验证器检查。

## 公开工具

从工具包获取独立的`sitoo-publish.mjs`，无需平台源码或node_modules。创建项目后在中心创建**项目发布凭据**：仅此项目、测试环境、查询/提交，有效7天，秘密只展示一次。原命名空间只读凭据不能用来提交；组织角色变化及显式撤销使发布凭据持久失效。

配置`publish.json`不存秘密：

```json
{ "origin": "http://127.0.0.1:18683", "tokenEnv": "SITOO_PUBLISH_TOKEN" }
```

```powershell
# 从安全凭据配置设置环境变量，不把秘密写进仓库或日志。
node tools/sitoo-publish.mjs prepare dist release-input.json
node tools/sitoo-publish.mjs submit dist <project-id> publish.json
node tools/sitoo-publish.mjs status - <project-id> publish.json
```

prepare只读校验目录，输出发布物JSON供中心上传；输出路径已存在则拒绝覆盖。submit先本地校验，再通过真实HTTP提交。命令成功退出0，失败退出1；只输出记录号、版本、摘要、状态/请求号，不回显令牌。origin只允许HTTPS或本地HTTP，拒绝重定向。同版本同摘要重试返回原记录，同版本异内容返回`VERSION_IMMUTABLE`；连接中断后先status查询，不盲目改版本补跑。

## 审核与发布

提交状态为pending。平台审核者核对声明、许可、权限、兼容性和内容摘要，写入批准或拒绝理由；提交者不能自审。批准后由另一身份的发布者显式签名测试发布，服务复核审核者/提交者当前权限、原摘要及依赖。审核者和发布者不能由同一身份完成同一发布。批准后提交者角色变化会使批准永久失效；重新授权不复活旧凭据。

拒绝/失效的旧记录保留；修正包后提高版本重新提交，不覆盖旧版本。发布内容和签名在同一SQLite事务提交，重启后只查询原发布，不形成半发布文件。测试Ed25519签名沿用现有公共格式与七天有效期；客户端仍须从可信宿主配置选择公钥，不能把包附带公钥当信任。

## 当前服务接口

会话接口继续使用HttpOnly Cookie、Origin和X-CSRF-token；Bearer工具路由单独验证项目/环境，不能用于成员管理、审核或发布批准。

| 方法     | 路径                                                  | 输入/结果                                                  |
| -------- | ----------------------------------------------------- | ---------------------------------------------------------- |
| GET/POST | `/v1/projects`                                        | 查询当前范围；创建{packageId,type,name,license,author,sdk} |
| GET/POST | `/v1/projects/:project/submissions`                   | 查询；提交{manifest,sources,sha256,attestation?}           |
| GET      | `/v1/projects/:project/publishing-credentials`        | 只读元数据，无秘密                                         |
| POST     | `/v1/projects/:project/publishing-credentials`        | 创建测试项目凭据，秘密只返回一次                           |
| DELETE   | `/v1/projects/:project/publishing-credentials/:id`    | 当前所有者/管理员或凭据创建者撤销                          |
| GET      | `/v1/submissions/:id/artifact`                        | 所有者或平台审核者只读检查内容，不执行                     |
| GET      | `/v1/review-queue`                                    | 仅平台reviewer，读取待审声明                               |
| GET      | `/v1/publication-queue`                               | 仅平台publisher，读取已批准记录                            |
| POST     | `/v1/submissions/:id/review`                          | {sha256,decision:approved或rejected,reason}                |
| POST     | `/v1/submissions/:id/publish`                         | {sha256}，返回{id,environment:test,attestation}            |
| GET/POST | `/v1/environments/test/projects/:project/submissions` | Bearer项目凭据，查询/提交                                  |

项目/提交成功分别201，其余成功200。400为无效包/摘要/依赖或不兼容；401为凭据失效；403为作用域/环境/职责越权；404不暴露其他组织项目；409为版本不可变、审核状态或批准冲突；413为请求超过2MiB；503为安全脱敏的服务故障。可选上传签名只按平台配置的publisherKeys核验，包不能自签发信任。实际发布私钥从不返回。

本说明描述真实本地测试契约；目录分发/安装、渠道生命周期、诊断反馈和外部开发者Beta验收由后续实现分别记录。

新增本地冻结CI、诊断与反馈及R04交付；原prepare/submit/status保持，0.2.0不在CI摘要回显审核理由。


# 本地发布CI、诊断与反馈

返回文档目录 · 当前状态 · 测试发布 · 目录安装 · API参考 · 本轮交付

适用：开发者中心0.4.0、发布工具0.2.0、Node24、npm lockfileVersion2/3。SDK0.0.11与Desktop0.0.32保持。仅本地/受邀测试；需要正常审核与签名，成功CI不等于版本已发布。

## 准备工程与凭据

从下载工具包解压`sitoo-publish.mjs`，不需要平台源码/node_modules。工程包含package.json、已提交的package-lock.json、test.mjs及build.mjs。build.mjs接受一个尚不存在的输出目录，输出现有公共capability-package.json与平铺源码；可使用公开共享工具的项目模板。测试和构建是你信任并主动运行的本地代码，先审查，再运行；服务端不执行上传脚本。不要在测试中调用收费服务来证明发布流程。

先在项目目录提交依赖锁文件；不要把生成锁文件放进CI。例为无第三方依赖的Node24工程：

```json
{"name":"my-core","version":"1.0.0","private":true,"type":"module"}
```

```powershell
# 只在首次准备依赖时运行，然后将package.json/package-lock.json纳入版本管理。
npm install --package-lock-only --ignore-scripts --offline --no-audit --no-fund
```

CI使用Node24同目录的npm；确保Node24完整安装包含npm。正式依赖工程用npm安装并提交完整锁文件；离线CI要求缓存就绪。test.mjs例（按自己的实际输入/输出补业务断言）：

```js
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
// 仅用于模板的纯文本函数：本地Node用例，不代替受限QuickJS宿主验收。
const source = await readFile(new URL('./src/main.guest', import.meta.url), 'utf8');
assert.deepEqual(new Function('input', source)({ text: ' hello ci ' }), { text: 'HELLO CI' });
```

在中心当前项目创建7天**项目发布凭据**，配置不含秘密：

```json
{"origin":"http://127.0.0.1:18683","tokenEnv":"SITOO_PUBLISH_TOKEN","offline":true}
```

秘密通过安全环境变量配置；不要写进源码、报告、截图或命令参数。HTTPS或本地HTTP可用，拒绝重定向。`offline:true`让npm仅取本地缓存；省略时按锁文件下载依赖。仅支持npm，其他锁文件不能代替。

## 运行与恢复

```powershell
node tools/sitoo-publish.mjs ci ./my-core <project-id> publish.json ./ci-001.json
node tools/sitoo-publish.mjs status - <project-id> publish.json
```

按install→test→build→validation→submission顺序执行：npm ci禁用安装脚本，测试/构建各60秒上限；每阶段复查package.json和package-lock.json原字节。发布秘密不传给这些子进程；工程脚本仍是开发者主动运行的可信本地代码。构建写入`.sitoo-ci/build-*/package`的新目录，失败不会执行后续提交。将`.sitoo-ci/`、报告及凭据配置加入忽略规则，按你的证据保留策略清理，工具不删除旧记录。

报告独占创建，已存在则在执行前拒绝；每次使用新报告名。报告JSON包含toolVersion、lockSha256、固定阶段状态/代码、HTTP请求号及已接受发布{id,project,version,sha256,state}；不记录子进程stdout/stderr、上传源码或凭据。

| 退出码 | 含义 | 处理 |
| --- | --- | --- |
| 0 | 测试、构建和服务接受提交 | pending等待独立审核/发布；原版本可能已有rejected状态 |
| 1 | 配置/Node/锁文件/报告路径错误 | Node24与同目录npm、已有锁文件、有效项目凭据及新报告路径 |
| 2 | npm冻结安装失败 | 检查声明与锁文件一致；离线时先准备缓存 |
| 3 | 测试失败或测试后锁文件变化 | 修复用例/恢复原锁文件，再重试 |
| 4 | 构建失败或构建后锁文件变化 | 核对build.mjs输出契约，修复后新报告重试 |
| 5 | 包校验失败 | 核对公共包格式、路径、长度与摘要 |
| 6 | HTTP提交失败或中断 | 先status查原记录，再按原字节/版本恢复 |

同版本同字节返回原发布号；修改内容使用新版本，不能替换已提交版本。HTTP超时可能发生在服务已提交之后，先查询而非盲目重建。审核拒绝后重复CI仍返回原rejected，不会自动晋级；修订新版本后仍需独立审核与发布。

## 请求与发布诊断

每次HTTP响应含`X-Request-Id`；错误JSON含`error.code/requestId`。在中心“诊断与反馈”选择当前可访问项目，用请求号或原发布号查询。成功提交关联原发布号，失败包校验可由请求号看到submission.validation与固定错误码；审核/发布看到对应阶段。诊断只含服务元数据，不含业务输入、包源码、URL、堆栈或用户审核理由。只保留最近20000条、每次最近100条；未可信鉴权或不能确定项目的错误没有项目诊断，保留响应中的请求号联系操作者。诊断写失败不撤销业务已提交状态，恢复仍查原发布。

## 反馈闭环

创建工单：标题、最小复现说明，任选该项目已有requestId/release。不要包含令牌、私钥、客户数据或完整业务请求；常见凭据/私钥会被拒绝，这不是对任意文本的全面敏感检测。

组织所有者/管理员开始处理，再填写答复；个人项目由所有者处理。工单创建者或管理者在answered后确认关闭。状态open→processing→answered→closed，允许open直接答复；关闭不重新开启。修改须带当前revision，冲突409时重新查询，不能覆盖他人的处理。项目访问与角色每次实时检查，审核者不能凭审核角色查看其他组织工单。

| 方法 | 路径 | 输入/结果 |
| --- | --- | --- |
| GET | `/v1/projects/:project/diagnostics?requestId=...&release=...` | requests[{id,at,release,stage,status,code}]；筛选项可省略 |
| GET/POST | `/v1/projects/:project/feedback` | tickets摘要；创建{title,description,requestId?,release?}，201 |
| GET | `/v1/projects/:project/feedback/:ticket` | 正文、当前revision和事件 |
| PATCH | `/v1/projects/:project/feedback/:ticket` | {revision,state,reply?}，answered必须提供答复 |

会话Cookie+Origin+X-CSRF-token沿用中心规范；项目CI凭据不能访问诊断、工单或管理接口。404隔离他组织/私有项目；403无处理权限；409修订/状态冲突；400含敏感内容或无效输入；401会话失效。页面显示原请求号，可据此联系支持。
